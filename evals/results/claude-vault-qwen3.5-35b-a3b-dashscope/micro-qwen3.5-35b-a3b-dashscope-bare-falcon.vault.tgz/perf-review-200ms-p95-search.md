---
id: 01a04e63-c18d-743d-a6f0-640ebd919586
name: Falcon perf review 2026-04
description: Performance review committed to 200ms p95 latency target on search endpoint (staging in eu-west-1)
---

## Summary
Perf review came back for Falcon. Team committing to **200ms p95 latency target** on the search endpoint.

## Environment
- **Stage**: Staging cluster
- **Region**: eu-west-1

## Date
2026-04-10