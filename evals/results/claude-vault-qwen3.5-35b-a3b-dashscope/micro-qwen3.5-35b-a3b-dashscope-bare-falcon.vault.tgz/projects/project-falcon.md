name: Project Falcon API Rewrite
description: Internal API rewrite project - Postgres 15, Friday afternoon deploys, Marco (billing) + User (gateway), $40k contractor budget

---

## Project Details

**Codename:** Falcon  
**Project Type:** Internal API rewrite  
**Start Date:** 2026-03-02  

### Technical Stack
- Database: PostgreSQL 16 (migration from v15 completed 2026-05-21)  
- Deployment schedule: Wednesday mornings (Friday deploys killed 2026-05-21 due to weekend incidents)  

### Team Assignments
- **Marco:** Billing service owner  
- **User:** Gateway owner  

### Budget
- Contractor budget: $40k for this half
