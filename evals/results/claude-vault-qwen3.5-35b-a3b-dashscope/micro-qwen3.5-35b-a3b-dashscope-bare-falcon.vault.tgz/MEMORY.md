# falcon — memory index

- [Billing service ownership change](billing-service-dana-owner.md) — Marco on parental leave, Dana taking over through end of year
- [Falcon perf review 2026-04](perf-review-200ms-p95-search.md) — Performance review committed to 200ms p95 latency target on search endpoint (staging in eu-west-1)
