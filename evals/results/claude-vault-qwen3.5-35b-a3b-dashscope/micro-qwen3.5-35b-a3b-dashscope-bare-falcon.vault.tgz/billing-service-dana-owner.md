---
id: 01a04e63-c596-71ad-a53c-36e18ee57421
name: Billing service ownership change
description: Marco on parental leave, Dana taking over through end of year
---

## Summary
Billing service ownership transferred due to Marco's parental leave.

## Details
- **Previous owner**: Marco (starting parental leave next week)
- **New owner**: Dana
- **Duration**: Through end of 2026

## Date
2026-04-10