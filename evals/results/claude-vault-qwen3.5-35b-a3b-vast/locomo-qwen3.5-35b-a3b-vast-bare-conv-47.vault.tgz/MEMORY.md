# conv-47 — memory index

- [james.md](james.md) — ⚠ no frontmatter
- [James's Hobbies and Interests](james-hobbies.md) — Personal hobbies, interests, and recent activities of James
- [john.md](john.md) — ⚠ no frontmatter
- [John's Hobbies and Interests](john-hobbies.md) — Personal hobbies, interests, and recent activities of John
- [project_ideas.md](project_ideas.md) — ⚠ no frontmatter
- [Shared Interests with John and James](shared-interests.md) — Common hobbies and activities between John and James
