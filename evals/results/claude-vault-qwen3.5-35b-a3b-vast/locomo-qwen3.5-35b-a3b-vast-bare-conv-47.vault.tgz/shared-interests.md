---
id: 01a0508f-3a06-7b6a-8721-27669142fef5
name: Shared Interests with John and James
description: Common hobbies and activities between John and James
---

# Shared Interests

## Gaming
- Both are passionate about video games
- Use gaming as a way to connect with each other
- Both attend gaming conventions
- John plays CS:GO competitively; James explores RPGs and strategy games

## Drums
- Both play drums (shared musical interest)
- Exchange encouragement and progress updates about their drumming

## Photography
- Both take photos of their drum kits
- Use photography to document their hobbies and experiences
- Share images with each other in conversations

## Goal-Setting
- Both value tracking progress and setting small goals
- Motivated by continuous improvement and learning

## Social Connection
- Use shared hobbies (gaming, drums) as bonding activities
- Support each other's achievements and new challenges

## Conversation Context
- Had a conversation on 12:40 am, March 27, 2022
- Discussing recent wins, new hobbies, and motivational strategies
- Long-time friends re-connecting

- Had a conversation on 9:52 am, April 12, 2022
- John shared his excitement about a new immersive RPG game
- James adopted a new dog named Ned from a Stamford shelter
- John recommended the game to James despite some technical issues
- Planning for James to try the game after receiving a link

- Had a conversation on 9:32 pm, April 20, 2022
- John shared excitement about meeting three new friends in programming course
- James shared about creating a Witcher 3-inspired virtual world project with a gaming pal
- Discussed travel plans: James has visited Italy, Turkey, and Mexico; John visited Japan
- Both enjoy the principle of resting well to work well
- Made plans to travel together next year
- John shared photos: a photo of a canyon he found in the surrounding area (river running through canyon surrounded by mountains)
- James shared a screenshot of the game character he created (woman in armor kneeling on a rock)

- Had a conversation on 2:36 pm, April 29, 2022
  - John discussed his freelance programming work - building a website for a local small business (first professional project outside of class), facing challenges with payment integration
  - Both discussed fantasy reading: John recommended "The Name of the Wind" by Patrick Rothfuss to James
  - James mentioned buying an adventure book with fantasy novels and art (late April 2022)
  - Gaming updates: James playing Civilization VI (strategy game, been playing for a month); John playing AC Valhalla
  - Board games discussion: John plays Uno with friends (multi-colored numbered cards, matching rules)
  - John recommended a game about finding impostors (Among Us) to James and advised gathering a large group to play

- Had a conversation on 7:01 pm, May 4, 2022
  - James shared about a frustrating bug in a game mechanics project that he couldn't solve alone, but a group of friends helped fix it
  - John shared about his day off, inviting new friends over to watch movies, emphasizing work-life balance
  - James shared photos of his pets: Daisy (a Labrador who loves toys and eating) and two shepherds
  - Discussed favorite pizzas: James prefers pepperoni (spicy salami and cheese), John prefers Hawaiian (pineapples and ham)
  - James also likes cheese pizza and prosciutto; John was curious about prosciutto

- Had a conversation on 7:33 pm, May 23, 2022
  - James shared about going to an amusement park with friends last weekend, riding roller coasters, Ferris wheel, electric cars and buggies; felt like being in a video game
  - James also shared about finishing a big project after months of work - learned a new language and handled many details; learned problem-solving, patience, and perseverance
  - John shared about taking second place in a local tournament last Friday, received money and a trophy; felt satisfied his effort paid off
  - Both congratulated each other on their achievements
- Had a conversation on 4:30 pm, June 13, 2022
  - John shared he got his dream job, starting July 2022
  - James shared he started a gaming/programming course and is building a football simulator with player databases
  - Discussed football teams: James is a Liverpool FC fan; John is a Manchester City FC fan
  - They watched Liverpool vs Chelsea match and made a bet about which team will finish higher in standings
  - John is passionate about Manchester City; James is passionate about Liverpool
- **June 16, 2022**: John and James had a conversation where:
  - John started a new coding blog, sharing his journey and tracking everything
  - James shared about his dog Max, who loves swimming, frisbee, and walks
  - They discussed Max's talents: catching frisbees mid-air, swimming at beaches/lakes, enjoying long walks on trails
  - John mentioned his love for sci-fi and fantasy books, especially "The Stormlight Archive" and "Kingkiller Chronicle"
  - Both discussed the importance of support systems during tough times
  - James mentioned Max brings him joy and helps him relax during difficult moments


- **June 19, 2022**: John and James had a conversation where:
  - James introduced his new pup Ned to his existing pets (Max, Daisy, and two shepherds)
  - The dogs are slowly adapting and bonding; James finds it sweet to watch them have fun together
  - John shared he's been thinking about his career and wanting to make a positive impact on the world
  - John is considering volunteering and non-profit work to use his passions for causes he cares about
  - James shared a photo from volunteering last month with an organization that provides necessary items to those less fortunate
  - John shared a photo of a young boy standing outside a yellow building and asked James to take him there
  - James offered to take John this weekend and introduce him to previous staff members
  - James noted no interview is required - just being friendly, polite, and having a desire to help people
  - Both expressed determination to make the world a better place

- **August 10, 2022 (9:16 am)**: John and James reconnected
    - John discussed his gaming passions and goals, thanking James for encouraging him to try new game genres
    - John shared he's been exploring strategy and RPG games instead of his usual shooters
    - John is already planning to make competitions for these new game genres
    - John revealed he's playing "The Witcher 3" - loves the storytelling, characters, and immersive experience
    - John mentioned being hooked on making the right choices to shape the world in the game
    - John shared a photo of his organized gaming room workspace with wall lighting
    - James shared about taking his three dogs to a beach outing to bond with other dog owners
    - James mentioned meeting a beautiful girl named Samantha at the beach
- James and Samantha are now dating (she agreed to be his girlfriend on September 4, 2022)
- James and John are planning to attend a baseball game together on Sunday, September 4, 2022
- James is interested in cooking (joined a $10/class cooking class in September 2022)
    - Samantha left her phone number with James
    - James plans to call Samantha to ask her out on a date
    - John encouraged James to call her and wished him well
    - Exchanged photos: James shared a photo of a man in armor with a sword; John shared his gaming room workspace photo


- **August 26, 2022 (9:18 pm)**: John and James reconnected
    - James shared a photo of Ned (his new dog) on a couch while gaming on his console
    - John had forgotten Ned's name initially but remembered after James reminded him
    - John shared he's been helping his younger siblings with a programming course
    - They're working on a text-based adventure game together to help them learn coding
    - John is proud of their progress and hopes they might create their own video games someday
    - James discussed his ambition to create a strategy game like Civilization
    - He appreciates how complicated and in-depth strategy games are
    - James expressed hope that he'll make his own strategy game someday
    - John mentioned his day off is tomorrow (August 27, 2022)
    - James shared a photo of his laptop with a colorful keyboard
    - Initially suggested meeting at Starbucks for coffee
    - John suggested having a beer instead
    - James proposed McGee's Pub, mentioning their great stout
    - John doesn't like dark beer
    - James noted they have light beers at McGee's
    - **Agreement:** Meet at McGee's Pub tomorrow (August 27, 2022) for light beer
    - Conversation ended with plans to see each other the next day

- **August 6, 2022 (1:45 pm)**: John and James reconnected after some time apart
   - John shared he left his IT job after 3 years to pursue something that makes a difference
   - John is now happy with his new job and passionate about the gaming industry
   - John wants to become a tournament organizer for computer games (CS:GO, Fortnite) in his state
   - James offered his support, financial assistance if needed, and advice
   - James shared that he took his puppy (Ned) to the clinic for a routine examination and vaccination
   - John expressed relief that the puppy is okay and appreciation for James's care of his pets
   - Both agreed to stay in touch and John mentioned he would reach out if he needs anything
- **September 18, 2022 (6:02 pm)**: John and James reconnected
  - John shared he started getting into board games
  - Tried "Dungeons of the Dragon" last week and found it very exciting and fun
  - James shared he started writing tasks in a notebook to avoid forgetting things
  - Discussed idea sources: James gets ideas from books, movies, and dreams
    - James had a vivid dream about a medieval castle with a labyrinth full of puzzles and traps that inspired creative ideas
    - James showed sketches and notes from his dream experience (including a drawing of a guitar)
  - Discussed music preferences:
    - Both like rock music
    - John used to play drums, James used to play guitar (both haven't played in a while)
    - John enjoys electronic music as well
    - John used drums as a way to let off steam
  - Discussed music sessions: John jammed with friends before (no recordings/videos, more about the experience)
  - James shared he started streaming games (no details yet, hoping it works out)
  - On September 20, received amazing community feedback that left him feeling stoked and inspired
  - John said he'll keep his fingers crossed for James's streaming success
- **September 1, 2022 (6:53 pm)**: John and James reconnected
    - James shared that he finally finished developing his own Unity strategy game after months of hard work and effort
    - The game was inspired by Civilization and Total War
    - James shared photos: a screenshot of a stone building with a giant creature, and a game screen showing a person on a horse
    - James faced challenges balancing mechanics and ensuring fairness, but persevered with trial and error
    - Key learnings: perseverance, patience, and the importance of feedback and collaboration
    - James emphasized that John's support and encouragement made a real difference
    - John mentioned he has been teaching his siblings coding - they're making basic games and stories, and he finds it inspiring and fulfilling
    - Both shared pride in seeing the next generation pick up coding and making games
    - John shared that he's going through some difficult times
    - James offered to be there for John as someone to talk to or vent to
    - Both reaffirmed the importance of their friendship and mutual support

- **October 31, 2022 (12:37 am)**: John organized a charity gaming tournament
     - John held a gaming tournament with his buddies
     - Games played: Fortnite, Overwatch, and Apex Legends
     - Raised a decent amount for a children's hospital
     - Combining gaming and a good cause felt awesome for everyone
     - John shared a photo from the tournament showing a game menu on a computer screen
     - Both friends celebrated the successful event

- **November 5, 2022**: 
      - James shared about going on a road trip with family and dogs - exploring new places and nature with his pets
      - James visited friends Josh and Mark during the road trip
      - They stopped at an animal sanctuary on the way, seeing many cute rescue dogs
      - James has three dogs at home and feels having more would be too much
      - Both shared their love of furry pals and discussed the joy dogs bring to life
      - John shared a photo of his cousin's dog, Luna
      - John shared he won the regional chess tournament on Tuesday (November 1, 2022) - felt proud and confident about all his hard work paying off
      - James congratulated John and asked about the strategies used
      - John explained his strategy: analyzing and anticipating opponent's moves to stay one step ahead
      - John shared tips for improving at chess: studying opening moves and strategies, learning from experienced players, analyzing past games
      - John mentioned James's earlier advice also helped him
      - John shared a photo of a book with a list of different chess openings as a helpful resource
      - James expressed interest in getting chess resources
      - John mentioned he's hooked on FIFA 23 - a football game with online multiplayer
      - James considering trying the sports genre with FIFA 23
      - Plan: James will practice with a gamepad and develop a sense of timing, then they can play FIFA 23 together

- **October 31, 2022 (12:37 am)**: James and Samantha moving in together
     - James and Samantha decided to move in together
     - Made a mutual and informed decision
     - Rented an apartment not far from McGee's bar
     - One of the criteria for choosing the apartment was having McGee's bar nearby
     - John and James discussed the decision and John expressed support
     - John mentioned they love spending time at McGee's bar

- **October 31, 2022 (12:37 am)**: James shared a family photo
     - James shared a photo of a man and two dogs running in a field
     - Sent as a casual update to John while saying goodbye
     - Showed James's love for his pets and outdoor activities