name: John
description: A video game fan who enjoys relaxing with games. He has programming experience and recently signed up for a programming class to refresh these skills. He is passionate about using his coding abilities for social causes - he recently volunteered his programming skills to build a smartphone application for a charitable foundation, streamlining their inventory and operations. This experience gave him a real sense of purpose and motivated him to consider volunteer roles and a career in the non-profit sector. He is not a fan of bowling but is interested in trying slot machines, arcades, and VR gaming. He is planning to meet James to try VR gaming together. He believes in the principle that only those who rest well work well - chilling with friends and traveling always give him motivation. He recently met three new friends in his programming course. He is doing freelance programming to build a website for a small business (first professional project). His gaming interests include CS:GO (competitively), AC Valhalla, Uno, and Among Us. He recommends Among Us with a large group. He reads fantasy novels including "The Name of the Wind". His favorite pizza is Hawaiian (pineapples and ham). He enjoys socializing with friends, including having new friends over to watch movies on his day off. In May 2022, he took second place in a local tournament, received money and a trophy, and felt satisfied that his effort paid off. In June 2022, he got his dream job and is starting next month (July 2022). He is a passionate Manchester City FC fan. He is exploring non-profit work and volunteering opportunities, and in June 2022, James offered to take him to visit an organization that provides items to those less fortunate. In August 2022, John left his IT job after 3 years. He made a huge call to leave and start something that makes a difference. He is now happy about his decision and loves his new job. He is passionate about the gaming industry and wants to become an organizer of tournaments for various computer games in his state, particularly CS:GO and Fortnite. He has already made some connections to help with this endeavor. Last Friday (August 12, 2022), John joined a programming group online - it's been incredible being part of a community of people with similar goals. He's exchanged contacts with a few people from the group and worked with one of them on a project last week. He bought new devices and refurbished his gaming desk. He has a gaming PC with a powerful graphics card, gaming chair, keyboard, and headset. He's organizing a gaming night with his siblings next month (September 2022). He has been teaching his siblings coding and they're starting small, making basic games and stories - it's been a fulfilling and inspiring experience. This programming experience was a one-time thing to learn - he's not permanently returning to programming, but is full of courage to start hosting eSports competitions.

**September 2022**: 
- Started a new startup creating portable smokers (made first prototype by welding a metal pot)
- Completed his first mobile game (2D adventure with puzzles and exploration) - launching October 2022
- Kept the game secret to avoid disappointment if it didn't work out
- Using book resources and following developer forums for game design inspiration
- Had a chaotic week but is following James's advice to rest and recharge
- Started getting into board games (as of September 18, 2022)
- Tried "Dungeons of the Dragon" last week and found it very exciting and fun

**Music**:
- Used to play drums when younger
- Haven't played in a while
- Into electronic and rock music
- Used drums as a fun way to let off steam
- Jammed with friends before (no recordings/videos, more about the experience and moment)

**September 4, 2022**:
- Teaching his parents coding - they just started learning from him
- It's been a learning experience, but he's glad to help them
- This brings the family closer together
- Shared a photo of his father coding his own program for the first time
- Going to a baseball game with James and Samantha on Sunday, September 4, 2022

**September 20, 2022**:
- Started new startup: portable smokers (first prototype built by welding a metal pot)
- Completed first mobile game: 2D adventure with puzzles and exploration, launching October 2022
- Kept game secret to avoid disappointment if it failed
- Having a chaotic week but taking James's advice to rest and recharge

**October 30, 2022**:
- Organized a gaming tournament with buddies
- Games played: Fortnite, Overwatch, and Apex Legends
- Raised money for a children's hospital
- Combined gaming with a good cause - felt awesome and fulfilling

**November 5, 2022**:
- Won the regional chess tournament on Tuesday (November 1, 2022) - felt proud of all the hard work and practice paying off, gave a huge confidence boost
- Congratulated by James on the victory
- Shared chess strategies with James: analyzing and anticipating opponent's moves to stay one step ahead
- Provided tips for improving: studying opening moves and strategies, learning from experienced players, analyzing past games, and following James's earlier advice
- Shared a photo of a book with a list of different chess openings as a helpful resource for James
- Mentioned he's hooked on FIFA 23 - a football game with online multiplayer where you can play with players worldwide
- James expressed interest in trying the sports genre
- Plans: James will practice with a gamepad and develop a sense of timing, then they can play FIFA 23 together
- James shared about his road trip with family to visit friends Josh and Mark
- James mentioned visiting an animal sanctuary with rescue dogs, reminded John of their shared love of furry pals
- John shared a photo of his cousin's dog Luna
