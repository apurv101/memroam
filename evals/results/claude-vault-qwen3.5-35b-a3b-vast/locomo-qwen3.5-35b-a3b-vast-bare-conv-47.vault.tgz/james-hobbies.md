---
id: 01a0508f-3278-7f41-9745-75f5c1ec430a
name: James's Hobbies and Interests
description: Personal hobbies, interests, and recent activities of James
---

# James's Hobbies

## Music/Drums
- Recently started learning drums (a few days of practice)
- Practices daily
- Sees improvements in his skills
- Finds it tough but rewarding

## Gaming
- Got a new cutting-edge gaming system (great graphics)
- Plays all kinds of new games
- Explores different game genres, particularly:
  - RPGs
  - Strategy games
- Uses gaming to relax after work
- Connects with friends who share passion for gaming
- Attended gaming conventions
- **September 4, 2022**: Shared a photo of a video game scene showing a couple of people with John

## Photography
- Takes photos of his drum kit
- Shares images in conversations
- **September 4, 2022**: Shared a photo of a video game scene (showing a couple of people) with John

## New Activities (September 2022)
- **Cooking class**: Signed up two days ago (around September 2)
  - Never liked cooking before but wanted to learn something new
  - Cost: $10 per class (very affordable)
  - First lesson achievements: made a great omelette, meringue, and learned dough-making
  - Plans to treat John to his cooking once he learns more
  - John's support gives him strength to pursue this new hobby
- **Dating Samantha**: Asked her to be his girlfriend at the theater and she agreed (September 4, 2022)
  - They have been through ups and downs in a short period
  - Samantha loves theater and lager beer
  - Going to a baseball game with her on Sunday, September 4, 2022
  - Invited John to join the baseball game

## Motivational Approach
- Sets small goals and tracks progress
- This method helps him stay motivated and focused

## Recent Activities (as of March 2022)
- Started drums practice (daily routine)
- Explored new gaming genres
- Using gaming system for relaxation and social connection

## Recent Activities (as of April 2022)
- Adopted a new dog named Ned from a shelter in Stamford (early April 2022)
- John shared his excitement about a new immersive RPG game with James
- Enjoying spending time with Ned and the cat in the family
- Last Thursday (April 14): Worked with a gaming pal on a programming project, created a virtual world inspired by Witcher 3
- Created a game character (woman in armor kneeling on a rock)
- Idea came from a walk with his dogs two weeks prior (early April): Saw a stranger walking towards them, her eyes and appearance amazed him, seemed to fall in love at first sight, didn't approach her but remembered her appearance and embodied it in the game
- Has visited Italy, Turkey, and Mexico (last year visited Italy; also been to Turkey and Mexico)
- Bought an adventure book with fantasy novels and cool arts (late April 2022)
- Playing Civilization VI (strategy game, been playing for a month now)
- Recommending "The Name of the Wind" to John
- Enjoying strategy board games with friends
- Playing a game about finding impostors (Among Us) with friends
- Planning to travel together with John next year

- **May 7, 2022**: John organized a CS:GO tournament with friends for charity, raising funds for a local dog shelter and using leftover money to provide food for the homeless. This event reinforced his commitment to combining gaming with community service.
  - Early May 2022: Had a frustrating bug in a game mechanics project that he couldn't solve alone, but a group of friends helped fix it
  - His happiness comes from pets, computer games, travel, and pizza
  - Favorite pizza is pepperoni (spicy salami and cheese), also likes cheese pizza and prosciutto
  - Owns Daisy (a Labrador who loves toys and eating) and two shepherds
  - **May 23, 2022**: Went to an amusement park with friends last weekend, had an awesome time on roller coasters, Ferris wheel, electric cars and buggies; felt like being in a video game
  - Finished a big project after months of work - had to learn a new language and handle many details; learned problem-solving, patience, and perseverance; feels more confident to take on bigger projects
- **June 2022**: Started a course combining gaming and programming; working on a football simulator project collecting player databases; passionate Liverpool FC fan

- **August 2022**: Beach outing and personal life update
  - Took his three dogs to a beach outing to have fun and bond with other dogkeepers
  - Met a beautiful girl named Samantha at the beach
  - Samantha left her phone number with James
  - James plans to call Samantha to ask her out on a date (planned for August 11, 2022)
  - John encouraged him and wished him well

- **September 1, 2022**: Unity strategy game completion
  - Finished developing his own Unity strategy game after months of hard work and effort
  - Game inspired by Civilization and Total War
  - Faced challenges with balancing mechanics and ensuring fairness
  - Used trial and error to get it to where he wanted
  - Key learnings: perseverance, patience, and the importance of feedback and collaboration
  - Very proud of completing the game
  - John's support and encouragement made a real difference
  - Shares screenshots with John including: a stone building with a giant creature, and a person on a horse

- **September 4, 2022**: Personal life update
  - Asked Samantha to become his girlfriend at the theater and she agreed
  - They have been through a lot in a short period with ups and downs
  - James is happy with the relationship
  - Going to a baseball game with Samantha on Sunday, September 4, 2022
  - Invited John to join the baseball game

- **September 2022**: Personal challenges and new hobbies
  - Going through some difficult times, but appreciates having supportive friends like John
  - Willing to be there for John as well when he needs someone to talk or vent to
  - **Cooking class**: Signed up two days ago (around September 2, 2022)
    - Never liked cooking before but wanted to learn something new
    - Cost: $10 per class (very affordable)
    - First lesson: prepared several simple dishes including an omelette (great result!), meringue, and learned how to make dough
    - James hopes to treat John to his cooking once he learns more
    - John's support gives James strength to pursue this new hobby
  - **Productivity method**: Started writing everything needed to do in a notebook to avoid forgetting tasks (as of September 18, 2022)
  - **Game inspiration from dreams**: Gets ideas from books, movies, and dreams
    - Had a vivid dream about a medieval castle with a labyrinth full of puzzles and traps that led to creative ideas
    - Woke up with interesting thoughts from the dream
    - Made sketches and notes from this experience (including a drawing of a guitar, though unrelated to the castle dream)
  - **Streaming games**: Started streaming games (as of September 18, 2022), no details yet but hoping it works out. On September 20, received wonderful community feedback that left him feeling stoked and inspired to continue.

- **October 2022**: Support for John's charity tournament
  - John organized a gaming tournament with buddies
  - Games included Fortnite, Overwatch, and Apex Legends
  - Raised money for a children's hospital
  - John combined gaming with a good cause - felt awesome
  - **Music setup**: Has headphones and uses them for music
  - **Gaming setup**: Uses a laptop with a monitor

- **November 5, 2022**:
  - James went on a road trip with family and dogs - had fun exploring new places and taking in nature with his pets
  - Supported John's chess victory - John won the regional chess tournament on Tuesday (November 1, 2022)
  - John shared chess strategies and tips: analyzing opponent moves, studying openings, learning from experienced players
  - John shared a photo of a chess openings book as a resource
  - James interested in FIFA 23 (football/sports genre) that John recommended - John plays online with players worldwide
  - Plan: James to practice with a gamepad and timing, then play FIFA 23 together
