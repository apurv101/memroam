name: John
description: John is interested in gaming and helping people. He started a volunteer gig as a programming mentor at a game dev non-profit.
