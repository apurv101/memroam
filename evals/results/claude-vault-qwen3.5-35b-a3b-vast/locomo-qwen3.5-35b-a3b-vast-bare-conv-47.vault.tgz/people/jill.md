---
id: 01a0508f-3c45-7d78-a123-456789abcdef
name: Jill
description: Important person in John's life; received a souvenir from James during his trip to Nuuk in July 2022
---

# Jill

## Relationship to John
- Jill is someone significant in John's life (relationship not explicitly specified in available records)
- John was excited that Jill would be delighted with the souvenir James brought back from his trip

## Key Events
- **July 22, 2022**: James brought souvenirs for both John and Jill from his trip to Nuuk (another country)
- John expressed gratitude and said Jill would be delighted with the gift

## Context
- Mentioned in conversation transcript dated 9:49 am on July 22, 2022
- James had just returned from traveling to Nuuk and brought souvenirs for John and Jill
- This suggests John and Jill are close enough that James knows to bring gifts for both of them
