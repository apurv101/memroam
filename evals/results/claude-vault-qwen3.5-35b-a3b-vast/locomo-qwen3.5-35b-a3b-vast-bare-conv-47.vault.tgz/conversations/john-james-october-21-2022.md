---
id: conv-oct-21-2022
name: John and James Conversation - October 21, 2022
description: John and James catch up; James shares gaming power outage experience, childhood Nintendo photos; John shares programming seminar insights; discusses Cyberpunk 2077
---

# John and James - October 21, 2022 Conversation

## Date
October 21, 2022 at 7:36 pm

## Summary
James and John reconnect after some time apart. James shares recent gaming frustrations including a power outage that caused progress loss, and nostalgic childhood gaming memories. John updates James on a programming seminar he organized and shares insights about Cyberpunk 2077. They exchange gaming memories and resources.

## Key Topics Discussed

### James's Power Outage Experience
- **Incident**: Three days ago (October 18, 2022), James's apartment lost power
- **Impact**: Interrupted gameplay during a critical moment in a game
- **Consequence**: Lost some progress because he hadn't saved frequently enough
- **Lesson Learned**: Now saves more often during gameplay

### John's Programming Seminar
- **Event**: Programming seminar organized last week (around October 14-15, 2022)
- **Outcome**: Great turnout, went really well
- **Learning Gains**: Insight into various programming approaches and techniques
- **Experience**: Fulfilling to share knowledge and see it benefit the group
- **Future Plans**: Planning to experiment with new techniques in his own work
- **Resources**: Will share resources and tutorials with James

### Childhood Gaming Memories
- **Photos Shared**: 
  - James shared photo of military veterans (mother and her friend) with their dog
  - Childhood photo of James playing on their old Nintendo gaming setup
  - Photo of the Nintendo console and Mario game controller
- **Favorite Games**: Super Mario and The Legend of Zelda
- **Impact**: These games sparked James's passion for gaming and he's been hooked ever since
- **First System**: Nintendo was James's first gaming system

### Cyberpunk 2077
- **Timeline**: James tried the game yesterday (October 20, 2022)
- **Impression**: Great game, very addictive
- **John's Advice**: 
  - Most difficult aspect is making the right choices
  - Even dialogue line choices can lead to life-changing consequences
  - You don't have to be friends with every character
  - Willing to provide advice without spoilers

### James's Family
- **Visit**: Mother came to see James 2 days ago (October 19, 2022)
- **Accompanying Guest**: Mother's army friend who is still serving but retired long ago
- **Experience**: Had fun hearing stories about their military time and their dog

## Photos Shared During Conversation
1. James: Photo of a man and woman in military clothing standing next to a dog
2. James: Photo of Nintendo game console with Mario controller
3. James: Photo of The Witcher Wild Hunt game cover

## Emotional Tone
- Friendly and nostalgic
- Supportive friendship
- Enthusiastic about gaming and learning

## Key Quotes
- James: "Had to wait hours before playing again"
- John: "The choices here can be life-changing!"
- James: "Those games sparked my passion for gaming"

## Notable Insights
- Power loss during gaming can cause frustration and progress loss
- Childhood gaming experiences can shape lifelong passions
- Programming seminars create valuable learning communities
- Choice-based games like Cyberpunk 2077 offer deep narrative experiences
- Supporting friends' hobbies and interests strengthens relationships

## Action Items
- John to send James resources and tutorials on programming approaches and techniques
- James to reach out if he needs help with programming or gaming questions
