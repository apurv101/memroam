---
id: conv-sep-20-2022
name: John and James Conversation - September 20, 2022
description: John and James chat about John's new startup and mobile game, and James's game streaming journey
---

# John and James - September 20, 2022 Conversation

## Date
September 20, 2022 at 8:56 pm

## Summary
John and James catch up after a few days. John shares exciting news about starting a portable smokers startup and launching his first mobile game. James talks about his new game streaming journey. They also discuss their shared magazine for game developers.

## Key Topics Discussed

### John's New Startup
- **Portable smokers startup**: John started a new business creating portable smokers
- Built his first prototype by welding a metal pot
- Asked James for feedback on how it looks

### John's Mobile Game Launch
- **Major career milestone**: Completed his first mobile game
- **Genre**: 2D adventure game with puzzles and exploration
- **Launch**: Next month (October 2022)
- **Reason for secrecy**: John kept it secret to avoid disappointment if it didn't work out
- **Development timeline**: Been working on it for the past few months
- **Puzzle design resource**: John mentions a book that helped him with puzzles (shared a photo of a book with a cartoon character playing a game)
- **Development resources**: Also watches tutorials and follows developer forums

### James's Game Streaming
- **New activity**: Started streaming games
- **Community response**: Impressed by the nice comments from the gaming community
- **Feeling**: Stoked and inspired to keep going
- **Shared a photo**: A card with a graduation cap on it (celebratory)

### Shared Game Development Resource
- **Magazine**: Both are reading a magazine about game development
- **Content**: Tutorials, interviews with developers, and helpful tips
- **Both found it valuable**: James recommended it to John, and John had already been reading it
- **James shared a photo**: Magazine cover with a cartoon character

### Weekly Check-in
- **James's week**: Trying to find balance between work and other activities
- **John's week**: Chaotic but powering through
- **Mutual support**: 
  - James advised John to take time for himself and recharge
  - John appreciated the advice and agreed to follow it
  - Both emphasized self-care importance

## Photos Shared
1. Fire burning in a metal pot (John's portable smoker prototype)
2. Card with graduation cap (James)
3. Demonic demon flying with a sword (John's mobile game)
4. Video game with multiple screens (John's mobile game screenshot)
5. Book with cartoon character playing a game (puzzle design resource)
6. Magazine with cartoon character (game development resource - shared by both James and John)

## Notable Quotes
- John: "I kept it a secret because I would have been very upset if I had told you about her in advance and then it wouldn't have worked out."
- James: "This made me think of such an exciting time."
- John: "Basically, staying informed and constantly learning is key!"
- James: "You deserve it. Relax and recharge."

## Follow-up Plans
- John will let James know when mobile game testing is ready
- James offered to help with testing

## Emotional Tone
- Supportive and encouraging
- Celebratory of each other's achievements
- Warm friendship with mutual care for well-being
