name: John and James Conversation - June 13, 2022
description: John and James caught up. John got his dream job starting next month. James started a gaming/programming course and is building a football simulator with player databases. They are Liverpool vs Manchester City fans and made a bet about the season standings.

---

**Date**: June 13, 2022, 4:30 pm

**Participants**: John, James

## Key Topics Discussed

### John's New Job
- John finally got his dream job after lots of interviews and late nights
- He was ecstatic about the offer
- Starting next month (July 2022)
- Excited to begin his journey

### James's New Course
- James recently started a course combining gaming and programming
- The course is fun and challenging
- Increased his excitement for both gaming and programming

### Football Simulator Project
- James is working on a new part of a football simulator
- Currently collecting player databases (wasn't easy but succeeded)
- Combines his love of football with his programming skills

### Football Team Rivalry
- John is a Manchester City fan
- James is a Liverpool fan (supports every match, "no club better than Liverpool")
- They discussed Liverpool vs Chelsea match
- James and John made a bet about which team will be higher in the final standings
- James believes Man City are in bad form with terrible transfer policy
- John believes City manager can handle it

### Themes
- Friendship and catching up
- Career and personal growth
- Pursuing passions through education
- Friendly sports rivalry and betting
- Support and encouragement
