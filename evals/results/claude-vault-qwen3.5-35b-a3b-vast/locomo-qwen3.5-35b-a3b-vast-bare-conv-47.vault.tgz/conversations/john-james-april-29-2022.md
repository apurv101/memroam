name: John and James Conversation - April 29, 2022
description: John and James discussed freelance work, fantasy books, and various games including Civilization VI, AC Valhalla, Uno, and Among Us.

---

**Date**: April 29, 2022, 2:36 pm

**Participants**: John, James

## Key Topics Discussed

### John's Freelance Work
- Currently doing freelance programming work
- Working on a website for a local small business (first professional project outside of class)
- Progress is slow with some hiccups along the way
- Main challenge: figuring out how to get payments on the website
- Used resources to understand the payment process
- Getting closer to a solution but it's taking a while
- Determined to keep pushing through challenges

### Fantasy Books & Reading
- James shared that three days ago (around April 26) he bought himself an adventure book with fantasy novels and cool arts
- Shared a photo of a person holding a book open to a picture of a male character
- Art was described as awesome
- John recommended "The Name of the Wind" - a great novel with awesome writing
- John mentioned it's a trilogy and James would love it
- James never heard of it but said he'd definitely check it out

### James's Pets
- Shared a photo of a dog (Daisy) laying on a bed with a computer in the background
- James was playing a game when Daisy came to lay down next to him
- James's dogs love to watch him gaming and often hug him
- Described them as "good cuddle buddies"

### Video Games - John
- Currently playing Assassin's Creed Valhalla (AC Valhalla)
- Described it as cool

### Video Games - James
- Been playing Civilization VI (strategy game)
- Has been playing it for a month now
- The game has challenged his strategy skills
- Description: A high-quality turn-based strategy game where you manage resources, lead armies, and conquer territories
- Requires a lot of strategy - planning, managing resources, making good decisions to beat rivals
- Every move matters
- Great for working on problem-solving and thinking skills
- Satisfying when plans work out and you win

### Board Games - John
- Shared a photo of a board game with lots of cards on it
- Played one with friends two days ago (around April 27)
- Very exciting

### Card Game Identification
- John played a game with friends that he forgot the name of
- Description: Multi-colored cards with numbers
- You can only place a card with the same color or number on your opponent's card
- Sometimes trade cards, sometimes need to draw extra from the deck, sometimes skip a turn
- This describes **Uno**

### Impostor Game
- John mentioned playing a game to figure out who the impostors are
- Described it as super fun
- James said he's heard of it and been meaning to try it
- John recommended gathering a large group to play as it will be much more interesting
- This describes **Among Us**

## Themes
- Professional growth and freelancing
- Fantasy literature appreciation
- Gaming as bonding activity
- Board games for social connection
- Problem-solving through games
- Support and encouragement between friends
- Pet companionship during gaming
