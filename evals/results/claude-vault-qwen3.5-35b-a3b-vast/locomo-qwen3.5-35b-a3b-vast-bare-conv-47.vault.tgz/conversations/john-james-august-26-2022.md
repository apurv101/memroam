---
id: 01a0508f-8c3d-7e2a-9123-456789abcdef
name: John-James Conversation - August 26, 2022
description: Conversation on 9:18 pm August 26, 2022 about pets, siblings' programming project, game development ambitions, and meeting plans
---

# John & James Conversation - August 26, 2022
**Date:** 9:18 pm, August 26, 2022

## Topics Discussed

### James's Dog Ned
- James shared a photo of Ned (his dog) on a couch while he was gaming on his console
- Ned is a new pup James adopted
- John had forgotten Ned's name initially but remembered after James reminded him
- James said he can't imagine life without Ned

### John's Siblings Learning Programming
- John has been helping his younger siblings with a programming course
- They're working on a text-based adventure game together
- John is proud of how they're learning coding skills while having fun
- Hopes they might create their own video games someday

### James's Game Development Ambitions
- James is interested in creating a strategy game
- Specifically mentioned wanting to make a game like Civilization
- Appreciates how complicated and in-depth strategy games are
- Hopes to make his own strategy game someday

## Meeting Plans

### Tomorrow's Plans (August 27, 2022)
- John's day off tomorrow
- James shared a photo of his laptop with a colorful keyboard
- Initially suggested meeting at Starbucks for coffee
- John suggested having a beer instead
- James proposed McGee's Pub, mentioning their great stout
- John doesn't like dark beer
- James noted they have light beers at McGee's
- **Agreement:** Meet at McGee's Pub tomorrow

## Photo Shares
1. James shared a photo of Ned (his dog) on a couch while gaming
2. James shared a photo of his laptop with a colorful keyboard on a table

---

*Conversation ended with "See you John, bye!"*