name: James and Cyberpunk 2077
description: James is considering playing Cyberpunk 2077 on his new video card. John recommended it as having an immersive world and amazing story.
