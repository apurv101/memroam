---
id: 02b1619e-3b0f-820e-a31f-d4ee350101d1
name: John's CS:GO Charity Tournament - May 2022
description: Details of the CS:GO charity tournament organized by John in early May 2022
---

# CS:GO Charity Tournament - May 7, 2022

## Overview
John organized a Counter-Strike: Global Offensive (CS:GO) tournament with his friends for charitable purposes.

## Event Details
- **Date**: May 7, 2022 (the night before this conversation)
- **Game**: CS:GO (Counter-Strike: Global Offensive)
- **Organizers**: John and his friends
- **Purpose**: Charity fundraising

## Outcome
- Successfully raised money for charity
- Tournament attracted many participants
- Event was well-organized and successful

## Charitable Impact
1. **Primary beneficiary**: Local dog shelter near John's residence
   - The shelter received all the funds raised initially

2. **Secondary use of leftover funds**:
   - Purchased groceries
   - Cooked food for homeless people
   - The homeless people were very grateful for the food

## Personal Significance to John
- Combined his interest in gaming with community service
- Found the experience rewarding to see people come together for a good cause
- Plans to organize more events like this in the future
- Values combining gaming with volunteering as both fun and fulfilling

## Future Plans
John expressed interest in organizing more charity events that:
- Combine his gaming interests with helping the community
- Bring people together for friendly competition
- Support various charitable causes

## Conversation Context
This event was discussed in a conversation with James on May 8, 2022, where James praised John's efforts and encouraged him to continue doing good work in the community.
