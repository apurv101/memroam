---
id: 01a0508f-2a9e-719c-905d-c3ee249010c0
name: John's Hobbies and Interests
description: Personal hobbies, interests, and recent activities of John
---

# John's Hobbies

## Gaming
- Plays video games competitively
- Favorite game: CS:GO (Counter-Strike: Global Offensive)
- Advanced to the next level in a game (confident breakthrough win)
- Attended a gaming convention
- Participated in a tournament at the convention
- Takes photos at gaming events (photography hobby)

## Drums
- Started playing drums approximately one month ago
- Finds it challenging but fun
- Owns a drum kit that he keeps set up

## Photography
- Takes photos of his drum kit
- Captures images at events and conventions

## Motivational Approach
- Commited to hitting new goals
- Applies same commitment to hobbies and other areas

- **June 2022**: Got his dream job, starting July 2022; passionate Manchester City FC fan
- **June 16, 2022**: Started a blog about coding, sharing his coding journey with others and tracking his progress. Finds it exciting and scary.
- **June 16, 2022**: Bought many new books, almost completely filled his bookshelf. Enjoys sci-fi and fantasy books, especially epic fantasy series with immersive world-building and intricate storylines.
- **June 16, 2022**: Favorites are "The Stormlight Archive" and "Kingkiller Chronicle"; recommends "The Expanse" series for sci-fi fans. Obsessed with how these books create magical worlds where characters feel real.
- **June 16, 2022**: Discusses James's dog Max, learning Max loves swimming at beaches/lakes, catching frisbees in mid-air, and enjoying long walks on trails. Max brings James joy during tough times.

## Recent Activities (as of March 2022)
- Gaming win that boosted confidence
- Attended gaming convention, tried new games, met developers, played in tournament

## Recent Activities (as of September 20, 2022)
- Started new startup: portable smokers (first prototype built by welding a metal pot)
- Completed first mobile game: 2D adventure with puzzles and exploration
- Game launches October 2022
- Kept game development secret to avoid disappointment if it failed
- Using book resources and following developer forums for game design
- Following advice to balance work and self-care during chaotic week

## Recent Activities (as of April 2022)
- Playing a new RPG with an immersive futuristic dystopia story and world
- Experienced some lag and errors in the game, but still enjoying the awesome graphics and gameplay
- Shared game recommendation with friend James; planning to send link
- Last Tuesday (April 12): Met three cool new friends in his programming course who share his passion for programming

## Recent Activities (as of April 2022)
- Freelance programming for a website for a local small business (first professional project outside of class)
- Working on integrating payment functionality into the website
- Playing Assassin's Creed Valhalla (AC Valhalla)
- Reading "The Name of the Wind" by Patrick Rothfuss (fantasy novel trilogy)
- Playing Uno with friends (board game with multi-colored numbered cards)
- Recommending a game about finding impostors (Among Us) to friends
- Playing strategy board games
- April 18: Wanted to be alone with nature, found a canyon in the surrounding area with a river running through it, very calming view
- Follows principle: "only those who rest well work well" - chilling with friends and traveling give him motivation to work further
- Visited Japan (before April 2022): Impressed by technologically advanced megacities, huge screens on buildings, and tasty street food
  - Early May 2022: Had a day off, invited new friends over to watch movies, emphasizing importance of balancing work and enjoyment
  - May 7, 2022: Organized a CS:GO tournament with friends for charity
    - Raised money for a local dog shelter (near where John lives)
    - Used leftover funds to buy groceries and cook food for homeless people
    - Plans to organize more charity events combining gaming with community help
  - Mid-May 2022: Volunteered programming skills to build a smartphone application for a charitable foundation. The app structured their work and digitized their inventory system (previously paper-based), allowing everything to be tracked on smartphones. This experience gave him a sense of purpose and showed him the power of tech to make positive changes. It motivated him to consider volunteer roles and potentially a career in the non-profit sector.

  - **May 23, 2022**: Entered a local tournament last Friday, took second place and received money as a prize; got a trophy (graduation cap on a book with rope) that reminds him to always put in his best effort; felt satisfied that his effort paid off
  - Favorite pizza is Hawaiian (pineapples and ham), appreciates the sweet and salty combination

## August 2022: Career Change

- **Early August 2022**: Made a huge call - left his IT job after 3 years
  - The decision was tough but he wanted something that makes a difference
  - At first, it was super scary, but he knew he had to make a change and focus on things that align with his values and passions
  - Now with his new job, he is happy about his decision and loving the new role

- **August 2022**: Passionately exploring the gaming industry as a career path
  - Wants to become an organizer of tournaments for various computer games in his state
  - Specific games he wants to organize competitions for:
    - CS:GO (Counter-Strike: Global Offensive)
    - Fortnite
  - Has already made some connections that will help him with this endeavor
  - Plans to gain more experience and perfect his skills to be successful in this field
  - Describes it as a "new journey" for him

- **August 10, 2022**: Gaming interests expanded
  - Been exploring strategy and RPG games instead of his usual shooters
  - Already planning to make competitions for these new game genres
  - Currently playing "The Witcher 3"
  - Loves the storytelling and characters in "The Witcher 3"
  - Gets hooked on making the right choices to shape the world in the game
  - Finds the game really immersive
  - Shares photos of his organized gaming room workspace with wall lighting

- **August 2022 - September 2022**: Teaching siblings to code
  - Has been teaching his siblings coding
  - They're starting small, making basic games and stories
  - Finding it a fulfilling and inspiring experience
  - Impressed by how fast they learn and the good time they're having
  - Excited to see how far they can go with their passion for video games
  - Hopes they can use their coding skills to create something cool

- **September 4, 2022**: Teaching parents coding
  - His parents just started learning coding from him
  - It's been a learning experience, but he's glad to help them
  - This activity brings the family closer together
  - Shared a photo of his father coding his own program for the first time

- **September 2022**: Board games
  - Started getting into board games (as of September 18, 2022)
  - Tried "Dungeons of the Dragon" last week and found it very exciting and fun
  - Enjoys board games as a new hobby to explore

- **October 2022**: Charity gaming tournament organizer
  - Organized a gaming tournament with buddies
  - Games played: Fortnite, Overwatch, and Apex Legends
  - Raised money for a children's hospital
  - Combining gaming and a good cause felt awesome and fulfilling
  - Moving forward with goal to become an eSports tournament organizer

- **Music**: 
  - Used to play drums when younger
  - Haven't played in a while
  - Into electronic and rock music
  - Played drums before as a fun way to let off steam
  - Jammed with friends before (more about the experience and moment than recording)

- **November 5, 2022**:
  - Won the regional chess tournament on Tuesday (November 1, 2022) - proud that all hard work and practice paid off, huge confidence boost
  - James congratulated John and asked about strategies
  - Shared chess strategy: analyzing and anticipating opponent's moves
  - Provided tips for improvement: studying opening moves/strategies, learning from experienced players, analyzing past games
  - Mentioned James's earlier advice also helped
  - Shared a photo of a chess openings book as a resource for James
  - John mentioned he's hooked on FIFA 23 - football game with online multiplayer worldwide
  - James expressed interest in trying the sports genre
  - Plan: James to practice with gamepad and timing, then play FIFA 23 together