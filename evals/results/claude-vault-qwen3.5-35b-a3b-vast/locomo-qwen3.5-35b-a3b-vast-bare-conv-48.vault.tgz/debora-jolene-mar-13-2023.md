name: Deborah & Jolene conversation
description: March 13, 2023 - Deborah teaching yoga to neighbors, Jolene struggling with Engineering assignments

---

**Date:** March 13, 2023 (11:22 am)

Deborah: Hi Jolene! We haven't corresponded for a long time!

Jolene: Hey Deb, yeah life can get chaotic. How's it been going lately?

Deborah: So much has been going on lately. I started this yoga class in the neighborhood - it's such a good feeling! Now I get to share the exercise with my neighbors and watch it really transform them.

Jolene: Congrats. How did you do this?

Deborah: [shares a photo: a photo of a group of women posing for a picture] Thanks! My neighbors were interested in trying yoga, so I hosted a class for them on Friday. It was great to see everyone embrace and enjoy it. Here is our photo together.

Jolene: That's cool! What made you want to start teaching it?

Deborah: I find it calming and wanted to share that with others. Giving people peace and awareness brings me so much happiness.

Jolene: Wow, Deb! It's awesome when we can share something we love and make things better for others.

Deborah: Teaching it is awesome because it can help others and I've made such great friends through it. It's really nice for building community connections.

Jolene: That's really motivating. It's great to have support in tough times.

Deborah: It's one of life's best parts, right?

Jolene: Yeah, having someone to rely on is key in tough times. It really makes a difference in how we handle life. Plus, there's something I wanted to tell you.

Deborah: What's up? I'm listening. We'll figure it out.

Jolene: I'm having a hard time dealing with my Engineering assignments. It's a lot to manage and I'm struggling to keep up. Can we still talk about time management?

Deborah: Sure, Jolene. Let's find a time that works for both of us.

Jolene: Let's find a time to chat - I'll check my schedule and get back to you.

Deborah: Take your time, Jolene. We'll work it out. Take care of yourself, OK?

Jolene: I'll make sure to take it. See you soon!

Deborah: I'm here for you if you need me. Let's catch up soon.

Jolene: Have a great day!

---

**Key topics discussed:**
- Deborah teaching yoga to neighbors and building community connections
- Jolene struggling with Engineering assignments
- Plan to discuss time management strategies later
