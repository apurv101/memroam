name: Jolene
description: Engineering student passionate about sustainable solutions and helping communities

name: Deborah
description: Cat owner (Max and Luna), values connection to nature and self-care

name: Shared values
description: Both value perseverance, resilience, and helping others

name: Jolene's values
description: Learned from her mother: never give up, stay resilient, help others, pursue goals

name: Jolene's engineering goals
description: Wants to work on sustainable initiatives, renewable energy (solar), clean water projects, and social causes that make a real difference to communities

name: Jolene's pets
description: Has snakes; they watch her practice yoga

name: Deborah's pets
description: Max (8 years old, her mother's cat she took when her mother passed away) and Luna (5 years old, from a shelter)

name: Self-care practices
description: Deborah recommends taking breaks, stretching/yoga, walks, enough sleep, and work-life balance. Jolene practices yoga and meditation regularly with her partner, planning a meditation retreat together.