name: Deborah & Jolene - September 12, 2023 Conversation
description: Jolene shares meditation retreat experience in Phuket; discusses mindfulness and a cat card game
---
**Date:** September 12, 2023, 2:18 pm

**Participants:** Deborah, Jolene

**Summary:**
Jolene shares her recent meditation retreat experience in Phuket with her partner. She reflects on the importance of balance, mindfulness, and appreciating small moments in life. Deborah and Jolene plan to play a card game together in the future.

**Key Points:**
- Jolene and partner traveled to a meditation retreat in Phuket for a few weeks last weekend (early September 2023)
- Retreat focused on nature, reflection, and taking a break from engineering studies
- Jolene found inner peace and realized the importance of incorporating relaxation and self-care alongside her studies
- Key session taught releasing expectations and judgments, savoring the present
- Jolene realized she's usually too consumed with hitting goals and forgets to appreciate the journey
- Now trying to be more mindful and grateful, appreciating small wins like the feeling of the sun or a great coffee
- Experiencing a new level of joy and happiness!
- Deborah shared a photo of two children on yoga mats, emphasizing the value of supportive community
- Deborah mentioned playing a card game about cats where you take cards from a deck and attack opponents
- Both friends plan to play the cat card game together in the future
- Jolene looks forward to meeting Deborah and playing the game

**Photos Shared:**
- Jolene: Photo of a woman doing a yoga pose on the beach
- Deborah: Photo of two children standing on yoga mats in a room

---
