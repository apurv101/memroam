name: Conversation with Jolene
description: 2023-02-25 - Balancing engineering school, relationship, and self-care practices

Date: 2023-02-25, 4:50 pm

Participants: Jolene, Deborah

Summary:
Jolene and Deborah discussed Jolene's recent experiences balancing engineering school with her partner's video game hobby, and how she's making time for herself through yoga and meditation.

Key Points:
- Jolene is attending engineering school while her partner plays video games
- She practices yoga and meditation for calm amidst the craziness
- Yoga helps her chill out, gain perspective, and become more alert and motivated afterward
- Her partner has started joining her for yoga sometimes, which has brought them closer
- They've been together for three years but are not married; the ring on his hand is just a decoration
- They met in an engineering class in college and quickly became friends before it blossomed into romance
- They enjoy working on engineering projects together as a team
- Breathing exercises and meditation help Jolene when overwhelmed, making her feel calmer and clearer
- Jolene values Deborah's support and plans to continue prioritizing self-care

Deborah's practices:
- Morning routine: meditation, yoga, teaching classes, and jogging (started jogging yesterday in a nearby park, plans to make it daily)
- Evenings: time with loved ones
- Views exercise as key for feeling connected to her body
- Shares the wisdom: "Can't pour from an empty cup" - self-care gives energy to help others
- Shared a photo of a person on a bench looking at sunset as a reminder to find peace in chaos

Theme: The importance of balancing demanding pursuits (engineering, relationships) with self-care practices like yoga, meditation, and exercise.
