name: Deborah
description: Yoga teacher who bonds with students and friends through yoga

## Practice
- Teaches yoga
- Spends a lot of time in a dance studio
- Recent class with Anna - tried Warrior II pose
- Modified pose: sit on edge of chair, feet planted, twist torso, use hand on knee for support, hold for a few breaths, switch sides

## Nature Spots
- Park with forest trail - calming, gets lost in nature
- Beach nearby - peaceful, sound of waves and sand under feet
- Spot by water near mom's old house - reflection and finding peace

## Mother
- Has a white shirt and gold chain necklace amulet from her mother
- Brings amulet to reflective spot near mom's old house to feel her love and stay close to her
- Mom had grace and strength when facing hardships
- The flowers from when Deborah was struggling remind her of someone special
- **September 2023**: Reconnected with mom's old friends; hearing their stories was emotional - a mix of happiness and sadness
- Through her mom's friends' eyes, gained deeper appreciation for her mom
- Learned things about her mom she hadn't known before
- They reminisced and looked through old photos together
- These stories gave her a glimpse into her mom's life beyond what she knew

## Friend: Anna
- Bonded during yoga class
- Anna wears a pendant in memory of her mother

## Philosophy
- When things get tough, take a deep breath and remember why you're doing this
- Small things like flowers can make a real difference
- Nature helps us forget daily craziness and find inner peace
- Stay connected to sources of strength

## Friend Connection
- Jolene is a supportive friend; encourages her goals and passions

## Pets
- Has two cats: Max (8 years old, her mother's cat she took when her mother passed away) and Luna (5 years old, from a shelter)
- Cats bring joy, peace, and comfort to her home

## Recent Conversation (August 26, 2023)
- Discussed remembering loved ones and their influence
- Shared photos: yoga pose on beach, two cats (Luna and Max) on window sill
- Discussed pet ownership: Max came from her mother, Luna from shelter
- Discussed self-care practices: taking breaks, stretching/yoga, walks, sleep
- Deborah recommends finding balance between work and self-care


## Recent Conversation (August 16, 2023)
- Jolene feeling overwhelmed trying to juggle engineering, relationship with bf, and personal growth
- Has started using bullet journal for time management - finds it helpful and satisfying
- Haven't tried mindfulness yet but interested in giving it a shot for destressing
- Deborah shares she led meditation yoga session for elderly at local care home during sunset
- Mutual encouragement to pursue mindfulness and support each other
## Recent Activities (April 2023)
- Went biking with neighbor last week - felt free and beautiful
- Checked out an art show with a friend - cool and inspiring
- Art reminds her of her mother
- Mom believed art could give out strong emotions and uniquely connect us
- Going to art shows feels like experiencing them together with mom even though she's gone (hard but comforting)
- Finding ways to keep mom's memory alive gives her peace
- Artwork brings back powerful emotions and reminds us of those we've lost
## Yoga Retreats & Community (June 2023)
- Preparing for a yoga retreat with friends/buddies
- Seeks opportunities to connect with like-minded people
- Values finding peace, understanding, and centeredness
- Shares photos from retreat: group yoga in parks and fields
- Tries new poses regularly (e.g., Dancer Pose/Natarajasana, Tree pose)
- Views statues and symbols (like a statue of peace/enlightenment) as meaningful parts of practice
- Believes peaceful time is essential for everyone to relax and reflect

## Photography & Sharing
- Enjoys capturing nature and peaceful moments (shared sunset over lake with boat)
- Uses photos to share experiences with friends
- Finds value in visual storytelling of her yoga journey

## Community Project (August 2023)
- Early August 2023: Started a cleanup project for their community
- Actively raising funds for the project
- Excited to see everyone come together to make a difference
- Supporting Jolene during her project setback:
  - Offering emotional support and encouragement
  - Sharing yoga practices and routines
  - Sending tutorial videos for gentle flow poses
  - Emphasizing finding balance and calm during tough times
  - Reminding Jolene that small moments can provide a boost to push forward

## Recent Conversation (August 16, 2023)
- Jolene shares feeling overwhelmed juggling engineering, relationship with bf, and personal growth
- Uses bullet journal for time management and tracking tasks
- Shares new photos: book with checklist, bullet journal spread with motivating quote, group yoga on beach
- Mentions she hasn't tried mindfulness yet but is keen to give it a shot
- Deborah shares she led a meditation yoga session at a local care home during sunset
- Both friends committed to mutual support on mindfulness journey

## Yoga Practices Shared (August 2023)
- Recommended a gentle yoga flow focused on breathing and grounding
- Shared photos of yoga studio and herself practicing
- Will send tutorial video with poses to Jolene
- Believes yoga helps find balance in tough times and keeps one centered
- Continues to prioritize self-care through yoga, meditation, and nature

- About finding solace in the things we love

## Recent Conversation (September 3, 2023)
- Went to a community meetup last Friday - shared stories, felt connected to community
- Shared an old photo of herself doing yoga with two children
- Her yoga pals have been like a second family - they've held each other up through a lot
- Her mother was her biggest fan and source of motivation - often came to yoga classes with her

## Recent Conversation (September 6, 2023)
- Shared a photo of a sunrise and beach walk with Jolene
- Jolene mentioned the photo reminded her of a past beach getaway
- Both friends expressed appreciation for calm environments and nature
- Made a mutual plan to potentially watch a sunrise together someday
- Offered support and encouragement to Jolene during her studies and project