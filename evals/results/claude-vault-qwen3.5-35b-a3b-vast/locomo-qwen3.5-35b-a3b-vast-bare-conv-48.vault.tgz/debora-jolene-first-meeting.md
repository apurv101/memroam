name: Deborah and Jolene's First Conversation
date: 2023-01-23

Deborah and Jolene met for the first time on January 23, 2023.

Jolene:
- Completed an electrical engineering project that week
- Mother passed away last year (2022)
- Has a heart-shaped pendant with a bird symbol, given by her mother in Paris in 2010
- The pendant represents freedom and motivates her to pursue her goals
- Had a room in her mother's house with a bench and window

Deborah:
- Visited her mother's old house, which holds special memories
- Her mother passed away a few years ago (before 2023)
- Her mother used to sit on a special bench near the window every morning
- Deborah visits the bench sometimes to stay connected to her mother
- Has a pendant that reminds her of her mother
- Teaches yoga and is passionate about supporting her community
- Was inspired to teach yoga because it helped her find peace during a rough time
- Goal is to keep teaching yoga and helping others find peace and joy

Both women bonded over:
- Losing their mothers
- Having meaningful jewelry/pendants to remember their mothers by
- Finding connection through physical spaces (the bench, Jolene's room)
