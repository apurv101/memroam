name: Jolene and Deborah - Yoga and Wellness
description: Shared interests in yoga practice, scents, and music for relaxation between Jolene and Deborah.

## Shared Yoga Practice
Both Jolene and Deborah practice yoga together and enjoy creating serene spaces for their practice.

## Favorite Scents
- **Lavender** - Jolene's favorite
- **Rosemary** - Both enjoy this scent
- Deborah uses candles and essential oils to add warmth and calm to her yoga sessions

## Music Preferences

### Jolene's Favorites
- Nils Frahm
- Olafur Arnalds
- Both artists have calming music that helps her get into a different headspace

### Deborah's Recommendations
- Track: "Savana" (instrumental with mellow melodies and rhythms)
- Album: "Sleep" - great for meditation and deep relaxation
- Prefers instrumental tracks with mellow melodies and rhythms

## Conversation Context
This conversation took place on March 28, 2023. Both expressed appreciation for how music and scents can enhance their yoga practice and create peaceful atmospheres.

## Recent Conversation (June 26, 2023)
- Deborah preparing for yoga retreat with friends; seeking peace and connection with like-minded people
- Jolene working on engineering internship, feeling intense but determined; had breakthrough on project
- Shared new photos: snake Seraphim (Jolene's pet, 1 year old), yoga poses, nature scenes, project drawings
- Jolene appreciates retreats as ideal for finding refreshment; values peaceful time for relaxation
- Both continue to support each other through challenging times

## Recent Conversation (August 16, 2023)
- Jolene shares feeling overwhelmed juggling engineering, relationship with bf, and personal growth
- Started bullet journal for time management - finds it helpful for tracking tasks and staying organized
- Shares photos: book with checklist, bullet journal spread with motivating quote, group yoga on beach
- Expresses interest in trying mindfulness and destressing
- Deborah shares experience leading meditation yoga session for elderly at care home during sunset
- Both friends offer mutual support on mindfulness journey
