name: Deborah and Jolene - August 16, 2023 Conversation
description: Conversation about Jolene's work-life balance challenges and interest in mindfulness

Jolene shares a photo of a book with a checklist, mentioning she's been thinking a lot about her plans, especially after checking in with her boyfriend. She's been feeling overwhelmed trying to juggle engineering, relationship, and personal growth. She's unsure how to handle it all.

Deborah suggests that finding ways to restore balance is important and taking time for oneself while recognizing needs can make a difference.

Jolene mentions she's been trying out time management strategies and started using a bullet journal. It's been helpful for tracking tasks and staying organized. She also shares a photo of her newest spread with a quote she loves.

The quote is a reminder to stick to goals and never give up - it motivates her when she sees it.

Deborah shares a photo of a group doing yoga on a beach and mentions she led a meditation yoga session for the elderly at a local care home during sunset. She suggests mindfulness can help find peace.

Jolene hasn't tried mindfulness yet but is keen to give it a shot. She's interested in destressing and trying mindfulness, as she could use some calm in her life.

Deborah shares her own journey - started with workshops and books, now mindfulness is a huge part of her life. She offers to help Jolene get started and is happy to assist with her journey.

The conversation ends with mutual support and encouragement.
