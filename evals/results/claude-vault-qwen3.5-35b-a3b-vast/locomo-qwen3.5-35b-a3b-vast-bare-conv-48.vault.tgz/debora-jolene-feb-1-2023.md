name: Deborah and Jolene - February 1, 2023 Conversation
date: 2023-02-01

**Jolene's Updates:**
- Received a huge robotics project from her engineering professor
- Project is tough but fun, making her get creative and problem-solve
- Initially felt a mix of emotions - excited and nervous
- Now really enjoying it, like solving a puzzle
- Figuring out the best design and programming
- Finds it awesome seeing the robot come together
- Plays console with her partner (planned to play instead of resuming yoga)

**Deborah's Updates:**
- Met her new neighbor Anna at yoga in the park
- They talked about how yoga has improved their lives
- Discussed the sense of community yoga gives
- Yoga has been a positive influence on both of their lives

**Themes from conversation:**
- Engineering challenges and creative problem-solving
- Finding enjoyment in difficult projects
- Building community through shared interests like yoga
- Making time for activities together with partners
- The satisfaction of seeing projects come together
