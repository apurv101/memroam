name: Deborah & Jolene conversation
date: 2023-03-22
description: March 22, 2023 - Jolene discusses time management struggles and surfing aspirations with Deborah; introduces Eisenhower Matrix technique

## Jolene's Time Management Journey
- Using the Pomodoro Technique (25 min work, 5 min break) to avoid burnout
- Still struggling with prioritization
- Finds to-do lists overwhelming when facing big stacks of tasks
- Asked Deborah for additional time management tips

## Deborah's Recommendations
- Shared Eisenhower Matrix method for organizing tasks by urgency and importance
- Explained it sorts tasks into four boxes: urgent/important, important/not urgent, urgent/not important, neither urgent nor important
- Jolene found the visualization helpful

## Jolene's Surfing Pursuit
- Wants to learn to surf
- Has been gathering information and watching videos
- Got a beginner's guide to surfing
- Needs to find the right time and place to get a lesson
- Deborah encouraged her to take first steps and believe in herself

## Deborah's Personal Notes
- Recently spent time by the sea with Anna, watching sunset and talking
- Realized they inspire each other
- Encouraged Jolene to take it easy and look after herself

## Key Takeaways
- Both friends support each other's dreams and goals
- Deborah emphasizes that the experience matters as much as the end result
- Jolene feels encouraged to keep pushing forward with her surfing goals