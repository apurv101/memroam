name: Deborah and Jolene - August 12, 2023 Conversation
description: Conversation on 8:50 pm August 12, 2023 about Jolene's notebook designs and aerial surveillance project.

## Deborah's Yoga Retreat Preparation
- Made a meditation guide for her upcoming yoga retreat

## Jolene's Recovery from Setback
- Had been stressed after losing work files
- Was overwhelmed by the loss
- **Meditation practice** helped her:
  - Stay calm and chill
  - Regain clarity
  - Feel gratitude for the support and practice

## Jolene's Notebook Design Project
- **Created two notebooks with blue covers and white strips**
- **Design elements inspired by:**
  - Love for space
  - Love for engines
  - Galaxies
  - Circuitry
- Deborah admired the creativity and artistry

## Art and Engineering Connection
- Jolene's perspective: Seeing art and design in various things gives unique perspective on problems
- Deborah noted that creativity seems to inspire her engineering projects

## New Engineering Project
- **Prototype for aerial surveillance system**
- **Goals:**
  - More productive
  - More affordable
  - Help with emergency response
  - Help with environmental monitoring
- **Aim:** Make the world better and safer
- Working on this project currently, eager to see results

## Key Themes
- Mutual support and encouragement
- Self-care practices (meditation) helping through adversity
- Creativity and engineering intersecting
- Ambition to make a positive difference
- Friendship and collaboration

## Conversation Tone
- Supportive, warm
- Encouraging
- Jolene open and sharing
- Deborah consistently affirming and supportive