name: Deborah and Jolene - January 27, 2023 Conversation
date: 2023-01-27

**Deborah's Update:**
- Her father passed away suddenly two days ago (around January 25, 2023)
- Her family is dealing with grief and trying to be supportive of each other
- She's trying to channel her grief by spending more time with family and cherishing memories
- Photos bring her peace during difficult times
- Her parents were married in 1993 and were a beautiful couple
- She and her husband are trying to be as good a family as her parents were
- Love and openness are what keep her relationship strong
- Yoga group members sent her a letter thanking her for her positive influence on them
- Her passion for yoga comes from helping others find peace
- She practices yoga in her old home, in a spot by the window where her mother used to sit and read every night
- Her mother was a reader and traveler; that window seat was one of her favorite places
- She visits her mom's old house sometimes to stay connected

**Jolene's Updates:**
- Has two snakes: Susie and Seraphim
- Snakes calm her down and make her happy
- Played video games with her partner (boyfriend) last week, played "Detroit"
- They're planning to play "Walking Dead" next Saturday
- Learned to play video games on her own as a child
- Both she and her partner are crazy about video games
- Bought her snake a year ago in Paris
- Shows how pets bring happiness into her life

**Themes from conversation:**
- Both women dealing with loss and finding comfort in memories
- Deborah's grief over her dad's sudden death
- The importance of cherishing family memories during difficult times
- How physical spaces and objects hold sentimental value
- Pets and hobbies as sources of comfort and joy
- Community support through letter from yoga group members
- Shared values of being there for each other
