name: Deborah and Jolene - Conversation
description: Conversation transcript from February 9, 2023 at 9:03 pm
---

## Date: February 9, 2023 (9:03 pm)

### Summary
Jolene shared with Deborah about a mini retreat she did last Wednesday (around February 1, 2023) to assess where she's at in life. She gained confidence and a new outlook from the experience.

### Key Topics Discussed

**Mini Retreat Experience:**
- Jolene achieved more than she imagined
- It was a real confidence boost
- Gave her a new outlook on life

**Engineering Project:**
- She accomplished something with her engineering project
- Came up with neat solutions
- Very excited about the progress

**Green Tech Interest:**
- Interested in how green tech could make a difference in disadvantaged areas
- Wants to explore how she can contribute

**STEM Volunteer Program Idea:**
- Concept: A volunteer program where engineers teach STEM to underprivileged kids
- Planning to team up with local schools/centers to do workshops
- Considering inviting engineers as guest speakers to show kids career options
- Haven't finished planning yet
- Wants to solidify the plan before reaching out to schools/centers

**Notes:**
- Jolene shared a photo of her planner/notebook with sketches and notes about this initiative
