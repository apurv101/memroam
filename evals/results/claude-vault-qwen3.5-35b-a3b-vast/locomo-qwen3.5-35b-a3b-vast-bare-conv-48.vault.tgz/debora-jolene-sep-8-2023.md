name: Deborah & Jolene - September 8, 2023 Conversation
description: Rescheduling coffee date to Friday at 5; Jolene will sort books; Deborah asked for book recommendations
---
**Date:** September 8, 2023, 7:39 pm

**Participants:** Deborah, Jolene

**Summary:**
Deborah and Jolene rescheduled their coffee date from Wednesday to Friday at 5. Jolene mentioned she needs to sort books from her bookcase to be free. Deborah asked Jolene to bring interesting books.

**Key Points:**
- Deborah had a tough week; storm forced cancellation of yoga getaway
- Deborah found comfort in work and home time; feeling better
- Jolene and partner plan camping trip to connect with nature and practice yoga
- Jolene uses routine/schedule for classes, studying, personal time; self-care activities (yoga, meditation) help balance
- Originally planned to meet at a coffee shop next Wednesday at 4
- Deborah had conflicting plans for that day
- Rescheduled to Friday at 5
- Jolene mentioned sorting books from bookcase as preparation
- Deborah asked Jolene to grab interesting books for her

**Photos Shared:**
- Jolene: Photo of coffee shop with coffee machines
- Jolene: Photo of person holding coffee in front of flowers
- Deborah: Photo of group of people at tables in a room (reminded of hidden coffee shop near her)
- Jolene: Photo of room with bookshelf and ceiling fan

---
