name: Deborah's Yoga Props and Setup
description: Deborah's equipment and setup for her yoga practice.

Deborah uses props for her yoga class. She also bought a candle with rosemary on it for the atmosphere and to improve her yoga practice. She creates a serene space with candles and essential oils to add warmth and calm to her sessions.

Date noted: March 28, 2023
