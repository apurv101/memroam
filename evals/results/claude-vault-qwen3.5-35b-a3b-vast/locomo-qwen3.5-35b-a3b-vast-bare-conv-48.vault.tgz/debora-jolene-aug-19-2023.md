name: Deborah and Jolene - August 19, 2023 Conversation
description: Conversation about video games, yoga events, and Deborah's special bench with her late mother

Deborah tells Jolene about telling Anna "the story of her life" last Friday (August 11), and how meaningful it was to have that connection.

Jolene shares she bought a black Xbox console for her partner on August 17 as a gift - her partner even managed to play it! Engineering studies are going strong, and she's been focusing on balance between hobbies and studies.

Deborah has been teaching yoga and organizing community events. She organized a yoga event last month (July) with yoga, food stalls, and live music - reached out to local businesses to make it happen.

Jolene asks Deborah about balancing hobbies and studies. Deborah's advice: prioritize, manage time effectively, make a schedule, and set aside specific time for both studying and hobbies.

They discuss video games:
- Jolene recommends: Zelda BOTW (Switch open-world), Animal Crossing: New Horizons (calming/cute), Overcooked 2 (co-op, hilarious/chaotic cooking)
- Jolene mentions playing Overcooked 2 with her partner for bets and once won three large pizzas
- Deborah used to play games with her late husband - they preferred detective games together
- They also enjoyed spending time outdoors and exploring nature together

Deborah shares about her special park spot near her house with a forest trail and beach. There's a special bench there with deep meaning:
- She and her mother would come here to chat about dreams and life
- They once watched a beautiful sunset together in silence - the sky colors were so special
- The bench holds lots of special memories with her mom
- Every time she returns, she feels peace and gratitude for the time they had

Jolene shares a photo of the bench (in the park with a tree in the background) and then a photo of someone sitting on the bench in the forest. Both agree on how calming and peaceful nature can be.

Conversation ends with mutual appreciation for cherishing memories and finding peace/gratitude in special places and moments.
