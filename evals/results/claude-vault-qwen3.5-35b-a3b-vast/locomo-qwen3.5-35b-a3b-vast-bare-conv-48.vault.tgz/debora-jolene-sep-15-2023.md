name: Deborah & Jolene - September 15, 2023 Conversation
description: Deborah reconnects with mom's old friends, shares emotional stories and special memories; discusses yoga, surfing, and their pet companions.
---
**Date:** September 15, 2023, 3:09 pm

**Participants:** Deborah, Jolene

**Summary:**
Deborah shares an emotional journey reconnecting with her mother's old friends, hearing stories that deepened her appreciation for her mother. The conversation flows through shared interests in yoga, meditation, peaceful environments, and Jolene's pet snake.

**Key Points:**

### Deborah's Mom Reconnection
- Deborah reconnected with her mom's old friends
- Hearing stories about her mom was emotional - a mix of happiness and sadness
- It was both happy and sad to hear things she hadn't heard before
- Overall comforting experience to reconnect with her mom's friends
- Through their eyes, she gained a deeper appreciation for her mom
- They reminisced and looked through old photos together
- These stories gave her a glimpse into her mom's life beyond what she knew

### Beach Memories & Surfing
- Deborah shared a photo of a special beach - where she got married
- This is also where she discovered her love for surfing
- The beach is always filled with joy and peace for her
- Pictures bring back memories and remind us of strong love and amazing human relationships

### Yoga & Meditation Practice
- Deborah does yoga on the beach, finding it super relaxing
- The ocean, sand, and fresh air create a peaceful atmosphere
- She believes this is the perfect way to take care of herself
- Jolene creates serene yoga spaces with candles and oils
- Jolene mentioned trying a new meditation style in Thailand with flowers
- Both agree that environment enhances their practice
- Creating a safe, chill space is key to their routines
- Jolene relaxes in her room - her "little haven for peace and rest"
- She uses essential oils and soft, soothing music to center herself
- Jolene finds calm through yoga and meditation

### Jolene's Pet Snake
- Jolene has a pet snake named Susie (also called Seraphim)
- She's had Susie for two years now
- Susie is a great companion who brings comfort
- Pets make life brighter and give priceless love

### Shared Appreciations
- Both value how photos and memories deepen appreciation for loved ones
- They agree that our surroundings affect our mood and how much zen we get from routine
- They appreciate the special bond between friends and loved ones
- Both recognize the power of love and human relationships

**Photos Shared:**
- Deborah: Living room with couch and fireplace
- Deborah: Two women in pajamas taking a mirror selfie (Deborah and her mom)
- Deborah: Person walking on beach with surfboard
- Deborah: Woman doing yoga pose on beach
- Jolene: Two towels on a table (her serene yoga space setup)
- Jolene: Snake in a container (Susie/Seraphim)

---
