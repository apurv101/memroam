name: Conversation between Deborah and Jolene
description: Conversation from Feb 22, 2023 - discussing dinner, garden, grieving, and travel memories
---
**Jolene:** [shares a photo: a photo of a plate of food and a glass of wine] Hey Deborah, totally buzzing! Had a great night out last night - dinner, and drinks with my friends. So glad I got to let my hair down. You?

**Deborah:** [shares a photo: a photo of a garden with a bunch of flowers in buckets] Sounds great, Jolene! I just visited this place and it was so calming. Nostalgic too.

**Jolene:** Wow, those flowers are beautiful! What type are they? It looks so peaceful there.

**Deborah:** The roses and dahlias bring me peace. I lost a friend last week, so I've been spending time in the garden to find some comfort.

**Jolene:** Sorry to hear about your friend, Deb. Losing someone can be really tough. How are you holding up?

**Deborah:** Thanks for the kind words. It's been tough, but I'm comforted by remembering our time together. It reminds me of how special life is.

**Jolene:** Memories can give us so much comfort and joy.

**Deborah:** [shares a photo: a photo of two women are riding on a motorcycle on a dirt road] Memories keep our loved ones close. This is the last photo with Karlie which was taken last summer when we hiked. It was our last one. We had such a great time! Every time I see it, I can't help but smile.

**Jolene:** Wow, looks like a great trip! Where else have you traveled?

**Deborah:** [shares a photo: a photo of a swing on a beach with a blue sky] I've been blessed to travel to a few places and Bali last year was one of my favs. It was a gorgeous island that gave me peace, great for yoga.

**Jolene:** Wow, that's great! Is yoga on the beach a thing? I've been wanting to try it.

**Deborah:** The sound of the waves and the fresh air is wonderful!

**Jolene:** I'll definitely give it a go! It sounds peaceful. Thanks!

**Deborah:** Let me know how it goes. Enjoy it!

**Jolene:** I'll keep you posted if I decide to go there.

**Deborah:** Take care!
