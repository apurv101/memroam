name: debora-jolene-sep-17-2023
description: Deborah & Jolene chat on Sep 17, 2023

Deborah:
- Ran a free gardening class with her neighbor yesterday that was awesome - people of any age joined
- Visited her mom's old house last Sunday - very comforting experience, felt her mom's presence
- Mom was passionate about cooking, would make amazing meals full of love and warmth
- Mom baked pineapple birthday cakes for Deborah when she was a kid
- Has a big bookshelf
- Has a cozy bathroom nook with black and white walls and wooden stool - likes relaxing with books there
- Tries surfing (has tried it based on photo shared)

Jolene:
- Tried scuba diving lesson last Friday, had an awesome time
- Found a cool dive spot they can explore together
- Hopes to become a certified diver someday
- Bakes cookies with someone close to her (chocolate chip cookies are favorite)
- Has an aesthetically nice bathroom where she read a self-discovery book that resonated
- Has never tried surfing but has interest, just started learning
- Sharing photos including: a book on bed, a palm-tree painted surfboard

They discussed:
- Dealing with memories and how cooking brought families together
- The importance of cozy spaces for reading and relaxation
- Surfing as an activity - Deborah has tried it, Jolene hasn't yet but is interested
- Planned to try surfing together sometime in the next month - Deborah is really excited
