name: Jolene
description: Engineering friend who completed a solar vehicle project, now interning at engineering firm

## Major Achievement (Feb 2023)
- Built a sustainable water purifier for a rural community in need
- It was tough but loved the experience
- Seeing it work providing clean water was surreal and incredibly satisfying
- Made her feel like she had a purpose and had done something good
- February 2023: Did a mini retreat (around Feb 1) to assess where she's at in life. Achieved more than imagined, gained new outlook and confidence boost


## Career Aspirations
- Wants to continue working in engineering
- Interested in green tech solutions for disadvantaged areas
- February 2023: Developing an idea for a volunteer program where engineers teach STEM to underprivileged kids (planning to partner with local schools/centers, considering guest speakers)

- Goal: Make positive impact on communities in need by creating sustainable solutions
- Wants to contribute to making the world a better place with her work

## Books Read
- "Sapiens" - fascinating look at human history and how technology has affected us
- "Avalanche" by Neal Stephenson - read in one sitting (Feb 2023)

## Nature & Travel
- Beach in Bogota (vacation last summer before Feb 2023) - beautiful and calming, sunset over the water

## Emotional State
- Was on an emotional rollercoaster (Feb 2023) but coping

## Friend Connection
- Deborah is a supportive friend who encourages her passions and goals

## Recent Activities (April 2023)
- Been working on a big project - tough but cool to watch it take shape
- Can't wait to see the final result
## Solar Vehicle Project (June 2023)
- Completed a tough engineering project involving a solar-powered vehicle
- The engineering was challenging but proud of sticking it out and finishing
- Final result has a solar panel on the back
- Big milestone achievement

## Current Internship
- Now interning at a well-known engineering firm
- Great opportunity to test skills and gain real-world experience
- Best part: applying what was learned in school to real projects
- Fulfilling to see ideas come to life
- Has positive impact: stoked love of engineering and encouraged striving for dreams
- Inspiration from working with passionate colleagues
- Has shown that dedication and effort make anything possible
- Struggles with work-life balance - finds it hard to make time for hobbies and relaxing
- "Slogging away" during the internship

## Yoga & Meditation
- Doing yoga and meditation sporadically for about 3 years
- Had a real positive effect on life
- Helps with stress management and keeps centered
- Practiced yoga on mount Talkeetna (photo shared)
- Considers it essential for survival

## Deborah's Connection
- Deborah is a supportive friend who encourages her passions and goals
- Deborah recommended mindful breathing practice for yoga
- Snakes are a way to be in tune with myself

## Pets
- Has a snake named Seraphim (also referred to as Susie) - acquired about 2 years ago (September 2021)
- Purchased a new aquarium for her snake 2 days before a June 2023 conversation
- Snake brings comfort, joy, and a sense of peace
- Snakes are a way for her to be in tune with herself
- Seraphim/Susie enjoys watching her practice yoga and chill

## Recent Conversation (August 26, 2023)
- Discussed incorporating personal values into engineering work
- Values learned from her mother: persevere, stay resilient, never give up, help others
- Future goals: work on projects that make a real difference to communities
- Specific interests: sustainable initiatives, renewable energy (especially solar), clean water projects, social causes
- Shared yoga photo and discussed yoga/meditation practice with partner
- Plans to go on a meditation retreat together with partner

## Current State (June 2023)
- Feeling intense and overwhelmed with internship and projects
- Pushing herself to succeed, determined to overcome obstacles
- Had a breakthrough on a big project (engineering-related - drawing of a house with ruler)
- Describes the work as "tough" but exciting and rewarding
- Appreciates peaceful environments and considers retreats ideal for finding refreshment


## Project Setback (August 2023)
- Early August 2023: Experienced a huge project setback
- Put in significant work but everything crashed
- Lost all progress and data
- Found it very frustrating and depressing
- Coping mechanisms during this time:
  - Spending time with snake (Seraphim/Susie)
  - Playing video games for distraction
  - Continuing yoga and meditation practice for balance
  - Relying on friends like Deborah for support

## Recent Support (August 2023)
- Deborah starting a community cleanup project and raising funds
- Shared yoga practices and routines to help during tough times
- Deborah sent yoga tutorial with poses focusing on breathing and grounding
- Jolene appreciates the support and plans to practice the yoga routine
- Both friends continuing to support each other through challenges

## Current State (August 16, 2023)
- Feeling overwhelmed trying to juggle engineering, relationship with bf, and personal growth
- Unsure how to handle everything when it feels too much
- Started using a bullet journal for time management and task tracking
- Finds bullet journal satisfying when crossing tasks off list
## Photography & Art
- Hasn't tried mindfulness yet but is keen to give it a shot
- Interested in destressing and trying mindfulness to find calm in her life
- Values Deborah's support and offers to help on mindfulness journey

## Project Setback (August 2023)
- Enjoys capturing nature photos (shared photos of snake in plant-filled areas)
- Created a drawing of a house with ruler (engineering project)
- Shares photos as a way to connect with friends
- Playing video games with partner after long day is a great way to relax and bring them closer together

## Recent Conversation (September 3, 2023)
- Going through finals this month - studying hard, feeling stressed but worth it
- Planning to take a trip somewhere to relax and recharge after finals
- Parents got her a Nintendo game console at age 10, which started her passion for video games
- Taught herself to play but her dad was supportive and mom played games with her
- Favorite game: "Monster Hunter: World" - loves the immersive story and open-world gaming
- Uses gaming as a way to de-stress and take a break from life

## Recent Conversation (September 6, 2023)
- Signed up for a meditation course at a retreat near a lake
- Looking forward to sharing the experience with her partner and learning new techniques
- Working on studies and a project that's tough but she's chugging along
- Enjoys beach walks and sunrise viewing - they help her relax and stay balanced
- Expressed desire to watch sunrise together with Deborah someday
## Recent Conversation (September 12, 2023)
- Last weekend (early September 2023): Traveled to a meditation retreat in Phuket with partner for a few weeks
- Amazing experience with nature, reflection, and break from engineering studies
- Helped find inner peace
- Realized importance of incorporating relaxation, self-care, and balance in life alongside engineering studies
- Beauty of nature was inspiring and refreshing
- Key session: releasing expectations and judgments, savoring the present
- Learned to appreciate the journey, not just the finish line
- Usually too consumed with hitting goals and forgets to appreciate the ride
- Now trying to be more mindful and grateful, appreciating small wins (feeling of sun, great coffee)
- Experiencing a new level of joy and happiness!
- Looking forward to meeting Deborah to play a card game about cats (take cards one by one from deck, attack opponent with them)

## Beach Memories
- Has a special beach where she got married
- Discovered her love for surfing there
- The beach is always filled with joy and peace for her
- Pictures from the beach remind her of strong love and amazing human relationships