name: Dave and Calvin - Friendship
description: Dave and Calvin are friends who catch up regularly and share mutual interests. Dave turned his childhood passion for working on cars into his career.

Dave and Calvin are friends who regularly catch up with each other. They have a friendly rapport and enjoy sharing things with each other - photos, stories, and experiences.

Their shared interests include:
- Cars: Dave now works as a car restoration specialist, doing as a job what was his childhood passion; Calvin has a red sports car
- Music: Both enjoy music; Calvin and his dad used to sing "California Love" on road trips
- Creating together: They planned a jam session together and expressed excitement about creating something special

They seem to have a positive, supportive friendship where they're happy to celebrate each other's accomplishments and provide encouragement during setbacks (like Dave's car trouble).