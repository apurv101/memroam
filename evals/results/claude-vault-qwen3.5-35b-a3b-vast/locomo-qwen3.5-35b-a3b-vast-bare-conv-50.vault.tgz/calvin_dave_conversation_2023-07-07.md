name: Calvin & Dave - July 7, 2023
description: Conversation from July 7, 2023 about Calvin's car accident recovery, Japanese mansion life, and music collaborations

---

Dave asked Calvin about his car after the crash. Calvin shared that it's fixed and going strong, and he's excited to be back on the road.

Dave mentioned hanging out with friends at parks, arranging regular walks together with friends. He shared a photo of a city skyline with a river and boats, saying they were going to that spot.

Calvin responded with a photo of a boat docked in a canal at sunset, commenting on the beautiful view. He mentioned living in his Japanese mansion with an epic cityscape, sharing a photo of the mansion from his backyard. Calvin expressed how awe-inspiring it is to see the city lights through the windows, describing it as "luxury and beauty on a whole new level."

Dave praised the mansion and asked if Calvin was looking forward to anything else in Japan. Calvin said he can't wait to try the food and check out the culture. Dave shared he's never been to Japan but is keen to go, mentioning he's "hooked on their music."

Calvin mentioned working on music collaborations with Japanese artists and can't wait to share the results. He described collaborating with various artists as exciting and a chance to create something unique.

The conversation ended with mutual well-wishes, with Dave telling Calvin not to overwork and Calvin having to get back to work.