name: Calvin's Japan Trip
description: Calvin's upcoming trip to Tokyo in November 2023 after his Frank Ocean tour

Calvin is planning to visit Tokyo in November 2023 after his tour with Frank Ocean ends. He met Frank Ocean at a festival in August 2022, and they've been touring together since then.

Calvin is excited to visit specific locations in Tokyo:
- Shibuya Crossing (which he calls "Tokyo's Times Square")
- Shinjuku
- He wants to try authentic ramen in Tokyo

This upcoming trip builds on his previous experiences in Japan. He's already looking forward to the food and exploring the city's vibrant life.