---
id: 01a050a5-ad84-7b4e-90c1-17fa345bf56a
name: Dave
description: Friend who opened a car maintenance shop
---

# Dave - Friend & Car Enthusiast

## Key Information
- **Major Life Event (early May 2023)**: Opened his own car maintenance shop after celebrating with friends
- **Recent (June 2023)**: Joined a rock band and has been practicing guitar
- **Passion**: Classic cars - restoration and design/engineering
- **Recent (October 2023)**: Attended a conference in Detroit, learned a lot
- **New Interest**: Rock music and playing guitar
- **Current Work**: Automotive engineer working on car projects
- **Photography**: Does car photography, including photos of people washing cars in a garage
- **Business**: Works on all kinds of cars from regular maintenance to full restorations
- **Dreams**: 
  - Primary: Work on classic cars
  - Already achieved: Opened his car maintenance shop

## Notable Achievements
- Restored a classic car last year (described as "bringing it back to life")
- Hard work and dedication paid off
- Finds satisfaction in seeing transformations and helping people keep cars in good condition

## Character Traits
- Passionate about his craft
- Dedicated and hardworking
- Values seeing his skills and hard work make a difference
- Likes to share photos of his work
- Encouraging to friends
- Exploring new musical interests through rock band
- Car work calms him down and helps him "get out of his head"
- Father took him to his first car show at age 10 - that's when he got hooked on cars

## Friendship with Calvin
- Old friends who haven't seen each other in a while
- Support each other's dreams and encourage one another
- Regularly share photos and life updates
- Motivate each other through the challenges
- October 2023: Dave advised Calvin to visit Boston, which Calvin enjoyed
- Dave shared a photo of his car project work
- Both express their passions (music/art, cars) as sources of fulfillment and purpose