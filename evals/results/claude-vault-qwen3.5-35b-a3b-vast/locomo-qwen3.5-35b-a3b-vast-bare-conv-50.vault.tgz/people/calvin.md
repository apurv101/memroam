---
id: 01a050a5-b6ca-7b74-97de-a4a4a8c79b88
name: Calvin
description: Friend who is a musician
---

# Calvin - Musician & Supportive Friend

## Key Information
- **Profession**: Musician
- **Passion**: Making music and creating art
- **Believes**: Hard work and dedication pay off
- **Values**: Creating things from scratch, seeing work resonate with people, supporting the next generation
- **October 2023**: Visited Boston with a high school friend - enjoyed architecture and history
- **November 2023**: Invited high school friend to Boston performance; began supporting young musicians from music program
- **Upcoming (May 2023)**: Performance in Tokyo
- **Upcoming (June 2023)**: Tour with Frank Ocean
- **New Residence**: Small town in Japan with stunning mountain views

## Notable Items
- Owns a beautiful gold necklace with diamond pendant
  - Gift from another artist
  - Reminder of why he keeps hustling as a musician
- Music gear and favorite microphone (saved during flood incident in May 2023)
- Red sports car (for relaxation and long drives)
  - Had a minor accident in mid-June 2023
  - Repairs completed after about a week of insurance process

## Friendship with Dave
- Old friends who haven't seen each other in a while
- Support each other's dreams enthusiastically
- Regularly share photos of their lives/work
- Give encouragement and motivation
- Remind each other of "why we're doing it" when the road gets hard
- October 2023: Calvin visited Boston (following Dave's advice) and enjoyed it
- Calvin shared a photo of performing with someone he admires - described it as a "dream come true"
- Both express music/art as their "passion and purpose"

## Character Traits
- Encouraging and supportive
- Appreciates ambition and dedication
- Values friendship and mutual support
- Expresses himself through photo sharing
- Motivational - "Keep on keepin' on, bud!"
- Stays positive despite challenges (flood incident in May 2023, car accident in June 2023)
- Adventurous - planning to try skiing

## Key Themes He Emphasizes
- Dreams are important and worth pursuing
- Hard work and passion are a great blend
- Making a difference in people's lives is rewarding
- Remembering why you started helps keep going
- Embracing new experiences and challenges (skiing, living abroad, music)
- Supporting the next generation of artists is like passing on a torch
- Having a supportive network is essential for artist development and staying true to yourself