name: Calvin and Dave conversation
description: Conversation from 4:45 pm on 26 March, 2023 between Calvin and Dave
---
## Calvin's Updates
- Calvin got a new luxury car - a red sports car, which was a dream come true after hard work
- Calvin wrote new tunes and had studio sessions last week
- Excited about upcoming collaborations
- Describes the car as "super smooth and real powerful" - an "adrenaline rush"

## Dave's Updates
- Dave attended a music festival in Boston last weekend
- Found the atmosphere electric with many cool bands
- **Favorite band**: Aerosmith - saw them live for the first time
- Dave's favorite band was Aerosmith
- Didn't get to hang out with the performers after the show

## Future Plans
- Calvin plans to share new music and collaborate with others
- Dave offered to keep updated on Calvin's collaboration progress