---
id: 01a050a7-f692-7e37-96b7-cd27c0c6d616
name: Calvin & Dave - August 22, 2023
description: Calvin secured Frank Ocean collaboration deal; performed at Tokyo music festival; podcast recorded with friends
---

# Calvin & Dave Conversation - August 22, 2023

**Date:** August 22, 2023 (11:06 am)

## Dave's Updates
- Had a card night with friends last Friday (August 18, 2023)
- Shared a photo of the group at the table with playing cards
- Launched and enjoyed the gathering with friends

## Calvin's Updates
### Frank Ocean Collaboration
- Secured a deal to continue collaboration with Frank Ocean
- Described it as a dream come true
- Met Frank Ocean at a music festival in Tokyo
- They clicked and started sharing ideas
- Arranged a meeting and recorded a song in the studio at Calvin's mansion

### Tokyo Music Festival
- Performed at the festival in Tokyo
- Festival had buzzing energy with a super upbeat crowd
- Described the experience as "fuel for my soul"
- Shared a photo of the crowd sitting on the grass at night
- Someone noticed his performance and they're now working together

### Future Plans
- Tour is ending soon
- Heading to Boston
- Invited Dave to meet up when he arrives in Boston

### Podcast Recording
- Recorded a podcast with friends about the rapidly evolving rap industry
- Discussing the podcast content with Dave
- Will let Dave know when it's uploaded

## Notes
- Both agreed to stay in touch
- Dave is looking forward to hearing more about the podcast
- Plans to meet up in Boston when Calvin's tour ends