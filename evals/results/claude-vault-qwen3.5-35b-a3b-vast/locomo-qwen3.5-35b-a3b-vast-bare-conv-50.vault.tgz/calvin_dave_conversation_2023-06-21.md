---
id: 01a050a5-b6ca-7b74-97de-a4a4a8c79b89
name: Calvin & Dave - June 21, 2023
description: Conversation from June 21, 2023 about Calvin's car accident recovery and Dave's rock band
---

# Calvin & Dave Conversation - June 21, 2023

**Date:** 3:15 pm on 21 June, 2023

## Calvin's Recent Experiences

### Car Accident and Repairs
- Had a car accident last Friday (around June 15, 2023)
- The accident was upsetting but no one was hurt
- Spent time dealing with insurance and repairs
- Insurance process was a hassle with lots of paperwork
- Took about a week to sort everything out
- Cost wasn't too bad
- Photo shared: red car with black rim parked on sidewalk
- Photo shared: tow truck parked in parking lot
- Photo shared: mechanic working on car in garage

### Mechanic
- Skilled and knowledgeable
- Calvin trusts their expertise
- Doing their best to get the car running again

### Living Situation
- Calvin now has a view from his living room
- Located in a small town in Japan
- Mountain views described as "unbelievably stunning"
- Photo shared: view of small town with mountain in background

### Travel Plans
- Hasn't been to Japan before
- Plans to visit after his tour with Frank Ocean ends
- Has a small town in Japan on his to-do list
- Interested in skiing (hasn't tried it before)
- Photo shared: person on skis on snowy mountain

## Dave's Recent Activities

### Rock Band
- Recently joined a rock band
- Practicing guitar
- Photo shared: group of men playing instruments in a room
- Says good company and great music lift mood and bring positive emotions

## Photos Shared by Calvin
1. Red car with black rim on sidewalk (after accident)
2. Tow truck in parking lot
3. Mechanic working on car in garage
4. View from living room - small town in Japan with mountain
5. Person on skis on snowy mountain

## Key Themes
- Overcoming challenges (car accident)
- Trusting expertise of others
- Anticipation and excitement for future experiences
- Supportive friendship with shared encouragement
- Work-life balance (music, repairs, travel)

---
*Memories from this conversation.*