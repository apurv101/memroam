---
id: 01a050a7-f692-7e37-96b7-cd27c0c6d617
name: Calvin & Dave - August 31, 2023
description: Calvin shared tour highlights, announced new album video shoot in Miami, discussed custom octopus guitar and unique style
---

# Calvin & Dave Conversation - August 31, 2023

**Date:** August 31, 2023 (2:55 pm)

## Dave's Updates
- Reached out to Calvin after a long time
- Enthusiastic about Calvin's tour
- Shared a photo of a guitar with an octopus on it

## Calvin's Updates
### Tour Experience
- Completed a tour that was amazing
- Felt pumped from all the energy from the audience
- Performing on a big stage was a dream come true
- Described the experience as incredible energy and surreal
- Felt "on top of the world" during performances

### New Album Video
- Started shooting a video for his new album last weekend
- Video is being shot on location in Miami
- Picked an awesome beach location
- Expected to have epic visuals in the video
- Enthusiastic about the Miami vibe for the shoot
- Open to help from Dave with props or assistance

### Custom Guitars
#### Octopus Guitar
- Has a custom guitar with an octopus design
- Custom made by his Japanese artist friend
- Represents his love for art and the sea
- One of his favorite instruments
- Means a lot to him as a reminder of his passion for music
- Symbolizes the amazing friendships he's made

#### Purple Glow Guitar
- Has a custom guitar with a purple glow
- Got it customized with a shiny finish
- Chose the shiny finish for a unique look
- Goes with his personal style
- Describes it as totally his style

### Personal Philosophy
- Values staying true to himself
- Puts emphasis on being unique in his music
- Appreciates when others notice and support his unique style
- Views each mark and strum as holding a story
- Sees his journey and friendships reflected in his instruments

## Notes
- Dave and Calvin have a close friendship
- Dave offers ongoing support for Calvin's creative endeavors
- Calvin appreciates Dave's encouragement and support
- Both value authenticity and unique artistic expression
- Dave continues to be excited about Calvin's work and creative process
