name: Calvin-Dave October 23, 2023 Conversation
description: 2023-10-23 - Calvin discusses Frank Ocean tour challenges, car restoration passion, and using art as therapy

Dave and Calvin discussed:

Calvin's Tour Experience:
- Performing with Frank Ocean has been "incredible" and "energizing"
- Fame comes with challenges in balancing job and personal life
- Calvin takes it "one day at a time" but admits it can get overwhelming
- Strong support system of friends and team keeps him on track

Calvin's Creative Process:
- Staying connected to world events helps his music stand out
- Recent inspiration from people's struggles makes him dig deeper into his music
- Music serves as therapy - a way to express himself and work through emotions
- Uses music to share experiences and feelings with fans

Dave's Car Restoration Passion:
- Has been working on cars since age 10
- Started by finding an old car in a neighbor's garage and asking to fix it
- Loves transforming broken-down cars into high-running vehicles
- Last year restored a car and sold it to a collector
- Currently working on a new, challenging project
- Finds car working to be an outlet and "oasis of calm"
- Values having tools in place and attention to detail

Shared Philosophy:
- Both value attention to detail in their respective crafts (music and cars)
- Believe "little things can make a big impact"
- Appreciate how art/music reflects the world and connects people

Concert Connection:
- Both share appreciation for concert atmosphere and crowd energy
- Calvin: "Concerts are what I live for - the indescribable connection between the artist and the crowd is just amazing!"
- Dave notes how music creates memories and brings people together
- Both find the energy at concerts "unbeatable" and "electrifying"