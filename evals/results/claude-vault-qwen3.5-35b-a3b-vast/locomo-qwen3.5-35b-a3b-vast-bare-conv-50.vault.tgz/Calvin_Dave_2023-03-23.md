name: Calvin and Dave conversation
description: Conversation from 11:53 am on 23 March, 2023 between Calvin and Dave
---
## Calvin's Life Updates
- Calvin had a major life change and moved into a new mansion
- Calvin is fascinated by Japanese culture and traditions

## Calvin's Japan Trip Plans
- **When**: Heading to Japan the next month from 23 March 2023
- **Duration**: A few months
- **Accommodation**: Nice place arranged by an agent
- **Plans in Japan**:
  - Explore the city
  - Try local cuisines
  - Collaborate with local musicians
- **After Japan**: Plans to go to Boston
- **Prior travel**: Never been to Japan before

## Dave's Updates
- Attended an inspiring classic car event
- Has been spending time at a beautiful park with a lake and boats (shared a photo)

## Future Plans
- Dave recommended the park to Calvin to visit when Calvin returns from Japan
