name: Calvin and Dad - California Love
description: Calvin's childhood memory with his dad singing "California Love" during road trips

Calvin has a warm childhood memory involving his father and music. They used to take road trips together and would sing along to "California Love" by Tupac and Dr. Dre. This song always makes Calvin smile when he thinks about it.

He describes these road trips as a time when "we had so much fun singing along" to the song. This memory represents family bonding and positive childhood experiences.

Dave and Calvin bonded over this music memory, and Calvin mentioned that they could jam some music together - they both agreed it would be awesome to have a jam session.