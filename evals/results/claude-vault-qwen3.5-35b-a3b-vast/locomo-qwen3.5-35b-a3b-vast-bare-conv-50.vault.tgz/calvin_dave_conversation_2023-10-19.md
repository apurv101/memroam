name: Calvin-Dave October 19, 2023 Conversation
description: 2023-10-19 - Calvin discusses his Frank Ocean tour, Tokyo performance, and upcoming travel plans

Calvin updates Dave about his ongoing tour with Frank Ocean, describing it as amazing with incredible crowd energy. They discuss:

- The tour began in August 2022 when they met at a festival
- Calvin performs in front of large crowds with amazing energy
- A recent performance was in Tokyo where the crowd energy was "nuts"
- Calvin is excited about performing with Frank Ocean, calling it a "dream come true"

Dave shares photos of busy streets and crowded city life. Calvin mentions he's actually going to visit Tokyo next month (November 2023) after the tour ends.

Specific Tokyo plans Calvin shares:
- Shibuya Crossing (which he calls "Tokyo's Times Square")
- Exploring Shinjuku
- Trying authentic ramen (he hasn't had it yet but is looking forward to it)

The conversation ends with Dave encouraging Calvin to try the ramen and Calvin expressing gratitude before signing off.
---
Calvin: Hey Dave! Been a few days since we talked, but lots happened. Started touring with Frank Ocean and it's been amazing - so much energy from the crowd, such a connection when I'm on stage - unreal! Take a look at how I performed on stage, that was awesome!
Dave: Congrats, Calvin! That's awesome. Being able to play your music to a crowd and feel that connection must be unreal. How's the tour going?
Calvin: Thanks, Dave! The tour has been great, the energy from the crowd is awesome and jamming with Frank Ocean is a dream come true. It's been amazing!
Dave: Wow, Calvin! I bet performing with him is like a dream come true! How did it happen?
Calvin: [shares a photo: a photo of a band performing on stage with a projection of a man on the wall] It all started August last year when we met at a festival and he said he wanted to collaborate. We clicked right away and the chemistry on stage was incredible. I'm so lucky! Check the photo, of how we perfectly look together on stage!
Dave: Wow, Calvin - you and Frank are so in tune! It's clear you both rock on stage. Can't wait to catch your show!
Calvin: [shares a photo: a photo of a large crowd of people in a large auditorium] Thanks, Dave! I'm so excited you'll be at one of our shows. It's such a great experience, you'll definitely enjoy it! Look at this crowd, that was insane!
Dave: That sounds really exciting! Can't wait to experience it. I'm sure everyone in the crowd is going to be pumped up!
Calvin: [shares a photo: a photo of a crowd of people at a concert with their hands in the air] Wow, the crowd energy is amazing! It always gets me so pumped and it's awesome. Look at that photo, that was awesome!
Dave: Wow, Calvin, that's an awesome pic! Everyone looks so pumped. Where was that taken?
Calvin: Thanks, Dave! That pic was taken in Tokyo during a concert. Man, the energy was nuts - felt like the whole city came out!
Dave: [shares a photo: a photo of a busy street with people walking and shopping] Wow, Calvin, Tokyo looks incredible! Here's a pic I found online, and it's making me dream about visiting someday. The energy there seems unbeatable! Have you ever visited streets like that?
Calvin: Yes, Dave! That was an incredible experience to visit similar streets like you shared in your photo. Is there anything else that interests you in Tokyo?
Dave: [shares a photo: a photo of a crowded street at night with people walking and walking] Of course, Calvin! Tokyo is amazing! I want to know everything about it - the people, the culture, the food, take a walk at the vibrant city life! In the photo below, the city is so alive and colorful that's impressive! It will be an unforgettable experience!
Calvin: That photo's a great pic! The lights, the people - so lively! Can't wait to hear your emotions when you see that in person!
Dave: It's really amazing. Hope I'll get to see it in person soon!
Calvin: [shares a photo: a photo of a city at night with a tall building in the background] Cool, Dave! I'm actually going to Tokyo next month after the tour ends. Sometimes I wish I could go back to places like the one in the photo below. What a great view!
Dave: Wow, Calvin! That's great to hear! Any specific spots in Tokyo that you're really excited to check out?
Calvin: [shares a photo: a photo of a crowd of people with umbrellas in the rain] Yeah definitely! Shibuya Crossing is like Tokyo's Times Square, and I was excited to explore Shinjuku. Plus, there's amazing food there, can't wait to try it again! Look at the photo of Shibuya Crossing at night, that's amazing!
Dave: [shares a photo: a photo of a bowl of soup with broccoli and noodles] Shibuya and Shinjuku are cool spots! The food in Tokyo is great, I'll have so much fun exploring all the different places. Have you tried ramen yet? Here's a photo of a ramen bowl that I tried in Boston, it was delicious, but i think in Tokyo it will be even better!
Calvin: Thanks, Dave! Never tried it, but it's supposed to be awesome. Gonna give it a shot while in Tokyo!
Dave: Do it, Calvin! Once you try it, you'll never go back. Bon voyage and have fun!
Calvin: Thanks, Dave! I'll definitely give it a shot. Appreciate the encouragement! See you soon, bye!
---