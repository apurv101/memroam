---
id: 01a050a5-d4f2-9c81-b4e3-8f7c6d5e4a3b
name: Calvin & Dave - November 13, 2023
description: Calvin shares Boston performance with high school friend, supporting young musicians, paying it forward
---

# Calvin & Dave Conversation - November 13, 2023 (9:15 pm)

## Key Topics Discussed

### Boston Performance & High School Friend
- Calvin invited his old high school buddy to see him perform in Boston
- The trip was described as "insane" and got Calvin thinking about how far he's come
- His friend has been a great source of support and encouragement throughout Calvin's journey
- Seeing his friend brought back memories of their teenage years - freestyling and talking about getting famous
- Calvin's friend's positivity has made a significant difference in his musical journey

### Supporting Young Musicians
- Calvin has been supporting young musicians from a music program
- He finds their passion and enthusiasm inspiring
- Calvin views this as "like a torch being passed to keep music alive"
- He considers these young musicians very ambitious and plans to support them for a long time
- Calvin sees his role in paying it forward - this is how he's "making a difference"

### Studio Work & Creative Growth
- Calvin is working with a young artist, creating beats for him
- The young artist has great potential in music
- Calvin is having fun trying new sounds and pushing boundaries
- He believes in staying ahead in the music industry by exploring new ideas
- Calvin is excited about seeing where these new creative directions lead

### Core Philosophy
- Calvin values supportive relationships as key to artist development and growth
- He believes in having people who motivate you to get better while staying true to yourself
- Calvin emphasizes that growing and evolving is essential for any artist
- Both agree that experimentation and pushing boundaries are key to making art grow

## Photos Shared
1. Photo of Calvin with his high school friend on a sidewalk with a car in the background
2. Photo of a group of people sitting around a desk (musicians Calvin is supporting)
3. Photo of Calvin at his computer in his studio, making a beat for a young artist

## Conversation End
- Calvin expressed excitement about the future and new creative directions
- Dave encouraged Calvin to keep pushing himself and exploring
- Calvin signed off, saying he needed to go
