---
id: 01a050a5-c168-76f2-8390-4b0e379cdcbe
name: Dave & Calvin
description: Longtime friends who support each other's dreams
---

# Dave & Calvin - Friendship Dynamics

## Relationship
- **Type**: Longtime friends who haven't seen each other in a while
- **Communication Style**: Share photos and life updates regularly
- **Dynamic**: Enthusiastically supportive of each other's dreams

## How They Interact
1. **Photo Sharing**: Both regularly share photos documenting their lives
   - Dave shares photos of cars, shop, and restoration work
   - Calvin shares photos of his life and artistic items

2. **Encouragement**: Each celebrates the other's achievements
   - Calvin enthusiastically congratulates Dave on opening his shop
   - Dave appreciates Calvin's support and encouragement

3. **Mutual Motivation**: They remind each other of their "why"
   - Discuss how hard work pays off
   - Talk about the satisfaction of creating something
   - Keep each other going through challenges

## Shared Values
- Passion for what you do
- Hard work and dedication
- Creating things from scratch
- Helping/fulfilling others
- Pursuing dreams despite challenges

## Conversation Themes (May-June 2023)
- Dave opening his car maintenance shop
- Passion for classic cars and restoration
- Music and artistic work
- Calvin's upcoming performance in Tokyo
- The flood incident and Calvin staying positive
- The meaning behind hustling and working hard
- The reward of seeing your work come to life
- Dave joining a rock band (June 2023)
- Calvin's car accident and recovery (June 2023)
- Calvin's new home in Japan with mountain views
- Calvin's plans to visit Japan after Frank Ocean tour
- Travel and skiing interests

## Notable Quotes
- "It's like bringing something back to life"
- "When we remember why we're doing it, it keeps us going"
- "Keep on keepin' on, bud!"