name: Calvin-Dave April 2023 Conversation
description: Calvin and Dave discuss Calvin's Tokyo festival, advice from a producer, plans to tour the world, upcoming Frank Ocean tour, and Calvin's trip to Boston after. Dave shares photos of Boston skyline and car show; Calvin shares photo of his red sports car.

Calvin visited an awesome music festival in Tokyo. He didn't see any bands but met talented artists and industry people. He learned a lot and received advice from professionals.

Key advice Calvin received: A producer told him to stay true to himself and sound unique. This inspired him to think about where he wants his music to go.

Calvin's dream: To tour the world, perform for different people, connect with them, and have his music reach a global audience.

Upcoming plans: Calvin is finishing up the Frank Ocean tour and has an upcoming trip to Boston. He's heard Boston's music scene is awesome.

Dave's Boston highlights: Paradise Rock, House of Blues, Fenway Park. Dave offered to show Calvin around town and the cool spots.

Photos shared:
- Dave shared a photo of a Boston city skyline with a boat in the water.
- Dave shared a photo of a green mustang parked in a field of grass from a car show last weekend. Dave is into auto engineering and loves classic cars.
- Calvin shared a photo of a red sports car on display at a show, which he put a lot of work into.

Food plans: Calvin and Dave agreed to grab a bite together when Calvin is in Boston. Dave will show Calvin his favorite spots.
