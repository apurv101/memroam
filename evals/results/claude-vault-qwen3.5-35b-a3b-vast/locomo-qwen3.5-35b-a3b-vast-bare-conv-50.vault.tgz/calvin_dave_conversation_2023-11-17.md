name: Calvin & Dave conversation
description: 2023-11-17 conversation

Dave shares that he's taken up photography as a new hobby and has been taking photos of the local scenery. He recently bought a vintage camera in November 2023 that he loves. Dave enjoys capturing nature - sunsets, beaches, waves, waterfalls, and rocks. He mentions finding a serene spot in a nearby park with a waterfall and rocks, as well as a spot with a bench under a tree with pink flowers.

Calvin mentions attending a fancy gala in Boston where he met interesting people, including an inspiring artist they connected with over music and art. Calvin also shares that he's accepted an invitation to perform at an upcoming show in Boston.

Both friends express enthusiasm about catching up again and Calvin mentions he'll be in Boston soon.