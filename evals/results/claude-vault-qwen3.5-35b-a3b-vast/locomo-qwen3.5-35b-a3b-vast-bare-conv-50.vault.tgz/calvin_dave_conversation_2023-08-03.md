name: Calvin & Dave - August 3, 2023
description: Conversation from August 3, 2023 about Calvin's Ferrari, Dave's car restoration hobby, and Calvin's music career goals

---

Calvin mentioned the stressful experience of getting his Ferrari serviced, revealing his attachment to the car as a symbol of his hard work and dedication.

Dave shared that fixing cars is like therapy for him. He has fond memories of working on cars with his dad growing up, including one summer they spent restoring an old car together. Despite the hard work, seeing the end result and knowing they accomplished it together was really satisfying for Dave.

Dave shared a photo of himself and his dad as a child, posing together.

Calvin shared a photo of his red Ferrari on a lift in a garage, explaining that while it's material, it reminds him of his hard work and dedication and inspires him to keep pushing.

Calvin shared a photo of himself and his band performing on stage with lights on. He shared his goals: expand his brand worldwide, grow his fanbase, work with artists from around the globe, and create special music. He expressed determination to make his dreams come true.

Both Calvin and Dave exchanged words of encouragement and support, with Dave reminding Calvin to stay focused and keep going toward his dreams.
