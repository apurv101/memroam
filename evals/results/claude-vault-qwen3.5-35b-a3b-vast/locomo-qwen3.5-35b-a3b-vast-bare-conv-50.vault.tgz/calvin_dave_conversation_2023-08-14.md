---
id: 01a050a5-8d92-7c5f-b841-23fa856cb91a
name: Calvin & Dave - August 14, 2023
description: 2023-08-14 - Dave attended car restoration workshop in SF; Calvin performed in Tokyo with sold-out crowd singing along
---

## Date: August 14, 2023 (12:35 am)

## Participants: Dave, Calvin

---

### Dave's Updates

**Car Workshop Experience:**
- Attended a car workshop in San Francisco
- Deeply immersed in the world of car restoration
- Found the passion and dedication of others truly inspiring
- Currently restoring a car with a broken engine
- Transformation project going well - transforming from "beat-up mess to real beauty"
- **Goal:** Complete restoration by end of next month (September 2023)
- Project requires "lots of elbow grease" but Dave is confident it will be worth it
- Shared photo of the car with broken engine in the woods

### Calvin's Updates

**Music Tour Experience:**
- Recently toured with a well-known artist
- Experience of performing and connecting with audiences described as "unreal"
- **Tokyo Show:**
  - Ended tour in Japan
  - Crowd was extremely engaged - sang along when Calvin played one of his songs
  - Described as a "magical moment"
  - Shared photo of concert crowd with hands up
  - Energy and connection with audience is what Calvin loves about his job

**Personal Life:**
- Explored his new place
- Described as a "dream come true"

### Friendship Dynamics

- Mutual encouragement and support for each other's creative passions
- Dave appreciates Calvin's support
- Calvin is motivated by seeing Dave's enthusiasm
- Both believe in the value of pursuing dreams
- Calvin's closing sentiment: "Keep growing, buddy. It'll be worth it!"

---

### Key Themes

- Passion and dedication to craft (car restoration, music)
- Finding inspiration in others' commitment
- The joy of performance and audience connection
- Transformation projects (cars, music, personal growth)
- Long-term friendship built on mutual support
- Hard work paying off

---

### Photos Shared

1. **Calvin:** Concert crowd with hands up - captures the energy and connection of live performance
2. **Dave:** Car with broken engine in woods - before transformation restoration
