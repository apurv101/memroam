name: Audrey and Andrew Conversation
description: March 27, 2023 conversation between Audrey and Andrew about pets, hiking, and birds

Date: March 27, 2023, 1:10 pm

Participants: Audrey, Andrew

Key Topics:

- Andrew started a new job as Financial Analyst last week
- Audrey's dogs: Pepper, Precious, and Panda (she has had them for 3 years)
- Audrey's dogs are city dogs who love exploring new parks and trails on adventures
- Andrew's favorite animal: birds, especially eagles
- Andrew enjoys hiking at Fox Hollow on weekends
- Andrew does not have pets but loves animals

Shared photos:
- Audrey shared a photo of two dogs in grass with open mouths wearing new collars
- Andrew shared a photo of two birds flying in the sky with sun behind them
