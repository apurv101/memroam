name: Audrey and Andrew Conversation - May 6, 2023
description: Andrew discusses his ongoing search to adopt a dog, considerations for dog ownership in apartments, and Audrey shares her experience taking her dogs on road trips

Andrew and Audrey continued their conversation on May 6, 2023, focusing on Andrew's dog adoption journey and pet-related topics.

Andrew shared that since their last conversation, he had been actively searching for a dog to adopt. His process included:
- Browsing websites
- Visiting shelters
- Asking friends who have dogs

Andrew offered advice for others considering getting a dog:
- Consider the size of living space
- Consider the exercise needs of the breed
- For apartment living, a smaller dog would be best
- If active, consider a dog that loves to play and run

Andrew is currently:
- Looking for a pet-friendly apartment
- Contacting landlords
- Checking out neighborhoods
- Specifically seeking a place near a park or woods so he can stay close to nature and give his future dog large open space to run

Audrey shared her experiences:
- Last Friday, she took her dogs on a road trip to a beautiful national park - they had a blast
- She takes her dogs on road trips once every couple of months
- She finds it's a great way for dogs to explore and stay active
- She has a park nearby that's great for her pup's walks

Andrew expressed his desire to go on road trips with his future dog, calling it something on his bucket list.

Both exchanged well wishes for Andrew's dog search, with Audrey expecting to see a picture of his new furry friend soon.