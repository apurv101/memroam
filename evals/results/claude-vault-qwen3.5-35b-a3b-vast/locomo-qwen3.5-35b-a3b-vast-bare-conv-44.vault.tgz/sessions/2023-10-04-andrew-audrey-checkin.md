name: 2023-10-04 Andrew & Audrey Check-in
description: Andrew and Audrey caught up; Audrey shared beach trip with dogs, Andrew discussed missing outdoors in city life

---

## Key Points

### Audrey
- Took her pups to the beach over the weekend
- Dogs had a blast swimming in the ocean

### Andrew
- Haven't been to the beach in a while
- Lives in the city, finds it hard to find open spaces
- Used to hike a lot but work-life balance makes it challenging
- Exploring nature used to be his escape/way to find peace
- Feels a void in his heart from not being outdoors
- Considering getting more plants for his house
- Open to advice about plants to bring peace to his home
- Thanks Audrey for her help and suggested he might reach out for more advice

### Context
- Long-time friends checking in after a while
- Conversation about outdoor/nature activities
- Andrew appreciative of Audrey's support and suggestions
