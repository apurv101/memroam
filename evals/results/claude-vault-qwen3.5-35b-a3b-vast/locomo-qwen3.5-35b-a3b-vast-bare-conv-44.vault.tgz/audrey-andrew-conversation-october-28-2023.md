---
id: 01a0508b-bfb4-79d4-88ef-23c7e166a472
name: Audrey and Andrew Conversation - October 28, 2023
description: Audrey's dogs behavior issues with behaviorist appointment and positive reinforcement; they plan a hiking trip with dogs for Saturday
---

On October 28, 2023, Audrey and Andrew discussed Audrey's dogs. Audrey mentioned they weren't acting normally, so she made an appointment with an animal behaviorist last Wednesday. The appointment was hectic at first, but the behaviorist checked them out and gave her some tips to try and help with their problems.

The behaviorist suggested changes in their routine and Audrey is now using positive reinforcement techniques. So far, the dogs seem to be responding well, though it's still a work in progress. Audrey is seeing some progress and hopes it keeps going. She's devoted to keeping them healthy and happy, saying they mean everything to her. She's looking forward to the day they are back to normal.

Audrey has four dogs: Pepper and Panda are Lab mixes, and Precious and Pixie are Chihuahua mixes. They are all mutts.

Andrew shared some photos from his hiking experiences, including a photo of a man hiking up a mountain and a photo of a man walking a dog on a leash. He invited Audrey to join for a hike soon. They planned to go hiking on Saturday, with both bringing snacks. Audrey is excited to spend time outdoors with the fur babies.

Andrew mentioned he is going on a picnic date with his girlfriend on Sunday.

They discussed exploring a trail near a lake with great views, which would be peaceful and dog-friendly. Audrey shared a photo of a lake with a boat and forest in the background. They talked about taking photos during their hike, especially with the beautiful autumn colors.

Both expressed gratitude for having a friend who shares their love of exploring and being outside with dogs.
