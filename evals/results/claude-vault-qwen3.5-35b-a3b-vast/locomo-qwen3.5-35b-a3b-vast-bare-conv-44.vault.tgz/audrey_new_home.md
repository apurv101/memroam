---
id: 01a0508b-bc24-76bd-ac85-54533cde4bcc
name: Audrey's New Home
description: Audrey moved to a new place with a bigger backyard for her dogs
---

Audrey recently moved to a new place with a bigger backyard for her dogs/pets. The backyard has:
- A doggy play area with agility stuff and toys set up
- More space for dogs to run and explore

She's been unboxing all the packed boxes after the move.