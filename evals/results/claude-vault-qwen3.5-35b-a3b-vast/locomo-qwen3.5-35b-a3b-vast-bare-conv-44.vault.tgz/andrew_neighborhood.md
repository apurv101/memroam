---
id: 01a0508b-d3a7-73bc-94cd-7722eb56ab0a
name: Andrew's Neighborhood
description: Andrew lives in a neighborhood with a park that has colorful flower beds
---

Andrew's neighborhood has a park with flower beds containing many different colored flowers. He shared a photo of this park in June 2023.

He also has a doggy daycare near him with a big indoor space for dogs to play.