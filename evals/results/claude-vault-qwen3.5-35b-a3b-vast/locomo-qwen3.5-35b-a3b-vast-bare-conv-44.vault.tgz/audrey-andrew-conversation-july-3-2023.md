name: Audrey and Andrew Conversation - July 3, 2023
description: Conversation from 8:32 pm on 3 July 2023 about dog training, cooking, recipes, and hobbies.
date: 2023-07-03 20:32

**Participants:** Audrey, Andrew

**Summary:**
Audrey is taking a dog training course with her four dogs (all 3 years old - two Jack Russell mixes, two Chihuahua mixes). They're doing well, including attending a doggy playdate. Andrew is struggling to find dog-friendly rental spots, which prevents him from hiking. Instead, he's gotten into cooking as a new hobby. Audrey loves cooking, shares her family's Chicken Pot Pie recipe (inspired by her grandma's kitchen), and a Mediterranean-style Roasted Chicken recipe (her favorite comfort meal). Both find cooking therapeutic and creatively fulfilling.
