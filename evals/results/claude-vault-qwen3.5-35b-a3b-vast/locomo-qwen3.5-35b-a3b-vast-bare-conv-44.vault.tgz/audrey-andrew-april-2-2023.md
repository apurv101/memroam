---
id: 01a0508a-c33e-7eed-9996-c3dd5c5cac1f
name: Audrey and Andrew conversation - April 2, 2023
description: Audrey and Andrew discuss Audrey's new puppy Pixie and Andrew's interest in getting a dog and finding dog-friendly housing
---

# Audrey and Andrew Conversation - April 2, 2023

## People Mentioned
- **Audrey**: Has two dogs (Pepper and new puppy Pixie)
- **Andrew**: Friends with Audrey, interested in getting a dog
- **Pixie**: Audrey's new white puppy, recently adopted
- **Pepper**: Audrey's older dog, adjusting well to Pixie
- **Andrew's family's dog**: Seen in photos, Andrew misses hiking with them

## Key Events
1. **Pixie's adoption**: Audrey adopted a new white puppy named Pixie
   - Pixie has settled in well despite initial adjustment period
   - Now friends with Pepper and other dogs
   - Pixie and Pepper are always together now

2. **Andrew's situation**: 
   - Considering getting a dog but finding dog-friendly housing challenging in the city
   - Audrey shared advice about using websites with filters to find dog-friendly apartments
   - Successfully found a dog-friendly apartment through those websites

3. **Hiking interests**:
   - Andrew misses hiking and exploring nature trails with his family's dog
   - Both discussed the joy of bonding with dogs outdoors
   - Andrew wants to find a dog-friendly spot to explore again

## Future Plans
- Andrew hopes to find a dog-friendly apartment soon
- Andrew is excited about potentially getting a furry friend
- Both friends support each other in finding housing and potential pets

## Photos Shared
- Audrey: Pixie (white puppy sitting on carpet)
- Audrey: Dogs playing together
- Audrey: Pepper and Pixie together near a fence
- Audrey: Dog in a field of flowers
- Andrew: Family's dog on a couch
- Audrey: Dog on couch with pillow
- Andrew: Man walking dog on trail
- Andrew: Man sitting on rock with dog
- Audrey: Dog laying on couch with pillow

---
*Transcript from 2:42 pm on April 2, 2023*
