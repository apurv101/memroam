---
id: 01a0508b-bfb4-79d4-88ef-23c7e166a471
name: Audrey's Dogs/Pets
description: Audrey has multiple dogs that she loves very much
---

Audrey has dogs (plural - referred to as "pooches" and "fur babies"). She loves them very much and considers them like family. She appreciates friends who understand this deep love for pets.

In July 2023, Audrey made personalized wooden keychains for her dogs, each engraved with their names. She wanted to make them special and fit their personalities, putting a lot of love into the handmade items so her pets feel seen and loved.
Audrey has four dogs with distinct personalities and names (as of August 2023):
- Pepper (oldest): relaxed, likes lounging on the couch
- Pixie (second): always ready for a game, curls up in her bed
- Precious (third): naughty but loves cuddles, has her chair
- Panda (youngest): full of life, up for adventure, loves relaxing on his rug

In August 2023, Audrey got a tattoo of her four dogs on her hand, and they each have their own cozy favorite spots to relax.

She also fondly remembers her childhood dog Max, who had lots of energy and loved fetch. They would take long walks together where she shared her worries and hopes with him. Max was a great listener and those walks were some of her favorite childhood memories.

In September 2023, Audrey had a knee injury that prevented her from walking her dogs, which was tough since they bring her so much joy. After recovering, she was able to walk them again and was thrilled to get back to this activity.

Audrey also mentioned she can't volunteer at the animal shelter anymore but still finds ways to support them, including donating a portion of her jewelry-making profits to the shelter.

In late October 2023, Audrey noticed her dogs weren't acting normally, so she made an appointment with an animal behaviorist. The behaviorist gave her tips on handling the situation and suggested changes to their routine. She's now using positive reinforcement techniques and is seeing some progress, though it's still a work in progress. Audrey is hopeful the dogs will get back to normal soon.