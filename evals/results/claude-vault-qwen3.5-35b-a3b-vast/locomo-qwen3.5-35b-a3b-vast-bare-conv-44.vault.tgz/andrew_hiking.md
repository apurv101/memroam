---
id: 01a0508b-c3dc-7e97-9989-a5c4c0b45bb5
name: Andrew's Hiking
description: Andrew went hiking with friends last Friday (June 2023)
---

Andrew went hiking with some friends last Friday (June 2023). The weather was great and he enjoyed being outdoors. He took photos but hadn't gone through them yet at the time of the conversation.

Andrew mentioned in July 2023 that work has been stressful and he's been stuck inside, missing the peace and freedom of hiking. He has plans for a hike next month (early August 2023) and invited Audrey and her dogs to join.

He's been missing the connection with nature and the peace it brings. He's looking forward to exploring more.