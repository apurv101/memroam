---
id: 01a0508e-07ab-71ed-b778-f8501ef2cf05
name: Andrew
---

# Personal Details

## Relationships
- Has a girlfriend named Toby

## Pets
- Has a German Shepherd puppy named Toby
- Toby loves wearing sweaters
- Toby enjoys playing fetch and frisbee
- Toby once chased a squirrel around a tree at the dog park

## Interests & Hobbies
- Enjoys board games (plays with Toby, his girlfriend, and friends)
- Lives in the city but misses nature
- Likes visiting parks and hiking
- Enjoys cozy cafes

## Recent Activities
- Had a board game night with girlfriend on Tuesday
- Visits cozy cafes
- Enjoys dog parks with his pup
