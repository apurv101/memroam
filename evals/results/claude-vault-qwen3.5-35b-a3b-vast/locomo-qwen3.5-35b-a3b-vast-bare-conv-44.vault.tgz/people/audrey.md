---
id: 01a0508e-0dfb-719c-9ecf-2d5fa0cea829
name: Audrey
---

# Personal Details

## Pets
- Has multiple dogs (mentions "my dogs" and "four dogs")
- Dogs love fetch and frisbee
- Dogs enjoy socializing at dog parks
- Dogs hate snow
- Dogs prefer sunny days in the grass

## Tattoos
- Has a tattoo of her four dogs
- Went to add more dog drawings to the tattoo collection
- Got a tattoo of a dog with sunflowers
- Considering getting another tattoo if she gets another dog someday

## Interests & Hobbies
- Likes making cookies for neighbors
- Lives in the city
- Very busy lately
- Wants to go on hikes with her dogs
- Enjoys walks with her dogs in nature

## Recent Activities
- Made cookies to thank neighbors for their pet-friendly homes
- Visited a dog park
- Considering a hike with her dogs for therapy
