name: Audrey's Jewelry-Making
description: Audrey creates jewelry from recycled objects and donates profits to animal shelter
date: 2023-10-06
topics: jewelry, recycling, sustainability, charity, animal shelter

---

## Overview
Audrey creates one-of-a-kind jewelry pieces from recycled materials. She started this as a hobby and now sells some pieces.

## Materials Used
- Bottle caps
- Buttons
- Broken jewelry
- Other recycled objects

Each piece holds a special story and has its own unique appeal.

## Purpose & Impact
- **Creativity**: Shows her love of creativity through handmade designs
- **Sustainability**: Gives recycled objects new life, reducing waste
- **Charity**: Donates a portion of profits to an animal shelter
- **Customer Value**: Customers enjoy her work while supporting a cause

## Philosophy
Audrey sees her jewelry-making as a way to combine two passions: making jewelry and making a difference. She believes any hobby can have an impact when used right.

## Personal Connection
Audrey can't volunteer at the animal shelter anymore, so this is her way of continuing to help out and contribute to a cause close to her heart.
