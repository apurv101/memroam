name: Audrey
description: Andrew's friend with four dogs (mutts) and a small garden

Audrey has four dogs, all mutts:
- Two Jack Russell mixes
- Two Chihuahua mixes
She calls them her "fur babies" and they mean everything to her.

Dog incident (last Friday): One of her pups saw something at the park and pulled so hard the leash busted. Audrey had to chase after her to keep her safe. She petted, hugged, and spoke calmly to calm her down, which strengthened their bond.

Training & activities:
- Works on obedience and teaches tricks: sit, stay, shake, roll over
- Takes dogs for walks multiple times a day (exercise and bonding time)
- Dogs enjoy playing in her garden, running and exploring

Garden:
- Has a small garden with Peruvian Lilies and a veggie patch
- Peruvian Lilies: bright colors, delicate petals, easy to care for (just water and sun)
- Finds caring for plants relaxing and brings her peace
- Feels accomplished when seeing them grow
- Plants bring her joy

Overall: Audrey loves her dogs and finds great joy and companionship with them. They make everything better in her life.