name: Caroline and Melanie - Pride & Family Moments
description: Caroline joins LGBTQ activist group 'Connected LGBTQ Activists'; shared personal memories including beach trips, camping, meteor shower, and family milestones.

Caroline shared that she joined a new LGBTQ activist group called "Connected LGBTQ Activists" on Tuesday (around July 18, 2023). The group consists of diverse people passionate about rights and community support. They hold regular meetings, plan events and campaigns together.

Caroline mentioned missing the city's pride parade that was held last weekend (around July 15, 2023), describing it as a powerful reminder that they are not alone in the fight for equality and inclusivity.

Melanie shared several family memories:
- Beach trips: Usually go once or twice a year; the kids had a blast playing on the beach
- Camping tradition: Annual summer camping trip with marshmallows and campfire stories
- Best camping memory: Saw the Perseid meteor shower last year, lying under a star-filled sky, making wishes
- Personal milestone: Youngest child's first steps, a moment that put life's fleeting nature into perspective

Both friends appreciated the beauty of everyday moments and the importance of family bonds.
