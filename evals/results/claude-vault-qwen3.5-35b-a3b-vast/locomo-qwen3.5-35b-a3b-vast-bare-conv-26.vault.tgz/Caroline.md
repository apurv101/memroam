name: Caroline
description: Researching adoption agencies as a single parent, considering adoption for LGBTQ+ inclusive agency
---

**Major Life Pursuit (as of May 2023):**

- Researching adoption agencies - it's been a lifelong dream to have a family
- Goal: give a loving home to kids who need it
- Will be a single parent - feeling it'll be tough but up for the challenge
- Chose an adoption agency because they help LGBTQ+ folks with adoption
- Their inclusivity and support really spoke to her
- Feeling hopeful and optimistic despite the process being a lot to take in
- Grateful for support from friends and mentors
- Transitioned three years ago (around 2020)
- Friends, family, and mentors are her rocks - she's known these friends for 4 years since moving from her home country
- Experienced a tough breakup, but support helped her through
- The hard work starts now to turn the dream into reality

**Transgender Journey & School Event (June 2023):**
- Spoke at a school event last week about her transgender journey
- Encouraged students to get involved in the LGBTQ community
- Had a powerful, moving experience sharing her struggles and growth since coming out
- The audience related to her story and it inspired them to be better allies
- Deeply grateful for the love and support she's received throughout her journey
- Feels it's important to share experiences to build a strong, supportive community of hope
- Wants to keep using her voice to promote understanding, acceptance, and lift others up

**Current Focus:** Adoption process, building a family, LGBTQ+ inclusive support, art and creativity

**August 2023 Updates:**
- August 23, 2023: Took the first step in her adoption journey by applying to adoption agencies
- Attended an adoption advice/assistance group that provided great support and guidance
- Shares her journey as exciting but nerve-wracking, recognizing parenting as a big responsibility
- Pet: Oscar, her guinea pig - loves veggies, especially parsley and hay
- Has a deep love for horses - grew up horseback riding with her dad, would go through fields feeling the wind
- Active artist: creates art as a therapeutic outlet for self-expression and exploring identity
- Created a self-portrait with blue face in August 2023 - felt liberated, empowered, and authentic while painting it
- Values art for giving her freedom and helping her be true to herself
- Committed to living authentically and promoting LGBTQ+ rights to help others do the same
- Sees her art as a way to explore identity and express who she really is


**October 2023 Updates:**
- Attended a transgender poetry reading on October 6, 2023 - it was powerful and empowering, celebrating transgender stories in a safe space
- Inspired by the event to create art - drew a painting of a woman in a dress representing freedom and embracing womanhood
- Values being authentic and encourages others to do the same

**September 2023 Updates:**
- Went biking with friends to the beach last weekend (before Sept 13, 2023) - had a "wicked day out" with the gang
- Has been creating art to express feelings, explore gender identity, and show things hard to put into words
- Used art to understand and accept herself during her transition
- Created a painting to show her path as a trans woman - uses red and blue to represent the gender binary, mixed colors to show smashing rigid thinking
- Views art as both a reminder to love her authentic self and as a way to create a more loving world
- Her work with the LGBTQ+ community inspires her - grateful for the impact she's making
- Some close friends continued supporting her through her transition, others couldn't handle it - now values genuine relationships with accepting people

**July 2023 Updates:**
- July 14, 2023: Attended a council meeting for adoption - inspiring and emotional; made her even more determined to adopt
- Attended an LGBTQ+ pride parade (late June/early July 2023) - felt accepted, happy, proud, and grateful; saw how much the community has grown; being around accepting and celebrating people inspired her
- Realized she can be herself without fear and had the courage to transition - this was the best part
- Attended an LGBTQ+ conference on July 10, 2023 - felt deeply welcomed and connected with others who've had similar journeys; inspired to fight for trans rights
- Starting to learn to play piano as a creative outlet
- Still pursuing counseling and mental health as a career path - motivated by community experiences and her own struggles; wants to provide support systems for others
- Favorite color is blue (makes her feel relaxed)
- Believes sunflowers mean warmth and happiness; roses stand for love and beauty

**New Conversations (July 6, 2023):**
- Has been creating a library of books for future kids: kids' classics, stories from different cultures, educational books
- Had a picnic with friends last week
- Grateful for her support network of friends and family who've been there for her every step of the way during transition
- Friends and family have provided love, guidance, and acceptance - instrumental in her transition and acceptance of true self

