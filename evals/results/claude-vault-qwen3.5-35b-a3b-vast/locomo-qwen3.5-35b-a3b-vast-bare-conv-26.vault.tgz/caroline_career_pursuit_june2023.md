name: Caroline's Career Pursuit
description: Caroline plans to pursue counseling and mental health work, specifically with trans people
---

**Career Goal (as of June 2023):**
- Pursuing counseling and mental health as a career
- Wants to help people who have gone through similar experiences
- Specifically interested in working with trans people
- Aims to help trans people accept themselves and support their mental health

**Motivation:**
- Personal journey and the support Caroline received made a huge difference
- Saw how counseling and support groups improved her own life
- Started caring more about mental health and understanding herself
- Passionate about creating a safe, inviting place for people to grow
- Wants to use her experience to help others

**Recent Activities:**
- Attended an LGBTQ+ counseling workshop last Friday
- Workshop was enlightening, covered different therapeutic methods
- Learned how to best work with trans people
- Inspired by the passion of professionals in making safe spaces for trans people
- Motivated by her own journey and the support she received

**Key Quote:**
"It really mattered. My own journey and the support I got made a huge difference. Now I want to help people go through it too."
