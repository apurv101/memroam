---
id: 01a05076-00f4-7095-a7ef-13e2680e81b0
name: Caroline
description: Friend who volunteers at LGBTQ+ youth center and plays guitar
---

# Caroline

## Personal Life
- Volunteered at an LGBTQ+ youth center
- Finds it gratifying to talk to similar young people
- Shares her story to support young people who might feel alone
- Plans to continue volunteering at the youth center
- Organizing a talent show for the kids next month

## Music
- Plays acoustic guitar, started about 5 years ago
- Playing helps her express emotions and escape into her feelings
- Deeply connected to "Brave" by Sara Bareilles - song about courage and fighting for what's right
- Finds music cathartic and uplifting

## Values
- Believes in community and supporting each other
- Strongly believes in being kind and showing support
- Finds purpose in making a difference for others
