---
id: 01a05076-05c5-7e06-8661-4a7ffed2a0e3
name: Melanie
description: Friend with kids, loves live music, plays clarinet
---

# Melanie

## Family
- Has children
- Took kids to a park and enjoyed watching them play outdoors
- Believes in quality family time

## Music
- Plays clarinet, started when young
- Love live music and concerts
- Musical preferences include:
  - Classical: Bach, Mozart
  - Modern: Ed Sheeran's "Perfect"
- Finds music a form of self-expression and relaxation
- Enjoys how music brings people together

## Personality
- Appreciates others' dedication to helping people
- Enjoys sharing experiences through photos
