---
id: 01a05089-8d28-727c-b67b-431d81141c1f
name: John-Tim Conversation - December 26, 2023
description: John shares his seminar work and charity basketball camp; Tim discusses Himalayan travel inspiration and fantasy interests
---

## Conversation Summary

**Date**: December 26, 2023, 3:35 PM

### John's Updates
- **Seminar Work**: Started doing seminars helping people with sports and marketing. Worked with aspiring professors who were eager and motivated.
- **Charity Work**: Focused on supporting youth sports and fighting for fair chances in sports for underserved communities. Collaborating with organizations to create more opportunities for young athletes.
- **Basketball Camp**: Organized a basketball camp for kids in his hometown last summer. Described it as a week full of laughs, high-fives, and personal growth. Felt it was priceless seeing the kids' faces light up when they hit the court.
- **Philosophy**: Uses his influence and resources to help causes he believes in, committed to making the world a better place.

### Tim's Updates
- **Travel Planning**: Reading stories from travelers around the world to plan his next adventure. Particularly inspired by a book about two hikers who trekked through the Himalayas - the challenging terrain, altitude sickness, and bad weather were worth it for the amazing sights they saw.
- **Dream Trip**: Visited a travel agency to check requirements for his next dream trip.
- **Philosophy**: Believes facing challenges makes us stronger. Encourages John to keep pushing for his goals.
- **Entertainment Interests**:
  - Harry Potter fan, especially admires Emma Watson as a supporter of gender equality
  - Loves fantasy genre (Lord of the Rings is favorite)
  - Excited about "The Wheel of Time" TV series coming out next month, based on a book series he loves
  - Enjoys movie marathons with friends
- **Reading**: Still loves getting lost in good books, Harry Potter series is a favorite escape.

### Shared Values
Both John and Tim value:
- Making a difference in the world
- Using their platforms for important causes
- The importance of challenges and personal growth
- Supporting others and inspiring those around them

### Photo Context
The conversation included multiple shared photos:
- Basketball court with crowd
- People on stage at a convention
- Books (including Harry Potter series)
- Two men on horseback in front of a mountain
- Newspaper article with woman's picture
- Two men on stage (charity event)
- Kids playing basketball in gym
- Signed basketball
- Harry Potter books on desk
- Three guys watching movies
- Fantasy movie poster (Lord of the Rings)
