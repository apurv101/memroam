name: Tim and John conversation - November 21, 2023
description: Tim and John discuss storytelling setbacks, basketball challenges, resilience, and their love of reading

---

**Date**: November 21, 2023, 10:22 am

## Topics Discussed

### Tim's Storytelling Journey
- Tim mentioned having a setback while trying to write a story based on his UK experiences
- He's been swamped with studies and projects
- John advised him to reflect on what went wrong and how to improve, similar to how John handles challenges on the court

### John's Basketball Experience
- John shared about a major ankle injury last season that required physical therapy
- He was unable to play or help his team during recovery
- It was both a mental and physical challenge
- Another challenge: messed up during a big game, learned to accept mistakes and keep growing

### Shared Love of Reading
- Tim's favorite books: Harry Potter, Game of Thrones (fantasy)
- Tim also reads books on growth, psychology, and self-improvement
- Tim recently read a book about "how small changes can make big differences" (likely Atomic Habits)
- John reads non-fiction about personal development and mindset
- John recently reread "The Alchemist" - found it inspiring about following dreams and personal legends
- Both read and loved "The Alchemist"

### Values and Approach
- Both value: resilience, perseverance, learning from mistakes, staying motivated by passion
- Tim stays motivated through writing and reading
- John stays motivated through love of basketball
- Both believe in continuous growth and improvement

### Visual
- Tim shared a photo: "a bunch of books on a wooden floor" - described as "companions on my growth journey"
