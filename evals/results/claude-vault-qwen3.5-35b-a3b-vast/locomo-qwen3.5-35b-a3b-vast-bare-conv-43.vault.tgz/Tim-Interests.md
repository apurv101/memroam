---
id: 01a05089-a9d9-7d22-86fd-74dad94666a0
name: Tim
description: Interest in travel, languages, and fantasy literature (currently reading "The Name of the Wind", studying abroad in Galway, Ireland)
---

# Personal Details

## Travel
- Joined a globetrotting group with shared interests
- Italy is on his travel list
- **Jan 2024: Going on a semester study abroad program in Galway, Ireland**
- Interested in exploring different cultures and landscapes through fantasy
- Excited to visit **The Cliffs of Moher** for its ocean views and cliffs
- **January 2024**: Researched visa requirements for multiple countries; overwhelmed but excited about travel plans
- **January 2024**: John recommended Barcelona; added to Tim's travel list

## Languages
- Currently learning German (found it tough but fun)
- Prior French knowledge from high school helps with German
- Uses a language learning app for practice

## Reading & Entertainment
- Loves reading and escaping to book worlds
- Has a collection of books
- Favorite book: Harry Potter (described as "so immersive")
- **Jan 2024: Reading "The Name of the Wind" by Patrick Rothfuss (fantasy novel)**
- Favorite fantasy movie: Star Wars (never gets old)
- Has a collection of movies and DVDs
- Has a Middle-earth map from LOTR

## Preferences
- Values immersion in fantasy worlds
- Appreciates seeing details in fantasy stories
- Likes getting lost in another world