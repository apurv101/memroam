name: Basketball conversation - Dec 11, 2023
description: Conversation with John and Tim about basketball and dreams

## John
- Plays basketball on a team
- Had a career-high in assists last Friday in a game against their rival
- Favorite game moment: hitting a buzzer-beater shot to win when they were down 10 in the 4th quarter
- Used basketball as a way to deal with doubts and stress when younger - practiced outside for hours, dreaming of playing in big games

## Tim
- Had a tough time with an English lit class
- Doing analysis on a series, thought it went ok

## Themes
- Basketball as a way to express themselves and stay positive
- Both supporting each other in pursuing their dreams
- Mutual encouragement and motivation

---
*Conversation dated 8:28 pm on December 11, 2023*
