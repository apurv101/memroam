name: John and Tim Conversation - September 21, 2023
description: Conversation about John's new teammates, team trip plans, basketball career, and future goals

## Date: September 21, 2023 (8:17 pm)

## Key Topics

### New Teammates
- John attended a local restaurant with new teammates last week
- They're great friends who share a love for basketball
- Connected over shared hobby and had fun together

### Team Trip Plans
- Planning to take a team trip next month (October 2023) to explore a new city
- Still deciding on destination
- Tim suggested Edinburgh, Scotland:
  - Has a magical vibe
  - Birthplace of Harry Potter
  - Awesome history and architecture
  - Beautiful city

### Basketball Career
- John loves playing pro ball
- Sees it as a constant challenge that keeps him growing
- Enjoys seeing himself get better and beating goals
- Loves playing with teammates and having fans cheer
- Gets great sense of satisfaction and purpose from the sport

### Goals and Aspirations
**On court:**
- Focusing on better shooting
- Making more impact on the court
- Wants to be known as a consistent performer
- Wants to help his team

**Off court:**
- Looking into more endorsements
- Building his brand
- Planning for life after basketball

### Future Plans
- Wants to use his platform to make a positive difference
- Inspire others
- Considering starting a foundation
- Interested in charity work
- Wants to make the most of his chances
- Eager to leave a meaningful legacy

### Book Recommendations
- Tim recommended a fantasy novel by Patrick Rothfuss
  - Book cover shows a man in a hooded jacket
  - Said it would take you to a different world
  - Great for traveling
- John has "The Alchemist" on his bookshelf
  - John loved it
  - Made him think about life and importance of following one's dreams
  - John highly recommends it

### Bookshelf
- John shared a photo of his bookshelf
- Has a variety of books he's read and enjoyed

## Advice Shared
Tim advised on picking endorsements:
- Make sure they align with your values and brand
- Look for companies that share your desire to make a change and help others
- Endorsement should feel authentic to your followers