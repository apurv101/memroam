name: John-Tim Conversation — August 31, 2023
description: Tim got summer job rejection; gave class presentation; John's NYC subway trouble; soup recipe with sage; Tim's Universal Studios trip
---

Conversation dated August 31, 2023 (2:52 pm).

**Tim's updates:**
- Rejected for a summer job he wanted — not great, but staying positive
- Yesterday: Gave a presentation in class
  - Was nervous but made it through
  - Feels like progress, a small step forward
- Planning a trip to Universal Studios next month
  - First time going
  - Super excited about the Harry Potter stuff
  - Can't wait to experience it

**John's updates:**
- NYC trip went okay overall
  - Had trouble figuring out the subway at first
  - Became easy after someone helped explain it

**Shared topics:**
- Cooking and recipes:
  - John shared a photo of soup he made (with a spoon and butternut on a cutting board)
  - Made it up on the spot, no recipe
  - Added sage for flavor
  - Tim is excited to try making it himself

**Photos shared:**
- John: Photo of a bowl of soup with a spoon and a butternut on a cutting board

**Key sentiment:**
- Mutual encouragement and support
- Tim's positive attitude despite setbacks
- Celebrating small wins (Tim's presentation)
- John's helpfulness with NYC tips
