name: John's Motivational Strategies
description: John's methods for staying motivated and focused

## Physical Reminders
- Whiteboard with motivational quotes and workout strategies
- Desk plaque with message "make it happen"
- Uses physical reminders to stay focused and believe in himself
- Helps him push through tough workouts and obstacles

## Sources of Motivation
- Teammates believing in him and their encouragement
- Love for improving his skills
- Family and friends providing support
- Support network of people who are always there for him
- Doesn't want to let his team down

## Connection to Tim's Journey
- Tim shares his own sources of motivation
- Both value having a strong support network
- John's team is described as "like my second family"
