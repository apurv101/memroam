name: John's Surfing
description: Surfing activities, experiences, and connection to nature

## Background
- Started surfing 5 years ago (around 2018)
- Has been great overall
- Loves the connection to nature

## Experiences
- Had an awesome summer with friends surfing and riding waves
- Found the feeling "unreal"
- Describes surfing as exciting and free-feeling
- Connects the ocean, waves, and wind with freedom

## Preferences
- Loves the ocean
- Enjoys being out in the water
- Finds nature "pretty special"

## Connection to Seattle
- Seattle has an ocean
- Plans to enjoy local seafood there
- Connects with the ocean vibe in Seattle