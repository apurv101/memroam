---
id: 01a05089-b1b6-7230-b8f5-0fff0267fb11
name: John
description: Interest in travel, sports, and fantasy
---

# Personal Details

## Travel
- Recently visited Italy (last month before conversation)
- Visited Paris and saw the Eiffel Tower
- Loves traveling to learn about different cultures and places
- Finds travel educational and eye-opening

## Languages
- Knows some German and Spanish
- Uses a language learning app
- Values languages for personal and professional opportunities

## Sports
- Basketball is his passion
- Practices and trains every day
- Values it for staying in shape and improving

## Reading & Entertainment
- Has a collection of Star Wars movies
- Huge fan of Lord of the Rings
- Favorite character: Aragorn
- Appreciates the adventure, world, and characters of LOTR

## Personal Values/Inspiration
- Inspired by Aragorn's character traits:
  - Brave
  - Selfless
  - Down-to-earth
  - Never gives up
  - Stands up for justice
  - A great leader who puts others first
- Has a painting of Aragorn in his room to remind him to stay true and be a leader

## Recent Activities
- Got a cooking book in Italy
- **January 2024**: Secured an endorsement deal with a popular beverage company (photo of baseball player with bat and soda)
  - Feels like a dream come true after years of hard work
  - Training hours and efforts finally paid off