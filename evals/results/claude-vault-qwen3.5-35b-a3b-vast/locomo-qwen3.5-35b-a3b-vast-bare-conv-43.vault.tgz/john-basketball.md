name: John's Basketball Journey
description: Basketball player's achievements, endorsements, and game plans

## Achievements
- Scored 40 points (highest ever) - July 2023
- Had a tough win with teammates
- Celebrated at a restaurant with team
- Recent game (August 2023): Won with a tight score, exciting last basket, amazing crowd atmosphere
- Basketball journey: watched NBA with dad as a kid, joined local league at age 10, played through middle/high school, earned college scholarship, drafted by professional team (dream come true)

## Endorsement Deals
- **Signed**: Nike - basketball shoe and gear deal
- **In talks**: Gatorade - potential sponsorship
- **Interested in**: Under Armour

## Networking & Skills
- Uses contacts in basketball industry
- Has marketing skills
- Networking plays a big role in endorsements

## Future Plans
- Game in Seattle next month (August 2023)
- Seattle is one of his favorite cities to explore
- Loves the energy, diversity, and food in Seattle
- Plans to try local seafood
- Goal: win championship
- Charity work: partnering with local organization to help disadvantaged kids with sports and school
- Also visiting Chicago (August 2023) - loved the energy and friendly locals

## Team Dynamics
- Strong bond with teammates
- Teammates push each other to be their best
- Describes teammates as "a second family"

## Teammate Interactions
- Tim is a friend who supports John
- Had nice conversations about achievements and endorsements
- Shared lucky basketball shoes with Tim - they've been with him through his journey, symbolizing resilience and determination