name: Tim's Harry Potter Connection
description: Tim's interest in Harry Potter and reading

## Recent Activity
- Last week (July 2023): Had a nice chat with a Harry Potter fan in California
- Described it as "magical"
- August 9, 2023: Skyped with a Harry Potter fan from CA, discussed characters and potential collaboration

## Reading Habits
- Reads fantasy books to escape and feel free
- Enjoys reading in comfy spots
- Reading helps him feel like he's "in another world"
- Reading in free time: curls up with a good book, escaping reality
- Favorite author: J.K. Rowling - reading her works "for a long time"
- Favorite J.K. Rowling quote: "Turn on the light - happiness hides in the darkest of times"

## Writing Project
- Currently in the middle of writing a fantasy novel
- Finding it nerve-wracking but exciting
- Researching castles in the UK for inspiration and ideas
- Takes notes on J.K. Rowling's style and creative storytelling
- Books, movies, and real-life experiences all fire up his creativity

## Home
- Has a living room with a brown couch and white ottoman
- Finds comfort in these reading spaces
- Describes reading bliss as "like being in another world"

## Connection with John
- Supports John's basketball achievements
- Compares John's surfing to his reading (both provide freedom and escape)
- Has conversations about passions and what makes life awesome
- NEW (Aug 2, 2023): John shared story about Anthony and John winning Harry Potter trivia prize at charity event; John reading inspiring book about keeping dreams alive