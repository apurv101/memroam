# conv-43 — memory index

- [basketball_conversation_dec11.md](basketball_conversation_dec11.md) — ⚠ no frontmatter
- [John](John-Interests.md) — Interest in travel, sports, and fantasy
- [john_conversation_dec19_2023.md](john_conversation_dec19_2023.md) — ⚠ no frontmatter
- [john-basketball.md](john-basketball.md) — ⚠ no frontmatter
- [john-motivation.md](john-motivation.md) — ⚠ no frontmatter
- [john-surfing.md](john-surfing.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-08-26.md](john-tim-conversation-2023-08-26.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-08-31.md](john-tim-conversation-2023-08-31.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-09-21.md](john-tim-conversation-2023-09-21.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-10-13.md](john-tim-conversation-2023-10-13.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-10-17.md](john-tim-conversation-2023-10-17.md) — ⚠ no frontmatter
- [john-tim-conversation-2023-10-21.md](john-tim-conversation-2023-10-21.md) — ⚠ no frontmatter
- [john-tim-conversation.md](john-tim-conversation.md) — ⚠ no frontmatter
- [john-tim-friendship.md](john-tim-friendship.md) — ⚠ no frontmatter
- [Tim](Tim-Interests.md) — Interest in travel, languages, and fantasy literature (currently reading "The Name of the Wind", studying abroad in Galway, Ireland)
- [tim-harry-potter.md](tim-harry-potter.md) — ⚠ no frontmatter
