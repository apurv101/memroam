name: John-Tim Conversation
description: John signed with Minnesota Wolves as shooting guard; Tim working on Harry Potter fan project
---

John and Tim met on May 21, 2023.

**John's updates:**
- Just signed with a new team: Minnesota Wolves
- Position: Shooting guard
- Season opener next week
- Goal: Improve shooting percentage
- Challenge: Fitting into the new team's style of play
- Things going well with the new team; team members are nice and fun
- Has a sneaker collection he enjoys talking about

**Tim's updates:**
- Working on a Harry Potter fan project
- Discussed collaborations with a friend who is a Harry Potter fan
- Went on a tour in London a few years ago (described as "walking into a Harry Potter movie")
- Plans to explore real Potter places someday
- Discusses various aspects of the Harry Potter universe (characters, spells, magical creatures)
- NEW (Aug 2, 2023): Writing articles about fantasy novels for an online magazine, found opportunity on fantasy lit forum, studying characters and themes, making book recommendations, loves writing about Harry Potter and Game of Thrones
- Aug 11, 2023: Recommended "The Name of the Wind" to John - described it as a fantasy novel with great magician/musician protagonist, excellent world-building; discussed with John how meaningful objects (like his lucky basketball shoes) become special through the stories they carry

Both had fun exchanging photos during the conversation, including basketball jerseys, game photos, and book collections.
- June 15, 2023: John exploring endorsement opportunities with sports brands (Nike, Under Armour); Tim shared photo of Harry Potter bookshelf featuring MinaLima props (props created for HP films), mentioned these help him "escape reality" and plans to visit more HP spots in the future
- August 9, 2023: Tim skyped with a Harry Potter fan from CA, discussed characters and potential collaboration; John shared photo from a recent basketball game they won with a tight score; Tim mentioned reading a fantasy book by Patrick Rothfuss
- August 11, 2023: John shared he visited Chicago, loved the energy and friendly locals; Tim recommended "The Name of the Wind" by Patrick Rothfuss (fantasy novel with magician/musician protagonist); John shared his lucky basketball shoes with stories from his journey; John detailed his basketball journey (watched NBA with dad, local league at 10, college scholarship, drafted); John shared goals (championship, charity work helping disadvantaged kids with sports and school)

- August 15, 2023: John reunited with teammates after a trip - atmosphere was electric, everyone missed him, felt so welcome and lucky to be part of the team
- August 17, 2023: Tim mentioned plans to attend a book conference next month (September 2023) with authors, publishers, and book lovers; John shared photo of autographed basketball from teammates as a symbol of their friendship and appreciation; discussed how meaningful objects remind them of their journey and support
- August 21, 2023: John found a new gym with a basketball court and cones; discussed adapting his routine with a balance of basketball training and strength training (which builds muscle, increases power, prevents injuries, and makes him more explosive); Tim has been focusing on school, reading fantasy books, and learning to play the piano; discussed favorite piano song (theme from Harry Potter and the Philosopher's Stone) and family movie memories from watching the first HP film; shared photos of family gatherings and Thanksgiving traditions; discussed favorite holiday movies: Home Alone, Elf, and The Santa Clause; Tim decorated a Harry Potter-themed Christmas tree himself

- October 2, 2023: Tim shared a photo of his bookcase filled with DVDs and games; John shared a photo of his wedding ceremony in a greenhouse, the most important day of his life with his wife. They had an intimate gathering following safety protocols. John's hiking club friends attended despite him recently joining. A favorite moment was seeing his wife walking down the aisle, her face lit up with joy. The first dance was at a cozy restaurant with music and candlelight. Tim shared a photo of his bookshelf with fantasy novels that fire up his imagination and serve as an escape to alternate realities. John shared a photo of his basketball jerseys collection. Their favorite team is the Wolves and they admire LeBron James for his skills, leadership, and work ethic. John has met LeBron a few times and seen him play live, finding the energy and motivation incredible. John expressed how much he loves his job and finds joy in the moments he experiences.