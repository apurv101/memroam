name: Project Falcon
description: Internal API rewrite project.
---
# Project Falcon

## Overview
- **Codename**: Falcon (internal)
- **Purpose**: Internal API rewrite

## Technical Details
- **Database**: Postgres 16 (migration complete from Postgres 15)
- **Deploy Schedule**: Wednesday mornings (Friday deploys discontinued due to weekend incidents)
- **Staging Region**: eu-west-1
- **Search Endpoint Target**: 200ms p95 latency (staging)

## Team
- **Billing Service**: Marco (parental leave starting next week), Dana (acting owner, through end of year)
- **Gateway**: [User]

## Budget
- **Contractor Budget**: $40k for this half
