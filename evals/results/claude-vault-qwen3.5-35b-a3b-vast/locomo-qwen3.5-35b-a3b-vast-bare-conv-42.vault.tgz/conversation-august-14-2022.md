name: conversation-august-14-2022
description: Conversation between Nate and Joanna on August 14, 2022 about their current projects

---
**Date:** August 14, 2022, 6:12 pm

**Participants:** Nate and Joanna

**Summary:**
Joanna and Nate caught up on their current activities. Joanna shared that writing has become a huge part of her life, serving as an escape and way to express feelings. She mentioned someone wrote her a letter after reading her online blog post about a hard moment, and that her story brought them comfort—reinforcing why she loves writing and its impact on others.

Nate shared that he's been teaching people how to make dairy-free desserts, specifically coconut milk ice cream. He showed a photo of a dessert with whipped cream and chocolate sauce. Joanna expressed she'd love to try his recipe, and Nate agreed to share it with her. Joanna planned to surprise her family with the dessert.

**Key points:**
- Writing is Joanna's way to express feelings and heal
- Joanna's blog post comforted someone who wrote her a letter
- Nate is teaching dairy-free dessert making (coconut milk ice cream)
- Nate shared a new creamy, dairy-free dessert recipe
- Joanna will try the recipe and share with family