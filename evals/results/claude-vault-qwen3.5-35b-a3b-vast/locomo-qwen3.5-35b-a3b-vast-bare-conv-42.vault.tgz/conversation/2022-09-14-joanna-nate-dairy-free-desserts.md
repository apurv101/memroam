name: Conversation with Joanna & Nate - Dairy-Free Desserts
description: September 14, 2022 conversation about vegan ice cream cooking show and dairy-free dessert recipes

# Session Overview
**Date:** September 14, 2022, 1:43 PM  
**Participants:** Joanna, Nate  
**Platform:** Casual chat about personal projects and recipes

# Joanna - Personal Updates
- **Profession:** Writer
- **Recent incident:** Laptop crashed early September 2022, lost all work
- **Response:** Now uses external drive for backups
- **Quote:** "Losing all progress was like a major blow"

# Nate - Personal Updates
- **Recent milestone:** Started teaching vegan ice cream recipes on cooking show (last Monday = Sept 5, 2022)
- **Favorite dish from show:** Coconut milk ice cream (dairy-free, smooth, creamy, tropical coconut twist)
- **Other favorites:** Dairy-free chocolate mousse (super creamy, tastes like the real thing)

# Dessert Recipes Shared

## Joanna's Favorites
1. **Chocolate Raspberry Tart**
   - Almond flour crust
   - Chocolate ganache
   - Fresh raspberries
   - [Shared photo]

2. **Dairy-Free Chocolate Cake**
   - Ingredients: almond flour, coconut oil, chocolate, raspberries
   - Her favorite for birthdays and special days
   - Moist, delicious, perfect sweetness
   - [Shared photo]

3. **Blueberry Coconut Dessert**
   - Blueberries, coconut milk
   - Gluten-free crust
   - Creamy and delicious
   - [Shared photo]

## Nate's Recipes
- Coconut milk ice cream (shared recipe willing)
- Dairy-free chocolate mousse

# Themes & Takeaways
- Shared love of dairy-free/vegan desserts
- Joanna committed to dairy-free desserts (especially for birthdays)
- Nate encouraging about spreading dairy-free options
- Both open to sharing and trying each other's recipes
