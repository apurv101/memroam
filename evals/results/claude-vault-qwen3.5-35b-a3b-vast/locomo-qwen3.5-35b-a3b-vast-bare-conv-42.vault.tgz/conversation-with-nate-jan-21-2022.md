name: Conversation with Nate - January 21, 2022
description: Nate and Joanna catch up about hobbies, movies, and game tournaments

Nate and Joanna had a catch-up conversation on January 21, 2022.

**Nate's interests:**
- Video games (main hobby) - recently won his first tournament in Counter-Strike: Global Offensive, a team shooter
- Movies (main hobby) - loves action and sci-fi movies for the cool effects

**Joanna's interests:**
- Writing
- Reading
- Watching movies
- Exploring nature
- Favorite genres: dramas and romcoms (loves getting immersed in feelings and plots)

**Movie discussion:**
- Joanna recommended a romantic drama about memory and relationships to Nate
- She shared a photo of the movie poster showing a man and woman on a bench
- Joanna first watched it around 3 years ago and bought a physical DVD copy
- She's seen it a few times and considers it one of her favorites
- Likes it for the idea and the acting
- Nate is interested in watching it, enjoys watching classics

**Notable moment:**
Nate shared exciting news about winning his first video game tournament the week before the conversation.
