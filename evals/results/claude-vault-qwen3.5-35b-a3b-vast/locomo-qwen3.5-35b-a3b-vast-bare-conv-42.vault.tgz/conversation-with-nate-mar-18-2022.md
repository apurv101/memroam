name: Conversation with Nate - March 18, 2022
description: Joanna wraps up her second script; Nate shares tortoise and turtle photos; they discuss pets, allergies, and next steps for Joanna's screenplay

Joanna and Nate had a conversation on March 18, 2022.

**Joanna's screenplay journey:**
- Has WRAPPED her SECOND script (progression from finishing first screenplay in January 2022)
- Experiencing a wild mix of feelings: relief, anxiety, excitement, and terror
- Nervous about her work getting noticed and hitting the big screen
- Has been doing research and networking non-stop for the next steps
- Determined to make it happen but finding it tough
- Feeling grateful for Nate's support throughout the process

**Nate's pets:**
- Shares a photo of two tortoises laying on the ground in a jungle
- Shares a photo of three turtles sitting on rocks in a pond
- Attracted to turtles because they're unique, have a slow pace (nice change from life's rush), low-maintenance, and calming
- Takes care of them by keeping their area clean, feeding them properly, and ensuring they get enough light
- Sends photos regularly so Joanna can watch them grow

**Allergies:**
- Joanna is allergic to cockroaches (new information)
- Previously allergic to most reptiles and animals with fur
- Would love to get two turtles if she could despite her allergies

**Joy and connection:**
- Joanna shares a photo of a cinema ticket on a chair
- Finding it comforting to have someone to support her through the script process
- Nate reminds her to enjoy small moments, like walking the pets
- Both see pets as bringing joy and comfort

**Themes:**
- Hope vs. doubt - the tug-of-war Joanna experiences
- Support system importance - having Nate's encouragement helps her keep pushing
- Finding calm in unexpected places (turtles, pets, creative work)
- Persistence despite challenges
