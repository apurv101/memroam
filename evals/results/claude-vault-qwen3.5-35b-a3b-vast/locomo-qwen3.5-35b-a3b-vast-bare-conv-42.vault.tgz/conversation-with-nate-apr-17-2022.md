name: Conversation with Nate - April 17, 2022
description: Discussion about books, hiking, nature, pets, and ice cream recipe

---

## Date & Time
- 6:44 pm, April 17, 2022

## Participants
- Nate
- Joanna

## Key Topics Discussed

### Books & Reading
- Joanna has been reading a lot in the past week
- Both have books they haven't read in years

### Nature & Hiking
- Joanna found an awesome hiking trail in her hometown
- Joanna is a huge fan of nature and considers it her "haven"
- She finds nature calming, inspiring, and a way to reset
- Nature makes worries and stress vanish for her
- Nate mentioned a nice trail north of where he lives
- Nate isn't really into hiking but is curious to see trails

### Pets & Hobbies
- Nate has pets (turtles)
- Nate's hobbies include cooking and spending time with pets
- Pets and hobbies help Nate take a break from reality
- Nate brought turtles into the kitchen to watch him make food

### Shared Photos
- Photo of a turtle and a strawberry in a bowl
- Photo of a bowl of ice cream and a bowl of sprinkles

### Ice Cream Recipe (Dairy-Free)
**Ingredients:**
- Coconut milk
- Vanilla extract
- Sugar
- Pinch of salt

**Method:**
1. Chill mixture in fridge
2. Put in ice cream maker
3. Freeze until scoopable

**Notes:**
- Joanna is lactose intolerant
- Joanna plans to make it that night
- Nate's ice cream is dairy-free and easy to make

## Personal Details
- **Joanna:** Loves books, nature, hiking; lactose intolerant
- **Nate:** Has turtle pets, enjoys cooking, isn't into hiking but appreciates nature
