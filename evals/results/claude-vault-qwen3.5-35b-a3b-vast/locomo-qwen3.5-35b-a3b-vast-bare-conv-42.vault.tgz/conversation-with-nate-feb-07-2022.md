name: Conversation with Nate - Feb 7, 2022
description: Joanna and Nate discuss Joanna's screenplay submission to a film festival, Nate's coconut milk ice cream, and movie recommendations.

# Conversation with Nate - February 7, 2022 (9:27 AM)

**Joanna and Nate caught up:**

- **Joanna's screenplay**: Submitted to a film festival, experiencing mixed emotions (relief, excitement, worry). Hopeful a producer or director will love it and get it on the big screen.

- **Nate's ice cream discovery**: Made coconut milk ice cream, found it "super good" - rich and creamy. Plans to try different flavors and toppings. Favorite dairy-free flavors: coconut milk, chocolate, and mixed berry.

- **Nate's baking**: Made a dairy-free chocolate cake with berries, shared a photo with Joanna.

- **Movie recommendation**: Joanna watched "Little Women" and highly recommended it - described as a great story about sisterhood, love, and reaching for dreams. Nate plans to watch it and get back to Joanna.

**Key takeaways:**
- Joanna is pursuing her screenwriting dream and seeking support
- Nate has been exploring dairy-free desserts and enjoys creative cooking
- Both have interests in food and movies
