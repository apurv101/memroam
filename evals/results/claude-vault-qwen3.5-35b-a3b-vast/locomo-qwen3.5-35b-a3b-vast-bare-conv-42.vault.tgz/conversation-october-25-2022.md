name: Conversation with Joanna - October 25, 2022
description: Joanna shares that her movie script was shown on the big screen for the third time; Nate has two turtles with different personalities.
date: 2022-10-25

---

Nate: Hey Joanna, what's been up since we last chatted? How's it going?

Joanna: [shares a photo: a photo of a box of cards with a quote on it] Hey Nate! Another movie script that I contributed to was shown on the big screen last Sunday for the first time! It was such a surreal experience to see everything come together. I felt a mix of emotions, but overall, it was a satisfying moment. I've been waiting for this for a long time!

Nate: [shares a photo: a photo of a box with a controller inside of it] Congrats Joanna! How was it to finally see it on the big screen?

[shares a photo holding a videogame controller]

Joanna: It was an amazing experience! I'll never forget seeing all of the characters and dialogue I wrote being acted out - it was such a cool feeling. Having all the hard work and determination I put into writing pay off was definitely rewarding. I know this is the third time it's happened, but its just so awesome!

Nate: That must have been amazing. What was your favorite part of it?

Joanna: [shares a photo: a photo of a drawing book with a bunch of drawings on it] Seeing my characters I worked so hard on come alive was my favorite part. It felt like they jumped off the page and became real - it was totally surreal.

Nate: Wow Joanna, those drawings are really incredible! What inspired you to create them?

Joanna: Thanks, Nate! They're visuals of the characters to help bring them alive in my head so I can write better.

Nate: That's a cool way to gain insight into your characters. Where did you get your ideas for them?

Joanna: I got ideas from everywhere: people I know, stuff I saw, even what I imagined. It's cool to see how an idea takes shape into a person with their own wants, worries, and wishes.

Nate: Wow Joanna, that's so cool! It's amazing how our imaginations can bring ideas to life. Can you tell me more about the character on the left in the photo?

Joanna: Nope! You'll just have to watch the movie and find out for yourself!

Nate: You got it. I was already planning on watching it, but talking to you about it makes me want to watch it even more!

Joanna: Awesome! Well enough about me, what have you been up to?

Nate: [shares a photo: a photography of two turtles sitting on a log in a pond] I was bored today, so I just took my turtles out for a walk.

Joanna: Sound fun! Did they have a good time?

Nate: [shares a photo: a photography of a dog laying on a rock in a zoo] Of course! They look tired from all the walking, so they're relaxing in the tank right now.

Joanna: [shares a photo: a photo of a spoon full of ice cream and chocolate sauce] Aww, they're so cute! What do they eat?

Nate: [shares a photo: a photo of a container of lettuce and other greens] They eat a combination of vegetables, fruits, and insects. They have a varied diet.

Joanna: Wow, that's fascinating! It's interesting how they have such a varied diet, including insects. Do you have a favorite among their food choices?

Nate: [shares a photo: a photography of a group of strawberries and a turtle on a table] I love seeing them eat fruit - they get so hyped and it's so cute!

Joanna: Wow, that's so cute! They look like they really enjoy fruit.

Nate: [shares a photo: a photo of a person holding a small turtle in their hand] Yeah, it's adorable! Watching them enjoy their favorite snacks is so fun. I also like holding them.

Joanna: [shares a photo: a photo of a rock formation with a person standing on the side] Do they have different personalities, like the way dogs and cats do?

Nate: Yeah, they each do. One is more adventurous while the other is more reserved, which I find cute. Having them around brings me joy and they make great companions.

Joanna: That's super cool! I never knew turtles could be so interesting until I met your turtles. Wow!

Nate: I've always liked turtles since I was a boy, so I know all about them!

Joanna: You'll have to keep me posted on them! It's been fun chatting!

Nate: See you later Joanna!
