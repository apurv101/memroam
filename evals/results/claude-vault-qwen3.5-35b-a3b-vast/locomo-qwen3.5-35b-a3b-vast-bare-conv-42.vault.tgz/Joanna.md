name: Joanna
description: Creative writer working on blog and publishing book, makes dairy-free desserts

**About:**
- Works on screenplay projects and recently shared her book with a writers group
- Enjoys experimenting in the kitchen
- Cooking and baking are her creative outlets
- Specializes in making dairy-free desserts
- Received coconut recommendation from Nate previously
- On Nov 11, 2022, finally filming her own movie from the road-trip script. Found every day on set "awesome and full of potential"
- Had emotional moment when an actor told her how much she liked her script - gave her chills
- Pitched a script to producers on Nov 8, 2022 (day before this conversation) and they liked it
- Took a road trip to Woodhaven, a small Midwest town, in June 2022 for research and inspiration
- Discovered a library in Woodhaven with a cool old book collection
- Found a 1900s book with stories and sketches about the town, which sparked ideas for her next script
- Started working on a book in July 2022, her first time attempting to publish a book
- Her book explores themes of loss, redemption, and forgiveness through dialogue
- Received great feedback from her writers group on her book

**Notable creations:**
- Dairy-free vanilla cake with strawberry filling and coconut cream frosting
- Shares desserts with friends and family
- Finds it rewarding to see people enjoy her dairy-free creations

**Relationship with Nate:**
- Received "Lord of the Rings" trilogy recommendation from Nate and enjoyed it
- Corresponds regularly about their respective projects
- Agreed to go hiking together on trails

**Hiking:**
- Believes she is now an expert hiker
- Discovered amazing trails in her town
- Finds hiking deeply inspiring and calming
- Visits Whispering Falls, a peaceful location with a waterfall
- Photography: took a photo of a waterfall with dark sky at Whispering Falls
- Nature hiking inspires her to write dramas and screenplays
- Feels like a "different person" after being in nature
- When hiking, she feels the present moment matters most and everything else fades away