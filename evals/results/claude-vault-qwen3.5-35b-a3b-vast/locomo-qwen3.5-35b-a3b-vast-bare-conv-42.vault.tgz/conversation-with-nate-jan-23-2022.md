name: Conversation with Nate - January 23, 2022
description: Joanna shares finishing her screenplay; Nate shows off his turtles

Joanna and Nate had a conversation on January 23, 2022.

**Joanna's news:**
- Finally finished her first full screenplay (drama/romance mix)
- Printed it last Friday
- Planning to submit to film festivals
- Wants producers and directors to check it out
- Feeling relief, excitement, and anxiety about finishing

**Nate's turtles:**
- Has an adult turtle and a turtleling
- Has had them for 3 years
- They help calm him when nervous about important things
- They have big personalities despite being small
- Recommends having pets like these for stress relief

**Allergies:**
- Joanna is allergic to most reptiles and animals with fur
- Her face gets puffy and itchy around certain animals
- Has always stayed away from pets due to allergies

**Joy and coping:**
- Joanna finds joy in writing and hanging with friends
- Writing helps her create wild worlds with awesome characters
- Writing is a way to express her feelings
- Nate enjoys video game tournaments and has made friends outside his circle
- Nate plays for fun, not just to win

**Tournament friends:**
- Nate hangs out with people outside his circle at tournaments
- Some people are competitive, so he sticks with chill people
- Plans to cheer them on even if he loses