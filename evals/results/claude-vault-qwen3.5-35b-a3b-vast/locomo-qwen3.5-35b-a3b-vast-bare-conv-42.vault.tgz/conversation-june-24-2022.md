name: Conversation with Joanna - June 24, 2022
description: Conversation about screenplay contest, gaming party success, and vegan ice cream recipe

Joanna: Hey Nate, long time no see! How have you been? I just got done submitting my recent screenplay to a film contest just to see how others might like it!
Nate: That's really cool Joanna! I hope it does well, and I've been doing great! The gaming party was a great success! We even played some Chess afterward just for fun.
Joanna: Nice! Did your friends like the controller accessories?
Nate: Most of them did! I can't say if all of them will continue to use them or not, but that's beside the point.
Joanna: Yeah Nate, you're right. It doesn't matter if they use it, its the thought that matters right?
Nate: Absolutely! There were 7 people that attended, and 6 of them said they'd want to do it again next month!
Joanna: That sounds like a huge success then! Congrats!
Nate: [shares a photo: a photography of a group of people sitting on a bench] Thanks! On another note, I made vegan ice cream last Friday and shared it with some people in my vegan diet group. It was awesome!
Joanna: Mm, yum! Can you give me the recipe for that? It sounds like it'd be a good recipe!
Nate: Sure thing! I can give it to you tomorrow, how does that sound?
Joanna: Awesome! I'm going to make it for my family this weekend - can't wait!
Nate: Nice one, Joanna! Hope you and your family like it. Let me know how it went!
Joanna: Sure thing! They love it when I make them new things!
Nate: Then I have no doubt they'll love the icecream!
Joanna: Thanks Nate! Your support is greatly appreciated. I'll make sure to keep you updated.
Nate: Can't wait to hear about it. Have a great day! Take care.
