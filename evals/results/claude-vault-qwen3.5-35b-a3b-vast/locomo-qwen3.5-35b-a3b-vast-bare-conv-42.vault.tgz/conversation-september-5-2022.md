name: Nate & Joanna conversation
description: Conversation from September 5, 2022 about gaming, desserts, and spending time together

**Date:** September 5, 2022 (6:03 pm)

**Nate:**
- Shared a photo of two turtles sitting on a rock in a pond
- Had a letdown in a video game tournament - didn't do well despite trying
- Calling it a setback but trying to stay positive
- Mentions hanging with the turtles has been a big help recently
- Interested in baking and cooking as activities that bring people together
- Offered tips for dairy-free baking to Joanna

**Joanna:**
- Shared a photo of cake with strawberries and chocolate (revised old recipe)
- Been tinkering with recipes as a way to find comfort and get creative
- Experimenting with flavors: chocolate, raspberry, and coconut
- Made dairy-free chocolate coconut cupcakes with raspberry frosting
- Still making all sorts of dairy-free desserts (cookies, pies, cakes)
- Shared photos of dairy-free chocolate coconut cupcakes and a cookie with chocolate drizzle and almonds
- Agreed to let Nate join her in the kitchen sometime

**Key points:**
- Continuing their interest in dairy-free desserts
- Joanna using baking as a creative outlet and comfort
- Nate encouraging and supporting Joanna's baking
- Planning to potentially spend time cooking together
- Both maintaining positive attitudes despite setbacks (Joanna finding comfort in baking, Nate staying positive about gaming)
