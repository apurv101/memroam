name: Conversation with Joanna - November 4, 2022
description: Joanna shares success with movie producer meetings, discusses her early writing including a story about a turtle, and plans to meet Nate to share recipes
date: 2022-11-04

---

Joanna: Wow, Nate, I'm on fire! I just set up meetings with movie producers — my dreams are comin' true!

Nate: Wow Joanna, nice work! How did it go with those producer meetings?

Joanna: Thanks, Nate! The meetings went really well. I felt confident discussing my script and vision and they seemed interested and excited. They loved the elements of self-discovery in it. It was so validating to be taken seriously. I'm feeling hopeful and inspired about the future!

Nate: [shares a photo: a photo of a television screen showing a game being played] Way to go, Joanna! Putting yourself out there is really brave and winning recognition for your hard work feels great. It's just like when I win a video game tournament - it feels awesome! I'm so proud of you and so glad you're feeling hopeful and inspired.

Joanna: [shares a photo: a photo of a notebook with a list of things to write] Thanks Nate! Your support and encouragement mean a lot. Writing isn't always easy but moments like these make me appreciate it. I'm so thankful for all the opportunities. Last week, I found these old notebooks with my early writings - it was cool to see how far I've come.

Nate: [shares a photo: a photo of a turtle laying on a bed of rocks and gravel] That's cool! You must love seeing how you've grown as an artist. Is there a favorite piece from your early writings that stands out to you?

Joanna: Yup, I still remember this story from when I was 10. It was about a brave little turtle who was scared but explored the world anyway. Maybe even back then, I was inspired by stories about finding courage and taking risks. It's still a part of my writing today.

Nate: [shares a photo: a photo of a turtle laying on a bed of rocks and gravel] You obviously have a passion for writing, and it's funny the story was about a turtle! Their resilience is so inspiring! Take courage and keep pushing yourself with your writing. Great job!

Joanna: Thanks, Nate! They make me think of strength and perseverance. They help motivate me in tough times - glad you find that inspiring!

Nate: What can I say, I love turtles. So, what's been happening with you?

Joanna: Hey Nate! Apart from meetings, I'm working on a project - challenging but fulfilling. How about you? What's been going on?

Nate: Just been helping some friends reset their high scores at the international tournament. It's been fun!

Joanna: Wow, sounds like so much fun! You're really passionate about gaming. Have an awesome time and keep helping others with those high scores!

Nate: Thanks! It feels good to use my skills to make a difference.

Joanna: I couldn't agree more! Which is why my meetings are so exciting!

Nate: [shares a photo: a photo of a bowl of ice cream with a spoon in it] On another note, want to come over and try some of this? It's super yummy, just made it yesterday!

Joanna: Mmm, that looks delicious! Is it lactose-free by any chance?

Nate: Yep, I made it with coconut milk so it's lactose-free!

Joanna: [shares a photo: a photo of a bowl of ice cream with a spoon in it] Thanks so much, Nate! Sure! I'll come over tomorrow if that's fine.

Nate: I don't see why not! I'm not doing anything then, so your completely welcome to!

Joanna: Awesome! I'll bring some of my recipes so we can both share deserts!

Nate: I'd love that! I've been wanting to try some of your chocolate and rasberry cake for a while now.

Joanna: You got it! See you tomorrow!

Nate: See you then! Take care!
