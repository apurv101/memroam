name: Conversation with Joanna - April 21, 2022
description: Nate and Joanna discussed Joanna's new writers group, her script "Finding Home", acting background, and exchanged book/movie recommendations.

On April 21, 2022, Nate and Joanna had a friendly conversation about their creative pursuits and hobbies.

Joanna shared that she just joined a writers group with inspirational people who support her writing. She's feeling motivated and finally feels like she belongs somewhere. Her current project with the group is called "Finding Home" - a script about a girl on a journey to find her true home, which Joanna finds rewarding and emotional.

Joanna's background:
- Acting was her first passion
- Now focuses on writing as her primary creative outlet
- Shared a photo of herself performing in a striped suit on stage
- Had a memorable experience of forgetting her lines in her first play, which taught her the importance of preparation

Nate shared:
- Has a gaming tournament next month (his 4th one)
- Loves fantasy and sci-fi movies as escapism and creativity inspiration
- Enjoys playing video games as a form of creative expression
- Showed Joanna a book trilogy he loves (world building, battles, storytelling)
- Recommended another book series to Joanna (adventures, magic, great characters)

Joanna mentioned she enjoys dramas and emotionally-driven films and was interested in book recommendations. Nate recommended series he thought she'd like, and Joanna agreed to check them out and share her thoughts later.

Both ended the conversation with friendly wishes.