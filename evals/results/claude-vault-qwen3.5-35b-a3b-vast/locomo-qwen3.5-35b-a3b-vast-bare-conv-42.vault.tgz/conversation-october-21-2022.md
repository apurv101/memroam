name: Conversation with Joanna - October 21, 2022
description: October 21, 2022 conversation between Nate and Joanna about recipes, stress, pets, and career setbacks.

---

Date: October 21, 2022, 2:01 pm

Nate: Hey Joanna, what's been up? Haven't seen you since we last talked.

Joanna: Hey Nate! I have been revising and perfecting the recipe I made for my family and it turned out really tasty. What's been happening with you?

Nate: Hey Joanna! That's cool. I've been getting so stressed lately because of my tournament progress - tough competitors - but my turtles always cheer me up.

Joanna: [shares a photo: a photo of a cat laying on the floor in a room] Pets have a way of brightening our days. I still have that stuffed animal dog you gave me! I named her Tilly, and she's always with me while I write.

Nate: Glad to hear it! What made you name her Tilly?

Joanna: I used to have a dog back in Michigan with that name, but then I got allergic and we had to get rid of her. The name helps me remember her back when I used to be able to hold and squeeze animal without an allergic reaction!

Nate: That's so touching! Glad the stuffed animal means so much!

Joanna: Tilly helps me stay focused and brings me so much joy. It's amazing how even stuffed animals can do that!

Nate: It really is, I'm not sure I'll ever understand why watching my turtles slowly walk around makes me so happy. But I'm very glad it does.

Joanna: Same here! So have you been up to anything recently?

Nate: Yeah, I've just been practicing for my next video game tournament. How about you?

Joanna: Well, I had a bit of a setback recently - another rejection from a production company.

Nate: Bummer, Joanna. Is this the one you sent to a film contest? Rejections suck, but don't forget they don't define you. Keep at it and you'll find the perfect opportunity.

Joanna: Yeah.. Thanks, Nate. It's hard, but I won't let it slow me down. I'm gonna keep grinding and moving ahead.

Nate: That's what I like to hear! I really respect you for that and being able to bounce back whenever something sad happens!

Joanna: Thanks, Nate! Your encouragement really means a lot. I'm gonna keep pushing forward and believing in myself.

Nate: You got this, and don't ever forget that you have people cheering you on from the sidelines wherever you go.

Joanna: Thanks! I'll see you around!

Nate: No problem! Catch you later!
