name: Conversation with Nate and Joanna
description: 2/25/22 - Nate shared ice cream recipes with Joanna, Joanna discussed her screenplay about self-discovery after loss

---
## Conversation Summary

**Date:** February 25, 2022, 1:07 PM

### Nate
- Made ice cream for a friend who loved it
- Created a chocolate and vanilla swirl
- Shares a coconut milk (dairy-free) recipe with Joanna
- Enthusiastic about baking desserts
- Supportive of Joanna's work

### Joanna
- Dairy-free (cannot have dairy)
- Interested in Nate's coconut milk ice cream recipe
- Screenwriter working on multiple screenplays
- **Current project:** Screenplay about a 30-year-old woman on a journey of self-discovery after a loss
  - Involves a road trip to heal and grow
  - Inspired by her own personal experiences
  - Themes: loss, identity, healing
- Currently waiting to hear back on her first screenplay's fate
- Describes her stories as her "own story"

### Notable Details
- Photo shared: person holding chocolate and vanilla ice cream cone
- Warm, supportive friendship
- Joanna's writing focuses on deep, personal topics involving loss and self-discovery
