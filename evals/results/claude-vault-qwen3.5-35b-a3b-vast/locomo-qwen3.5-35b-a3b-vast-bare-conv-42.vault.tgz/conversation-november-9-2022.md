name: Conversation - November 9, 2022
description: Nate and Joanna discuss recent events, new ventures, and plans to meet
date: 2022-11-09
participants:
  - Nate
  - Joanna

---

Nate shared a photo of himself making homemade dairy-free coconut ice cream. His game tournament was pushed back, so he tried cooking instead. The sprinkles changed the color this time around.

Joanna asked about the last game tournament. Nate said it was tough and he didn't make it to the finals, but he's staying positive and will get them next time.

Nate mentioned he's thinking of joining a new gaming team after the next tournament - he's had a few offers but hasn't decided yet. He sees it as a big step and a shake up, but he's excited.

Joanna shared that she worked hard on another script and created a plan to get it made into a movie. She pitched it to some producers yesterday and they really liked it, which gave her a big confidence boost. Nate shared a photo of a trophy and game controller, congratulating her.

Joanna shared a photo of a pen, notebook, and book. She's working on a new project - a suspenseful thriller set in a small Midwestern town. It's been a great creative outlet.

Nate shared a photo of his desk with a computer, headphones, and microphone. He's creating gaming content for YouTube as a way to entertain people and satisfy his video game cravings when there aren't tournaments going on.

Joanna advised him to watch other people's videos first to understand what the audience likes so his videos don't flop. Nate confirmed he's already doing that.

Joanna shared a photo of a sunflower in a field with a sunset background, taken on a hike last summer near Fort Wayne. She said the sunset and surrounding beauty were incredible and it was a reminder of nature's beauty.

Nate shared a photo of three turtles sitting on a rock in a pond. He got a third turtle - he saw another at a pet store and had to get him. The tank is now big enough for three, and turtles bring him joy and peace.

Joanna said it's always a shock where life takes us next. Nate agreed he's very happy with the decision.

Joanna asked if she could come over to watch the turtles play from a distance since she's allergic. Nate definitely invited her over and suggested they could watch one of her movies together or go to the park.

They both said they'd love to do either activity. Nate mentioned he'd give the turtles a bath before she comes so they're ready to play.

They said goodbye and agreed to see each other the next day (November 10, 2022).
