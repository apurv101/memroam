name: Joanna's Inspiration Board
description: Joanna has a cork board with inspiring quotes, family photos, and keepsakes

Joanna maintains an inspiring cork board that serves as her "little corner of inspiration." It features:
- Inspiring quotes
- Pictures and photos (including a family photo)
- Little keepsakes

The family photo specifically reminds her of the love and encouragement from her family every day. It keeps her going and means a lot to her.
