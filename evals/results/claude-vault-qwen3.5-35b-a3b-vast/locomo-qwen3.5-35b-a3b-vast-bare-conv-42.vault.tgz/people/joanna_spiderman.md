name: Joanna's Favorite Superhero
description: Joanna's favorite superhero is Spider-Man

Joanna mentioned that Spider-Man has always been her favorite superhero. She connects with Peter Parker's struggles between being a hero and being a person. However, she's also "kind of a sucker for any superhero" and appreciates that everyone has their own rad story and powers.
