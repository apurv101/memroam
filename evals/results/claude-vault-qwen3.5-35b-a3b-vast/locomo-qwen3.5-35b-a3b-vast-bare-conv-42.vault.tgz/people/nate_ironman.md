name: Nate's Iron Man Figure
description: Nate has an Iron Man figure that reminds him to keep working on his goals

Nate's favorite superhero is Iron Man, whom he loves for the tech and sarcastic humor. He has an Iron Man toy figure in his room that serves as a reminder to keep working on his goals. Its presence makes him feel invincible and reminds him of something he loves.
