name: Joanna's Screenplay Achievement
description: Joanna wrote bits for a screenplay that appeared on the big screen on June 4, 2022

Joanna shared that she wrote bits for a screenplay that appeared on the big screen on June 4, 2022 (May 5, 2022). She described it as nerve-wracking but inspiring to see her words come alive. It was described as a "real roller coaster" experience but seeing the hard work pay off was amazing.
