name: Nate
description: Competitive gamer with gaming room, also provides recommendations

**About:**
- Competitive gamer who also shares love for dairy-free desserts
- Plays CS:GO competitively and Street Fighter with friends
- Has a gaming room setup with computer and gaming chair
- Dedicated to practice and competition
- Started teaching people how to make dairy-free desserts
- Has a new recipe for creamy, rich dairy-free coconut milk ice cream
- Tried cooking and made dairy-free coconut ice cream on Nov 9, 2022 when tournament was pushed back

- On Nov 11, 2022, took turtles to the beach in Tampa - they bring him peace in the craziness of life
- Loves seeing turtles soaking in the sun and finds them calming
- Continuing to experiment with coconut milk ice cream flavors, made colorful bowls on Nov 11, 2022

**Fish keeping:**
- Has a fish tank with fish that he calls "little dudes" or "little buddies"
- Expanded the fish tank, giving them more room
- Got a third turtle on Nov 9, 2022 after seeing one at a pet store
- Describes the fish as calm and peaceful, which helps him relax after gaming
**Achievements:**
- Won first tournament in CS:GO
- Won second tournament in Street Fighter (local tournament)
- Last tournament opponent shook his hand after the match
- Won fourth video game tournament on July 8, 2022 (online tournament)
- Won an international gaming tournament on August 21, 2022
- Makes a living from gaming

**Interests:**
- Gaming is his main focus
- Gives recommendations (e.g., recommended coconut for baking)
- Watched "Lord of the Rings" trilogy on Joanna's recommendation
- Hiking: Enjoys being in nature, gets deep in thought about life or recipes when hiking, nature serves as a break from life's craziness
- Wrote up a drama screenplay and published it after hiking experience with Joanna

**Relationship with Joanna:**
- Discussed hiking with Joanna and agreed to join her on trails
- Joanna inspired Nate to write a drama screenplay about hiking experiences
- Previously exchanged book/movie recommendations
- Discussed attending a game convention together

---

**Recent Activities (Oct 2022):**
- Attended a game convention and made new friends who share his gaming interests
- Plans gaming sessions with new friends from the convention
- Enjoys gaming as a way to escape from life struggles and de-stress

**Board Games:**
- Loves Catan (a strategy game about building settlements and trading resources)
- Enjoys both competitive and chill gameplay styles
- Values shared hobbies as a way to bond with people

**Video Games:**
- Cyberpunk 2077 - playing nonstop, loves the futuristic setting and gameplay
- Gaming is his main escape and way to unwind

**Movies:**
- Inception - recently watched, "blew his mind with all the twists and dream stuff"
- Enjoys movies as a way to escape to new worlds and feel emotions
- Values movies for unwinding after a day

**Living Room Goals:**
- Wants to make his space cozier like Joanna's setup
- Interested in getting a comfortable couch that can sit multiple people
- Considering a weighted blanket for comfort
- Interested in dimmable lights for ambiance