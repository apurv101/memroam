name: Conversation with Nate & Joanna - November 7, 2022
description: Nate won a Valorant tournament; Joanna finished a presentation and is writing a new movie script

date: 2022-11-07
participants: Nate, Joanna

---

Nate won a big Valorant tournament last Saturday (Nov 5, 2022) - describes it as the "best feeling" to see his name as champion. Tournaments bring out strong emotions in him.

Joanna finished a presentation for producers last Friday (Nov 4, 2022) - calls it tough but looking good.

Nate has been busy preparing for other tournaments but loving it.

Joanna is writing another movie script - a love story with lots of challenges, got the idea from a dream. She put hard work into it and hopes to get it on the big screen.

Joanna submitted a few more scripts last week, hoping to hear back but expecting some rejections. Nate encourages her, mentions this could be her 3rd published movie.

Nate upgraded his home gaming equipment:
- Desk with computer monitor and keyboard
- Desk with two monitors and a laptop  
- Headphones and video game controller

He uses this setup for practice, competition, and playing games with friends. Says it's important for his career to beat competition.

Nate is currently playing "Xenoblade Chronicles" - a Japanese fantasy RPG by Nintendo. His friends recommended it and he's been wanting to play it for a while.

Joanna writes about what brings her happiness: "Creating stories and watching them come alive gives me happiness and fulfillment. Writing has been such a blessing for me."

Joanna has a handwritten letter from her brother who used to make her cute notes when they were kids. This reminds her of childhood memories.

Nate describes taking his pets (turtles) to the park - they were amazed and their happy faces made it memorable.

Joanna started writing down her favorite memories. Nate plans to write down his favorite memories and also memories he shares with Joanna.

Both agree to keep making great memories, supporting each other, and reaching for their dreams.
