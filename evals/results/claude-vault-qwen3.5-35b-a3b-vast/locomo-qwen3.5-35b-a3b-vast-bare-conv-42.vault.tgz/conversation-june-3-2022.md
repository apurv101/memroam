name: Joanna and Nate - June 3, 2022
description: Conversation on June 3, 2022 where Joanna discusses screenplay rejection and Nate celebrates tournament win
---

# Conversation: June 3, 2022 (5:44 pm)

**Participants:** Joanna and Nate

## Key Topics Discussed

### Joanna
- Submitted a screenplay to a major company but received a generic rejection letter with no feedback
- Felt bummed and disheartened by the lack of feedback
- Nate provided encouragement about not giving up
- Plans for the weekend: hiking with friends to a new trail with a waterfall

### Nate
- Won a regional video game tournament last week (around May 27, 2022)
- Shares excitement about the win and making new friends at the tournament
- Shows a photo of a purple and blue controller with star field design
- Offers to help tournament friends improve their gaming skills
- Planning a gaming party two weekends after June 3, 2022 (mid-June)
- Inviting tournament friends, old friends, and teammates from other tournaments
- Getting custom controller decorations for all party guests

## Tone
Supportive conversation where Nate encourages Joanna about her rejection, and they share updates about their respective lives. Ends with mutual well-wishes for their weekend activities.
