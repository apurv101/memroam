name: Conversation - July 10, 2022
description: Nate celebrates fourth video game tournament win; Joanna shares Woodhaven road trip and new book project

---

# Conversation: July 10, 2022 (2:34 pm)

**Participants:** Nate and Joanna

## Key Topics Discussed

### Nate
- Won his fourth video game tournament on Friday, July 8, 2022
- The tournament was online
- Made money from the tournament
- Very proud of being able to make money doing what he loves
- Victory was described as "indescribable"
- Encouraging and supportive of Joanna's work

### Joanna
- Took a road trip for research for her next movie while Nate was winning the tournament
- Went to Woodhaven, a small town in the Midwest
- Saw lovely scenery and historic buildings
- Visited the library in Woodhaven which had a cool old book collection
- Found a super cool book from the 1900s with stories and sketches about the town and its people
- Woodhaven's interesting past with cool people sparked ideas for her next script
- Her new script is different from her previous work but has potential to be awesome
- Started working on a book recently (her first time attempting to publish a book)
- The book page she shared has dialogues exploring loss, redemption, and forgiveness
- Deep and emotional story she's excited about

## Tone
Mutually supportive and encouraging conversation where both share exciting updates about their respective creative pursuits.

## Photos Shared
- Nate: Photo of a television screen showing a trophy
- Joanna: Photo of a bookshelf filled with books
- Joanna: Photo of a 1900s book with writing on it and a pen
- Joanna: Photo of a person holding a notebook with a handwritten page
- Nate: Photo of a person holding a small turtle in a container
