name: Conversation with Nate - March 24, 2022
description: Joanna has a writing gig audition; Nate discusses video game tournament; they exchange writing advice and encouragement
date: 2022-03-24

Joanna and Nate had a conversation on March 24, 2022.

**Joanna's writing gig audition:**
- Had an audition yesterday for a writing gig
- Experiencing mixed emotions: definitely excited but also a bit anxious
- Nate offered support and encouragement
- She plans to keep him updated on the outcome

**Nate's video game tournament:**
- Currently participating in a video game tournament
- Describes it as INTENSE with a lot of adrenaline flowing
- Going through multiple days of intense gaming

**Joanna's writing inspiration space:**
- Shares a photo of a bookshelf filled with books and magazines
- This is her go-to place for writing inspiration
- Helps her stay sharp and motivated

**Writing advice from Joanna to Nate:**
- Read lots and try out different genres
- Build a solid understanding of literature
- Don't be afraid to write and share, even if it's just with friends
- Practice and gather feedback to improve
- Have faith in yourself and continue following your writing dreams
- Acknowledges it's tough but worth it

**Themes:**
- Mutual support and encouragement between friends
- Pursuing creative dreams despite uncertainty and anxiety
- Finding inspiration in familiar spaces (books)
- Persistence and dedication to craft
