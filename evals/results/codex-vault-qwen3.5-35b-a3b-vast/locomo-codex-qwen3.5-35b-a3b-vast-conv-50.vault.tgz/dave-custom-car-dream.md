name: Dave's dream of building a custom car
description: Dave's long-term goal is to build a custom car from scratch

Dave's long-term dream is to build a custom car from scratch. For now, he's focused on working on current projects with the local garage he teamed up with, while continuing to learn about auto engineering and assist customers.
