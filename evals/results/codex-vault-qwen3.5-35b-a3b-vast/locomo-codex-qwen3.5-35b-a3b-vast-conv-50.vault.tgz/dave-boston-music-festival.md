name: Dave's Boston music festival
description: Dave attended a music festival in Boston featuring Aerosmith as a favorite performance

Dave attended a music festival in Boston last weekend. He enjoyed the electric atmosphere and many cool bands. His favorite performance was Aerosmith — seeing them live was a dream come true for him. He took photos during their performance.
