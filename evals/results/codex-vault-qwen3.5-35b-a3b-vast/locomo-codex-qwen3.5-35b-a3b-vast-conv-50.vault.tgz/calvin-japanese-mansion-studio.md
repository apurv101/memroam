name: Calvin's Japanese Mansion Recording Studio
description: Calvin transforming Japanese mansion into recording studio
---
Calvin is transforming a Japanese mansion into a recording studio. This has been his dream to have a dedicated space for creating music with other artists. He described it as his sanctuary that reminds him why he loves music. The project was in progress as of early July 2023.