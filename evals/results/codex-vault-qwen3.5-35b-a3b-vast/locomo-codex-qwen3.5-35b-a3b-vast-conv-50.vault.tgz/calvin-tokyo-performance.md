name: Calvin's upcoming Tokyo performance
description: Calvin has a music performance scheduled in Tokyo this month and is excited to share his music with a new audience

Calvin mentioned having an upcoming performance in Tokyo scheduled for this month. He's super excited about the opportunity to show his music to a whole new crowd and hopefully expand his following. He took a photo of Tokyo's stunning night skyline the previous night and shared it with Dave, commenting on how amazing the city lights are.
