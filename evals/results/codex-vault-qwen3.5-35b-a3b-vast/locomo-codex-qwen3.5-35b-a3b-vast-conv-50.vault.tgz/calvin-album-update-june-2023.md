name: Calvin album update - June 2023
description: Calvin met with creative team for album, excited about progress

On June 8, 2023 (conversation dated 9 June), Calvin reported meeting with the creative team for his album. He described it as a long but awesome session, seeing everything coming together. He's feeling stoked about the album and mentioned working with a team in the studio on the music and related aspects. He showed Dave a photo of his recording studio with a large window and desk.
