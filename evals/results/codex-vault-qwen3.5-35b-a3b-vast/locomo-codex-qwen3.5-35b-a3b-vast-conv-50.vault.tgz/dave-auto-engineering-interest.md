name: Dave's interest in auto engineering
description: Dave is passionate about auto engineering and attended a car show

Dave is deeply interested in auto engineering and attended a car show last weekend. He was captivated by classic cars and impressed by the dedication people put into restoring them. He plans to show Calvin some of these classic cars when Calvin visits Boston.
