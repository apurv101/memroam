name: Calvin's album release party at Japanese mansion
description: Calvin threw a party at his Japanese mansion with family and friends to celebrate his September 2023 album release
description: Album celebration party held at Calvin's Japanese mansion with loved ones

---

In late October/early November 2023, Calvin celebrated his September 2023 album release by throwing a small party at his Japanese mansion. He described it as "amazing" with "so much love from my fam and friends."

Calvin shared photos from the event showing friends and family celebrating together — including moments of people dancing and a group photo on a stage. He described the experience as "energizing" and an "awesome feeling" to have everyone come together to celebrate.

Calvin said moments like this are "powerful reminders of why I'm doing this" and that creating something people connect with and that brings joy is what he's all about. These celebrations motivate him to keep growing as an artist.
