name: Calvin's music studio sessions
description: Calvin wrote new tunes and had studio sessions, excited to collaborate and share his music

Calvin mentioned writing new tunes and having a few studio sessions the week before this conversation. He's excited to collaborate on his music and can't wait to share it with everyone.
