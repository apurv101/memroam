name: Dave started a car mods blog
description: Dave launched a blog about car modifications and restoration, recently posting about a blue Subaru build
description: Dave launched a car mods blog to share his passion, gaining traction as people seek his advice

---

In late October/early November 2023, Dave shared that he recently started a blog about car modifications. He's using it as a way to share his passion for cars with others.

Dave mentioned the blog is getting some success — people are checking it out and reaching out to him for advice. He recently posted about a blue Subaru he modified, describing it as turning the car into a "beast." He said it was great to hear that his work inspired others to start their own DIY projects.

The blog allows Dave to share his knowledge and help others unleash their creativity with car mods and restorations.
