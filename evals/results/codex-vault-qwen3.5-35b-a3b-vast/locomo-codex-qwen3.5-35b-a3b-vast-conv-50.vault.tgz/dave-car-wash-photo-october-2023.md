name: Dave shared car wash photo
description: Dave shared photo of car washing project in garage
---

Dave shared a photo with Calvin of a group of people washing a car in his garage. He mentioned that working on cars takes him out of his head and calms him down.
