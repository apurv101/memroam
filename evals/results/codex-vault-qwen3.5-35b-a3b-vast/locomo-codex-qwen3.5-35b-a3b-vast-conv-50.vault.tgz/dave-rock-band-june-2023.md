name: Dave joined a rock band
description: Dave recently joined a rock band in June 2023 and has been practicing guitar with the group
---
In June 2023, Dave joined a rock band and has been practicing guitar with the group. He shared a photo of himself and the other band members playing instruments together. Dave believes that good company and great music lift the mood and bring positive emotions.