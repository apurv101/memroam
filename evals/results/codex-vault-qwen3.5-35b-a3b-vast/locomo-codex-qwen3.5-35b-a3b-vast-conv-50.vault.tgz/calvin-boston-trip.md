name: Calvin's Boston trip and artist collaboration
description: Calvin met with artists in Boston for potential music collaboration, inspired by their individual styles

---

On October 3, 2023, Calvin met with some incredible artists in Boston and they talked about working together. It was an inspiring and exciting experience - the artists all have individual styles and Calvin is stoked to collaborate with them on new music. Their mutual friend knew they'd all be a great fit. Calvin is working on a music project and loves working on it to chill out. He can't wait to show Dave the final result.
