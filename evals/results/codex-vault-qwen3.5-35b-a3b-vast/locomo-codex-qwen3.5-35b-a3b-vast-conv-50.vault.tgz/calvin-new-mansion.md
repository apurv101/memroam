name: Calvin's new mansion
description: Calvin recently moved into a new mansion and is excited about this big life change

Calvin had a big life change and recently moved into a new mansion. He shared a photo of the building and was very excited about it.