name: Calvin's car working hobby
description: Calvin works on cars as a therapeutic hobby that helps him relax and clear his head
---
Calvin enjoys working on cars as a way to chill and clear his head. He finds it calming and gives him a real sense of achievement, comparing it to meditation. This hobby provides him the same therapeutic satisfaction that Dave gets from fixing things.
