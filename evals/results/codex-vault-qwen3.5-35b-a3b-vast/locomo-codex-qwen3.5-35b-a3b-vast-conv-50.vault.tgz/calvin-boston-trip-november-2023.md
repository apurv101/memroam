name: Boston trip with high school friend
description: Calvin's Boston performance and reunion with high school friend
---
November 2023: Calvin invited his old high school friend to see him perform in Boston. The experience was deeply meaningful for Calvin.

Seeing someone who had been there since the beginning brought back nostalgic memories of freestyling and talking about getting famous as teenagers. Calvin reflected on how far he's come and how life has changed.

The reunion reminded Calvin of how important relationships are in his career. His friend's continued support and encouragement has made a big difference in his journey, and having that person there to witness his success was "insane" and "felt so good."

The experience reinforced Calvin's belief in the importance of supportive people around him, especially in the tough music industry.
