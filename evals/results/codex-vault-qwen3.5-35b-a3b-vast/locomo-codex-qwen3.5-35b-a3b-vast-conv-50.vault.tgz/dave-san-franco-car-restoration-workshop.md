name: Dave's San Francisco car restoration workshop
description: Dave attended an inspiring car restoration workshop in San Francisco where he learned about different techniques and met passionate people
---
Dave attended a car restoration workshop in San Francisco where he explored various restoration techniques. He found the community of car enthusiasts to be incredibly passionate and dedicated, which he described as truly inspiring. This experience deepened his interest in car restoration and gave him new insights into the craft, which he wants to share with Calvin.
