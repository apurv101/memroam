name: Dave's recent jam session with rock band
description: Dave's band had an enjoyable jam session last night where everything clicked and music flowed

---

In mid-September 2023, Dave's rock band had a jam session where everything just clicked and the music kept flowing. It was such an enjoyable experience, though they were too into it to record it. These moments of musical connection are what make band practice worthwhile for Dave.
