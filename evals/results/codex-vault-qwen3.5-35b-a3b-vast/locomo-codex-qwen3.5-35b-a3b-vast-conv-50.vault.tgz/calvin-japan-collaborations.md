name: Calvin's music collaborations with Japanese artists
description: Calvin is working on music collaborations with Japanese artists and excited to share clips
---
On July 7, 2023, Calvin mentioned working on cool music collaborations with Japanese artists and being really excited to hear how it turns out. He said he'll share some clips when everything's ready.
