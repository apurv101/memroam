name: Calvin's small town in Japan with mountain views
description: Calvin lives in a small town in Japan with stunning mountain views he plans to visit after his Frank Ocean tour
---
Calvin lives in a small town in Japan with an unbelievably stunning view of mountains visible from his living room. He hasn't been there before but it's on his to-do list to visit after his tour with Frank Ocean ends. He's excited to see the snowy peaks in person. Calvin also mentioned he hasn't tried skiing before but thinks it would be fun and might give it a try once.