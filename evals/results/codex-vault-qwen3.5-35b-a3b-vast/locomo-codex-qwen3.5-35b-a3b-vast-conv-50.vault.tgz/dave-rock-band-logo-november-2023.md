name: Dave created rock band logo
description: Dave designed a logo for his rock band after joining the group
description: Dave created custom branding for his rock band

---

After joining a rock band, Dave created a custom logo for the group. He shared a photo of the logo design with Calvin, explaining the story behind it.

Dave mentioned he's been a fan of the band for ages and has had the opportunity to join them. Creating visual branding like the logo allows him to contribute creatively beyond just playing guitar.
