name: Dave's vintage camera purchase
description: Dave bought a new vintage camera in November 2023 that he says takes awesome photos

---

In November 2023, Dave purchased a new vintage camera. He mentioned it helps him capture special moments clearly and takes "awesome photos." Dave showed it to Calvin during their conversation in late November 2023.