name: Calvin and Dave concert photos exchange
description: Calvin and Dave exchanged photos during their conversation - Calvin shared a concert photo from Tokyo and Dave shared a photo of his car restoration project
---
Dave and Calvin exchanged personal photos during their conversation. Calvin shared a photo of a concert crowd with hands raised, taken during his Tokyo performance where the audience sang along with him - he mentioned these are the moments that make his job meaningful. Dave shared a photo of his silver Corvette project, a car with a broken engine in the woods that he's restoring. Dave mentioned he's aiming to have it fully restored by the end of the following month.
