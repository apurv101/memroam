name: Calvin's Electronic Music Experiments
description: Calvin experimenting with electronic elements, new genres, and creative boundaries
---
Calvin has been experimenting with different genres in his music, particularly adding electronic elements to his songs for a fresh vibe. This has been a process of self-discovery and growth, pushing himself out of his comfort zone by switching between styles.

November 2023: Calvin is having fun trying out new sounds and pushing creative boundaries. He believes in going for new ideas and staying ahead in the music industry. He values growth and evolution in his artistic practice, seeing experimentation as key to making art grow.