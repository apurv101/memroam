name: Calvin's Boston trip with high school friend
description: Calvin visited Boston with a high school friend on Oct 24, 2023
---

On October 24, 2023, Calvin visited Boston with a high school friend. He had a great time exploring sights and found the experience fun and eye-opening. Calvin thought Boston had awesome architecture and cool history. He also found it peaceful.
