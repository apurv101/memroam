name: Dave attended conference in Detroit
description: Dave attended a conference in Detroit where he learned a lot
---

Dave attended a conference in Detroit that he found really cool. He learned a lot of new things there.
