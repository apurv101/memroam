name: The Fireworks collaborated with Frank Ocean
description: The Fireworks musical act performed with Frank Ocean, mentioned in October 2023
---
The Fireworks is a musical act that has performed with Frank Ocean, as mentioned in mid-October 2023. Calvin noted that "performing with Frank Ocean recently has been really cool" when discussing the band that headlined a Boston music festival attended by Dave.

This conversation occurred on October 15, 2023, at 9:39 am.