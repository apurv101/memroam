name: Dave's recent car restoration completed and sold
description: Dave restored a car last year and sold it to a collector; he's now working on a new challenging project

---

Last year, Dave completed a car restoration project. He sold the finished car to a collector. After completing that project, he immediately started working on something new, which he describes as quite a challenge.

This demonstrates Dave's continuous cycle of finding, restoring, and moving on to new projects - a pattern that has defined his passion for car engineering.
