name: Calvin's Boston gala attendance
description: Calvin attended a fancy gala in Boston in late November 2023 and met interesting people

---

In late November 2023, Calvin attended a fancy gala in Boston where he met some interesting people. During the event, he had a particularly inspiring conversation with a cool artist they connected with over music and art. They discussed their favorite artists and how the power of music connects people. Calvin described it as such an inspiring conversation that he felt like he was "on a creative high."