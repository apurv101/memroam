name: Calvin's late August 2023 tour update and video shoot
description: Calvin's end of tour reflections, Miami beach video shoot for new album, and octopus guitar details

Calvin and Dave caught up in late August 2023. Calvin shared that his tour had just ended, describing it as amazing and fueled by incredible audience energy. He performed on a big stage, which he called a dream come true, saying he felt on top of the world during the surreal experience.

Last weekend (around late August 2023), Calvin started shooting a video for his new album at a Miami beach location. He chose Miami for its amazing vibe, perfect for the video's epic visuals. He told Dave he'd keep him updated on the progress and appreciated Dave's offer of help with props.

Calvin also showed Dave his custom guitar with an octopus design, made by his Japanese artist friend. The octopus represents Calvin's love for art and the sea. The guitar had a shiny purple finish customized to give it a unique look that matches his style. Calvin described it as one of his favorite guitars, meaning so much to him as a reminder of his passion for music and the amazing friendships he's made.

Dave supported Calvin throughout, praising his unique style and encouraging him to stay true to himself.
