name: Calvin's podcast about the rap industry
description: Calvin and friends recorded a podcast discussing the rap industry
---
In mid-August 2023, Calvin mentioned recording a podcast with friends about the rapidly evolving rap industry. He was excited to discuss the topic and plans to share when it's uploaded.
