name: Calvin's Motivation and Collaboration
description: How Calvin stays motivated through collaboration and community
---
Calvin stays motivated by collaborating with other artists and learning from them. Surrounding himself with positive energy and passion helps keep him driven. He started making music to follow his dreams and values the growth that comes from working with others.