name: Dave's card night with friends
description: Dave had a card night with friends last Friday and had a great time
---
On Friday, August 18, 2023, Dave had a card night with his friends. They played cards, laughed, and had a wonderful time together. Dave shared photos from the event with Calvin.
