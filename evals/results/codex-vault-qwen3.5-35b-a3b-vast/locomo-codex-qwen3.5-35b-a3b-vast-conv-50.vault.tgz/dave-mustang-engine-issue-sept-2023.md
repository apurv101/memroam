name: Dave's vintage Mustang engine issue - September 2023
description: Dave experienced frustration when his restored vintage Mustang engine made a weird noise after he thought he fixed it

---

On September 22, 2023, Dave shared with Calvin that he had been working on his vintage Mustang's engine, believing he had fixed it. However, when he started the car up, he heard a strange/weird noise. Dave was very disappointed after putting so much work into the restoration project. He shared a photo of the engine with Calvin and expressed his frustration about the situation.

Dave's passion for car restoration and auto engineering remains strong, and this setback was disheartening given how much effort he invested in the project.
