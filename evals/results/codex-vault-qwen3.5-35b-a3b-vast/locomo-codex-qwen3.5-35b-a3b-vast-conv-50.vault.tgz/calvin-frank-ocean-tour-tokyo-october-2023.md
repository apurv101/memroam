name: Calvin's Frank Ocean tour and Tokyo visit plans
description: Calvin toured with Frank Ocean, performing in Tokyo, and plans to visit the city again after the tour
---
In this conversation dated October 19, 2023, Calvin shared updates about his ongoing tour with Frank Ocean and his upcoming personal trip to Tokyo.

**Frank Ocean collaboration origins:**
Calvin and Frank Ocean first met at a music festival last August (August 2022). Frank Ocean expressed interest in collaborating, and they clicked right away. The chemistry on stage during their performances has been incredible, which Calvin describes as a dream come true.

**Tokyo tour performances:**
Calvin has already performed in Tokyo as part of the tour. He shared photos of the shows, including images of the crowd with their hands in the air, noting the insane energy. He mentioned that "the whole city came out" to the concert.

**Upcoming Tokyo visit:**
After the tour ends next month (November 2023), Calvin plans to visit Tokyo again personally. His favorite spots include:
- Shibuya Crossing (which Calvin calls "Tokyo's Times Square")
- Shinjuku

**Food plans:**
Calvin is excited to try ramen in Tokyo, noting that Dave recommended it highly in their conversation, saying "Once you try it, you'll never go back."
