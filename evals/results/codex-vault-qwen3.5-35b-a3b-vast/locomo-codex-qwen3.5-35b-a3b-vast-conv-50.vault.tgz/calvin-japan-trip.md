name: Calvin's Japan trip plans
description: Calvin is traveling to Japan next month for a few months to learn about Japanese culture

Calvin is fascinated by Japanese traditions and culture and plans to visit Japan next month. He'll be staying there for a few months before heading to Boston. He has a place to stay arranged through an agent. His plans include:
Calvin has now completed his Japan trip. He toured with a well-known artist and performed in Tokyo. The Tokyo show was magical - when he played one of his songs, the entire crowd sang along with him. After the Japan tour, he moved into a new place, which he called a dream come true.
- Exploring the city
- Trying out different local cuisines
- Collaborating with musicians in the area