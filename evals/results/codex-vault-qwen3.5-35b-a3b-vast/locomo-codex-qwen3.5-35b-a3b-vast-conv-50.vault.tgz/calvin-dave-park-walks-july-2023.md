name: Calvin and Dave regular park walks
description: Calvin and Dave have arranged to meet for regular walks together in the park
---
On July 7, 2023, Dave mentioned arranging with friends for regular walks together in the park. Calvin responded positively, saying it sounds like a great plan and can be a wonderful way to spend time together and stay active.
