name: Dave's photography hobby
description: Dave took up photography and loves capturing nature scenes like sunsets, beaches, and waves

---

In late November 2023, Dave mentioned taking up photography as a new hobby. He enjoys capturing the beauty of nature, particularly sunsets, beaches, and waves. He finds that nature conveys emotion and beauty through photos and helps boost spirits during tough times.

Dave discovered a serene spot in a nearby park with rocks and a waterfall that he finds particularly peaceful for photography.