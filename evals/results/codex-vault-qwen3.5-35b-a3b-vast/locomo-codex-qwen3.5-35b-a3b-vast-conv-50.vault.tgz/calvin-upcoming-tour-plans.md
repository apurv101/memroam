name: Calvin upcoming tour plans
description: Calvin announced an upcoming tour, calling it epic and exciting

After his album release on September 11, 2023, Calvin shared that his next major project is a tour. He described the upcoming tour spots as "awesome" and said it's going to be "epic." This tour is the immediate next step after his album release, followed by plans to explore and grow his brand.
