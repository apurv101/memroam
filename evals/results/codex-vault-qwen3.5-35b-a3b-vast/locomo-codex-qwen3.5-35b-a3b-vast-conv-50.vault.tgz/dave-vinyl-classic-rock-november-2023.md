name: Dave's vinyl collection and classic rock interest
description: Dave listens to vinyl records while working on cars, has an old record player, recently getting into classic rock
description: Dave uses vinyl records for focus during car work and recently explored classic rock music

---

Dave has developed a routine of listening to vinyl records when working on cars. He keeps a record player in his workspace that he describes as "a bit old" but says it "still gets the job done."

For Dave, music helps him focus and stay on track during car work, making the experience feel better. He recently shared that he's been getting into classic rock lately, saying the music from that era is timeless and always fun to explore.
