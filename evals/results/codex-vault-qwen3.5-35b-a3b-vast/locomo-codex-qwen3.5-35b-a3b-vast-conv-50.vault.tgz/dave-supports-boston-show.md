name: Dave will support Calvin in Boston
description: Dave will attend Calvin's Boston show during the Frank Ocean tour to cheer him on
---
Dave committed to attending Calvin's Boston performance during the Frank Ocean tour to support him. He told Calvin he'd be there to cheer him on and experiences the Boston music scene as awesome with talented musicians and cool venues.
