name: Calvin's upcoming Boston performance
description: Calvin accepted an invitation to perform at an upcoming show in Boston

---

In late November 2023, Calvin accepted an invitation to perform at an upcoming show in Boston. He described it as going to be an "unforgettable musical experience" and was looking forward to catching up with Dave about all the details. Calvin mentioned he would reach out when he's back in Boston.