name: Dave attended Fireworks Boston music festival
description: Dave attended a Boston music festival where The Fireworks headlined
---
In mid-October 2023, Dave attended a music festival in Boston. The headliner was The Fireworks, a band that had recently performed with Frank Ocean. Dave described the experience as amazing - commenting on the incredible main stage, the great performance, and the electric energy of the crowd. He felt alive and energized by the experience, noting how music brought people together.

This conversation occurred on October 15, 2023, at 9:39 am.