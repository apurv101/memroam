name: Dave's July 2023 Road Trip
description: Dave's road trip with friends in late June/early July 2023
---
Dave went on a road trip with friends in late June/early July 2023. They drove through stunning countryside on winding roads and had conversations. This break from his corporate work helped Dave recharge and reconnect with his passion for cars.