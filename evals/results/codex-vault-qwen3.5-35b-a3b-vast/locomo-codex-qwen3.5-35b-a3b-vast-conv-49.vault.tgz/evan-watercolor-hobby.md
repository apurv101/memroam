name: Evan's watercolor painting hobby
description: Evan started watercolor painting a few years back after a friend introduced him to it and gave him advice. In August 2023 he joined painting classes to learn from instructors and meet like-minded people, focusing on watercolors, landscapes, and nature scenes.
---

On August 19, 2023, Evan shared updates about his painting journey:

**Painting classes (started mid-August 2023):**
- Joined classes a few days before August 19 to find like-minded people and improve his skills
- Instructors emphasize observing nature and painting what he sees
- Learning about watercolors
- Considers it a relaxing way to take a break from everyday stress

**Favorite subjects:**
- Landscapes, especially nature scenes
- Recent works include: a sunset over the ocean, a tree with pink flowers in a field
- Aims to capture the peaceful vibe of being outdoors in nature

**Inspiration:**
- A friend gave him a painting of a forest scene on an easel, which inspired him to start painting

