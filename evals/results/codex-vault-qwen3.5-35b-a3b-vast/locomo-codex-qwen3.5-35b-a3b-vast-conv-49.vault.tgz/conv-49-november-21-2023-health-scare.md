name: Evan's health scare
description: Evan had a health scare last week before Nov 21, 2023 requiring hospital visit; doctors found suspicious issue during checkup which turned out to be a misunderstanding.
description: Doctors said everything is fine after the scare. The experience taught Evan the value of life and importance of keeping an eye on health.
