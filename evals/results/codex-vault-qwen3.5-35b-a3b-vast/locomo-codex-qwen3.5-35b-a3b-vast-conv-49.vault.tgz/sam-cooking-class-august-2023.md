name: Sam's cooking class - August 2023
description: Sam is taking a cooking class to learn healthier recipes; made grilled salmon with vegetables and shared a roasted veg recipe; as of August 19, shared a grilled chicken and veggie stir-fry recipe with homemade sauce.
---

**August 19, 2023 update:**

**Health progress:**
- Has been living healthier and finds it tough but remains determined
- Noticed positive changes: more energy, less sluggishness after eating
- Currently eating spinach, avocado, and strawberries as part of healthier diet

**Recipe sharing:**
- Shared a grilled chicken and veggie stir-fry recipe with his homemade sauce
- Described it as flavorful and healthy
- Sent a photo of the recipe card (which had a decorative drawing of flowers)
- Evan expressed interest in trying it


---

In mid-August 2023, Sam started taking a cooking class focused on learning healthier meal options.

**Progress:**
- The cooking class has been great
- Learned awesome recipes
- Last night before the August 15 conversation, made a grilled dish with salmon and vegetables
- Marinated with different ingredients and grilled it - turned out really flavorful

**Recipe sharing:**
- Sam shared a tasty and easy roasted veg recipe with Evan
- Evan is interested in adding more vegetables to his meals
- Sam offered to share more recipes from the class

**Health motivation:**
- Taking the class is part of Sam's broader motivation to make positive health changes
- Previously mentioned using a motivational quote: "Don't fear it, just take the first step"
- Taking small steps toward a healthier life is seen as progress

**Parallel with Evan:**
- Both Evan and Sam are taking better care of themselves
- Evan recently had a heart palpitation scare that led to healthier lifestyle choices
- They support each other's health journeys
