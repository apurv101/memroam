name: Daily appreciation habit
description: Evan and Sam agreed to make it a habit to appreciate something each day to help them enjoy life more and focus on the little things.
