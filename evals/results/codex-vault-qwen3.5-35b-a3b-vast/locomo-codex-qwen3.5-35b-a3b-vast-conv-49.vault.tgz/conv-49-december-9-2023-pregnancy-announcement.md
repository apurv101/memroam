name: Evan expecting second child - December 2023
description: December 2023: Evan shares his partner is pregnant; he's excited and nervous, looking forward to expanding his family.
---
On December 9, 2023, Evan shared exciting news with Sam - his partner is pregnant!

**Evan's feelings:**
- So excited and a bit nervous
- It's been a while since he had a toddler around
- Really looking forward to parenthood
- Views parenthood as rewarding

**Family significance:**
- Family is his rock
- Looking forward to expanding his family and creating more beautiful memories
- Looking forward to witnessing the miracle of life with his family

**Family memories:**
- Shares a photo collage of top family memories - birthdays, holidays, vacations
- Photo showed a desk with lamp, picture frame, and a sign
- The sign says "Bring it on Home" - their family motto from Banff
- Motto reminds them of the importance of togetherness, no matter where they are

**Upcoming events:**
- Planning a big family reunion next summer (2024)
- Plans to add reunion photos to their family collage

---
Evan already has at least one child, mentions his "first child" being born in the past and it being "a while since I had a toddler around."
