name: Sam's childhood hiking memory
description: Sam hiked with his dad when he was ten years old. They hiked a good distance which was a great memory and really special for them. He loves hiking but it's been ages since he's done it.
