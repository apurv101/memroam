name: Evan's family motto - "Bring it on Home"
description: Evan's family motto from Banff trip: "Bring it on Home" - reminding them of the importance of togetherness no matter where they are.
---
**Family motto:** "Bring it on Home"

**Origin:**
- From the family's trip to Banff
- Features on a sign in a frame in their home

**Meaning:**
- Always reminding the family of the importance of togetherness
- No matter where they are, they should bring it on home to each other
- Keeps the family bond strong

**Significance:**
- Part of their home decor - framed with other family photos
- Connected to their family photo collage of birthdays, holidays, and vacations
- Reflects Evan's deep value of family - he says "My family means the world to me. They're my rock."
