name: Evan's childhood island and happy place
description: Evan grew up on a small island with a lone boat in the water - his happy place and peaceful retreat.
description: The island shaped him and holds a special place in his heart. He describes the place as soul-calming, serene with sun shining through clouds over water.
