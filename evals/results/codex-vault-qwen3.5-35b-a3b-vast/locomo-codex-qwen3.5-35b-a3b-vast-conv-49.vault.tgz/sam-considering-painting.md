name: Sam considering painting as a hobby
description: Sam was thinking about trying painting but hasn't pursued it as of August 19, 2023. He sees it as a nice way to chill and get creative. He's interested in winter sports but isn't sure his body can handle skiing.
