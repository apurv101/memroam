name: Evan's contemporary figurative painting - December 2023
description: Evan completed a contemporary figurative painting around December 14-15, 2023; emphasizes emotional state through expressive brushwork and vibrant colors; published in exhibition with help from a close friend.
---

On December 17, 2023, Evan shared details about a recent painting with Sam:

**The painting:**
- Contemporary figurative painting
- Finished a few days before December 17, 2023 (approximately December 14-15)
- Emphasizes emotional state through expressive brushwork and vibrant color choices
- Captures a moment of introspection where the subject is deeply immersed in thought

**Exhibition:**
- Evan shared a photo of the painting being displayed
- The painting was published in an exhibition
- A close friend helped Evan get the painting published in the exhibition

**Evan's feelings:**
- Very proud of the work
- Described it as emphasizing emotional state through artistic choices
- Views painting as a way to communicate emotions and capture moments of introspection

**Context:**
- This came up while discussing trying new things and stepping out of comfort zones
- The painting represents a significant achievement for Evan

---
