name: Sam's winter sports interest
description: As of August 19, 2023, Sam expressed interest in winter sports but isn't sure his body can handle skiing; Evan enjoys skiing, snowboarding, and ice skating.

---

On August 19, 2023, Evan and Sam discussed winter sports:

**Evan's winter activities:**
- Enjoys skiing, snowboarding, and ice skating
- Took a skiing trip to Banff in late July 2023
- Described it as great with amazing snow and views
- Plans to go back next year
- Invited Sam to join him someday

**Sam's interest and limitations:**
- Expressed interest in trying skiing ("sounds like a blast")
- Not sure his body can handle it due to his health challenges
- Wish he could join Evan in winter activities
- Appreciated Evan's understanding about his limitations
