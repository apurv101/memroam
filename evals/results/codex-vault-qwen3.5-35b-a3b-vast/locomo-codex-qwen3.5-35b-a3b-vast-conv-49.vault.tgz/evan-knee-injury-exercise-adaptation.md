name: Evan's knee injury and exercise adaptation
description: Evan twisted his knee on August 25, 2023, is doing PT, and swimming to stay active while healing.

On August 27, 2023, Evan and Sam discussed Evan's knee injury and his current fitness situation:

**Evan's knee injury:**
- Twisted his knee on Friday, August 25, 2023
- Experiencing significant pain
- Frustrated about not being able to stay consistent with his usual fitness routine
- Staying active is mega-important to him

**Current adaptation:**
- Physical therapy for his knee is on the cards (hoping to get an appointment soon)
- Swimming to stay active while healing (low-impact, easy on the joints)
- Keeping things low-key until the injury heals

**Sam's response:**
- Showed concern and offered to help
- Suggested low-impact exercises and physical therapy
- Encouraged Evan to keep up with his active lifestyle

---
