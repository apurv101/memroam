name: Sam's morning running habit - December 2023
description: Sam started running in the mornings as a way to clear his head, sharing this with Evan around December 26, 2023
---

On December 26, 2023, Sam shared with Evan that he had started running in the mornings.

**Key points:**
- Started morning running routines around late December 2023
- Uses running as a way to "clear his head"
- Described it as "a great way to clear my head"
- Framed it as something he's doing to enjoy rather than necessarily about love (contrast to Evan's recent marriage)

**Context:**
This came up during a conversation where Evan was sharing his recent wedding and his paintings. Sam mentioned morning running as his way of finding joy and peace, different from Evan's creative emotional expression through art.
