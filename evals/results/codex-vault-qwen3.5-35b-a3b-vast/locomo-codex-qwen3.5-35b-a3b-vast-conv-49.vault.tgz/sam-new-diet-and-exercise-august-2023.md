name: Sam's new diet and exercise routine
description: Sam started a new diet and exercise routine on August 21, 2023, and it's made a huge positive difference.

On August 27, 2023, Sam shared exciting news about his health journey:

**Sam's new routine:**
- Started a new diet and exercise routine on Monday, August 21, 2023
- Reports it has made a huge difference
- Feels great about the results

**Context and follow-up:**
- Evan encouraged Sam to stay committed to his active lifestyle
- Sam mentioned wanting to go hiking more but finding it challenging
- Working on becoming healthier, hoping to combine road trips with hiking

---
