name: Evan's new relationship and ongoing health journey
description: Evan met a Canadian woman during a recent Canada trip who makes him feel alive; he's been prioritizing health for 2 years with family and a fitness watch as motivation.

---

On August 7, 2023, Evan and Sam discussed Evan's recent trip to Canada and his health journey:

**Evan's Canada trip:**
- Recently traveled to Canada where he met a Canadian woman
- Described it as "something out of a movie"
- Says she's incredible and being with her makes him feel alive
- Finds it a nice change, especially after dealing with health issues

**Health journey (ongoing):**
- Been working on health for two years now
- Has had ups and downs but doing his best
- Motivated by family - his kids bring him lots of joy even through hard times
- Uses a fitness watch/smart watch that tracks progress and serves as a visual reminder

**Motivations:**
- Family (kids) motivates him to stay healthy
- Has a thirst for adventure on interesting hikes
- Has a bonsai tree that symbolizes strength and resilience; taking care of it helps through tough times
- Believes every little thing done for yourself helps in the long run

**Conversation details:**
- Evan shared photos of: cookies (ginger snaps), his kids on a swing set, his fitness watch, an island with a boat, and his bonsai tree
- Sam mentioned considering ordering a similar fitness watch
- Discussed consistency and perseverance
