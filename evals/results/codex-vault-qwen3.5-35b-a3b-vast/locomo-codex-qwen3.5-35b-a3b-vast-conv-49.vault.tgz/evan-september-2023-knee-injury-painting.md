name: Evan's September 2023 knee injury and painting
description: Evan twisted his knee playing basketball around Sept 22, 2023; uses watercolor painting as stress relief during recovery while doing gentle exercises.
---

On October 6, 2023, Evan and Sam caught up about Evan's recent knee injury and creative pursuits:

**Evan's knee injury:**
- Twisted knee playing basketball with the kids about 2 weeks before Oct 6 (around Sept 22, 2023)
- Had a cast on the leg
- Physical therapy has helped some
- Can't do intense workouts, but doing gentle exercises to keep the knee strong
- Misses being active outdoors and going on adventures

**Watercolor painting:**
- Evan paints watercolors to stay busy and relax during recovery
- Considers it a chill way to de-stress and "get into the colors"
- Shares a painting of a cactus in the desert (inspired by a road trip from last month)
- Previously mentioned a sunset painting inspired by a vacation from a few years back
- Uses painting as self-expression - paints what's on his mind or what he's feeling
- Views it as communicating emotions without words

**Unexpected adventure:**
- Two weeks ago (around Sept 22), helped a lost tourist find their way
- Ended up taking an unexpected tour around the city
- Described it as a blast

**Sam's updates:**
- Learning to draw
- Writes in journal and does creative writing as self-expression
- Finding writing therapeutic for sorting out feelings
- Having issues with new phone's navigation app malfunctioning

---
