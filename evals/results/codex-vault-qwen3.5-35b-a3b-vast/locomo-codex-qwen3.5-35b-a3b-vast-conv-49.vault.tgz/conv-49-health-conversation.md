name: Evan and Sam's health conversation
description: Evan had a heart palpitation scare that made him adopt a healthier lifestyle; Sam was motivated to try healthier swaps like seltzer for soda and dark chocolate for candy.

On June 6, 2023, Evan reached out to Sam after a health scare. Evan experienced sudden heart palpitations a week prior, which was a serious wake-up call about his lifestyle.

**Evan's changes:**
- Trying to eat less processed food and sugary snacks
- Loved ginger snaps but cutting back
- Working out with dumbbells
- Supporting Sam's health journey

**Sam's situation:**
- Was trying to eat healthier (shared photo of vegetables and milk)
- Still enjoys soda and candy, acknowledges it's not the best habit
- Had a frustrating experience at the supermarket where all self-checkout machines were broken

**Health advice Evan gave Sam:**
- Swap soda for flavored seltzer water (still bubbly and tasty, no sugar)
- Try dark chocolate with high cocoa content instead of candy

They committed to continuing to support each other's health journeys.