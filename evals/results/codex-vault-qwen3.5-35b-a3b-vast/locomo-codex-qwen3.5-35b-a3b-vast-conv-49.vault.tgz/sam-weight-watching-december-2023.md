name: Sam's Weight Watchers meeting
- Attended a Weight Watchers meeting on December 4, 2023
- Learned helpful tips at the meeting
- Shared a smoothie bowl photo (variety of fruit and yogurt bowls)

description: Sam attended a Weight Watchers meeting on December 4, 2023, where he learned helpful tips.

---
