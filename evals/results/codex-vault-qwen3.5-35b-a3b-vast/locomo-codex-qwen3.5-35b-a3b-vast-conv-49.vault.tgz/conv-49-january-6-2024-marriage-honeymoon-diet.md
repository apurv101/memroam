name: Evan's January 2024 marriage announcement and honeymoon plans
description: Evan told family about marriage on Jan 5, 2024; going to Canada for honeymoon in February; started restrictive ginger snap diet
---

On January 5, 2024, Evan told his extended family about his marriage from late December. The conversation covered several topics:

**Marriage announcement:**
- Evan told extended family on January 5, 2024 about his marriage from late December 2023
- Overwhelmed by family's love and support
- Families are happy for them
- Describes their bond as getting stronger

**New diet:**
- Evan started a new diet limiting himself to just two ginger snaps per day
- Sticking to diet even during family gatherings
- Sam has homemade lasagna for dinner

**Honeymoon plans:**
- Trip to Canada next month (February 2024) for honeymoon
- Planning to ski, try local cuisine, enjoy snowy landscapes
- Specifically excited about trying poutine
- Both excited to create memorable experiences

**Shared moments:**
- Evan shared photos: wedding photo, family gathering with food, Canadian wedding cake photo, snowy forest/stream
- Sam shared photos: plate with bread and meat, raspberry-lime pie (from cousin's wedding)
- Both had homemade lasagna for dinner (Evan's family, Sam's separate meal)
