name: Aug 17, 2023 — Jolene's Xbox Gift for Partner
description: Jolene bought an Xbox console for her partner on Aug 17, 2023; they play with bets

---

On August 17, 2023, Jolene purchased a black Xbox console as a gift for her partner. They've been enjoying playing it together, often for small bets! Jolene mentioned once winning three large pizzas from her partner while playing.

**Games they enjoy:**
- **Overcooked 2** - a co-op cooking game they play for bets (described as hilarious and chaotic)
- **Zelda BOTW** - Jolene recommends this for its open-world adventure
- **Animal Crossing: New Horizons** - recommended as a calming, cute game

Jolene finds balance between engineering studies, hobbies, and gaming is key to her well-being.
