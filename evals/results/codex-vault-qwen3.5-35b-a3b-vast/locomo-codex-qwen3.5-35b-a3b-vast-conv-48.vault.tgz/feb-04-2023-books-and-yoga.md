name: Deborah and Jolene - Books and yoga
description: Jolene's favorite books are Sapiens and Avalanche by Neal Stephenson; Deborah teaches yoga and shares modified poses with friend Anna

---

Books mentioned in conversation on February 4, 2023:

**Jolene's favorite books:**
- "Sapiens" - described as a fascinating look at human history and how technology has affected people; "giving me a lot to think about"
- "Avalanche" by Neal Stephenson - read it in one sitting two weeks before the conversation (mid-January 2023)

Yoga and fitness:
- Deborah teaches yoga and spends a lot of time in a dance/yoga studio
- Deborah bonded with Anna during a yoga class the day before (February 3, 2023)
- They tried modified dance/yoga poses including Warrior II, which builds strength and boosts focus
- Deborah described a modified pose: sit on edge of chair with feet planted, twist torso to one side, use hand on knee for support, hold for a few breaths then switch sides
- The pose helps relax tense muscles and is good for stretching back and shoulders
