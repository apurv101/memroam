name: Aug 26, 2023 — Jolene's yoga and meditation self-care
description: On August 26, 2023, Jolene shared her yoga and meditation practice with Deborah

---

**Jolene's self-care routine:**
- Into yoga and meditation lately
- Helps recharge and relieve tension
- Calms the mind
- Doing different poses is particularly helpful

**Jolene's partner:**
- Jolene has shared her newfound love for yoga with her partner
- They are planning to go on a meditation retreat together
- Want to enhance their practice together

**Deborah's advice for staying relaxed while studying:**
- Taking breaks
- Doing stretching/yoga
- Going for a walk
- Getting enough sleep
- Taking time for self-care
- Finding balance between work and self-care

**Susie (Jolene's pet snake):**
- Just likes watching Jolene chill
- Brings a sense of calm