name: Bullet journal for time management
description: Jolene uses a bullet journal for tracking tasks and staying organized as a time management strategy

---

## Details

**Date:** August 16, 2023

**What it is:** Jolene started using a bullet journal as a time management strategy.

**Benefits:**
- Helps her stay on top of tasks
- Keeps her organized
- Satisfying when crossing tasks off the list
- Motivational when seeing progress

**Favorite quote spread:** Jolene shared a photo of her newest spread featuring a favorite quote that reminds her to stick to her goals and never give up.

---

**Durable facts:**
- Jolene uses a bullet journal for task tracking and organization
- Crossing items off provides satisfaction and motivation
- Visual elements like favorite quotes help keep her motivated
