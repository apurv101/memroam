name: Aug 26, 2023 — Jolene and partner discuss loved ones' influence and values
description: On August 26, 2023, Jolene and her partner discussed how their deceased loved ones influenced them

---

Jolene and her partner had an emotional conversation about how their loved ones have influenced their lives and values. Key points:

**Values learned from loved ones:**
- Perseverance and resilience (Jolene's mom always said "never give up")
- Staying determined (partner's dad showed them this value)
- Helping others (Jolene's mom stressed this)

**How values influence their lives:**
- Jolene pursues engineering and wants to solve important problems, make things more efficient, and make the world better
- Partner pursues creative endeavors
- These values drive them to pursue their respective goals and passions

**How they're incorporating values into work:**
- Jolene aims to work on projects that make a real difference to communities
- Interested in sustainable initiatives and developing innovative solutions for environmental issues
- Wants to get involved with organizations focusing on social causes
- Seeks to connect passion for engineering with commitment to making positive impact

**Jolene's specific project interests:**
1. Developing renewable energy (like solar) to help communities and reduce dependence on non-renewables
2. Finding ways to supply clean water to those with limited access
3. Both align with her beliefs about sustainability and assisting those in need

Jolene still has much to figure out before beginning these projects but is up for the challenge.