name: Sep 12, 2023 — Jolene returns from Phuket meditation retreat, Deborah shares card game
description: September 12, 2023 conversation about Jolene's transformative meditation retreat in Phuket and plans to play a cat card game together

---

On September 12, 2023, Jolene reconnects with Deborah after returning from a meditation retreat in Phuket, Thailand.

**Jolene's Phuket retreat experience:**
- Traveled to Phuket with her partner for a few weeks at a meditation retreat
- Described it as an amazing experience combining nature, reflection, and a break from engineering studies
- Helped her find inner peace
- The beauty of nature there was so inspiring and refreshing

**Key reflections from the retreat:**
- Realized importance of incorporating relaxation, self-care, and balance in life alongside engineering studies
- One standout session was about **releasing expectations and judgments** and savoring the present
- Strong reminder to appreciate the journey, not just the finish line
- Jolene admitted she usually gets too consumed with hitting goals and forgets to appreciate the ride
- Recognized how focusing only on big goals made her miss small moments of joy
- Now trying to be more mindful and grateful for tiny wins (feeling of the sun, a great cup of coffee)
- Experiencing "a new level of joy and happiness"

**Shared philosophy:**
- Both agree life's full of small moments and being grateful for those boosts happiness
- Practicing mindfulness and gratitude can change day-to-day perspective
- Even just a different outlook can make little things in life joyful

**Supportive community:**
- Deborah shared a photo of two children on yoga mats to illustrate supportive community
- Both value being able to motivate and encourage each other on this journey

**Deborah's cat card game:**
- Deborah recently played a card game she couldn't remember the name of
- Game mechanic: take cards one by one from a deck, then you can attack your opponent with them
- Deborah mentioned it's about cats
- Invited Jolene to play it together

---

**Durable facts:**
- Jolene and her partner attended a meditation retreat in Phuket, Thailand (Sep 2023)
- Key insight from retreat: releasing expectations/judgments and savoring the present
- Jolene now prioritizes mindfulness, gratitude, and appreciating the journey
- Deborah plays a cat-themed card game with attacking mechanics
- Deborah and Jolene plan to play the cat card game together
