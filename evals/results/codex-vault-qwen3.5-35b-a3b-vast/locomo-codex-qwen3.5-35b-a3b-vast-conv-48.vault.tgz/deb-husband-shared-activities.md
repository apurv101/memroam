name: Deborah's Husband and Their Shared Activities
description: Deborah's late husband enjoyed detective games and outdoor activities

---

Deborah speaks of her husband in the past tense, suggesting he is deceased. They shared several activities together:

**Gaming:**
- They preferred playing **detective games** together
- They took turns playing games
- Gaming was a way for them to bond and make memories

**Outdoors:**
- They enjoyed exploring nature together
- Found it refreshing to spend time outside and breathe fresh air
- These outdoor activities were a regular part of their time together

Deborah cherishes these memories and continues to honor that shared joy of activity and connection.
