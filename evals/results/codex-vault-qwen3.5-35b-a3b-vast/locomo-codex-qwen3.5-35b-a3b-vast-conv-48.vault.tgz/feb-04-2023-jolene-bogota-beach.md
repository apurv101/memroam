name: Jolene - Bogota beach vacation
description: Jolene took a photo of herself with a surfboard on a beach in Bogota during a summer vacation last year (summer 2022)

---

On February 4, 2023, Jolene shared a photo from her vacation:

**Bogota beach trip:**
- Jolene took a photo of herself walking on a beach with a surfboard
- The location was Bogota
- The vacation happened "last summer" (summer 2022)
- She took the photo while watching the sunset over the water
- She described it as "beautiful and calming"
- The experience made her appreciate nature's calming power

This photo was shared during a conversation about favorite nature spots, where Deborah had just mentioned her own peaceful water spot near her mother's old house.
