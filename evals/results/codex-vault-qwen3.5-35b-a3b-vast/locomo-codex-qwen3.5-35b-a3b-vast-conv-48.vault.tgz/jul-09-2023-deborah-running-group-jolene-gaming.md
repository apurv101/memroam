name: July 9, 2023 — Deborah's running group and workshops; Jolene's gaming with partner
description: July 9, 2023 — Deborah started a running group with Anna and organizes yoga/meditation workshops; Jolene games with partner (loves "It Takes Two")

---

## Details

**Date:** July 9, 2023

**Deborah's activities:**
- Started a running group with Anna - connecting with fitness-minded people
- The group helps and pushes each other during runs, building motivation
- Organizes workshops and events focusing on mindfulness and self-care
- Activities include yoga, meditation, and self-reflection
- Aims to cultivate self-awareness, promote mental/emotional well-being, help people find inner peace
- Creates spaces for people to connect, explore, and grow together
- Takes her two cats for runs in the park every morning and evening
- Doesn't like dogs, which is why she has cats

**Jolene's activities:**
- Struggling to add workouts into studying schedule
- Gaming with her partner - finds it challenging but fun
- Has someone who's also into gaming with her
- They play "It Takes Two" together - a team-strategy game that's competitive
- Games strengthen their relationship and help them bond
- Takes photos of sunsets and nature spots (lake with trees, dock on lake)
- Enjoys walking to take in nature and find peace

**Shared themes:**
- Both value community and supportive relationships
- Both find peace through nature
- Both share many photos of their activities and experiences
- Both appreciate the joy and calm that pets bring
- Both engage in physical activities for well-being

**Jolene's snake:**
- Fascinated by reptiles
- Taking care of the snake is calming
- Great way to connect with nature
- Shared memory of snake getting out and finding her snuggling under the bed

---

## Context

This conversation builds on previous discussions about Deborah's yoga/meditation practice (see June 26 entry) and Jolene's yoga/meditation practice (see June 6 entry). Both friends are in similar life phases - Deborah actively organizing community wellness events, Jolene balancing studying with work-life challenges. The conversation reflects their ongoing mutual support and shared appreciation for activities that foster connection, peace, and personal growth.
