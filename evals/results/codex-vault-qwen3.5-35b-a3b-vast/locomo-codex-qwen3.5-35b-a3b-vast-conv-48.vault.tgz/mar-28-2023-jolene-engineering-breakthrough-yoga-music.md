name: March 28, 2023 - Jolene's Engineering Breakthrough; Yoga & Music Preferences
description: Jolene shared engineering breakthrough; both discussed yoga props, scents, and music preferences for practice
---

## Jolene's Engineering Breakthrough

- Had a breakthrough on Friday, March 24, 2023 with her engineering project
- Solved a problem that had been bugging her for a while
- Feels great to see hard work paying off
- Debated it as a "long time no talk" moment after some time apart

## Deborah's Yoga Props

- Bought new props for the yoga class she hosts in her neighborhood
- Shared a photo of the new props in use (cardboard mat with coffee cup)
- Continues teaching yoga to neighbors who have shown interest

## Shared Yoga & Music Preferences

### Scents & Rituals
- **Deborah**: Uses candles and essential oils to add warmth and calm to yoga sessions
  - Favorite scents: lavender, rosemary
  - Believes certain smells can transport you to a place of peace
- **Jolene**: 
  - Also uses candles and essential oils (lavender, rosemary)
  - Loves creating serene spaces with soothing scents
  - Finds these rituals help enhance the practice

### Music Preferences
- **Deborah**:
  - Prefers instrumental tracks with mellow melodies and rhythms
  - Favorite track: "Savana"
  - Currently listening to an album called 'Sleep' (great for meditation and deep relaxation)
- **Jolene**:
  - Loves listening to Nils Frahm and Olafur Arnalds during practice
  - Finds their music calming and puts her in a different headspace
  - Open to recommendations for similar artists or tracks

## Supportive Friendship Dynamic

- Deborah encouraged Jolene about her engineering breakthrough: "You've really proven your skills"
- Both friends continue to support each other's personal growth and wellness practices
- Exchange of recommendations and shared interests in wellness activities
