name: Mar 22, 2023 - Jolene's Stress & Time Management; Surfing Goals
description: Discussed Pomodoro Technique, Eisenhower Matrix, and Jolene's plan to learn surfing

Deborah and Jolene discussed time management during a stressful period with exams and deadlines.

**Time management techniques discussed:**
- **Pomodoro Technique** (Jolene): 25 minutes work, 5-minute breaks - helps avoid burnout but still struggles with prioritization
- **Daily schedules/to-do lists**: Both shared examples (photos sent), but can feel overwhelming with big stacks of tasks
- **Eisenhower Matrix** (Deb introduced): Sorts tasks into four boxes based on urgency and importance; helps organize and prioritize

**Jolene's surfing goal:**
- Plans to learn surfing
- Has been gathering information and watching videos
- Owns a beginner's guide to surfing
- Still looking for the right time, place, and instructor for lessons
- Deborah encouraged: "Chase your dreams, don't be daunted" and "the experience matters just as much as the end result"

**Deborah's personal context:**
- Mentions Anna as someone she connects with - "Recently, Anna and I were sitting by the sea, watching the sunset and talking about each other. And we realized that we inspire each other."
- Recently had a beach/sunset experience with Anna

**Key encouragement from Deborah:**
- Breaking tasks down and prioritizing helps
- When overloaded, use methods like Eisenhower Matrix to figure out what's important and urgent
- Step by step, have fun along the way
