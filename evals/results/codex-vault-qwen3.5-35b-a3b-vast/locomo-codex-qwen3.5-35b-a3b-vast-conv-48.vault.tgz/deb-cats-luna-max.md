name: Deborah's cats - Luna and Max
description: Deborah has two cats: Luna (5 years, from shelter) and Max (8 years, from deceased mother)

---

**Luna:**
- 5 years old
- Taken from a shelter by Deborah
- Deborah's younger cat
- Likes to sit on the window sill

**Max:**
- 8 years old
- Deborah's mother's cat
- Deborah took him after her mother passed away
- Deborah is taming him
- Likes to sit on the window sill

Both cats bring joy and peace to Deborah's home. Deborah loves cats and believes they need a home, love, and care.