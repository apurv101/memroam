name: March 2, 2023 conversation - Deborah and Jolene
description: Deborah and Jolene discussed comfort foods, self-care practices, and Jolene's exam stress
---

## Food Preferences
- **Deborah**: enjoyed vegan stir-fry (tofu, vegetables, ginger, soy sauce) given by Anna
- **Jolene**: favorite dish is lasagna

## Self-Care Practices
- **Jolene**: did yoga and meditation last Friday to relax
- **Deborah**: also did yoga and meditation

## Jolene's Pets
- Has a tamed snake named **Seraphim**
- Took Seraphim to the park on Sunday

## Jolene's Current Situation
- Stressed about studies and exams
- Has overwhelming to-do lists and deadlines
- Recognizes need to be more mindful of stress levels and mental health
- Trying to prioritize self-care despite busy schedule

## Advice Given
Deborah recommended:
- Breaking tasks into smaller pieces
- Setting goals
- Using planners or schedulers to stay organized
- Making time for self-care
- Offered to help with study plans

## Closing Gestures
- Deborah gave Jolene a yellow coffee mug with handwritten encouraging message as a gift
