name: Jolene's self-care routine
description: Jolene practices yoga and meditation for balance and grounding during tough times

---

Jolene prioritizes self-care to stay balanced and grounded, especially during challenging times. Her routine includes:

- **Yoga** - Helps her find balance and stay grounded
- **Meditation** - Part of her daily self-care practice

Jolene is always looking for new routines to mix things up. Deborah shared that one of her favorite yoga routines is a gentle flow focused on breathing and grounding, which helps find balance in tough times.

---

**Durable facts:**
- Jolene practices yoga and meditation regularly
- These activities help her stay balanced and grounded
- She seeks variety in her self-care routines
- Gentle flow yoga with focus on breathing and grounding works well for balance
