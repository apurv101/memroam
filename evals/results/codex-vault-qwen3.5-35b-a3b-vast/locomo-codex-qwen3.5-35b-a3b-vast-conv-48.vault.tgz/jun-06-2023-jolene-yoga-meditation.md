name: Jolene's yoga and meditation practice
description: Jolene has practiced yoga and meditation sporadically for about 3 years; she used it to manage internship stress.

---

## Details

**Date:** June 6, 2023

**Practice duration:** About 3 years (sporadic practice, not consistent)

**Practice description:** Jolene does yoga and meditation to:
- Manage stress
- Stay centered
- Recharge and regroup
- Combat burnout from her engineering internship

**Recent milestone:** Practiced yoga on top of Mount Talkeetna (photoshared photo showing her standing on a rock with arms outstretched)

**Benefits reported:**
- Helped with stress
- Kept her centered
- Made a real positive effect on her life
- Jolene said "No idea how I would've survived without them!"

**Current challenges (Aug 2023):**
- Jolene is finding it difficult to balance engineering work, relationship, and personal growth
- Some days feel overwhelming when juggling all three areas
- Seeking ways to handle when it's too much

**Advice shared:** Deborah recommended mindful breathing practice for yoga:
- Set aside a few minutes each day
- Sit with eyes closed
- Take deep breaths
- Focus on how the air feels entering and leaving the body

**Visuals:** 
- Jolene shared photo of herself on Mount Talkeetna
- Deborah shared photo of her favorite yoga studio (room with bench and window)

---

## Context

Jolene started incorporating yoga and meditation into her routine as a response to finding work-life balance difficult during her new engineering internship. She had been "slogging away" and struggling to make time for hobbies and relaxation, making these practices particularly valuable for her.