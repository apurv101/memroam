name: Jolene's mini retreat and engineering breakthrough
description: Jolene's mini retreat on Wednesday gave her a new outlook and confidence; she achieved her engineering project with green tech solutions for disadvantaged areas.

On Wednesday (9 February, 2023), Jolene had a mini retreat to assess where she's at in life. It was a "dope experience that totally gave me a new outlook." She achieved more than she imagined, which gave her a real confidence boost.

Jolene accomplished something with her engineering project - she came up with some neat solutions and is excited about it. She specifically noted that green tech could make a difference in disadvantaged areas, and she wants to explore how she can contribute.

Jolene also shared her planner/sketches showing her plans and ideas.
