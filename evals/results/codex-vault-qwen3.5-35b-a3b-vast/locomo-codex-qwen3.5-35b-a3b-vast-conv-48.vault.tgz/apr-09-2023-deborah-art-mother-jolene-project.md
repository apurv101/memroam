name: April 9, 2023 — Deborah on art and her mother, Jolene's project
description: On April 9, 2023, Deborah shared how art reminds her of her mother and brings her peace; Jolene discussed her big project and personal coping activities
---

On April 9, 2023, Deborah and Jolene had a conversation about art, memory, and personal projects:

**Deborah on art and her mother:**
- Her mother was interested in art and believed art could give out strong emotions and uniquely connect people
- When Deborah goes to art shows, she feels like she and her mother are still experiencing art together even though her mother has passed away
- She finds it hard but comforting to connect with her mother through art
- Finding ways to keep her mother's memory alive gives Deborah peace
- Art brings back powerful emotions and reminds us of those we've lost
- Deborah values finding solace in things we love

**Jolene's personal connections:**
- Jolene shared that even though her snakes can't chat or understand her, their time together is valuable
- Interacting with her snakes teaches her to take time and be in tune with herself
- Playing video games with her partner after a long day is a great way for her to relax
- Jolene has been working on a big engineering project lately - it's been tough but cool to watch it take shape
- She was eager to share her progress and couldn't wait to see the final result

**Deborah's bike ride:**
- Deborah shared a photo from a recent bike ride nearby with her neighbor
- She found it freeing and beautiful
