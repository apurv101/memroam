name: Aug 1, 2023 - Community cleanup fundraising and Jolene's project setback
description: Deborah started a community cleanup project; Jolene's project crashed last week

---

On Aug 1, 2023, Deborah shared that she started a new community cleanup project and has been raising funds for it. She described it as amazing to see everyone come together to make a difference.

Jolene shared that she had a huge setback with her project the week before (late July 2023). She put in a lot of work but it all crashed and she lost everything. She found this very frustrating and depressing.

---

**Durable facts:**
- Deborah is fundraising for a community cleanup project (Aug 2023)
- Jolene experienced a major project failure in late July 2023 - lost all work due to a crash
