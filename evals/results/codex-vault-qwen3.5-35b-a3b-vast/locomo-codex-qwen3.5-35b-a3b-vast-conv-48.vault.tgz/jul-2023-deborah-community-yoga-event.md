name: Deborah's Community Yoga Event
description: Deborah organized a community yoga event with food stalls and live music in July 2023

---

In July 2023, Deborah organized a community yoga event that brought people together. The event featured:

- Yoga sessions
- Food stalls
- Live music

She reached out to different nearby businesses and venues to make it happen. Deborah found it rewarding to see the community come together, and described it as "amazing."

This reflects Deborah's ongoing commitment to teaching yoga and building community connections, following her previous yoga retreat work.
