name: Jan 31, 2023 — Jolene's robotics project and Deborah's new neighbor
description: On January 31, 2023, Jolene shared about her engineering professor's robotics project, and Deborah introduced her new neighbor Anna
---

On January 31, 2023, Deborah and Jolene had a conversation touching on robotics and new connections:

**Jolene's robotics project:**
- Jolene is working on a large robotics project from her engineering professor
- She finds it tough but fun
- It's making her get creative and problem-solve
- She felt a mix of emotions when she first received it - excited and nervous
- Now she's really enjoying it
- She compares it to solving a puzzle, figuring out the best design and programming
- She finds it awesome to see the robot come together

**Deborah's new neighbor:**
- Deborah met her new neighbor Anna at yoga in the park
- They talked about how yoga has improved their lives and the sense of community it gives
- Deborah asked Jolene if she ever thought about resuming yoga
- Jolene mentioned she and her partner planned to play the console together instead

**Conversation details:**
- Jolene shared a photo of a table with a robot on it and a laptop
- Deborah shared a photo of a yellow sign with a picture of a family
- Jolene shared a photo of a purse with a plant on a table
