name: Yoga retreat with partner
description: Jolene attended a peaceful yoga retreat with her partner; the sunrise over a valley created a profoundly moving experience.

---

Jolene and her partner went to a yoga retreat. During sunrise yoga, the view of the valley was spectacular—sunrise colors lit up the entire sky. The experience made Jolene feel "connected to nature and myself," "incredibly peaceful and thankful," and "alive." This was a deeply meaningful moment of connection to nature and self.