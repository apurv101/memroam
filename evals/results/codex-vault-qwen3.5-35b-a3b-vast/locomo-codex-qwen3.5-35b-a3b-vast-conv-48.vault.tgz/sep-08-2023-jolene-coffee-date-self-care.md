name: Sep 8, 2023 — Coffee date planned, Jolene shares self-care routine
description: September 8, 2023 conversation about Deborah's canceled yoga trip and planning a coffee meetup
---

On September 8, 2023, Jolene and Deborah connect after a tough week:

**Deborah's setback:**
- Had a yoga getaway canceled due to a storm
- Initially felt bummed but found comfort in work and home time
- Embraced the setback as a reminder to be grateful for little things

**Jolene's plans:**
- Planning a camping trip with her partner to connect with nature and practice yoga
- Maintains a schedule with classes, studying, and personal time
- Self-care activities like yoga and meditation help her stay balanced and relaxed

**Routine and strategies:**
- Jolene uses routines to stay on top of responsibilities
- Takes time for experimenting with what works best
- Found that balancing schedule with self-care has been really helpful

**Coffee date plans:**
- Deb and Jolene initially planned to meet Monday, then Wednesday at 4 PM
- Deborah had existing plans for Wednesday
- Eventually settled on Friday at 5 PM
- Jolene will be sorting books from her bookcase beforehand
- Deborah mentioned wanting interesting book recommendations

**Shared interests:**
- Both enjoy coffee shops and have shared photos of various cafes
- Deborah mentioned a hidden coffee shop near her
- Both expressed excitement about catching up

**Durable facts:**
- Jolene and Deborah scheduled a coffee date for Friday at 5 PM (Sep 2023)
- Jolene's self-care routine includes yoga, meditation, and maintaining a balanced schedule
- Jolene's partner shares her interest in yoga and nature
- Deborah is interested in book recommendations
- Both friends value staying connected despite busy schedules
