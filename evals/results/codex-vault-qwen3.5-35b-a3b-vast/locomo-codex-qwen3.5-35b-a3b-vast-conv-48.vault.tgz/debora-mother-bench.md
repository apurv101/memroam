name: Deborah - Mother's memory bench and teachings
description: Deborah's mother had a special bench near a window where she loved to sit and take in the view; Deborah visits it to stay connected to her mother's memory

---

On January 22, 2023, Deborah shared memories about her mother:

- Her mother's old house holds special memories for her
- Her mother passed away a few years before the conversation
- Her mother had a special bench near a window where she loved to sit every morning and take in the view
- Deborah sometimes sits on the bench to stay connected to her mother's memory
- Deborah has a pendant that reminds her of her mother

Deborah's personal goals:
- To keep teaching yoga
- To support her community
- She is passionate about helping people find peace and joy through yoga

Deborah was inspired to teach yoga because it helped her find peace during a rough time in her life, and now she wants to share that with others.
