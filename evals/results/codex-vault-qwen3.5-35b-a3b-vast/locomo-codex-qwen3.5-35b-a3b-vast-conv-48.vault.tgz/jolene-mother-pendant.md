name: Jolene - Mother's memory items and philosophy
description: Jolene has a heart-shaped pendant with a bird symbol from her mother given in Paris 2010; symbolizes freedom to her; mother passed away in 2022

---

On January 22, 2023, Jolene shared memories about her mother:

- Her mother passed away in 2022
- She has a heart-shaped pendant with a bird on it that reminds her of her mother
- Her mother gave it to her in 2010 in Paris
- The pendant has a special symbol representing freedom for Jolene
- It reminds her to go for her goals and not get held back

Jolene's philosophy:
- Staying connected to loved ones who have passed is super important
- Memory items like jewelry give strength and energy
- Freedom is an important value to her

During the conversation, Jolene also shared a photo of her mother's room in her house, which holds many memories.
