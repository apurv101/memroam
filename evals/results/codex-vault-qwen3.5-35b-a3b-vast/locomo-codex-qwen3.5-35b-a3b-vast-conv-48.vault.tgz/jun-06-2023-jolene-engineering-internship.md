name: Jolene's engineering internship
description: Jolene started interning at a well-known engineering firm in June 2023.

---

## Details

**Date:** June 6, 2023

**Opportunity:** Internship at a well-known engineering firm

**Timing:** Started after completing her solar-powered vehicle project (May 2023)

**Key experiences:**
- Applying learned concepts from school to real projects
- Seeing her ideas come to life
- Working with colleagues who are passionate about engineering
- Testing her skills in a professional environment

**Impact:**
- Rekindled her love of engineering
- Encouraged her to keep striving for her dreams
- Inspired her to stay focused on her goals
- Shown her that dedication and effort make anything possible

**Visual:** Jolene shared a photo of her new colleagues at the engineering firm.

---

## Work-life balance challenge

Jolene mentioned that finding work-life balance has been tough during the internship. She's been working hard and struggling to make time for hobbies and relaxation. This challenge led her to lean more into yoga and meditation.

**Current situation (Aug 2023):**
Jolene is finding it difficult to juggle her engineering work, relationship with her boyfriend, and personal growth. Some days feel overwhelming, and she's looking for ways to handle when it's too much.