name: Jan 27, 2023 — Deborah's father passes, family memories
description: On January 27, 2023, Deborah shared that her father died suddenly on January 25; Jolene shared details about her snakes and gaming with her partner

---

On January 27, 2023, Deborah and Jolene had a conversation touching on grief, family, and personal interests:

**Deborah's family updates:**
- Her father passed away suddenly on January 25, 2023 (two days before the conversation)
- Her mother also passed away (previously mentioned)
- She's channeling grief by spending more time with family and looking through family albums
- Her parents' wedding was in 1993
- Deborah values love and openness in her relationship with her husband
- She's trying to be as good a family as her parents were

**Deborah's yoga teaching:**
- Group members sent her a thank-you letter for her positive influence on them
- This reinforces her passion for yoga teaching

**Jolene's pets:**
- Jolene has two snakes: Susie and Seraphim
- She bought them a year ago in Paris
- They calm her down and make her happy
- They've been known to slink out of their cages while she plays video games

**Jolene's gaming:**
- Jolene and her partner play video games together
- They played "Detroit" last week
- They were both crazy about the activity
- Jolene learned to play on her own as a child
- They planned to play "Walking Dead" the following Saturday
