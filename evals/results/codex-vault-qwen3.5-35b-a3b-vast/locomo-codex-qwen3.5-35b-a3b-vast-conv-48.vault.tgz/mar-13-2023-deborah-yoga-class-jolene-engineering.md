name: March 13, 2023 conversation - Deborah and Jolene
description: Deborah shared hosting neighborhood yoga class; Jolene discussed struggles with Engineering assignments and need for time management talk

---

## Deborah's Yoga Class

- Started a yoga class in her neighborhood (March 2023)
- Hosted first class on Friday, March 10, 2023
- Neighbors were interested in trying yoga
- Deborah teaches yoga because:
  - She finds it calming
  - Giving people peace and awareness brings her happiness
  - It helps build community connections
  - She's made great friends through teaching
- Shared a group photo with her students (women in the class)

## Jolene's Current Challenges

- Struggling with Engineering assignments
- Feeling overwhelmed managing the workload
- Wants to discuss time management strategies
- Plans to check her schedule to find a time to chat with Deborah

## Supportive Friendship

- Deborah offered continued support and availability
- Both friends emphasized the importance of having someone to rely on during tough times