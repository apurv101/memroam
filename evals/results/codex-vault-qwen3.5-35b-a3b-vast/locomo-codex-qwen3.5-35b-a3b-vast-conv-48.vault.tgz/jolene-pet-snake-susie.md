name: Susie - Jolene's pet snake
description: Jolene adopted a pet snake named Susie in Aug 2021 when she was feeling lonely

---

Jolene adopted a pet snake named Susie two years before Aug 1, 2023 (around Aug 2021) when she was feeling lonely and wanted some company.

Susie has been a source of comfort for Jolene during tough times. Having Susie around helps Jolene feel strong and find joy in small moments. Pets have been great company and help Jolene cope when things get tough.

Jolene mentioned that having a pet teaches responsibility.

---

**Durable facts:**
- Jolene has a pet snake named Susie
- Adopted in Aug 2021 when Jolene was feeling lonely
- Susie provides comfort and companionship during difficult times
