name: Jolene's scuba diving lesson and surf trip plan with Deborah
description: Jolene tried scuba diving on September 15, 2023, and she and Deborah plan to go surfing together next month

---

On September 17, 2023, Jolene and Deborah shared recent adventures and plans:

**Jolene's scuba diving experience:**
- Last Friday (September 15, 2023), Jolene tried a scuba diving lesson
- She had an awesome time and found a cool dive spot she can explore
- She's still working toward becoming a certified diver
- She mentioned she's "just started learning, but haven't gone yet" - meaning she hasn't been out on a real dive yet
- Jolene invited Deborah to come with her sometime

**Deborah's interest in underwater activities:**
- Deborah has been interested in underwater life
- She hasn't had the chance to try scuba diving yet
- She was curious about Jolene's experience

**Surfing plan:**
- Deborah and Jolene are planning to go surfing together
- They discussed timing for next month
- Jolene will check her schedule and let Deborah know the specific day
- Both are excited about the planned adventure

This shows both friends trying new water-related activities - Jolene diving and both planning surfing lessons together.
