name: Aug 21, 2023 — Jolene's new game, Deborah's flower memories
description: Aug 21, 2023 conversation about Battlefield 1, Deborah visiting a bench to honor her mother, and the healing power of small moments
---

On August 21, 2023, Jolene and Deborah reconnect after some time apart:

**Jolene's gaming:**
- Received Battlefield 1 for her console as a new game
- Playing games helps her escape studying and work stress

**Deborah's reflective visit:**
- Went to a place holding many memories - sat on a bench where they used to chat
- Felt a mix of nostalgia, longing, and gratitude for the memories
- Brought flowers to the location

**Deborah's mother and flowers:**
- Her mother really loved flowers and they always made her happy
- Her mother appreciated the simple things in life
- She taught Jolene to take it slow, see beauty, and find joy

**Finding balance and appreciation:**
- Both agreed to make an effort to appreciate life's small things
- Jolene practices yoga (3 years) and meditation
- Jolene's favorite yoga pose: savasana (corpse pose) for rest and surrender
- Deborah practices yoga, meditation, and goes for mindful walks
- Deborah takes photos of sunsets and peaceful moments during walks
- Deborah describes the peaceful feeling as "like a reboot" and "hitting the refresh button"

**Closing:**
- Both wish each other well and agree to stay in touch

---

**Durable facts:**
- Jolene plays Battlefield 1 (as of Aug 21, 2023)
- Jolene has been practicing yoga for 3 years
- Jolene's favorite yoga pose is savasana (corpse pose)
- Deborah's mother loved flowers and found joy in simple things
- Deborah takes photography on mindful walks, especially of sunsets and peaceful moments
- Deborah visits a meaningful bench to honor memories of her mother
