name: Jolene - Water purifier engineering project
description: Jolene designed and built a sustainable water purifier for a rural community, marking a major engineering milestone and accomplishment

---

On February 4, 2023, Jolene shared a major engineering milestone she achieved the week before:

- She designed and built a sustainable water purifier for a rural community in need
- The project required significant planning and research
- Seeing the water purifier work and provide clean water was a "surreal moment" for her
- The experience was incredibly satisfying and gave her a sense of purpose
- It reinforced her belief that engineering can make a real difference in people's lives

Jolene's career aspirations:
- To keep working in engineering
- To continue making a positive impact on communities in need
- To create sustainable solutions that contribute to making the world a better place

This project was described as a "huge accomplishment" that left Jolene feeling relieved and proud.
