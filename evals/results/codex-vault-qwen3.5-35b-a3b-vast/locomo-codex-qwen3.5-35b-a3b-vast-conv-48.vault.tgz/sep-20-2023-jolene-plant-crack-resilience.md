name: Jolene's plant-in-crack photo
description: Jolene's photo of a plant growing from a building corner symbolizes resilience and growing through obstacles.

---

Jolene shared a photo she took of a plant growing out of a corner of a building. She said it's a "great visual representation" of the idea that beauty and growth can be found even in tough places. For Jolene, this image represents the lesson that "I can keep growing through any obstacles"—a personal symbol of resilience.