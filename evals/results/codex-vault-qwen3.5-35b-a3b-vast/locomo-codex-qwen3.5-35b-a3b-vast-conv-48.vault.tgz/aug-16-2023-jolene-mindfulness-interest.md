name: Jolene's interest in mindfulness
description: Jolene expressed interest in trying mindfulness and meditation to de-stress

---

## Details

**Date:** August 16, 2023

**Context:** Jolene was sharing that she feels overwhelmed juggling engineering, relationship, and personal growth. She was asking for advice on handling when it's too much.

**Interest in mindfulness:**
- Deborah shared about her own meditation yoga session at a local care home during sunset
- Jolene said she hasn't tried mindfulness yet but is keen to give it a shot
- She expressed interest in destressing and trying mindfulness
- She could use some calm in her life right now

**Deborah's background:**
- Started with workshops and books
- Now mindfulness is a huge part of her life
- Offered to help Jolene get started

---

**Durable facts:**
- Jolene is interested in trying mindfulness and meditation
- She wants to de-stress and find calm
- Deborah has experience with mindfulness through workshops, books, and leading sessions
