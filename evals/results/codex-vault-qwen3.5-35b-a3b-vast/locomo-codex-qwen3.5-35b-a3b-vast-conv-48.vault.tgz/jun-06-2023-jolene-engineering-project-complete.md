name: Jolene completes engineering project
description: Jolene finished a tough solar-powered vehicle engineering project last month (May 2023).

---

## Details

**Date:** June 6, 2023

**Project:** Solar-powered vehicle with solar panel on the back

**Context:** Jolene had been working on this engineering project for some time. She described it as a tough engineering project with problems, but she stuck with it and finally completed it in May 2023.

**Significance:** Jolene considers this a big milestone and is proud of herself for persevering through difficulties.

**Visual:** Jolene shared a photo of the completed solar-powered vehicle.

---

## Aftermath

After completing the project, Jolene started a new internship at a well-known engineering firm where she's been able to apply what she learned in school to real projects.