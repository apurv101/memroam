name: September 3, 2023 — Deborah's yoga mom memory; Jolene's gaming origin story
description: Sept 3 conversation: Deborah found old yoga photo with mom who was her biggest fan; Jolene shared gaming origins (Nintendo at age 10, Monster Hunter: World favorite, parents' support)

---

On September 3, 2023, Deborah and Jolene caught up:

**Deborah's community and yoga:**
- Attended a community meetup on Friday, Sept 1, 2023
- Shared stories with the group; felt the connection of community
- Found an old photo of herself on a yoga mat with her two children
- That photo was from when she first started doing yoga
- Her mother was her biggest fan and source of motivation
- Mum would often attend Deborah's yoga classes with her
- Deborah is currently organizing a yoga retreat (ongoing project)

**Jolene's gaming history:**
- Received a Nintendo game console and controller at age 10
- That was the start of her passion for video games
- She taught herself to play
- Her dad was always supportive
- Her mom would play games with her
- Favorite game: "Monster Hunter: World"
- Loves the immersive story and open-world gaming
- Gaming is her way to de-stress and take a break from life
- Currently preparing for finals (stressful but worth it)
- Planning to take a trip somewhere to relax and recharge after finals

**Shared themes:**
- Both value supportive family relationships
- Both use activities (yoga, gaming) to relax and de-stress
- Both appreciate the importance of encouragement from loved ones

---

**Durable facts:**
- Deborah's mother attended her yoga classes and was her biggest fan/motivation
- Jolene received Nintendo console and controller at age 10
- Jolene taught herself gaming; dad supportive, mom played with her
- Jolene's favorite game is Monster Hunter: World
- Jolene has finals in September 2023
- Jolene plans a post-finals trip to relax and recharge
