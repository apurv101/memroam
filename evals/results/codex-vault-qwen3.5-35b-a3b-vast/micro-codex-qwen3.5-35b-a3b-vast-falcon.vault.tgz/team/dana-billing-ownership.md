name: Dana Taking Over Billing Service
description: Dana assumes ownership of billing service during Marco's parental leave through end of year
---

Marco is going on parental leave starting next week. **Dana** is taking over the billing service responsibilities while he is out.

**Timeline**: Starting next week through end of year
**Previous owner**: Marco
**Current owner**: Dana