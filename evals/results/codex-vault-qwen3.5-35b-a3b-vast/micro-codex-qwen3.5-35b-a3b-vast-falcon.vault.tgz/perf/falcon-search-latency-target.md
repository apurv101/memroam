name: Falcon Search p95 Latency Target
description: 200ms p95 latency target on Falcon search endpoint for staging (eu-west-1)
---

Falcon search endpoint has committed to a **200ms p95 latency target**.

**Environment**: Staging (eu-west-1)
**Metric**: p95 latency
**Target**: 200ms