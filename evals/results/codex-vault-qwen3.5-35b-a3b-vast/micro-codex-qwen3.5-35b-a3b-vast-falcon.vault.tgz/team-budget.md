name: Team and budget
description: Team roles and $40k contractor budget for the half.

# Team and Budget

- **Marco**: owns the billing service
- **You**: own the gateway service
- **Contractor budget**: $40k for this half
