name: Infrastructure and deployment
description: Postgres 16 stack and Wednesday morning deployment schedule.

# Infrastructure and Deployment

- Database: Postgres 16 (migration from Postgres 15 completed)
- Deploy schedule: Wednesday mornings (Friday deploys removed due to weekend incidents)
