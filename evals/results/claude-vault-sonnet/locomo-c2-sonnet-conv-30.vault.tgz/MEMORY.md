# Memory index — conv-30

- [Gina's clothing store](gina-clothing-store.md) — owns a clothing store, just launched an ad campaign to grow it
- [Jon's dance studio](jon-dance-studio.md) — grand opening 2023-06-20; full arc from location search through launch

