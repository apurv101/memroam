---
name: john-motivation-support
description: John's motivation habits (whiteboard, desk plaque) and his support network (team, family)
metadata:
  type: project
---

As of 2023-10-21, John shared his personal motivation habits: he keeps a whiteboard with motivational quotes/strategies to stay focused through tough workouts, and keeps a "make it happen" lightbox plaque on his desk as a reminder to believe in himself and trust his abilities. On support: his teammates' belief in him and encouragement (even when he makes mistakes) keep him going, and he describes them as a second family; he also has a broader supportive family/friend group he leans on outside of sports, and enjoys hanging out with them (movies, dinner out). This overlaps with his existing "team as family" theme (see [[john-basketball-endorsements]], [[john-mentoring]]) but centers specifically on his personal motivation tools and support system rather than on-court performance.

As of 2023-11-16, John reiterated visualizing his goals and success as a key motivation/focus technique specifically for studying-adjacent tough mental tasks (came up when Tim asked how he stays motivated during difficult exam prep — John related it to his own visualization habit).

As of 2023-12-11, John shared a childhood origin detail for his motivation habits: as a kid he'd practice basketball outside for hours, dreaming of playing in big games — it was his way of coping with doubts and stress, framing a ball and hoop as a powerful outlet (parallels his current "team as family"/visualization habits above).

**Why:** Came up in a catch-up chat with Tim about what keeps each of them motivated.

**How to apply:** Reference if John or Tim discuss motivation, resilience, or support systems — could ask if the whiteboard quotes have changed or what's currently on it.
