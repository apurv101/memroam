---
name: john-hiking
description: John's hiking hobby (joined a club ~Sept 2023) has led to an outdoor gear brand deal and photoshoot
metadata:
  type: project
---

As of 2023-12-19, John shared he landed a sponsorship deal with a "renowned" outdoor gear company (~week prior, ~2023-12-12) and got hiking/outdoor gear from it. He did a brand photoshoot in a forest, with the photographer capturing him mid-activity (shared a jumping-in-a-field shot). He described stumbling on a peaceful spot on a hike — a river and rocks — that put him in a reflective, energized mood; nature is a recurring source of calm/energy for him (parallel to his [[john-surfing]] "freedom" outlet).

This builds on [[john-wedding]], where his hiking club first came up (friends from the club attended his ~2023-09-25 wedding).

**Why:** Came up in a 2023-12-19 catch-up with Tim; John was excited to share the deal.

**How to apply:** Worth following up on how the outdoor gear partnership develops (any campaign/content, whether it grows like his basketball endorsements — see [[john-basketball-endorsements]]) and whether he's still active with the hiking club.
