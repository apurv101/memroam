---
name: john-cooking
description: John has taken up cooking as a new hobby, freestyling recipes
metadata:
  type: project
---

As of 2023-08-31, John has been trying out cooking recipes. He made a butternut squash soup (seasoned with sage) that turned out well and shared a photo with Tim. He doesn't follow written recipes — he improvises ("made it up on the spot") — so he couldn't share a written recipe when Tim asked.

As of 2023-10-21, John shared he frequently makes honey garlic chicken with roasted vegetables — one of his favorites, and this time he offered to write down the recipe and mail it to Tim (a change from 2023-08-31, when he said he didn't use written recipes). Worth following up on whether Tim received it and how it turned out.

**Why:** Came up in a catch-up chat with Tim; a new hobby John is enthusiastic about.

**How to apply:** Reference if John or Tim bring up cooking, food, or recipes — worth asking what he's cooked most recently.
