---
name: john-family-travel
description: John's home/family visits and love of traveling to new cities (e.g. NYC)
metadata:
  type: project
---

As of 2023-08-26, John visited home and caught up with family and old friends, reminiscing about childhood ("good ol' times"). He also shared a love of discovering new cities, citing a trip to New York City — enjoyed exploring the skyline, culture, and restaurants, and called it a "must-visit." This is on top of previously mentioned trips to Chicago and Seattle (see [[john-basketball-endorsements]]), suggesting travel is a recurring interest of his separate from basketball.

As of 2023-08-31, John mentioned the NYC trip had one hiccup: he initially struggled to figure out the subway, but it became easy once someone local helped explain it to him.

As of 2023-11-06, John and his wife (see [[john-wedding]]) just left for a short European vacation. Tim recommended visiting castles, tying into his own castle fascination (see [[tim-travel]]).

As of 2023-11-11, John recapped the European coastline road trip with his wife (the 2023-11-06 vacation) — shared a photo of them on a mountaintop, called the views spectacular and the trip a great bonding experience and "nice change" from regular life.

As of 2024-01-02, John visited Italy last month (~Dec 2023) and loved it — called out the food, history, and architecture; bought a cookbook there that's now inspiring his cooking (see [[john-cooking]]). He's also visited Paris and the Eiffel Tower, describing the view from up there as incredible.

**Why:** Came up in a catch-up chat with Tim, who is interested in traveling to NYC himself and asked John about the trip.

**How to apply:** Reference when John or Tim bring up travel plans — Tim has NYC on his travel list and may ask John for tips given John's positive experience there.

As of 2023-09-21, John's basketball team is planning a trip next month (~October 2023) to a new city, undecided as of this chat. Tim suggested Edinburgh, Scotland for its history, architecture, and Harry Potter connection, and John was open to the idea. See [[john-basketball-endorsements]] for the team context.

As of 2023-12-01, in a broader chat about nature/scenery, John shared photos and recalled a camping trip in the mountains (favorite part: just chilling and taking in the scenery, calling it peaceful/refreshing) and a separate solo Rocky Mountains trip from "last year" (~2022), describing the snow-capped peaks and fresh air as stunning and grounding. Both he and Tim riffed on nature as calming/humbling — a new recurring theme distinct from his city-travel interest above.
