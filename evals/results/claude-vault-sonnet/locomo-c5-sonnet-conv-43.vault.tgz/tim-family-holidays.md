---
name: tim-family-holidays
description: Tim's family traditions around Thanksgiving/Christmas and his HP-themed Christmas tree
metadata:
  type: project
---

As of 2023-08-21, Tim shared that family time is important to him, including a photo of his family gathered by a fireplace for a meal. His Thanksgiving traditions include prepping the feast with family, sharing what they're thankful for, and watching movies afterward — favorites are "Home Alone," "Elf," and "The Santa Clause." He decorated his own Christmas tree with a Harry Potter theme, tying into his HP fandom (see [[tim-interests]]).

John reciprocated with his own family gathering photo and a photo of his (non-themed) Christmas tree from the previous year, noting his family also gets together often.

**Why:** Came up in a catch-up chat on 2023-08-21 when the conversation moved from Tim's love of the first HP movie into family/holiday traditions.

**How to apply:** Reference if Tim or John bring up upcoming holidays, family gatherings, or Christmas decorating.
