---
name: tim-travel
description: Tim's travel plans, incl. first-time trip to Universal Studios
metadata:
  type: project
---

As of 2023-08-31, Tim is planning a trip to Universal Studios next month (~September 2023) — his first time going. He's especially excited for the Harry Potter areas, tying into his existing HP fandom (see [[tim-interests]]).

As of 2023-10-17, Tim also shared a photo he took of a sunset over a mountain (Smoky Mountains) from a trip there "last summer"/"last year," which he described as stunning to see in person.

As of 2023-10-21, Tim dreams of visiting UK castles someday after reading a book about them (see [[tim-interests]]) — not yet a booked/planned trip, just an aspiration.

As of 2023-11-16, that aspiration came true: Tim took a trip to the UK and visited a castle (with a river running through it) the Friday before (~2023-11-10), sharing a photo and calling the architecture and history "unbelievable."

As of 2023-12-06, Tim joined a travel club (shared a photo of a wall map, mentioned Westendell), citing his long-standing interest in different cultures and countries and excitement to meet new people through it.

As of 2023-12-26, Tim is reading a book of travel stories from travelers around the world to get ideas for his next adventure — mentioned one story about two hikers trekking the Himalayas (tough terrain, altitude sickness, bad weather, but worth it), which he found motivating. He'd just visited a travel agency to check requirements for his next dream trip (destination not yet specified).

As of 2024-01-02, Tim joined a group of fellow globetrotters (into the same travel stuff as him — possibly the same as or related to the 2023-12-06 travel club) and has enjoyed getting to know them and hearing about their trips. He also named Italy as a country he wants to visit but hasn't yet been to (John visited last month — see [[john-family-travel]]).

As of 2024-01-07, Tim got accepted into a study abroad program and is heading to Galway, Ireland next month (~February 2024) for a semester — chosen for its vibrant arts and Irish music scene. He's most excited to explore the nature there and wants to visit the Cliffs of Moher for the ocean views. John, who has his own travel habits (see [[john-family-travel]]), offered to stop by after his (basketball) season if he's in the area.

As of 2024-01-12, Tim is working through visa requirements for upcoming trips (feeling a bit overwhelmed but excited) — likely related to the Feb 2024 Galway semester and/or other destinations. John recommended Barcelona as a must-visit (culture, architecture, food by neighborhood, nearby beaches), and Tim added it to his list.

**Why:** Came up in a catch-up chat with John.

**How to apply:** Follow up on how the Universal Studios trip went, especially the Harry Potter sections, in future conversations. The UK castle trip aspiration is now fulfilled — could ask which castle, or if it's sparked interest in visiting more. Once Feb 2024 arrives, ask how the Galway semester and Cliffs of Moher visit went, how the visa research/prep worked out, and whether Barcelona ends up on a future itinerary.
