---
name: john-wedding
description: John got married in a greenhouse ceremony; also recently joined a hiking club
metadata:
  type: project
---

As of 2023-10-02, John shared that he and his girlfriend had their wedding ceremony the week before (~2023-09-25). They found a greenhouse venue for a smaller, intimate gathering, following safety protocols so guests felt comfortable. Favorite memory: seeing her walk down the aisle. Their first dance was at a cozy restaurant, candlelit. Friends from a hiking club he'd only just joined showed up to celebrate with him — first mention of John joining a hiking club.

**Why:** Major life milestone Tim congratulated him on in their 2023-10-02 catch-up.

**How to apply:** Ask how married life is going, follow up on the honeymoon (not yet mentioned) and whether he's stuck with the hiking club.
