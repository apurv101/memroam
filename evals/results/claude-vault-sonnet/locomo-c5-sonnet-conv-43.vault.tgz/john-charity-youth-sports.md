---
name: john-charity-youth-sports
description: John's charity work supporting youth sports access for underserved communities
metadata:
  type: project
---

As of 2023-12-26, John spoke at a charity event (shared a photo of himself on stage there) as part of using his influence/resources to support causes he believes in. His main cause is youth sports: fighting for fair access to good sports programs for underserved communities, and collaborating with organizations to create more opportunities for young athletes. His standout memory: organizing a basketball camp for kids in his hometown last summer (~2023), which he described as a week of laughs, high-fives, and personal growth, and said seeing the kids' faces light up on the court was priceless.

As of 2024-01-07 (the week prior, ~early Jan 2024), John organized and held a benefit basketball game — well-attended and successfully raised money for charity. He reflected on how basketball brings people together and creates a positive impact, echoing his broader youth-sports charity focus above.

**Why:** Came up in a catch-up chat with Tim, framed around "making a difference" — distinct from his on-team mentoring (see [[john-mentoring]]) and his new public seminars.

**How to apply:** Worth following up on future camps/events or how the youth-sports partnerships develop.
