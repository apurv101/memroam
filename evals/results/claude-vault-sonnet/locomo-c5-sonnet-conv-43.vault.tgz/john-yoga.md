---
name: john-yoga
description: John's new yoga practice for strength/flexibility/focus, favorite poses
metadata:
  type: project
---

As of 2023-12-01, John shared he's taken up yoga as a new hobby (photo: "30 positive suites" wall lettering) to build extra strength and flexibility. He says it's challenging but worth it, and has helped his strength, flexibility, focus, and balance during workouts. His favorite poses are Warrior II (makes him feel strong) and a balance/stability pose (shared a photo of himself doing it on a mat) — he typically holds poses for 30-60 seconds.

This came up when Tim shared a photo of himself succeeding after a tough exam and talked about resilience; John responded by sharing his own growth activity (yoga).

**Why:** New hobby John introduced in a catch-up chat with Tim, paralleling his other physical pursuits (see [[john-basketball-endorsements]], [[john-surfing]]).

**How to apply:** Reference if John or Tim bring up yoga again — Tim expressed interest in trying the balance pose John shared, so could follow up on how that went.
