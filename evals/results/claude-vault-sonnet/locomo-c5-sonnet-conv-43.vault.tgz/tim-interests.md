---
name: tim-interests
description: Tim's interests in fantasy literature, HP memorabilia, and his fantasy-writing gig
metadata:
  type: project
---

Tim is into fantasy literature — joined a fantasy literature forum (as of 2023-06-14) and enjoys discussing favorite books there. He collects Harry Potter memorabilia, including prop replicas from MinaLima (the studio that created props for the HP films), displayed on his bookshelf. He describes these as a way to escape reality and says he may visit more Harry Potter–related locations in the future. As of 2023-07-16 he'd had a memorable chat with a fellow Harry Potter fan in California; he frames reading fantasy books (in a comfy spot at home) as his equivalent of an escape/freedom outlet, comparable to how John feels about surfing.

As of 2023-08-02, Tim landed a gig writing articles about fantasy novels for an online magazine — he found the opportunity via the fantasy lit forum, pitched his ideas, and the magazine accepted. His articles cover character/theme analysis and book recommendations. His favorite books to write about are Harry Potter and Game of Thrones.

As of 2023-08-09, Tim Skyped with the Harry Potter fan he met in California — they discussed characters and are considering collaborating on something (unspecified, likely fandom/writing-related given his magazine gig). He's currently reading a fantasy book by Patrick Rothfuss and raves about the world-building and characters.

As of 2023-08-11, Tim confirmed the Rothfuss book is "The Name of the Wind" (fantasy novel with a magician/musician protagonist) and recommended it to John. He also mentioned recently attending a fan event, which he loved for being around other fans who share his interests.

As of 2023-08-17, Tim is hoping to attend a book conference the following month (~September 2023) — a gathering of authors, publishers, and book lovers to discuss favorite novels and new releases; he's looking forward to it as a way to learn more about literature.

As of 2023-08-26, Tim had a busy/stressful week with assignments and exams but is determined not to give up, and is trying to juggle studying with his fantasy reading hobby.

As of 2023-10-13, Tim attended a Harry Potter conference in the UK the prior week, which he described as incredible and inspiring — being around so many fellow HP fans felt like "a magical family" and gave him a new lease of life. He values how his fantasy fandom connects him with people worldwide.

As of 2023-10-21, Tim read a book about UK castles and was blown away — he dreams of visiting them someday (see [[tim-travel]]). He's currently mid-way through writing his fantasy novel, describing the process as nerve-wracking but exciting. His creative inspiration comes from books, movies, and real-life experiences (e.g. the castle book sparked ideas); he named J.K. Rowling specifically as a major inspiration, praising her detailed, immersive storytelling and saying he takes notes on her style for his own writing. His favorite Rowling quote: "Turn on the light - happiness hides in the darkest of times," which he uses to stay hopeful during tough times.

As of 2023-11-06, Tim shared that the prior week he'd gotten badly stuck on a plot twist in his novel (see [[tim-travel]] and earlier "mid-way through writing" note) but pushed through and got the ideas flowing again — framed it as a struggle that made the eventual breakthrough feel more satisfying. He also revealed a prized possession: a basketball signed by LeBron James, his favorite player; his go-to LeBron story is the chase-down block on Iguodala in Game 7 of the 2016 NBA Finals, which he cites as an inspiration for "never give up."

As of 2023-11-11, Tim shared he's currently reading "A Storm of Swords" (A Song of Ice and Fire/Game of Thrones series). He and John both frame fantasy books/shows as a mental escape/refreshing break from regular life — a recurring theme also tied to John's surfing (see [[john-surfing]]).

As of 2023-11-21, Tim tried writing a story based on his UK experiences (likely tied to his novel or the HP conference trip, see castle-book/UK conference notes above) but hit a setback — it didn't go the way he wanted. John suggested reflecting on what went wrong as a way to improve, drawing a parallel to how he handles on-court setbacks. Tim also shared he recently read a book about how small changes can make big differences (Atomic Habits-style), which changed how he approaches things; separately confirmed HP and GoT remain his all-time favorite reads, alongside growth/psychology/self-improvement books.

As of 2023-12-08, Tim attended a Harry Potter–themed party and met lots of people into the same fandom — didn't dress as a specific character but wore his Gryffindor scarf, and got a chocolate frog treat there. He also finished "A Dance with Dragons" (next in the ASOIAF/GoT series after "A Storm of Swords," see above) and recommended it highly; confirmed he's only read the GoT series among GRRM's books.

As of 2023-12-11, Tim mentioned a tough English lit class assignment where he did an analysis on a series (likely GoT/ASOIAF, given his ongoing read of that series — see above) and felt it went okay.

As of 2023-12-26, Tim named Lord of the Rings as his favorite film/fantasy franchise ("epic adventures and magical worlds") and is excited for the upcoming "The Wheel of Time" TV series (based on the book series he loves), premiering next month (~Jan 2024). He also does movie marathons with friends to relax, and mentioned being a big fan of Emma Watson, admiring her gender-equality/women's-rights advocacy specifically (not just her HP role).

As of 2024-01-02, Tim named Star Wars as his favorite fantasy film (previously he'd named Lord of the Rings as his favorite fantasy franchise on 2023-12-26 — both can hold true, or this may reflect his taste narrowing to "favorite movie" specifically vs. franchise overall). He also took French in high school, before starting German — see [[language-learning]].

**Why:** Came up in a casual catch-up conversation with John on 2023-06-15; recurring topic Tim is enthusiastic about.

**How to apply:** Reference when Tim brings up books, fantasy fandom, HP-related plans/trips, or his magazine writing — he'd likely appreciate follow-up questions on how the articles are going or which books he's covering next.
