---
name: tim-life-updates
description: Recent personal milestones/setbacks Tim has shared — job search, school presentations
metadata:
  type: project
---

As of 2023-08-31, Tim shared two recent life updates: he was turned down for a summer job he wanted but is staying positive about it; and he gave a class presentation the day before despite being nervous, which he counts as meaningful progress (small step forward).

**Why:** Came up in a catch-up chat with John; part of Tim's ongoing personal-growth narrative alongside his studies (see [[tim-interests]]).

**How to apply:** Ask about how the job search is going and whether he's found something new; acknowledge continued progress with public speaking/presentations if it comes up again.
