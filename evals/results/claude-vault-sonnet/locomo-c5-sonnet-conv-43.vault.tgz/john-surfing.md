---
name: john-surfing
description: John surfs as a hobby and connects it to feelings of freedom/nature
metadata:
  type: project
---

John has been surfing for about 5 years (as of 2023-07-16) and describes it as his connection to nature and a source of freedom, similar to how Tim uses fantasy reading as an escape. He loves the ocean and had a memorable summer surfing with friends.

**Why:** Came up in a catch-up chat with Tim on 2023-07-16 when discussing what makes each of them feel free/happy.

**How to apply:** Worth referencing alongside [[tim-interests]] when the two compare their respective "escape" hobbies, or when John shares more surf trips.
