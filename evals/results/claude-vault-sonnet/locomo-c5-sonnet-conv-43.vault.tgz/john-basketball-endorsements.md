---
name: john-basketball-endorsements
description: John plays competitive basketball and is pursuing brand endorsement deals
metadata:
  type: project
---

John plays basketball at a competitive level (shared a photo of himself playing in a game, June 2023) and is excited about it. As of 2023-07-16 his endorsement pursuits have progressed: he signed a deal with Nike (shoe and gear), is in talks with Gatorade about sponsorship, and still hopes to land Under Armour. He scored a career-high 40 points in a game the week before 2023-07-16 and celebrated a tough team win afterward. He has an upcoming game in Seattle in ~August 2023 (a city he loves for its energy, food, and fan support).

As of 2023-08-09, John had another intense game (shared a photo from a large arena) that his team won by a tight score, with John scoring the winning basket. He speaks strongly about his team feeling like family — mutual motivation/support on and off the court is a recurring theme for him.

As of 2023-08-11, John shared his basketball origin story: watched NBA games with his dad as a kid, joined a local league at age 10, played through middle and high school, earned a college scholarship, then got drafted by a team ("dream come true"). His career goals are winning a championship and giving back off the court — he's teaming up with a local organization that helps disadvantaged kids through sports and school, aiming to use his platform for community impact. He also has a pair of "lucky basketball shoes" he's kept since early in his journey, which he treats as a meaningful symbol of resilience and determination (marked up with stories from wins and losses along the way). Separately, he took a trip to Chicago and loved the city's energy and friendly locals.

As of 2023-08-17, John reunited with his teammates on 2023-08-15 after a trip (likely the Chicago trip) and described a warm, "electric" welcome back. His teammates gave him a basketball signed by the team as a symbol of their friendship/bond, which he keeps as a reminder of why he started playing and as motivation to stay strong.

As of 2023-08-21, John found a new gym (with a basketball court, used for drills) to stay in shape for pro ball. He had to adapt his routine to it but worked out a schedule balancing basketball practice with strength training, using a written workout plan and listening to his body for rest. He credits strength training with improving his shooting accuracy, agility, speed, and confidence on the court.

As of 2023-08-26, John shared a photo of his high school team (described as a girls' basketball team) while reminiscing about it — he and this squad were teammates for four years in high school.

As of 2023-09-21, John had been out to a restaurant the prior week with new teammates and bonded with them over their shared love of basketball, calling them "great friends." The team is planning a trip next month (~October 2023) to explore a new city, destination still undecided — Tim suggested Edinburgh, Scotland (see [[john-family-travel]]) and John was receptive to the idea. John reiterated his on-court goals (better shooting, being a consistent performer) and said he's now actively evaluating endorsement offers, wanting to be selective; Tim advised picking endorsements that align with his values/brand and feel authentic to his followers. He again mentioned wanting to build a meaningful legacy after basketball, including possibly starting a foundation for charity work.

As of 2023-10-02, John shared he's a big fan of the Minnesota Timberwolves ("the Wolves") and admires LeBron James specifically for his work ethic/leadership — he's met LeBron a few times ("real chill") and seen him play live, which he found motivating. Separately, he mentioned collecting basketball jerseys as a hobby (shared a photo of several laid out on his bed).

As of 2023-10-13, John wrapped a season with both tough losses and great wins, driven by facing tough opponents and strong team support ("we back each other up and won't quit"). He shared a photo holding a trophy in front of a crowd and said he felt elated that the hard work paid off. He also mentioned needing new shoes after all the games; Tim recommended a pair of running shoes he'd bought online.

As of 2023-11-06, John recounted a game from "last year" where his team was trailing big in the 4th quarter and dug deep to overturn the deficit, calling the buzzer moment unforgettable. He also referenced the 2016 Finals chase-down block by LeBron on Iguodala as a favorite basketball moment (Tim brought it up; John confirmed/added detail).

As of 2023-11-16, John has a leg injury (shared a photo of a bandaged leg) that's made for "a tough week," though he's staying positive. The doctor said it's not too serious. He expressed frustration at not being able to be on the court while recovering.

As of 2023-11-21, John (still recovering, per above) reflected on a separate past injury — he hurt his ankle "last season," requiring time off and physical therapy; he leaned on patience/perseverance to get through it. He also shared a story about messing up during a big game, which taught him the importance of resilience and owning mistakes to keep growing as a player/teammate.

As of 2023-12-06, John confirmed he's been playing professionally for "just under a year now," calling it a wild ride — growth on-court (overall game improving) and off it (endorsement deals, learning to market himself/build his brand). He shared another trophy photo (sitting on the ground with it) and, when Tim asked how he motivates teammates, listed: showing care for teammates, celebrating their achievements, giving constructive feedback, reminding them of the bigger goal, fostering a positive environment, and giving pep talks before games.

As of 2023-12-08, John's team played a tough game against a top team and fought hard to get the win. He said the best part was the camaraderie built both on and off the court, and reiterated (per his season-recovery/mentoring themes above) that team dinners and outings — the moments away from practice — are what really build and strengthen unity.

As of 2023-12-11, John had a career-high in assists in a big game against a rival team the prior Friday, describing an electric arena atmosphere and pride in creating opportunities for teammates. He also reiterated his favorite career moment: a buzzer-beater shot to win after being down 10 in the 4th quarter (see 2023-11-06 entry above).

As of 2023-12-16, John shared a trophy photo from a close win the prior week ("battle" that came down to the final buzzer). He also opened up about a foot injury (cast) that had sidelined him from games — likely the same injury referenced in the 2023-11-16/11-21 entries, now in recovery. He's been doing daily physical therapy, and on 2023-12-15 (last Friday) hit a milestone: jogging pain-free for the first time since the injury. He and his wife hosted a small get-together with friends and family to celebrate.

As of 2023-12-19, John said the team had a strong scrimmage the prior week and has been putting in a lot of work; he singled out communication and bonding as the areas of most growth, crediting it with helping teammates understand each other's strengths/weaknesses and improving performance.

As of 2024-01-12, John landed a new endorsement deal with a popular beverage company (shared a photo of himself holding a bat next to a soda), calling it a "dream come true." He described the feeling as less about the signing itself and more about validation that his training hours paid off.

**Why:** Came up in a catch-up chat with Tim; John was clearly excited and wanted to share updates.

**How to apply:** Worth following up on the Gatorade deal outcome, the Seattle game, whether Under Armour comes through, the progress of his charity partnership with disadvantaged kids, which endorsements he ends up choosing, where the team trip lands (Edinburgh was suggested), and how the new beverage-brand endorsement plays out.
