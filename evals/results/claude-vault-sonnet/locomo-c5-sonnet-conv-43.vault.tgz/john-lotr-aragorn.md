---
name: john-lotr-aragorn
description: John's love of LOTR and Aragorn specifically as a personal-leadership inspiration
metadata:
  type: project
---

As of 2024-01-02, John named Aragorn as his favorite Lord of the Rings character, admiring his growth from ranger to king and his brave, selfless, down-to-earth attitude and commitment to justice. John keeps a painting of Aragorn in his room as a reminder to stay true to himself and lead in everything he does. This builds on Tim naming LOTR as his own favorite fantasy franchise (see [[tim-interests]]) — a shared fandom between the two.

**Why:** Came up in a catch-up chat with Tim discussing favorite fantasy movies/characters.

**How to apply:** Reference if John or Tim discuss LOTR, favorite characters, or leadership inspirations — this is a fandom they clearly share and enjoy discussing together.
