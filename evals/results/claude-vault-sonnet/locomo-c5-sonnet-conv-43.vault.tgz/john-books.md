---
name: john-books
description: John's reading interests/bookshelf, distinct from Tim's fantasy-lit focus
metadata:
  type: project
---

As of 2023-09-21, John shared a photo of his bookshelf with Tim. He owns and loved "The Alchemist" by Paulo Coelho, saying it made him reflect on life and the importance of following one's dreams. Tim recommended Patrick Rothfuss's fantasy novel (see [[tim-interests]]) as good travel reading for John's upcoming team trip.

As of 2023-11-11, John finished an "amazing" fantasy series with lots of twists and strong characters/storylines — shows he enjoys getting lost in fantasy worlds too, not just reflective reads like "The Alchemist." He and Tim both said they'd watched/liked a fantasy show referred to as "That" (see [[tim-interests]]), which they described as a favorite escape from reality.

As of 2023-11-21, John confirmed non-fiction personal development/mindset books are his preferred genre outside fantasy — says they help him know himself better. He mentioned rereading "The Alchemist," which reinspired him to keep chasing his dreams and trust the process.

As of 2023-12-08, John is currently reading "Dune" by Frank Herbert, which he highly recommends — noted it's about religion and human control over ecology (a sci-fi pick, broadening beyond his stated fantasy/non-fiction personal-dev preferences). He hasn't read any GRRM/Game of Thrones books but said he'd check them out after Tim recommended the series.

**Why:** New topic in a catch-up chat with Tim — first time John's own reading habits/collection came up (previously only Tim's reading/fantasy-lit interest was tracked).

**How to apply:** Reference if John or Tim discuss books again — John enjoys reflective reads like "The Alchemist" as well as fantasy (a genre overlap with Tim), and is open to Tim's recommendations.
