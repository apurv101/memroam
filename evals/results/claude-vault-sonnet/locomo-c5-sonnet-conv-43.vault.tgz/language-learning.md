---
name: language-learning
description: Tim (German) and John (Spanish/German) both learning languages, share a language app
metadata:
  type: project
---

As of 2024-01-02, Tim is learning German — finds it tough but fun, and likes its structure better than the French he took in high school. John knows some German already plus Spanish, and just started learning Spanish more seriously (citing personal/professional opportunities as motivation). Both use the same phone app to practice, though the app's name wasn't specified.

**Why:** Came up in a catch-up chat between Tim and John, prompted by Tim mentioning he'd started German lessons.

**How to apply:** Follow up on Tim's German progress and John's Spanish progress in future chats — a shared hobby they can compare notes on.
