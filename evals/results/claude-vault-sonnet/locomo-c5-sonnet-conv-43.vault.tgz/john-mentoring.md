---
name: john-mentoring
description: John is mentoring younger players on his team during the off-season
metadata:
  type: project
---

As of 2023-10-17, John is mentoring younger players on his team, something he described as super rewarding and a way to stay involved in the game during the off-season. He finds it challenging at times (everyone is different, requires adapting his approach) but rewarding to motivate/encourage them and watch them develop. Some of the players see him as a mentor, which he says feels great — he tries to be a positive role model both on and off the court. He shared a photo of himself with some of the younger players at a recent practice.

As of 2023-12-26, John has started doing seminars helping people with sports and marketing (shared a photo of himself on a convention stage) — described the "aspiring profs" attending as eager and motivated, and said he's happy to share his knowledge. A new, more public extension of his mentoring beyond just his own team (see also his charity/youth-sports work in [[john-charity-youth-sports]]).

**Why:** Came up in a catch-up chat with Tim; a new facet of John's basketball life (see [[john-basketball-endorsements]]) beyond playing/endorsements.

**How to apply:** Worth following up on how the mentoring relationships develop and whether it continues into next season.
