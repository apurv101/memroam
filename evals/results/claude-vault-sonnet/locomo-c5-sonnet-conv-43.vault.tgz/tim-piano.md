---
name: tim-piano
description: Tim is learning to play piano; favorite piece is the Harry Potter theme
metadata:
  type: project
---

As of 2023-08-21, Tim started learning to play the piano, describing it as a satisfying learning curve. His favorite piece to play is the theme from "Harry Potter and the Philosopher's Stone," which ties into his broader HP fandom (see [[tim-interests]]) and family movie-watching memories.

As of 2023-12-06, Tim shared a photo of a violin and said he's now learning violin, mostly into classical music but keen to try jazz and film scores too — he described it as a way to relax and get creative. Note: in the same message exchange John asked "how long have you been playing the piano again?" and Tim answered "about four months," which lines up with the piano start date above rather than a new violin timeline — likely he's continuing piano and picking up violin as a second instrument, but this wasn't stated explicitly, so it's worth clarifying which instrument(s) he's actively playing next time it comes up.

**Why:** Came up in a catch-up chat with John; a new hobby alongside his existing fantasy/reading interests.

**How to apply:** Worth asking about piano/violin progress or other songs he's learning next time he comes up in conversation.
