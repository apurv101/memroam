---
name: tim-study-habits
description: Tim's Pomodoro-style study technique for exam prep
metadata:
  type: project
---

As of 2023-11-16, during a busy exam week, Tim described his study technique: breaking study sessions into 25-minute focused blocks followed by 5-minute breaks for something fun (a Pomodoro-style approach). He finds it makes studying feel less overwhelming and keeps him on track. This came up when John asked how Tim stays motivated during difficult study sessions (see [[john-motivation-support]] for John's own technique, visualization).

**Why:** Came up in a catch-up chat with John about exam prep and staying motivated.

**How to apply:** Could follow up on how exams went, or reference this technique if study/productivity comes up again.

As of 2023-12-01, Tim followed up: he had a tough exam the prior week that shook his confidence, but pushed through by studying hard, and framed the experience as proof of his own resilience and determination (shared a photo of his notes as his "success"). Fits his recurring "never give up" theme (see [[tim-interests]], LeBron chase-down block story).
