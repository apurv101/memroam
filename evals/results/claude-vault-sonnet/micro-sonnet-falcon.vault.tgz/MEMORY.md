# falcon — memory index

- [project-falcon-overview](project-falcon-overview.md) — Project Falcon (internal API rewrite) codename, stack, team, and deploy cadence
