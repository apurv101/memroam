---
id: 01a04df8-202f-73f0-93f4-e97b37002028
name: project-falcon-overview
description: Project Falcon (internal API rewrite) codename, stack, team, and deploy cadence
metadata:
  type: project
---

Project Falcon is the internal codename for an internal API rewrite, kicked off 2026-03-02. Use "Falcon" in docs.

- Stack: Postgres 16 (migrated off Postgres 15, completed by 2026-05-21).
- Deploys happen Wednesday mornings (moved from Friday afternoons as of 2026-05-21, due to weekend incidents from Friday deploys).
- Team: Dana owns the billing service (covering for Marco, who is on parental leave starting the week of 2026-04-13, expected through end of 2026); the user owns the gateway.
- Budget: $40k for contractors this half (H1/H2 2026, as of 2026-03-02).
- Perf target: 200ms p95 latency on the search endpoint, committed 2026-04-10 as a perf-review action item. Currently measured against staging, not prod.
- Staging cluster lives in eu-west-1.

**Why:** Established at project kickoff to set shared context for planning and scheduling work; updated 2026-04-10 with perf-review commitment and a team ownership change; updated 2026-05-21 with Postgres 16 migration completion and deploy-day change.
**How to apply:** Refer to this project as "Falcon" in any generated docs. Schedule risky changes for Wednesday mornings (not Friday — that caused weekend incidents). Route billing-service questions toward Dana while Marco is out; resume routing to Marco once he's back (check before assuming date). Route gateway questions toward the user. When discussing search latency, benchmark against staging (eu-west-1) unless told otherwise, and flag against the 200ms p95 target. Database is Postgres 16, not 15.
