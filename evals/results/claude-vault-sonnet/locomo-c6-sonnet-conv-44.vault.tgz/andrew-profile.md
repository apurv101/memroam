---
name: andrew-profile
description: Personal facts about Andrew — job, interests, hiking habits
metadata:
  type: user
---

Andrew started a new job as a Financial Analyst around 2023-03-20 (mentioned as "last week" on 2023-03-27), a change from his previous job.

He has no pets currently but loves animals, especially birds — eagles are his favorite for their strength and grace. He hasn't gone dedicated bird-watching but spots birds while hiking.

He hikes Fox Hollow trail on weekends and recommended it to Audrey for its views. As of 2023-05-03 he'd been feeling down about not getting outside enough, but found a new open hiking space near him and now escapes the city at least once a weekend as a much-needed break. He enjoys photographing nature (mountains, sunsets) and likes sharing those calming moments with others.

As of 2023-04-02 he's actively trying to get a dog but is struggling to find a dog-friendly apartment in the city; Audrey suggested using apartment-search websites with pet-friendly filters. He misses hiking with his family's dog (not his own) and hopes to find his own apartment and dog soon.

As of 2023-05-06, still searching for a dog to adopt — browsing adoption sites, visiting shelters, and asking friends for leads. He's now specifically looking for pet-friendly housing near a park or woods so the dog has open space to run. He advises that apartment dwellers should pick a smaller/lower-energy breed unless they're active enough to handle a dog that needs a lot of exercise.

He has a girlfriend; as of 2023-04-16 they enjoy exploring new cafes and restaurants around the city together to unwind after the week. He still feels the pull of nature over city life and misses the peacefulness of hiking.

As of 2023-05-11 he'd been hiking regularly at the new spot he found, including a trip with his girlfriend and friends the prior weekend (2023-05-06 weekend).

As of 2023-06-02 he's still searching for a pet-friendly apartment with no luck yet — feeling discouraged but determined not to give up. Audrey offered to help him search if he emails her his criteria.

As of 2023-06-13 he took a rock climbing class with friends the prior Sunday (2023-06-11) and made it to the top for the first time — a big confidence boost. He's now hooked and wants to try more outdoor activities weekly, mentioning interest in kayaking and possibly bungee jumping next. He agreed to join Audrey for a dog walk at a new park spot she found.

As of 2023-06-26 he'd hiked with friends the prior Friday (2023-06-23) and enjoyed being outdoors again, but says he's been missing that connection with nature and its calming effect lately and wants to explore more. He shared a photo from a doggy daycare near him with a large indoor play space (still no dog of his own as of this date, per earlier apartment search struggles) and offered to help Audrey find more dog-friendly places.

As of 2023-07-03 still hasn't found a dog-friendly rental. Since he can't hike as much, he's picked up cooking as a new hobby and is enjoying trying new recipes — says it helps him de-stress, be creative, and is becoming one of his favorite hobbies (a self-described "rookie" still experimenting). Audrey shared her Chicken Pot Pie and Mediterranean Roasted Chicken recipes with him to try.

Had a picnic with his girlfriend on 2023-07-07, which he described as amazing. Still hasn't gotten a dog (as of 2023-07-08), still citing difficulty finding pet-friendly housing and the right dog. He's found a few leash-only parks but wants somewhere with open space for a dog to run. Planned a hike with [[audrey-profile]] and her dogs for "next month" (~August 2023) and shared a trail map for it.

As of 2023-07-11 he finally got a puppy — named Toby — ending his long apartment/dog search. He's thrilled about the new addition despite the demands of city living. Work has been piling up lately, keeping him stuck inside and missing hiking/nature; he confirmed the hiking trip with [[audrey-profile]] and her dogs for next month, now planned as a first meeting between Toby and her dogs.

On 2023-07-24 (Monday) he and his girlfriend volunteered at a pet/animal shelter — described it as a hugely rewarding experience that reaffirmed his deep love for animals.

As of 2023-08-04 confirmed Toby is a German Shepherd. He and his girlfriend planned a camping trip for the weekend of 2023-08-05/06. He also went on a hike (shared trail photos) and mentioned taking Toby out for hikes at the local trail, hoping to build the same close bond with Toby that [[audrey-profile]] has with her dogs.

As of 2023-08-16 he and his girlfriend visited a farm to pick up fresh vegetables for dinner, which he described as really nice.

As of 2023-08-19 he took a break from work to check out a new cafe and shared a sunset/mountain/church hike photo. He's interested in learning dog grooming for Toby but hasn't had time; [[audrey-profile]] shared tips (go slow and gentle, pay attention to sensitive areas like ears/paws, stay patient and positive). He planned a weekend trip to a nature reserve to reconnect with nature.

As of 2023-08-24 he mentioned going fishing with his girlfriend the prior weekend (~2023-08-19/20) at a nearby lake — caught a few fish and had a great time; this is his first mentioned fishing trip. He shared a photo of Toby sleeping in a dog bed and another of Toby sitting with a leash, saying he hopes to build as strong a bond with Toby as [[audrey-profile]] has with her dogs. He declined her offer of dog-care tips for now, wanting to figure things out with Toby on his own first; she reminded him bonding takes time and not to rush it.

As of 2023-09-06 work has been tough and stressful, pushing outdoor activities to the backseat and making work/life balance hard. He's coping with small daily self-care habits — a morning coffee and a lunchtime walk — to recharge. He went on a hike over the prior weekend (~2023-09-02/03) and shared a mountain sunset photo. Notably, when Audrey asked whether he'd found a dog-friendly place to live, he said he's still working on it and finding it challenging — despite having gotten Toby back in 2023-07-11, so he may be looking to move to better/more dog-friendly housing now that he has Toby, or this may just be an inconsistency in his story.

As of 2023-09-24 he's taking care of flowers on his balcony (new gardening interest) and asked [[audrey-profile]] for advice on building a strong bond with Toby; she suggested patience and regular training. He remains focused on wanting the kind of close bond with Toby that Audrey has with her dogs.

As of 2023-10-01 he shared a beach sunset photo, excited for a beach trip "next month" (~November 2023) with his girlfriend and Toby. He offered to give [[audrey-profile]] birdwatching advice/tips and to join her on a birdwatching trip, saying he knows a fair bit about it; plans to bring binoculars and a notebook to log sightings. He also reads books about ecological systems/ecosystems and reiterated caring for nature for future generations. He suggested biking as a way to reduce carbon footprint and offered to show Audrey good bike routes near the river.

As of 2023-10-04 he shared a beach photo from a past trip (said he hasn't been to the beach in a while) after [[audrey-profile]] mentioned taking her dogs there. He reiterated missing the outdoors/hiking, saying it's hard to find open space in the city and harder to make time with his current work/life balance — described feeling "a void in his heart" without nature. She suggested houseplants or weekend park visits; he said he'd look into getting more plants for his house.

As of 2023-10-13 he had a board game night with his girlfriend and Toby (shared a photo of Toby posed at a chess set); also mentioned a separate Friday board game session with a group. Weekend plans: a cozy cafe and a newly-opened spot with a view that isn't dog-friendly, so he suggested getting coffee and meeting [[audrey-profile]] and her dogs at a nearby dog park instead. Shared a funny story of Toby chasing a squirrel up a tree at the dog park; confirmed again Toby is a German Shepherd who loves wearing sweaters.

As of 2023-10-19 he adopted a second dog from a shelter, named Buddy — Toby is still adjusting to sharing the home with him. He and Buddy already enjoy walks and hiking new trails together; he plans to bring Toby and Buddy hiking together soon, including on the hike planned with [[audrey-profile]] and her dogs "next month" (~November 2023). He shared photos of a rural dirt-road/trail area far from the city that he wished he could take the dogs to more often.

As of 2023-10-24 he went wine tasting with his girlfriend the prior weekend (~2023-10-21/22), trying many unique wines and enjoying it as a reminder to step outside his comfort zone. He also tried sushi for the first time recently at a new spot in town and loved it; [[audrey-profile]] recommended he start with a California or salmon roll and try different sauces/dips.

As of 2023-10-28 he and [[audrey-profile]] set the date for their planned dog hike (previously "next month") for that coming Saturday at a trail near a lake; he's going on a picnic date with his girlfriend the following Sunday. He shared hiking photos including one of himself walking a single dog on a leash on a dog-friendly trail near him.

As of 2023-11-04 (a Saturday — the date set on 2023-10-28 for their planned dog hike, which goes unmentioned in this conversation, another apparent continuity gap) he shared a photo of himself and his girlfriend biking, having found a new park outside the city over the weekend. Seeing [[audrey-profile]]'s pups made him consider getting a third dog, but she advised him to focus on Toby and Buddy first; he agreed that's the right call for now.

As of 2023-11-22 he adopted a third dog anyway — named Scout, for their "adventurous spirit" — despite having agreed on 2023-11-04 to hold off and focus on Toby and Buddy first (another continuity inconsistency in his story). He and his girlfriend bought essentials for Scout (bed, toys, puppy pads) and are keeping Scout leashed while they adjust to being outside. Plans to take Scout, Toby, and Buddy together to a small nearby park for their first outing; [[audrey-profile]] advised starting small, keeping Scout leashed, and introducing Scout to Toby and Buddy gradually.
