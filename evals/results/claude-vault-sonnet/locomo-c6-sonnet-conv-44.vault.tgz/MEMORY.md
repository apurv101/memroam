# Memory index — conv-44

- [Andrew profile](andrew-profile.md) — Financial Analyst, loves birds/eagles, hikes weekly (Fox Hollow + new spot); got a puppy named Toby (Jul 2023) after long apartment/dog search
- [Audrey profile](audrey-profile.md) — has 4 dogs (Pepper, Precious, Panda, Pixie), city dog adventures, dog booties, dog park playdates
