---
name: audrey-profile
description: Personal facts about Audrey — pets, hiking interests
metadata:
  type: user
---

Audrey has four dogs — Pepper, Precious, Panda, and a new puppy Pixie adopted around 2023-04-02. Pixie took a few days to bond with the other dogs (especially Pepper) but is now close with them all. They're city dogs and she takes them on frequent outdoor adventures to parks and trails.

She's interested in hiking spots and was planning to try Fox Hollow trail (recommended by [[andrew-profile]]).

She found her dog-friendly home using apartment-search websites with pet-friendly filters, and recommended this approach to Andrew when he asked (2023-04-02).

She has a tattoo of a dog and sunflowers on her arm, gotten to represent her bond with her dogs and love of nature. She also enjoys baking pastries (e.g. blueberry muffins).

For dog safety on walks she uses protective dog booties/shoes on her dogs. She regularly plays fetch/frisbee with them and takes them to a dog park near their usual walking park for playdates with other dogs (as of 2023-05-03).

She takes her dogs on road trips roughly once every couple of months (e.g. a national park trip around 2023-05-05) as a way for them to explore and stay active.

As of 2023-06-02 she mentioned an off-leash trip to a local dog park (2023-06-01) and a separate hiking trip to a national park (around 2023-05-26) that included a scenic peak at sunset — she finds these outdoor outings central to her happiness and often shares photos of them.

As of 2023-05-11 she signed up for a positive-reinforcement pet-bonding workshop (found via a flyer at her local pet store) happening the following month. She's firmly against punishment-based training, believing positive reinforcement is the only proper way to train pets, and plans to share tips from the workshop with Andrew for when he gets his own dog.

As of 2023-06-13 she found a new dog-walking spot — a small park with a tree-lined trail — and invited Andrew to join her and the dogs there; he agreed. She typically walks the dogs for about an hour, letting them explore at their own pace.

As of 2023-06-26 she moved into a new house with a bigger backyard for the dogs (a change from the dog-friendly home she'd found earlier via apartment-search filters). She's been unpacking boxes since the move and set up a dedicated doggy play area in the backyard with agility equipment and toys, which the dogs love. She also recalled a favorite memory of hiking to a mountain lake with friends a few years back and sitting by it to enjoy the peacefulness.

Her four dogs are mutts: two Jack Russell mixes and two Chihuahua mixes, all around 3 years old (as of 2023-07-03); they love running and playing fetch. As of 2023-07-03 she's taking a dog training course (challenging but rewarding — the dogs are already doing better), likely a continuation of/related to the positive-reinforcement workshop she signed up for in May. They had a doggy playdate on 2023-06-30 that was "a bit crazy but still lots of fun."

She loves cooking as a creative outlet/de-stressor — pours a glass of wine and puts on music while cooking. Her go-to ingredient is garlic. Favorite recipes: Chicken Pot Pie (a family recipe passed down, reminds her of her grandma's kitchen) and a Mediterranean-style Roasted Chicken with garlic, lemon, and herbs — both of which she shared with Andrew on 2023-07-03.

As of 2023-07-08 agreed to join [[andrew-profile]] on a hike "next month" (~August 2023) so her dogs can run off-leash; he sent a trail map. She also referenced hiking a scenic trail with a lake/mountain sunset view about a 3-hour drive away "last year" (~2022).

As of 2023-07-11 she makes personalized engraved wooden keychains/tags for her dogs herself, wanting each one to feel special and reflect its personality — another example of her strong focus on showing her pets love and care.

Her childhood dog was named Max — energetic, loved playing fetch, and was her walking companion/confidant growing up; she shared these as some of her favorite memories (as of 2023-07-27). Her current four dogs each have distinct personalities she described by age order: the oldest is calm/relaxed ("wise old sage"), the second is always up for a game, the third can be naughty but loves cuddles, and the youngest is lively and adventurous.

As of 2023-08-04 she started formal agility classes with her dogs at a dog park (building on the backyard agility setup from 2023-06-26), practicing twice a week — she finds it a great bonding experience and a good physical/mental workout for them.

As of 2023-08-16 she got a second tattoo — of all four dogs — on her arm (in addition to the earlier dog-and-sunflowers tattoo), so they're "with her wherever she goes." She took all four dogs to the vet together for checkups around this time and found it chaotic; next time she'll bring them one at a time. Each dog has a favorite relaxing spot: Pepper on the couch, Pixie curled up in her own bed, Precious in her chair, Panda on his rug.

As of 2023-08-19 she learned dog grooming by taking a dog grooming course and now grooms her dogs herself, saying it's made her feel closer to them. Her tips: groom slowly and gently, pay attention to sensitive areas like ears and paws, and stay patient and positive throughout. Weekend plan: taking the dogs for a stroll in the park.

As of 2023-08-24 she said she's never been fishing (in response to [[andrew-profile]]'s fishing trip) — for her it's always been about relaxing lakeside instead, and she shared a photo of her dogs on a rock near a lake and recalled a favorite memory of sitting by a mountain lake with friends years back, enjoying the stillness and birdsong. She reiterated her grooming routine (daily brushing, regular baths, nail trims, lots of love) and told Andrew that bonding with Toby takes time and shouldn't be rushed.

As of 2023-09-06 she organized a doggy playdate with the neighbors' dogs and shared a photo of dogs playing in a fenced area, saying seeing them happy made her heart feel full. She also recently bought new dog beds for her dogs as the weather started cooling, and shared a photo of one dog curled up cozily on a bed in her living room — she described it as bringing them a lot of comfort and happiness.

On 2023-09-22 (Friday) at the park, one of her dogs (Precious) pulled so hard on her leash that it broke, and Precious took off — Audrey chased her down and caught her before anything bad happened, and had to calm her afterward with petting, hugging, and calm talk. She mentioned the incident to Andrew on 2023-09-24, framing it as a reminder of how much her dogs mean to her and the importance of care/vigilance during walks. Her bonding advice to Andrew: build trust through patience and regular training, give time and love, and praise successes; their training work includes obedience and tricks (sit, stay, shake, roll over), and they walk multiple times a day. She also has a small home garden — a vegetable patch in progress and Peruvian Lily flowers (bright/colorful, low-maintenance — just needs water and sun).

As of 2023-10-01 she took the dogs to a nearby dog park the prior Saturday (2023-09-30) with a big grassy area and shaded spots. She's picking up birdwatching as a new hobby — bought a bird guide book and binoculars — and took [[andrew-profile]] up on his offer of birdwatching tips/a joint trip, planning to check her schedule. She usually takes public transport but is open to trying biking to reduce her carbon footprint, and asked Andrew for good bike routes near the river; they're also planning a hike together with the dogs "next month" (~November 2023).

As of 2023-10-04 she took the dogs to the beach over the prior weekend (~2023-09-30/10-01) and said they had a blast swimming in the ocean. When [[andrew-profile]] mentioned missing the outdoors due to work/city life, she suggested getting houseplants or taking weekend park trips as ways to feel closer to nature in the city, and offered further plant advice if he wants it.

As of 2023-10-06 she shared a photo of two of her dogs running in a field with a ball, taken after she'd recovered from a knee injury that had previously kept her from walking them — she described being unable to walk them as tough since they bring her so much joy. She also makes jewelry from recycled materials (bottle caps, buttons, broken jewelry) as a creative/sustainability hobby, sells pieces, and donates a portion of profits to an animal shelter — a way to combine her love of jewelry-making with supporting a cause. She noted she can no longer volunteer at the shelter in person, so donating is now her way of still contributing.

As of 2023-10-13 she baked cookies for her neighbors to thank them for being pup-friendly. She noted her dogs dislike snow — took them to a snowy park last winter and they were confused/unhappy, so they prefer sunny grass days. She went back to the tattoo parlor to add more drawings/detail to her existing four-dogs tattoo, and said she's done for now unless she gets another dog someday, in which case she'd add another tattoo.

As of 2023-10-19, after [[andrew-profile]] shared photos of a rural spot far from the city, she said she'd research and try to find an equally nice location for their planned hike together "next month" (~November 2023), now involving her dogs plus his two dogs (Toby and his newly adopted second dog, Buddy).

As of 2023-10-24 she had an accident playing with her dogs at the park the prior week (~2023-10-17/18) and is now wearing a cast on her arm; taking care of her four dogs one-handed has been tricky but manageable. She's a sushi fan and gave [[andrew-profile]] beginner tips when he tried it for the first time: start with a California or salmon roll, and mix up sauces/dips to make it tastier.

As of 2023-10-28 her dogs had been acting abnormally, so she took them to an animal behaviorist appointment the prior Wednesday (2023-10-25); got tips and is using positive reinforcement techniques, with the dogs showing early progress. She and [[andrew-profile]] firmed up plans for their hike (previously vague "next month") for that coming Saturday, at a trail near a lake; also discussed a second future trip to an autumn/yellow-trees trail. Note: in this conversation she describes her dogs' breeds as Pepper and Panda being Lab mixes and Precious and Pixie being Chihuahua mixes — inconsistent with the 2023-07-03 entry describing them as two Jack Russell mixes and two Chihuahua mixes; likely a continuity error in her story (see similar note on [[andrew-profile]]).

As of 2023-11-04 she recently joined a dog owners group, meeting up weekly for tips from other owners and playtime for the dogs. When Andrew mentioned considering a third dog, she advised him to focus on making Toby and Buddy happy and healthy first rather than expanding further. Her tips for keeping dogs mentally stimulated in the city: puzzles, training, and hide-and-seek at home, plus toys/games and regular fetch outings.

As of 2023-11-22 she took her four dogs to a pet salon the prior Friday (~2023-11-17) — they were excited beforehand and took a while to calm down afterward, but behaved well and came out looking cute and freshly groomed. She reacted to [[andrew-profile]]'s news of adopting a third dog (Scout) by congratulating him and giving advice: keep the new dog leashed at first, start with small outings, and slowly introduce Scout to Toby and Buddy.
