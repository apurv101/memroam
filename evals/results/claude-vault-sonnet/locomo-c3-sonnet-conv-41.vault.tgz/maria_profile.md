---
name: maria-profile
description: Profile info about Maria — hobbies and volunteer work from conversation with John
metadata:
  type: user
---

Maria volunteers at a homeless shelter and recently started aerial yoga as a fitness activity.
Donated her old car to the homeless shelter she volunteers at (2022-12-21).
Has a small family; prioritizes quality time with friends — movies, hiking, and game nights.
Enjoys nature/beach photography as a way to slow down (e.g., a sunset photo taken at the beach in Dec 2022).
Friends with [[john-profile]], who is pursuing local politics focused on education and infrastructure.
As of 2023-01-09, became friends with a fellow volunteer at the organization she volunteers with.
Started volunteering because her aunt believed in it and used to help Maria's family when they were struggling — her aunt is the source of her inspiration.
As of 2023-01-28, volunteered at a shelter event for kids; a standout moment was comforting an 8-year-old girl with no other family who was sitting alone.
As of 2023-02-05, did a charity event (2023-02-03) serving meals to homeless individuals; met a man named David there and connected him with a local organization providing housing/support.
As of 2023-02-05, offered to help [[john-profile]] with networking and volunteering at his food drive events.
As of 2023-02-25, took a creative writing class, which she found very enlightening. While volunteering, met a woman named Jean who had been through divorce, job loss, and homelessness, yet remained optimistic and grateful — Maria found her resilience inspiring.
As of 2023-03-06, her grandmother passed away the week prior (~2023-02-27); she's trying to stay positive but finding it hard.
As of 2023-03-06, made a painting of a castle on a hill, inspired by a trip to London a few years ago where she was mesmerized by the architecture/castles; keeps it at home as a reminder of that trip.
As of 2023-04-02, taking a poetry class to help process/express her feelings, describing recent times as "a rough ride."
As of 2023-04-07, ran a 5K charity run for a homeless shelter; found the shared sense of energy/unity rewarding and reaffirming of her passion for charity work.
As of 2023-04-10, gave talks at the homeless shelter she volunteers at, well-received by fellow volunteers; bought a cross necklace to feel closer to her faith. Also helped organize/prepare a communal meal for shelter residents the prior week (~2023-04-03), which she found heartwarming.
As of 2023-05-04, took a solo trip to Spain in 2022, where she tried surfing for the first time; found it taught her the value of not giving up, valuing different perspectives, the power of solitude, and letting go/trusting life. Maintains life balance via exercise, music, and time with loved ones; enjoys a banana split sundae as a treat after volunteering.
- As of 2023-05-06, joined a nearby church the day before (2023-05-05) to feel closer to community and faith; finding it great so far. Also mentioned life's been a bit rough lately, taking time to reflect and find balance. Offered to help [[john-profile]] with his renewed infrastructure/community project push.
- As of 2023-05-20, agreed to help [[john-profile]] with his new veterans support project. Is currently planning a ring-toss tournament as a fundraiser for the homeless shelter she volunteers at, happening later that month (~May 2023).
- As of 2023-06-03, recently started volunteering once a month at a local dog shelter; offered to help [[john-profile]] and family, who are grieving the loss of their dog Max and considering adopting a rescue dog.
- As of 2023-06-12, went camping the prior weekend (~2023-06-10) with friends from church to take her mind off things. Recalled a family road trip to Oregon from her youth, with a waterfall-and-bridge hike as the most memorable/magical spot. Favorite aerial yoga poses are inversions ("upside-down poses") for the feeling of freedom; also finds peace through alone time with music.
- As of 2023-06-16, joined a gym the prior week (~2023-06-09); enjoying the workout routine and finds the people/atmosphere welcoming and motivating. Current fitness goals: build strength and improve endurance; also trying kundalini yoga. Recalled a family vacation in Florida (sunset photo) that gave her a strong feeling of gratitude.
- As of 2023-06-27, going through a rough/hard time but staying positive by leaning on family and friends for support; describes them as "her rock," giving encouragement and reminding her she's not alone. While volunteering at the shelter, had a standout moment playing with kids: one child who'd been sad for months suddenly laughed — she found it deeply uplifting.
- As of 2023-07-03, was in a car accident (another driver ran a red light); everyone okay. Helping her cousin find a new place after she had to leave her previous home in a hurry — stressful but making progress; [[john-profile]] offered to help find housing resources. Received a heartfelt thank-you letter from a shelter resident named Laura, which she found inspiring/reaffirming of why she volunteers.
- As of 2023-07-05, cites chatting with people, volunteering, and listening to music as her main sources of inspiration. Recently started taking regular "me-time" walks at a nearby park, which has made a big positive impact.
- As of 2023-07-07, agreed to join a community meeting [[john-profile]] is organizing to discuss solutions after his old area (West County) was hit by a flood that ruined homes due to poor infrastructure.
- As of 2023-07-17, had a picnic with friends from church the prior weekend (~2023-07-09); played charades and a scavenger hunt.
- As of 2023-07-22, went hiking with church friends the prior weekend (~2023-07-15); wanted to make connections, laugh, and enjoy nature. Reaching the summit and taking in the breathtaking view gave her a sense of peace and feeling part of something greater. Plans to explore more and volunteer at shelters the following month (~August 2023). Enjoys baking cakes.
- As of 2023-07-31, dropped off baked goods at the homeless shelter the prior week; felt great and more motivated than ever to help people. Encouraged [[john-profile]]'s new fire brigade volunteering.
- As of 2023-08-03, clarified she started volunteering at the homeless shelter about a year prior (~mid-2022) after witnessing a family struggling on the streets, which prompted her to reach out and offer to help. Shared a heartfelt thank-you note from a shelter resident named Cindy.
- As of 2023-08-05, did community work with friends from church the day before (~2023-08-04), which she found super rewarding. Supportive of [[john-profile]] through his job loss and pivot toward a tech-industry hardware role.
- As of 2023-08-09, received a medal from the homeless shelter the prior week for her volunteering; found the recognition humbling. Congratulated [[john-profile]] on his 5K charity run for veterans.
- As of 2023-08-11, got a puppy about two weeks prior (~late July 2023), a white dog named Coco; described as adorable and joyful, greets her when she comes home. Supportive listener when [[john-profile]] opened up about feeling stuck/lacking impact, suggesting he channel his energy into volunteering/local organizations.
- As of 2023-08-13, adopted a second dog from a shelter the week prior (~2023-08-06), a black puppy named Shadow, full of energy; gets along great with Coco (see 2023-08-11 note). Learning commands and house training. Clarified she had no pets growing up.
- As of 2023-08-16, volunteered at the front desk of the shelter the prior Friday (~2023-08-11); found it fulfilling to see the smiles on people's faces when they received food or a bed. Congratulated [[john-profile]] on his fire brigade's donation drive and new fire truck (see his 2023-08-16 note).

