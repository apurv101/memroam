# Memory index — conv-41

- [John's profile](john_profile.md) — goals in local politics (education/infrastructure), kickboxing hobby
- [Maria's profile](maria_profile.md) — volunteers at homeless shelter, does aerial yoga
