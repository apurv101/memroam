---
name: deborah-profile
description: Biographical facts about Deborah from conversation with Jolene
metadata:
  type: user
---

Deborah is a yoga teacher who is passionate about supporting her community. Yoga helped her find peace during a rough period in her life, which is what inspired her to teach it and share that peace with others; one of her ongoing goals is to keep teaching yoga and supporting her community.

Her mother passed away a few years ago. Deborah has a pendant that reminds her of her mother. Her mother's old house had a bench/window seat where her mother loved to sit each night to read (reading and travel were her mother's favorite hobbies); Deborah still visits and sits there sometimes to feel connected to her mother. She recently (week of 2023-01-16) revisited her mother's old house.

Her father passed away suddenly around 2023-01-25 (shared this on 2023-01-27); the sudden loss left the family shell-shocked. She's coping by spending time with family and looking through old photo albums, including one from her parents' 1993 wedding. She is married and says love and openness are what she and her husband value in their relationship, modeled on her parents' marriage. She's part of a yoga group whose members sent her a thank-you letter for her positive influence. On 2023-02-01 she met her new neighbor Anna at yoga in the park; they bonded over how yoga has improved their lives and the sense of community it brings. On 2023-02-03 she and Anna practiced dance/yoga poses together (e.g. a modified seated Warrior II), which brought them closer; Anna also wears a pendant in memory of her own mother, which resonates with Deborah's own pendant. A friend once gave Deborah a bouquet of flowers when she was struggling, which still gives her hope and courage. Her favorite nature spots are a park with a calming forest trail and a nearby beach.

She lost a close friend named Karlie the week of 2023-02-13 (shared 2023-02-22); she's coping by spending time in a garden of roses and dahlias, which she finds calming and nostalgic. Her last photo with Karlie was from a motorcycle/hiking trip last summer (2022), which still makes her smile. She traveled to Bali last year (2022), a highlight trip for her, and did yoga on the beach there.

Daily routine (as of 2023-02-25): mornings are meditation, yoga, and teaching classes; evenings are spent with loved ones. She went for her first morning jog in a nearby park on 2023-02-24 and plans to add jogging to her regular routine — exercise makes her feel connected to her body.

Her neighbor/friend Anna made her a vegan tofu stir-fry with ginger and soy sauce (shared 2023-03-02), which she enjoyed.

She hosted a yoga class for her neighbors (Friday, shared 2023-03-13) and shared a group photo of the attendees; it felt great to watch neighbors embrace it and to build community connections through teaching.

Uses the Eisenhower Matrix (sorting tasks by urgency/importance) as her go-to method for staying organized when overloaded; shared it with Jolene on 2023-03-22. Recently (shared 2023-03-22) sat by the sea at sunset with Anna talking and reflecting on how they inspire each other.

As of 2023-03-28 she bought new props for her yoga class and a candle to enhance the atmosphere of her own practice. She likes scents like lavender and rosemary and enjoys instrumental tracks with mellow melodies during yoga (favorite track: "Savana"; also listens to the album "Sleep" for meditation/deep relaxation).

Went biking with her neighbor the week of 2023-04-02, which she found freeing and beautiful. On 2023-04-09 she visited an art show with a friend; it reminded her of her mother, who was passionate about art and believed it could evoke strong emotions and uniquely connect people — attending art shows now feels like a way of still experiencing that with her mother, bittersweet but comforting.

On 2023-06-06 she shared a photo of her favorite yoga studio (a room with a bench and window), describing it as always calming. She gave Jolene advice on calming the mind during yoga: practice mindful breathing daily — sit a few minutes with eyes closed, take deep breaths, focus on the sensation of air entering/leaving the body.

As of 2023-06-26 she's preparing for an upcoming yoga retreat with friends, looking forward to connecting with like-minded people and finding peace; the retreat location has a statue that's a symbol of peace and enlightenment, ideal for reflecting and getting centered. She practiced two new poses around this time: Dancer Pose (Natarajasana) on a beach, and Tree Pose in a group setting near the statue.

As of 2023-07-09 she started a running group with her neighbor/friend Anna; she finds it motivating to have people who push and support each other during runs. She reiterated that her workshops/events (yoga, meditation, self-reflection) aim to cultivate self-awareness and mental/emotional well-being. She has two cats (not dogs — she says she doesn't like dogs) and walks them in the park every morning and evening.

As of 2023-08-01 she started a new community cleanup project and has been fundraising for it; she's been moved by seeing the community come together to support it.

As of 2023-08-12 she made a meditation guide for her yoga retreat (the retreat she'd been preparing for since 2023-06-26).

As of 2023-08-16 she shared that she led a meditation yoga session for the elderly at a local care home during sunset the prior week (~2023-08-09). She got into mindfulness through workshops and books, and it's now a huge part of her life; she offered to help Jolene get started with her own mindfulness practice.

As of 2023-08-19 she mentioned organizing a yoga event "last month" (~July 2023) — reached out to nearby businesses/places to make it happen; the event included yoga, food stalls, and live music, and she found it rewarding to see everyone come together. She and her husband like to play detective games together, and also enjoy spending time outdoors exploring nature. She reiterated her favorite nature spot is a park with a forest trail and a beach where she does yoga and reflects; she described a "special bench" there that holds meaning for her and her mom — they used to sit there to chat about dreams and life, and she recalls watching a beautiful sunset together in silence. (Note: this park bench appears distinct from the bench/window seat at her mother's old house mentioned earlier — she may have more than one bench with sentimental meaning tied to her mother, or these could refer to the same memory told two different ways.)

As of 2023-08-21 she revisited the special bench where she and her mother used to chat, and brought flowers there; it brought a mix of nostalgia, longing, and gratitude. Her mother loved flowers and appreciated simple things in life by taking things slow, seeing beauty, and finding joy — a mindset Deborah tries to emulate. Her calming habits include yoga, meditation, and mindful walks (she often takes nature/sunset photos on these walks).

As of 2023-08-24 she attended the yoga retreat near her mom's place the prior week (~2023-08-17) that she'd been preparing for since 2023-06-26; called it life-changing, saying it let her connect with nature and get to know herself.

As of 2023-08-26 she named her two cats: Max (8 years old) is her mother's cat, which she took in when her mother passed away; Luna (5 years old) she adopted from a shelter.

As of 2023-08-30 she mentioned visiting her mom's house again "last month" (~July 2023) — it holds a special place in her heart as a symbol of her mother's strength and the love shared there; she relaxed outside and it brought back fond memories (shared a photo of her husband standing in front of the house). Her favorite spot to reflect and let go is a lake with a few trees growing in the water — she likes it for the soothing vibes and views. She traveled to Rio de Janeiro three years ago (~2020) and visited a large stone temple/structure with a mountain backdrop. She has a note/letter from a close friend (male) who has since died ("will never be able to support me... I miss him" — distinct from her friend Karlie, who died in Feb 2023) with the handwritten quote "Let go of what no longer serves you," which she keeps as a keepsake.

As of 2023-09-03 she attended a community meetup the prior Friday (~2023-09-01), sharing stories and feeling connected — reinforced how important relationships are to her. She shared a photo of a woman on a yoga mat with two children, from when she first started doing yoga; her mom was her biggest fan and would often come to her classes with her. She describes her yoga group/friends as her "second family."

As of 2023-09-08 a storm forced her to cancel a planned yoga getaway; she was initially bummed but felt better after finding comfort in her work and time at home, which reminded her to be grateful for little things. She and Jolene arranged a coffee date after some back-and-forth rescheduling, landing on Friday (~2023-09-15) at 5pm at a cafe with fresh pastries — Jolene needs to sort books from her bookcase first.

As of 2023-09-12 she recently played an unnamed card game about cats, where players draw cards one by one from a deck and can attack opponents with them (likely "Exploding Kittens," though she didn't recall the name); she plans to play it with Jolene.

As of 2023-09-15 she reconnected with her mother's old friends; hearing their stories about her mom was emotional (a mix of happiness and sadness, since she learned things about her mom she hadn't heard before) but ultimately comforting. She spent time with them reminiscing and looking through her mom's old photos, including an old selfie of her and her mom in pajamas — gave her a deeper appreciation of her mom's life beyond what she already knew. She also shared that the beach she does yoga at (her favorite nature spot, previously mentioned) is where she got married and where she discovered her love of surfing.

As of 2023-09-17 she and her neighbor (likely Anna) ran a free community gardening class the day before (~2023-09-16), open to all ages — she found it awesome to share her love of plants and help people connect with nature/each other. She shared that her mother had a big passion for cooking and made meals full of love and warmth that filled the house; a favorite specific memory is her mom baking her pineapple birthday cakes as a kid, which always made her feel special. She confirmed she has surfed before (consistent with her 2023-09-15 note that she discovered her love of surfing at the beach where she got married) and proposed trying surfing together with Jolene, tentatively planned for next month (~October 2023), pending Jolene checking her schedule.

As of 2023-09-20 she attended a music festival recently with friends — found it freeing to dance and felt it helped show/share feelings; it reminded her of her mother's soothing voice singing her lullabies as a child.

**Why:** Personal/emotional context shared directly by Deborah — useful for continuity in future conversations with her.
**How to apply:** Reference these details naturally if Deborah brings up her mother, yoga, or grief again; avoid re-asking things she's already shared.
