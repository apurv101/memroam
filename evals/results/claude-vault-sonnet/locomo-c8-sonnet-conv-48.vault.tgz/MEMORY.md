# Memory index — conv-48

- [Deborah's profile](deborah-profile.md) — yoga teacher, mother & (2023-01-25) father passed away, pendant/window-seat memories, married
- [Jolene's profile](jolene-profile.md) — electrical engineer, mother passed away 2022, pendant from Paris 2010, pet snakes, partner, signed up for meditation retreat (2023-09-06)
