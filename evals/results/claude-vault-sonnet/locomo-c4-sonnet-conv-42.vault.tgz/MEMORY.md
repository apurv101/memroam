# Memory index — conv-42

- [Nate's interests](nate-interests.md) — gaming (won CS:GO tournament ~2022-01-14), action/sci-fi movies, dairy-free dessert cooking
- [Joanna's interests](joanna-interests.md) — writing/reading/nature, dramas & romcoms, screenplay submitted to a film festival (2022-02-07)
