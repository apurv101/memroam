---
name: james-witcher-game-project
description: James collaborated with a gaming friend to build a Witcher 3-inspired virtual world/character as a programming project (mid-April 2022)
metadata:
  type: user
---

Around 2022-04-14 (last Thursday relative to the 2022-04-20 chat), James worked with a friend from his gaming circle to combine programming and gaming, building a virtual world inspired by The Witcher 3. He designed a game character (a woman in armor) and shared a screenshot of her. He said the character's look was inspired by a woman he glimpsed on a walk with his dogs about two weeks earlier and found striking, though he never approached her.

Update (2022-05-04, referencing "last Friday" 2022-04-29): James hit a bug that broke the game mechanics and couldn't solve it alone despite hours of debugging — frustrating setback. He teamed up with a group of gaming friends and they fixed it together. He values having a reliable team that shares his passions and contributes ideas.

Update (2022-05-23): James described finishing a big project he'd worked on "for months," which required learning a new language and handling many details — likely this same project reaching completion. He called it a personal milestone and said he feels more confident tackling bigger projects now.

**How to apply:** Good rapport topic tying into [[john-gaming-interest]] — ask how the virtual world project is progressing or if he's added more to it. Can also ask about the bug/fix or the friend group that helped, since teamwork on this project is now a positive story for James. As of 2022-05-23 he considers it finished — worth asking what he wants to build next.
