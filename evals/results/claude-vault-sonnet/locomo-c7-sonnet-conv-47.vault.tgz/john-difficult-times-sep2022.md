---
name: john-difficult-times-sep2022
description: John mentioned going through difficult times as of 2022-09-01, without specifics; James offered support
metadata:
  type: user
---

On 2022-09-01, John told James he's "going through some difficult times now" and appreciates having James's support, without giving specifics. James responded by offering to listen/vent. Unclear if related to the earlier [[john-stress-transition-new-job]] (job-start stress from 2022-07-09) or something new.

**How to apply:** Sensitive topic — check in gently on how he's doing before assuming it's resolved; avoid probing for details he hasn't offered.
