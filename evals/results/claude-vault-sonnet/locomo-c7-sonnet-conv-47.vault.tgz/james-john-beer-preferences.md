---
name: james-john-beer-preferences
description: John dislikes dark beer/stout and prefers light beer; came up planning a pub meetup, Aug 2022
metadata:
  type: user
---

While planning a meetup for 2022-08-27, James suggested McGee's Pub for its stout, but John doesn't like dark beer. They agreed on McGee's since it also serves light beers. Complements [[james-and-john-pizza-preferences]] as a food/drink rapport note.

**How to apply:** Avoid suggesting dark beer/stout for John; light beer or other options are safer picks for future pub meetups.
