---
name: james-strategy-gaming-and-books
description: James's gaming (Civilization VI, strategy games) and fantasy book interests, as of April 2022
metadata:
  type: user
---

As of 2022-04-29, James had been playing Civilization VI (a turn-based strategy game — resource management, army building, territory conquest) for about a month (since ~2022-03-29), calling it a good challenge for problem-solving and strategic thinking. This complements his existing interest in [[james-witcher-game-project]].

James is also into the fantasy book genre — three days prior (2022-04-26) he bought an adventure/fantasy novel with illustrated art he liked. John recommended he read "The Name of the Wind" (fantasy trilogy), which James hadn't heard of but was interested to check out.

As of 2022-08-26, James said he's been trying out different game genres and now wants to create his own strategy game in the style of Civilization, drawn to how complex and in-depth the genre is. Still an aspiration, not a started project — distinct from his completed [[james-witcher-game-project]] and ongoing [[james-football-simulator-course]].

**How to apply:** Good rapport topics: ask how Civ VI is going, whether he's started "The Name of the Wind," or how the strategy-game idea is coming along.
