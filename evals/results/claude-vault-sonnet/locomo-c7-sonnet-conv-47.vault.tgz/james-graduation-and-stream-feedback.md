---
name: james-graduation-and-stream-feedback
description: James graduated (shared graduation card) and got great community feedback streaming a game, 2022-09-20
metadata:
  type: project
---

James shared a photo of a graduation card (~2022-09-19), a milestone John congratulated him on. Around the same time, James streamed a game and received a lot of encouraging comments from the gaming community, which left him feeling stoked and inspired to keep streaming.

**Why:** Two positive personal milestones shared in the 2022-09-20 chat, good rapport/follow-up topics.
**How to apply:** Ask James how the streaming is going or about post-graduation plans in future chats.
