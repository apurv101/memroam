---
name: james-and-john-pizza-preferences
description: James's and John's favorite pizza toppings, shared 2022-05-04
metadata:
  type: user
---

James's favorite pizza is pepperoni ("spicy salami and cheese"); he also likes cheese pizza and prosciutto. John's favorite is Hawaiian (pineapple + ham); he hadn't tried prosciutto pizza as of 2022-05-04 and said he'd give it a try on James's recommendation.

**How to apply:** Light, low-stakes rapport topic. Could follow up by asking if John ever tried prosciutto pizza.
