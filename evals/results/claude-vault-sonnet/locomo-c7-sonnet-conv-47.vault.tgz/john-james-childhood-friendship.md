---
name: john-james-childhood-friendship
description: John and James have been friends since childhood (~age 10), bonded over skateboarding; shared history mentioned 2022-07-22
metadata:
  type: user
---

John and James have known each other since at least age 10 — on 2022-07-22, John shared an old elementary-school photo of a friend group with a skateboard. Both were into skateboarding as kids, sometimes skipping class to go to the skate park, and James still rides sometimes as an adult (he's even taught his dogs to balance on a skateboard). This establishes their friendship as long-running (childhood friends), not one that started in adulthood.

**How to apply:** Useful context for the depth/duration of their relationship — safe to reference shared childhood history or skateboarding as a nostalgic rapport topic.
