---
name: john-board-game-collab-project
description: John collaborated with a game developer on an online board game, revealed 2022-11-07, demo coming soon
metadata:
  type: project
---

John spent a weekend working with a game developer to create an online board game (described as "fun and unique"), first mentioned 2022-11-07. A demo is about to be released for public feedback. James expressed interest in trying the demo and giving feedback once it's out; John said he'd let James know when it launches.

**Why:** New collaborative project, distinct from John's earlier solo mobile game (see [[john-mobile-game-launch]]) — continues John's pattern of game-dev side projects alongside his day job/non-profit interests ([[john-game-dev-nonprofit-mentor-gig]]).
**How to apply:** Follow up on the board game demo's release and James's promised feedback in future chats.
