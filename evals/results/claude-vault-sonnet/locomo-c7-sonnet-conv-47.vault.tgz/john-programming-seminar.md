---
name: john-programming-seminar
description: John organized a programming seminar, ~2022-10-14, good turnout, learned new techniques, offered to share resources with James
metadata:
  type: project
---

John organized a programming seminar about a week before 2022-10-21 (~2022-10-14). It had a great turnout and he gained insight into various programming approaches/techniques from other developers, finding ideas he wants to incorporate into his own work (not yet tried as of 2022-10-21). He offered to send James resources/tutorials on the new techniques he learned.

**Why:** Shows continued involvement in the programming community beyond his day job/mobile game work (see [[john-mobile-game-launch]], [[john-game-dev-nonprofit-mentor-gig]]).
**How to apply:** Good follow-up topic — ask James/John whether he tried the new techniques, or whether James checked out the resources John sent.
