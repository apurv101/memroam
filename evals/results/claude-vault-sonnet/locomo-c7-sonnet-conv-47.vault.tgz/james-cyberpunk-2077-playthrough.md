---
name: james-cyberpunk-2077-playthrough
description: James started playing Cyberpunk 2077 (2022-10-20); John advised dialogue choices are life-changing, no need to befriend every character
metadata:
  type: project
---

James started playing Cyberpunk 2077 the day before 2022-10-21 (~2022-10-20) and finds it addictive. John, who's already played it, warned that the hardest part is making the right choices — even dialogue lines can send the story in unexpected/life-changing directions — and advised James he doesn't need to befriend every character. John kept this spoiler-free.

**Why:** New shared gaming topic alongside James's other gaming activity (see [[james-nintendo-childhood-gaming-origin]], [[james-first-game-release]]).
**How to apply:** Good follow-up — ask how James's Cyberpunk playthrough/choices are going.
