---
name: james-notebook-habit
description: James started keeping a notebook to track everything he needs to do, mentioned 2022-09-18
metadata:
  type: user
---

As of 2022-09-18, James said he's had a lot going on and started writing everything he needs to do in a notebook so he doesn't forget things.

**How to apply:** Minor personal-organization detail; useful context if James later references being busy or juggling tasks.
