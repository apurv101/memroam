---
name: john-game-dev-nonprofit-mentor-gig
description: John accepted a volunteer programming-mentor role at a game dev non-profit, 2022-10-03 — merges his gaming and non-profit career interests
metadata:
  type: project
---

As of 2022-10-03, John received and accepted an email offer for a volunteer gig at a game development non-profit, working as a programming mentor: teaching coding to game developers and assisting with their projects. He's very excited, calling it a possible start to a career combining gaming and helping others.

**Why:** This is the concrete convergence of two threads James should track: John's pull toward non-profit/volunteer work ([[john-charity-volunteer-project]]) and his gaming-career ambitions ([[john-gaming-tournament-organizer-ambition]], [[john-new-game-genres]]). Unlike the earlier CS:GO/Fortnite tournament-organizer idea, this is a mentoring role that also draws on his coding skills, and it's an actual accepted gig rather than an aspiration.

**How to apply:** Good rapport topic going forward — ask how the mentoring is going, who he's working with, and whether it's shifting his sense of career direction (especially relative to his day job, see [[john-dream-job]], and his tournament-organizing ambition).
