---
name: james-dream-inspiration
description: James draws creative ideas from books/movies/dreams; a vivid dream (early-mid Sep 2022) about a medieval castle labyrinth inspired sketches/notes
metadata:
  type: user
---

As of 2022-09-18, James said he draws creative ideas from various sources — books, movies, and dreams. A few weeks prior he had a vivid dream about a medieval castle with its own labyrinth full of puzzles and traps, which felt like "playing a video game in real life." He made sketches and notes from it.

**How to apply:** Ties into his creative/gaming interests ([[james-witcher-game-project]], [[james-unity-strategy-game]]) — worth asking whether the castle-labyrinth idea turns into an actual project.
