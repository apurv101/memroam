---
name: john-coding-blog
description: John started a blog about his coding journey, mid-June 2022
metadata:
  type: user
---

As of 2022-06-16, John started a blog documenting his coding journey — he described it as exciting but a little scary, and values it as a way to track his progress and connect with other coders. This follows his course work ([[john-new-course-friends]]), freelance project ([[john-freelance-project]]), and new job offer ([[john-dream-job]]).

**How to apply:** Good rapport topic — ask how the blog is going, what he's been posting about, or whether it's helped him connect with other coders.
