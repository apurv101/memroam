---
name: john-partner-jill
description: John's partner is named Jill, first mentioned 2022-07-22
metadata:
  type: user
---

John has a partner named Jill (first mentioned 2022-07-22, when James brought her a souvenir from his trip). No other details about Jill known yet.

**How to apply:** Safe to reference Jill by name in future conversation with John (e.g., asking how she's doing) as a rapport-building detail.
