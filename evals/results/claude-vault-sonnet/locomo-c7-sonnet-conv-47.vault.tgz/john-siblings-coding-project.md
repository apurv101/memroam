---
name: john-siblings-coding-project
description: John is teaching his younger siblings to code by building a text-based adventure game together, as of Aug 2022
metadata:
  type: project
---

As of 2022-08-26, John shared he's been helping his younger siblings learn programming since they joined a programming course. They're working together on a simple text-based adventure game as a teaching project — John is proud of their progress and jokes they might design their own video games someday. This is distinct from the periodic [[john-family-gaming-night]] tradition, and separate from his earlier one-off return to a coding community ([[john-programming-group]]).

Update (2022-09-01): John reports the siblings are starting small — basic games and stories — and picking it up fast. He's excited to see how far they go and hopes their shared love of video games (his and theirs) will carry into more ambitious coding projects.

Update (2022-09-04): John's teaching has extended to his parents too — as of this date he's also helping them learn to code, which he says brings the family closer. Shared a photo of his father coding his own program for the first time.

**How to apply:** Good rapport follow-up — ask how the siblings' coding/game project is progressing, and also how teaching his parents to code is going.
