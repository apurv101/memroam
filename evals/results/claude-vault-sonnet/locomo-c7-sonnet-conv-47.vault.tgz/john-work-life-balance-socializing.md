---
name: john-work-life-balance-socializing
description: John values balancing work and enjoyment; hosted friends for a movie day on a day off (2022-05-04)
metadata:
  type: user
---

On his day off (2022-05-04), John had friends over to watch movies, saying he's "trying to socialize more" and it's been going great. He explicitly said he thinks it's important to balance work and enjoyment, and invited James to join next time. Not confirmed whether these are the same three friends from [[john-new-course-friends]].

**How to apply:** Positive rapport topic — shows John is intentionally prioritizing social time alongside work/coding projects. Safe to ask about future hangouts or whether James ever joined.
