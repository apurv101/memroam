---
name: james-extreme-sports
description: James got into extreme sports (rope jumping, surfing) around early July 2022
metadata:
  type: user
---

As of 2022-07-09, James said he's become interested in extreme sports. He went rope jumping the day before (2022-07-08), jumping from 150 meters, and went surfing a few days before that (2022-07-06), which he said relaxes him despite being an intense activity. Contrasts with his usual de-stressing via hiking with dogs ([[james-hiking-with-dogs]]) and reading.

**How to apply:** New personality thread — ask if he keeps up with extreme sports, how the surfing/rope jumping went.
