---
name: james-first-game-release
description: James released his first game to the gaming community, inspired by The Witcher 3, announced 2022-10-13
metadata:
  type: user
---

As of 2022-10-13, James announced he made and released his first game for the gaming community, calling it exciting and fulfilling to watch players engage with the world he built. He again cited The Witcher 3 as his main inspiration (echoing the earlier [[james-witcher-game-project]] from Apr 2022 and [[james-unity-strategy-game]] finished 2022-09-01) — this release is likely one of those projects reaching public launch, though it's unclear which. He said the effort paid off and he's now planning to build more games in different genres and try new ideas.

**How to apply:** Good rapport topic tying into [[john-gaming-interest]] and [[john-mobile-game-launch]] (John's own game was launching around the same time, Oct 2022) — the two are now peers releasing games in parallel. Worth asking which project this was (Unity strategy game vs. something new), where it's published, and what genre he's eyeing next.
