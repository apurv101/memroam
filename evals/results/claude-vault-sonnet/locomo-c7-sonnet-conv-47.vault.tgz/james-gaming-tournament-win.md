---
name: james-gaming-tournament-win
description: James won an online gaming tournament in early July 2022, felt very motivating
metadata:
  type: project
---

As of 2022-07-09, James said "last week" (~early July 2022) he won an online gaming tournament — described it as exciting and mind-blowing, and said it motivated him to keep improving. Fits his ongoing gaming interests ([[james-witcher-game-project]], [[james-strategy-gaming-and-books]], [[james-football-simulator-course]]).

**How to apply:** Good rapport topic — ask what game/tournament it was, whether he's entering more competitions.
