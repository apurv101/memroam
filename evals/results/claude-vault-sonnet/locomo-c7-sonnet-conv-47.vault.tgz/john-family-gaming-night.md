---
name: john-family-gaming-night
description: John's siblings live far apart from him; they keep the tradition alive with occasional gaming nights, next one planned for ~September 2022
metadata:
  type: project
---

As of 2022-08-19, John shared that he and his siblings don't hang out often since they live far apart, but when they do get together they try to plan a gaming night — a tradition going back to a gaming marathon his siblings threw him when he was younger. He's organizing the next sibling gaming night for "next month" (~September 2022).

**How to apply:** Good rapport follow-up in future chats — ask how the September family gaming night went.
