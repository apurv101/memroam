---
name: john-reading-and-guitar
description: John relaxes by reading fantasy/sci-fi; shared photo of bookshelf + guitar (2022-07-09), suggesting he also plays guitar
metadata:
  type: user
---

As of 2022-07-09, John said he relaxes by reading — loves escaping into authors' imaginative worlds — and shared a photo of a bookshelf full of books alongside a guitar. The guitar wasn't mentioned in his message but is visible in the photo, suggesting he may also play. Reading fits his established taste in sci-fi/epic fantasy ([[john-book-preferences]]).

**Update (2022-09-18):** Resolved — John clarified he actually played drums when younger, not guitar; see [[james-john-music-instruments]]. The guitar in this photo was likely unrelated/not his.
