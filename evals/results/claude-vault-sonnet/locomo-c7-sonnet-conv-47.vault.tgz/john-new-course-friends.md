---
name: john-new-course-friends
description: John made three new friends in his programming course around mid-April 2022
metadata:
  type: user
---

Around 2022-04-19 (last Tuesday relative to the 2022-04-20 chat), John met three new people in his programming course who share his interests, and was happy about growing his social circle.

**How to apply:** Safe, positive rapport topic — can ask how things are going with his new programming course friends.
