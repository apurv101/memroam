---
name: john-board-games
description: John got into board games, enjoyed his first session ("Dungeons of the Dragon") in the week before 2022-09-18
metadata:
  type: user
---

As of 2022-09-18, John mentioned he's started getting into board games — tried one for the first time the week prior and had a lot of fun. The game was "Dungeons of the Dragon," which he described as very exciting.

**How to apply:** New rapport topic distinct from his usual coding/gaming ([[john-new-game-genres]]); ask if he's played more board games or found a regular group for it.
