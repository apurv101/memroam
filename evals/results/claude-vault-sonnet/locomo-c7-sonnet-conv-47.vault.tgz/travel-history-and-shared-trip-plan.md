---
name: travel-history-and-shared-trip-plan
description: James and John's travel history (Italy/Turkey/Mexico vs Japan) and their plan as of April 2022 to travel together next year
metadata:
  type: project
---

As of 2022-04-20: James has traveled to Italy (2021), Turkey, and Mexico. John's most recent trip was to Japan, and he was impressed by the tech-heavy megacities and street food. Both agreed they'd like to travel together in 2023, and James said he'd start researching a destination for the two of them.

Update 2022-07-09: James booked flights to Toronto, leaving 2022-07-11 (evening) and returning 2022-07-20. He also plans to visit Vancouver and possibly other places. This is Canada, James's 4th country visited. He promised to bring John a souvenir.

Update 2022-07-22: James confirmed the trip went well and mentioned Nuuk (Greenland) specifically as a new country added to his list — unclear if this was part of the same Canada trip or separate, but it brings his visited-country count up further. He brought back souvenirs for both John and [[john-partner-jill]].

**How to apply:** Follow up on whether James found a destination for the 2023 joint trip. Also ask about the Canada trip after 2022-07-20 — how Toronto/Vancouver were, whether he visited anywhere else, and about the souvenir. Can also ask about the Nuuk/Greenland leg specifically.
