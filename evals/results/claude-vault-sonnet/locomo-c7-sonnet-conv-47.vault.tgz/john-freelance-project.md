---
name: john-freelance-project
description: John started freelance programming in April 2022 to hone skills — first professional project is a website for a local small business
metadata:
  type: project
---

As of 2022-04-29, John took on freelance programming work to sharpen his skills, separate from his class/course work ([[john-new-course-friends]], [[john-work-stress-coding-project]]). His first professional project outside of class is building a website for a local small business. Progress has been slow with hiccups; one specific challenge was implementing payments on the site, which took him a while and required outside resources to figure out. James encouraged him to push through the hiccups.

**How to apply:** Good follow-up topic — ask how the small-business website launch went, whether the payment integration got resolved, and how freelancing compares to his course work.
