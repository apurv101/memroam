---
name: john-charity-volunteer-project
description: John built a free inventory/donation-tracking app for a children's charity, May 2022; now considering non-profit career path
metadata:
  type: project
---

As of 2022-05-11, John volunteered his programming skills to build a smartphone app for a charitable foundation (helps kids), replacing their paper-based inventory records. The app tracks inventory, resources, and donations, and generates reports for analysis.

**Why:** He was inspired by the foundation's mission and wanted to combine coding practice with doing good; it gave him a strong sense of purpose.

**How to apply:** This experience is shifting John toward considering volunteer work or a career in the non-profit sector — he hasn't picked a specific organization yet. Relevant context for future conversations about his career direction or further volunteer/charity coding projects. Related: [[john-freelance-project]], [[john-work-stress-coding-project]].

Update (2022-06-19): John got his dream job offer 2022-06-13 (starting ~mid-July, see [[john-dream-job]]), but in this session he's still separately drawn toward non-profit work "in the future" and asked James to take him to the organization James volunteers with (provides necessary items to people in need) that same weekend (2022-06-25/26). James said no interview is needed, just being friendly/polite and wanting to help. Note the tension: John has a demanding new job starting mid-July but is also pursuing a volunteering visit — worth asking how he's balancing both.
