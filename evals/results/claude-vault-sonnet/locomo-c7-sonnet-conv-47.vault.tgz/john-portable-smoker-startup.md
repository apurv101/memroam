---
name: john-portable-smoker-startup
description: John started a new startup making portable smokers, welded his first one, 2022-09-20
metadata:
  type: project
---

John started a new startup making portable smokers on 2022-09-19/20. He's already welded a first metal unit himself and shared a photo of it (fire burning in a metal pot on a street) for James's feedback.

**Why:** New venture mentioned alongside other major life updates in the same chat (James's graduation, John's mobile game launch).
**How to apply:** Can ask John for updates on how the portable smoker startup is progressing in future chats.
