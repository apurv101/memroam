---
name: james-nintendo-childhood-gaming-origin
description: James's first gaming system was a Nintendo console (Mario/Zelda) that sparked his passion for gaming
metadata:
  type: user
---

James's first gaming system was a Nintendo console (played with Mario game/controller) — he played Super Mario and The Legend of Zelda for hours as a kid, which sparked his lifelong passion for gaming. Shared a childhood photo of himself playing on it, 2022-10-21. Prompted by seeing an old photo of his mother's army friend and the friend's own gaming setup from that era (see [[james-mother-army-friend-visit]]).

**Why:** Origin story for James's gaming identity, useful context given his many ongoing gaming projects/hobbies (see [[james-witcher-game-project]], [[james-unity-strategy-game]], [[james-first-game-release]], [[james-gaming-group-and-setup]]).
**How to apply:** Background color for conversations about James's gaming history/nostalgia.
