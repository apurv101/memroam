---
name: james-john-football-rivalry
description: Friendly rivalry — James is a die-hard Liverpool fan, John supports Manchester City; they bet on next season's final standings
metadata:
  type: user
---

As of 2022-06-13, discussing a Liverpool vs Chelsea match revealed James is an avid Liverpool supporter ("no club better than Liverpool," never misses a match) while John supports Manchester City. They made a friendly bet over who'll finish higher in the league table next season (2022-23).

**How to apply:** Fun, low-stakes rapport/banter topic — bring up the Liverpool/Man City rivalry and the standings bet, especially once the 2022-23 season is underway or concluded.
