---
name: john-stress-transition-new-job
description: John feeling stressed/overwhelmed balancing personal and professional life as his new job start approaches (2022-07-09)
metadata:
  type: user
---

As of 2022-07-09, John described feeling "the tug of emotion lately" — determined and passionate on one hand, overwhelmed and stressed on the other — struggling to balance personal and professional life. This is shortly before his dream job start date (~mid-July 2022, see [[john-dream-job]]), so likely tied to that transition.

**How to apply:** Sensitive topic — check in on how he's coping and how the job transition is going; good opening for support rather than just excitement.
