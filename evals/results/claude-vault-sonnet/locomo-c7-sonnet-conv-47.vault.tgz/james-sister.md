---
name: james-sister
description: James has a sister; they're close and travel/spend time together, first mentioned 2022-07-22
metadata:
  type: user
---

James has a sister he's close with. On 2022-07-22 he shared a photo of her with his dogs (see [[james-adopted-dog-ned]]) captioned as "chilling together," and mentioned she joined him on part of his recent trip — they watched a sunset near the ocean together. James described the bond with his sister and dogs as feeling "like a family."

**How to apply:** Safe, positive rapport topic — can ask James about his sister or their trip together.
