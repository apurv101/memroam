---
name: john-new-game-genres
description: John branched out from shooters into strategy/RPG games (playing The Witcher 3) as of 2022-08-10, and is thinking about running competitions for these genres too
metadata:
  type: project
---

As of 2022-08-10, John has been trying strategy and RPG games instead of his usual shooters, at James's encouragement from an earlier conversation. He's currently hooked on "The Witcher 3," praising its storytelling, characters, and the impact of in-game choices on the world. He's already thinking about organizing competitions for these new genres too.

**Why:** Extends both [[john-gaming-interest]] (previously shooter-focused, e.g. CS:GO) and [[john-gaming-tournament-organizer-ambition]] (2022-08-06 ambition to organize CS:GO/Fortnite tournaments) — the genre-branching and tournament ambition are now merging into one interest.

**How to apply:** Good rapport topic — ask how far he's gotten in The Witcher 3, which choices he's made, or whether he's found other strategy/RPG titles. Could also ask whether he's scoping out RPG/strategy tournament formats alongside his CS:GO/Fortnite plans.
