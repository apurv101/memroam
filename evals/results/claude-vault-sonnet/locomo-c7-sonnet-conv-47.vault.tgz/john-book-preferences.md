---
name: john-book-preferences
description: John's favorite book genres/series — sci-fi and epic fantasy, as of June 2022
metadata:
  type: user
---

As of 2022-06-16, John's bookcase was nearly full from recent book purchases. He favors sci-fi and epic fantasy with immersive world-building — his favorites are "The Stormlight Archive" and "The Kingkiller Chronicle" (fantasy), and "The Expanse" (sci-fi). He values books that create a magical/escapist world with characters that feel real.

This pairs with [[james-strategy-gaming-and-books]], where John had earlier recommended James "The Name of the Wind" — consistent with John's fantasy taste here.

**How to apply:** Good rapport topic — ask if James has started any of these series, or ask John how his reading is going / what's newest on the shelf.
