---
name: james-road-trip-family-dogs
description: James started a family road trip with his dogs on 2022-11-04, exploring new places/nature
metadata:
  type: user
---

James started a road trip with his family and dogs on Friday 2022-11-04 (mentioned "yesterday" in a 2022-11-05 chat). He enjoyed spending time with family, exploring new places, and taking in nature with the dogs.

Update (2022-11-07): On the trip, James's family visited his friends Josh and Mark, and stopped at an animal sanctuary with rescue dogs. James was tempted to adopt more but held off since he already has three dogs at home (see [[james-adopted-dog-ned]]).

**How to apply:** Positive, recurring rapport topic — fits James's established pattern of using nature/outdoor time with his dogs to de-stress (see [[james-hiking-with-dogs]]). Safe to ask how the road trip went, where they traveled, and how the dogs enjoyed it. Josh and Mark are established friends of James's worth remembering as recurring names.
