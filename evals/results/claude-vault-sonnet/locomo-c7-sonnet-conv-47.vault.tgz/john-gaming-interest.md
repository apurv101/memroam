---
name: john-gaming-interest
description: John is an avid gamer who uses gaming to de-stress; games/genres played 2022-04 through 2022-11 (RPG, AC Valhalla, chess win, FIFA 23)
metadata:
  type: user
---

John enjoys gaming as a way to escape everyday stress ("like heading into another world"). As of 2022-04-12, he was playing a new RPG set in a futuristic dystopia with an immersive story/world and tough gameplay, though it had noticeable lag and bugs at the time. He recommended it to James and sent him a link to try it, despite the bugs.

As of 2022-04-29, John was playing Assassin's Creed Valhalla. He also plays social/party games with friends: a Uno-like card game (multi-colored numbered cards, match color/number, draw/skip mechanics — he forgot its name) played 2022-04-27, and Among Us ("figure out who the impostors" game), which he recommended James try with a large group.

On 2022-05-07, John organized a CS:GO charity tournament with friends, raising money for a dog shelter near his home; leftover funds went to buying groceries and cooking food for homeless people. He wants to organize more such charity gaming events in the future.

On 2022-05-20 ("last Friday" relative to 2022-05-23 chat), John entered a local tournament and placed 2nd, winning some prize money; he also received a trophy for the achievement. He was proud of the result even without winning outright.

As of 2022-07-22, John took up chess as a new hobby to improve his strategic thinking — plays mostly online but also joined a local chess club to practice with others in person. Motivated by a general interest in strategy games and wanting to sharpen decision-making skills.

As of 2022-09-04, John bought new gaming gear to improve his skills: Sennheiser headphones (chosen for their sound quality reviews) and a Logitech mouse.

On Tuesday 2022-11-01, John won the regional chess tournament — his strategy was analyzing/anticipating opponents' moves to stay a step ahead. He credited hard work, practice, and earlier chess advice from James; it gave him a big confidence boost. As of 2022-11-05 he shared chess-opening resources with James (a photo of a book listing openings) and recommended studying openings, learning from experienced players, and reviewing past games.

As of 2022-11-05, John is also playing FIFA 23 (online multiplayer football game) and invited James to practice and play together, suggesting a gamepad and good timing are all that's needed.

**How to apply:** Gaming is a good rapport topic with John; ask about current games (AC Valhalla), whether James tried Among Us with a group as John suggested, or about future charity gaming tournaments he plans to run. Can also follow up on the 2022-05-20 tournament placement/trophy as a recent achievement. Chess: congratulate on the regional tournament win (2022-11-01), a strong recent achievement; can ask how his form has held up since. Also ask how James's FIFA 23 practice is going / whether they've played together yet, and how chess club/online play and the Sennheiser headphones/Logitech mouse are working out.
