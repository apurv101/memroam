---
name: john-work-stress-coding-project
description: John was stressed in April 2022 by work deadlines and being stuck optimizing an algorithm in a coding project
metadata:
  type: user
---

As of 2022-04-23, John was feeling overwhelmed by work — multiple deadlines and a coding project he was stuck on, specifically trying to improve/optimize an algorithm and making no progress. James advised breaking the problem into smaller steps, researching similar algorithms, and asking other programmers for help; John found this useful and said he'd try it. John later shared a photo of a motivational quote written in a notebook, suggesting the pep talk landed well.

**How to apply:** Safe/relevant to follow up with John on whether the algorithm problem got resolved and how the coding project/course ([[john-new-course-friends]]) is going. James giving practical, step-by-step encouragement (vs. just sympathy) worked well for John.
