---
name: james-football-simulator-course
description: James started a new course combining gaming and programming, building part of a football simulator (player database collection)
metadata:
  type: user
---

As of 2022-06-13, James started a course that combines his love of gaming and programming. He's working on a new part of a football simulator, specifically collecting player databases — described it as a tough but rewarding task he completed. He chose the course primarily for self-improvement, though the football/gaming tie-in is a bonus since he loves the sport. This is a separate, newer project from his earlier Witcher-inspired game build ([[james-witcher-game-project]]), which he considered finished as of 2022-05-23.

**How to apply:** Good rapport topic tying into [[john-gaming-interest]] and [[james-witcher-game-project]] — ask how the football simulator course is progressing or what other features he's building.
