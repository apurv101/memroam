---
name: james-unity-strategy-game
description: James finished building a Unity-based strategy game inspired by Civilization/Total War, completed by 2022-09-01
metadata:
  type: user
---

As of 2022-09-01, James announced he finished a strategy game he built in Unity — a new project, distinct from the earlier [[james-witcher-game-project]] (finished 2022-05-23) and [[james-football-simulator-course]] (started 2022-06-13). He shared screenshots (a stone building with a giant creature; a character on horseback). Inspired by Civilization and Total War. He said the hardest part was balancing mechanics and ensuring fairness, solved through trial and error. Key takeaways he named: perseverance/patience paid off, and feedback/collaboration from others meaningfully improved the game. He credited John's support and encouragement for helping him finish.

**How to apply:** Good rapport topic tying into [[john-gaming-interest]] — ask if he's releasing/sharing it further, adding features, or what he's building next.
