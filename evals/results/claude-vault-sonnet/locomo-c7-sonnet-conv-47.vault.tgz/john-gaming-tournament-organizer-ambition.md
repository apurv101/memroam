---
name: john-gaming-tournament-organizer-ambition
description: John wants to become a professional organizer of gaming tournaments (CS:GO, Fortnite) in his state, voiced 2022-08-06; ran a charity gaming tournament for a children's hospital 2022-10-30
metadata:
  type: project
---

As of 2022-08-06, John — despite having just started his new dream job (see [[john-dream-job]]) — said he's drawn to turning his passion for gaming into a career: he wants to become an organizer of tournaments for various computer games in his state, starting with CS:GO and also Fortnite. He said he's already made some connections that will help with this, and his plan is to gain more experience and hone his skills in the field.

**Why:** Builds on his existing gaming/tournament track record ([[john-gaming-interest]] — he organized a CS:GO charity tournament 2022-05-07 and placed 2nd in a local tournament 2022-05-20), so this reads as a natural extension of an established interest rather than a new one.

**How to apply:** Good rapport topic — ask how the tournament-organizing plans are progressing, which connections he's leaning on, and whether he's tried Fortnite events yet. Also worth noting the possible tension with his brand-new day job (echoes the earlier non-profit-vs-job tension noted in [[john-charity-volunteer-project]]) — could ask how he's thinking about balancing the two, or whether this is a side pursuit vs. an eventual full career switch.

**Update 2022-08-19:** After a brief detour into an online programming group ([[john-programming-group]]), John reaffirmed unprompted that he's "still full of courage" to start hosting eSports competitions — the ambition is holding steady, not being replaced by the programming-group experience.

**Update 2022-10-13:** John and his programmer friends organized and ran an online competition the week before (~early Oct 2022), which he called "awesome." First concrete follow-through on this ambition since he voiced it — worth asking about the format/game, turnout, and whether he plans to run more.

**Update 2022-10-30:** John organized a charity gaming tournament (Fortnite, Overwatch, Apex Legends) with friends the night before, raising money for a children's hospital — combines this tournament-organizing ambition with his non-profit/charity interest ([[john-charity-volunteer-project]], [[john-game-dev-nonprofit-mentor-gig]]). He shared a photo of the game menu screen.
