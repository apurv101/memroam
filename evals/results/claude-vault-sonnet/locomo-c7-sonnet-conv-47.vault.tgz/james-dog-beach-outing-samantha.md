---
name: james-dog-beach-outing-samantha
description: James met Samantha at a dog-owner beach outing (2022-08-09); became a couple 2022-09-03; moved in together in an apartment near McGee's bar as of 2022-10-30
metadata:
  type: project
---

On 2022-08-09, James took his three dogs to a beach outing to socialize with other dog owners. There he met a woman, Samantha, who gave him her phone number; he said he plans to call her (as of 2022-08-10) and is considering asking her out.

Update (2022-09-03): At the theater (Samantha's favorite activity), James asked Samantha to be his girlfriend and she agreed. As of 2022-09-04, James describes it as an overwhelming-but-happy stretch with ups and downs. Other shared activities so far: McGee's bar, where Samantha turned out to enjoy lager beer (relevant to [[james-john-beer-preferences]]); a baseball game was planned for the following Sunday, with John invited along.

**Why:** New personal-life development for James, in the same vein as [[james-hiking-with-dogs]] (dogs/outdoor activity as a recurring theme) and [[james-sister]]/relationship-adjacent topics tracked for this friendship.

**How to apply:** Good rapport topic — ask how things with Samantha (now his girlfriend) are going, e.g. the baseball game or other shared activities. Sensitive/personal territory, so keep it light and let James lead on how much detail to share.

**Update 2022-10-30:** James and Samantha decided to move in together — a mutual, informed decision. They rented an apartment near McGee's bar, the bar they both love (see beer note above); proximity to McGee's was actually a factor in choosing the apartment. Big relationship milestone — worth following up on how the move/cohabitation is going.
