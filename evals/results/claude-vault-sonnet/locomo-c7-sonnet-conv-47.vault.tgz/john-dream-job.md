---
name: john-dream-job
description: John landed his dream job after many interviews, starting mid-July 2022
metadata:
  type: user
---

As of 2022-06-13, John got the offer for his dream job after a long stretch of interviews and late nights, and was ecstatic. He starts next month (~mid-July 2022). This follows his earlier freelance work ([[john-freelance-project]]) and course work ([[john-new-course-friends]]) — this appears to be his first full role, not more freelancing.

**How to apply:** Great rapport topic — ask how the first weeks on the job are going, whether it lives up to expectations, and how it compares to his freelance/course experience.

Update (2022-08-06): John confirmed he actually left his prior IT job (held ~3 years) to take this new role, and started it as planned. He says the transition was scary at first but he's now happy with the decision and loving the new job. Note: he's simultaneously voicing a longer-term pivot toward organizing gaming tournaments as a career — see [[john-gaming-tournament-organizer-ambition]].
