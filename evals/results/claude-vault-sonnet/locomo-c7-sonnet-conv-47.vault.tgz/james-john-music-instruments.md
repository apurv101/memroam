---
name: james-john-music-instruments
description: John into electronic/rock, used to play drums (jammed with friends casually); James used to play guitar — both haven't played in a while (2022-09-18)
metadata:
  type: user
---

As of 2022-09-18: John is into electronic and rock music, and used to play drums when younger (shared a photo of an old drum kit in a recording studio) — he's jammed with friends before but has no recordings/videos, says it was about the experience rather than documenting it. James used to play guitar when younger but also hasn't played in a while.

This resolves the earlier speculation in [[john-reading-and-guitar]] that John might play guitar — the instrument he actually played is drums, not guitar.

**How to apply:** Shared music rapport topic; could suggest jamming together sometime given both have background on instruments (drums/guitar pairing well).
