---
name: james-cooking-class
description: James signed up for a cooking class in early Sep 2022, a new hobby despite not previously liking cooking; $10/class
metadata:
  type: project
---

As of 2022-09-04 ("two days ago"), James signed up for a cooking class — surprising given he says he never liked cooking before, but wanted to try something new. Classes cost $10 each. In the first lesson he made an omelette (which turned out great), meringue, and learned how to make dough.

**Why:** New self-improvement hobby for James, complementing other recent personal-growth threads like [[james-unity-strategy-game]] and [[james-gaming-tournament-win]]. He explicitly welcomed John's encouragement and offered to cook for him once more skilled.

**How to apply:** Good rapport follow-up — ask how the cooking classes are going and what he's learned to make since.
