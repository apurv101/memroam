---
name: james-gaming-group-and-setup
description: James has a regular gaming group he plays/streams with, hosts gaming marathons; gaming PC + keyboard/mouse/chair setup, mentioned 2022-08-19
metadata:
  type: user
---

As of 2022-08-19, James mentioned he has a regular gaming group (not an online community like John's — a group of friends he games with) that streams their sessions together, and recently had an in-person get-together. He also hosts gaming marathons with friends (all-night sessions) as a bonding activity. His setup: gaming PC, keyboard, mouse, and a gaming chair.

John's parallel setup (same conversation): gaming PC with a powerful graphics card, gaming chair, keyboard, and a headset for immersive sound; John says gaming keeps him focused and motivated elsewhere.

**How to apply:** Good rapport topic — ask about the stream, the gaming group get-together, or plan a shared gaming marathon. Ties into [[john-new-game-genres]] and [[john-gaming-tournament-organizer-ambition]] as a recurring shared interest.

**Update (2022-09-18):** James mentioned he's started streaming games (possibly a more solo/personal streaming effort beyond the group streams noted above) — no details yet, outcome uncertain. Worth following up on how it's going.
