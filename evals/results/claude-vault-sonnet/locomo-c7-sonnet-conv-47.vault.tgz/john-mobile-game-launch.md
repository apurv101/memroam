---
name: john-mobile-game-launch
description: John's first mobile game (2D adventure/puzzle) launching ~Oct 2022, kept secret until working out; James offered to help test
metadata:
  type: project
---

John finished his first mobile game, a 2D adventure game with puzzles and exploration, revealed 2022-09-20 with a planned launch "next month" (~October 2022). He kept the project secret from James until it was working out, worried he'd be upset otherwise. He used a game design book (puzzle design tips) and a gaming magazine (tutorials, developer interviews) as key resources — James reads/uses the same magazine. James is into 2D adventure/puzzle games (compared it to Zelda) and offered to help test it once ready.

**Why:** Major career milestone for John (relates to [[john-coding-blog]] and [[john-new-game-genres]]); James's offer to test is a concrete follow-up.
**How to apply:** Follow up on the game's launch status/testing in future chats; this connects to John's broader coding/game-dev interests already tracked.
