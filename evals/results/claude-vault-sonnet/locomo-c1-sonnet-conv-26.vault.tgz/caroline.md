---
name: caroline
description: Durable facts about Caroline from ongoing conversations
metadata:
  type: user
---

Caroline attended an LGBTQ support group (as of 2023-05-07) and found the transgender members' stories inspiring; it made her feel accepted and gave her courage to embrace herself.

She is pursuing further education and exploring career options, specifically interested in counseling or mental health work, motivated by wanting to support others with similar experiences.

As of 2023-05-25, Caroline is researching adoption agencies, planning to adopt as a single parent. She specifically chose an agency known for supporting LGBTQ+ adoptive parents, citing their inclusivity as the reason.

As of 2023-06-09, Caroline began her gender transition roughly 3 years prior (~2020). She spoke at a school event about her transgender journey, encouraging students to get involved in the LGBTQ community. She moved from her home country about 4 years ago and credits the close friend group she made since then, plus family and mentors, as her main support system, especially through a past difficult breakup.

As of 2023-06-27, Caroline's home country is Sweden. She owns two sentimental keepsakes: a necklace (cross + heart) from her grandmother symbolizing love/faith/strength and her Swedish roots, and a hand-painted bowl a friend made for her 18th birthday (~2013). Her counseling career interest has narrowed toward working specifically with trans people on self-acceptance and mental health; she attended an LGBTQ+ counseling workshop on therapeutic methods on 2023-06-23.

As of 2023-07-03, Caroline attended an LGBTQ+ pride parade the week prior (~late June 2023), which reinforced her sense of belonging and further motivated her counseling/mental health career goal of giving back to the community. She has taken up learning piano as a creative outlet. She planned to attend a transgender conference in July 2023 to meet others in the community and learn about advocacy.

As of 2023-07-06, Caroline is building a home library in preparation for having kids someday (classics, stories from different cultures, educational books) and looks forward to reading to them. She had a picnic with her friend/family support network (~late June 2023), reaffirming how much their love and acceptance has meant to her transition.

As of 2023-07-12, Caroline attended the LGBTQ conference (~2023-07-10) she had planned; she connected with others who share similar journeys, felt fully accepted, and it strengthened her commitment to fighting for trans rights and spreading awareness. She is still exploring counseling/mental health career options; her motivation stems from her own past struggles with mental health and the support she received, which she wants to pass on to others. Her favorite guiding book is "Becoming Nicole" by Amy Ellis Nutt, a true story about a trans girl and her family — it taught her self-acceptance, the importance of finding support, and that hope and love persist through tough times.

As of 2023-07-15, Caroline attended a council meeting for adoption (~2023-07-14/15), which she found inspiring and emotional and which further motivated her plan to adopt as a single parent. She favors the color blue, saying it makes her feel relaxed.

As of 2023-07-17, Caroline joined a mentorship program for LGBTQ youth (~week of 2023-07-10), mentoring a transgender teen on building confidence and positive coping strategies; they attended an LGBT pride event together in June 2023, which she found especially meaningful watching her mentee feel supported. She is preparing for an LGBTQ art show with her paintings planned for next month (~August 2023), including a piece of a tree with a bright sun (blue/yellow palette) inspired by a visit to an LGBTQ center, meant to capture unity and strength.

As of 2023-07-20, Caroline joined a new LGBTQ activist group, "Connected LGBTQ Activists" (~2023-07-18), which holds regular meetings and plans events/campaigns; her city held a pride parade the prior weekend (~mid-July 2023) which she found a powerful reminder of solidarity in the fight for equality.

As of 2023-08-14, Caroline attended another pride parade the prior Friday (~2023-08-11). Her painting focuses on expressing her trans experience/transition and promoting LGBTQ+ acceptance; notable piece "Embracing Identity" depicts a woman as a symbol of the journey toward self-acceptance. She says art helps her process her transition and changing body, and has taught her to find beauty in imperfection.

As of 2023-08-17, Caroline had an upsetting encounter on a hike with a group of religious conservatives who said something that upset her, reinforcing her sense of how much work remains for LGBTQ rights; she relies on her supportive friend group to get through experiences like this. She and Melanie were discussing plans for a just-the-two-of-them nature trip this summer (~2023).

As of 2023-08-23, Caroline formally applied to adoption agencies (a step up from earlier researching), with help from an adoption advice/assistance group she attended. She has a pet guinea pig named Oscar, who likes eating parsley/veggies. She used to go horseback riding with her dad as a kid and has always loved horses. She recently painted a self-portrait with a blue face, saying it made her feel liberated and empowered and helped her explore her identity.

As of 2023-08-28, Caroline is volunteering at an LGBTQ+ youth center, where she shares her own story to support the kids there; she's organizing a talent show for the kids next month (~September 2023). She plays acoustic guitar (started ~5 years prior, ~2018) as an emotional outlet; her favorite song is "Brave" by Sara Bareilles, which resonates with her journey and the progress she's made.

As of 2023-08-25, Caroline followed up on the 2023-08-17 hiking incident, saying she apologized to the people she'd gotten into a bad spot with, and framed the whole encounter as a growth moment (courage/maturity). She painted a sunset scene inspired by a beach visit the prior week. She made stained-glass windows for a local church depicting a clock/changing time, explicitly symbolizing her own transition journey and the idea of accepting growth and change; she's photographed other trans-affirming public art (a rainbow mural with an eagle, a Pride Month rainbow sidewalk painting) that resonate with her sense of community and resilience. Her planned LGBTQ art show (first mentioned 2023-07-17 as "next month") is now confirmed for next month (~September 2023), featuring her paintings and other LGBTQ artists.

As of 2023-09-13, Caroline went biking with her friend group the prior weekend (~2023-09-09). She's been creating art since around age 17, calling it empowering and cathartic. She painted a piece depicting her path as a trans woman using red and blue (symbolizing the gender binary) mixed together (symbolizing smashing that rigid thinking) as a reminder to love her authentic self. She reflected that her transition changed her relationships — some close friends stayed supportive, a few couldn't handle it, and she's now happier and feels her relationships are more genuine surrounded by people who accept her.

As of 2023-10-13, Caroline has contacted her adoption mentor for advice, saying she's ready to be a mom (progression from formally applying to agencies on 2023-08-23). Her adoption tips for others starting the process: find an adoption agency/lawyer, gather documents (references, financial info, medical checks), and prepare emotionally for a potentially long wait. She's been experimenting with abstract painting, which she finds "freeing" as a form of self-expression. She attended a transgender poetry reading (~2023-10-06) where trans people shared their stories, which she found powerful and empowering. She drew a picture of a woman in a dress symbolizing freedom, authenticity, and embracing her womanhood.

As of 2023-10-22, Caroline passed her adoption agency interviews the prior Friday (~2023-10-20) — a significant milestone/progression from formally applying (2023-08-23) and contacting her mentor to say she was ready (2023-10-13). She reiterated her goal of adopting as a single parent to give kids who haven't had one a loving, accepting home, framing it as a way to give back after her own long journey to self-acceptance, which she credits to support from friends, family, and mentors.
