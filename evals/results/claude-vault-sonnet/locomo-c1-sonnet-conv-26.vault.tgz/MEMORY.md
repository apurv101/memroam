# Memory index — conv-26

- [Caroline](caroline.md) — LGBTQ support group, pursuing counseling/mental health career
- [Melanie](melanie.md) — has kids, busy with work, paints as creative outlet

