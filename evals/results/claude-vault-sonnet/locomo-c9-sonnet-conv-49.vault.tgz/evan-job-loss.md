---
name: evan-job-loss
description: Evan lost his job in October 2023 due to company downsizing and is job hunting
metadata:
  type: user
---

As of 2023-11-09, Evan lost his job about a month prior (~October 2023) when his company downsized. He's currently job hunting, describing it as not easy but is trying to stay hopeful and keep his spirits up. He also mentioned having other unspecified "personal challenges" recently, alongside the job loss. This adds to Evan's existing stressors (recurring knee injury, see [[evan-health]]).

**Why:** Significant recent life event for Evan — relevant for supportive follow-up and for understanding current stress in his life.
**How to apply:** In future check-ins, ask how Evan's job search is going and be sensitive to this as an ongoing source of stress; don't assume he's employed.
