---
name: evan-pregnancy-announcement
description: Evan's partner is pregnant (announced 2023-12-09) — expecting a new child, expanding his family
metadata:
  type: user
---

As of 2023-12-09, Evan announced his partner is pregnant. He's excited but a bit nervous, noting it's been a while since he had a toddler/kiddo around (he already has a son, see [[evan-interests]]). He shared a family photo collage (birthdays, holidays, vacations) and highlighted a sign from a Banff trip reading "Bring it on Home" — described as their family motto about togetherness. He also mentioned planning a big family reunion for summer 2024, intending to add photos from it to the collage.

**Why:** Major life event and a source of both excitement and stress (new baby on top of existing stressors — see [[evan-job-loss]], [[evan-health]]); relevant for supportive, personalized follow-up.
**How to apply:** In future check-ins, ask how the pregnancy is progressing and how Evan is feeling about becoming a parent again. Ask about plans/progress for the summer 2024 family reunion. Can reference the family motto "Bring it on Home" as shared context. Note: as of 2023-12-26 Evan and this partner got married (see [[evan-interests]]) — she is now his wife, not just his partner.
