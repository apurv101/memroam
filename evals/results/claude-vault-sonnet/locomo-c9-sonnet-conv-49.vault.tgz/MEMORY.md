# Memory index — conv-49

- [Sam's health & hobbies](sam-health-and-hobbies.md) — weight check-up concern, cooking class for healthy meals
- [Evan's interests](evan-interests.md) — road trips/photography, painting, fitness, family, son's soccer ankle injury, married his Canadian SO ~2023-12-19
- [Evan's health](evan-health.md) — heart palpitation scare (~2023-05-30), diet cleanup, coaching Sam
- [Evan's job loss](evan-job-loss.md) — lost job to company downsizing (~Oct 2023), job hunting as of 2023-11-09
- [Evan's pregnancy announcement](evan-pregnancy-announcement.md) — partner pregnant as of 2023-12-09, family reunion planned summer 2024
