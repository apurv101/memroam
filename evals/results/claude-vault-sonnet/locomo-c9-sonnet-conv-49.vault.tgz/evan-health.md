---
name: evan-health
description: Evan's heart palpitation health scare (~2023-05-30) and resulting diet/exercise changes
metadata:
  type: user
---

Evan had a sudden heart palpitation incident around 2023-05-30 (mentioned "last week" on 2023-06-06), which he described as a serious wake-up call about his lifestyle. Since then he's cutting processed food and sugary snacks (even foods he likes, e.g. ginger snaps) and leaning further into his existing fitness routine (see [[evan-interests]]). He's actively encouraging Sam toward similar small diet swaps (seltzer instead of soda, dark chocolate instead of candy) and offered to show Sam basic exercises in person.

As of 2023-08-07, Evan describes his broader "healthy road" as a two-year effort (predating the May 2023 scare), with ups and downs. His family is his main motivator, and he uses a fitness/smart watch to track progress and stay accountable.

Evan twisted his knee around 2023-08-25 (last Friday, per 2023-08-27 chat), which is painful and has disrupted his usual fitness routine — frustrating for him since staying active matters a lot to him. He's pursuing physical therapy (appointment pending as of 2023-08-27) and in the meantime is swimming as a low-impact alternative.

Evan reinjured/messed up his knee again around 2023-09-29 (last week, per 2023-10-06 chat), this time playing basketball with his kids. Knee trouble appears to be a recurring issue for him. As of 2023-10-06, PT is helping somewhat; he can't do intense workouts but keeps up easy exercises, and misses being able to go on outdoor adventures with the family like before.

As of 2024-01-06, Evan mentioned a new specific diet rule: limiting himself to just two ginger snaps a day — a continuation of the processed/sugary food cutbacks since the May 2023 heart scare (ginger snaps were named then too as a liked food he cut back on).

Around 2023-11-14 (last week, per 2023-11-21 chat), Evan had another health scare — a check-up found something suspicious that turned out to be a misunderstanding, with doctors confirming everything is fine. Distinct from the May heart palpitation and recurring knee injuries above. Evan framed it as a reminder to appreciate life and stay present.

**Why:** Significant recent health event for Evan — relevant for follow-up check-ins and for understanding his motivation in coaching Sam's health habits (see [[sam-health-and-hobbies]]).
**How to apply:** Ask how Evan's heart health is doing in future check-ins; recognize his health advice to others stems from his own recent scare and a longer two-year health journey. Knee issues are recurring (twisted 2023-08-25, reinjured via basketball 2023-09-29) — check on his knee/PT progress and whether he's back to normal activity before assuming he's fully recovered. As of 2023-11-21, Evan had another (unrelated) health scare that resolved as a false alarm — worth a light follow-up to confirm all's still well, though he already reported it resolved.
