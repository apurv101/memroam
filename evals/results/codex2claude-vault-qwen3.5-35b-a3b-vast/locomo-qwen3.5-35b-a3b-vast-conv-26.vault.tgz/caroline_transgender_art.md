name: Caroline's transgender art and poetry reading
description: Caroline attended a transgender poetry reading in October 2023 and created art inspired by the experience

---

October 2023: Caroline attended a transgender poetry reading last Friday where transgender people shared their stories through poetry. She found it empowering - it was a safe space for self-expression and celebrating identities. The room had electric energy and support.

Inspired by the experience, Caroline created a drawing of a woman in a dress. The drawing stands for freedom and being real - a nudge to always stay true to herself and embrace her womanhood.

Caroline views art as a form of self-expression and empowerment. She shared that being herself is a great feeling and part of an ongoing adventure of learning and growing.
