name: Melanie's family camping trip
description: Melanie and her family go camping yearly as a summer tradition with marshmallows and campfire stories; best memory was seeing the Perseid meteor shower.

---

Melanie and her family have a yearly summer camping tradition. They look forward to it each year, roasting marshmallows, telling stories around the campfire, and enjoying each other's company. It's the highlight of their summer.

Melanie's two younger kids especially love nature. The view from hikes and exploring the outdoors creates lasting memories for the family.

**Best camping memory**: Last year, Melanie's family saw the Perseid meteor shower during their camping trip. The sky was clear and filled with stars. Watching the sky light up with streaks of light as meteors fell was amazing—they all lay there making wishes and felt at one with the universe. Melanie will never forget that breathtaking, awe-inspiring moment.

**What it meant**: Melanie values family time deeply and cherishes these moments together. Family—her husband and kids—are her primary motivation. They give her love and strength, and she draws courage from them to face life's challenges.
