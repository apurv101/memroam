name: Caroline's LGBTQ youth mentorship
description: Caroline mentors a transgender teen through an LGBTQ youth mentorship program she joined in July 2023, helping them build confidence and find positive strategies
---
Caroline joined a mentorship program for LGBTQ youth in early July 2023. Through this program, she mentors a transgender teenager who, like Caroline, is navigating their gender identity.

**Their work together:**
- Building up the mentee's confidence
- Finding positive coping strategies
- Supporting each other through challenges

**Recent shared experience:**
They attended an LGBT pride event together in late June 2023, which was described as a great experience. Caroline finds it inspiring to work with resilient young people and sees the work as "paying off" in terms of their progress together.

Caroline, being transgender herself, brings personal understanding and lived experience to her mentorship, making her a particularly supportive presence for her mentee.
