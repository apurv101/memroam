name: Caroline's adoption journey
description: Caroline is pursuing adoption as a single parent, focusing on LGBTQ+-inclusive agencies.

---

Caroline is in the process of pursuing adoption as a single parent. She is actively researching adoption agencies, with a preference for ones that are LGBTQ+-inclusive and supportive. Caroline views this as a lifelong dream to build a family and give loving homes to children in need. She has identified adoption agencies that align with her values and is feeling hopeful and optimistic about the process, recognizing both the challenges and rewards ahead.

October 2023: Caroline contacted her mentor for adoption advice and feels ready to start this new chapter. She shared advice with Melanie about the adoption process, including doing research, finding an agency or lawyer, gathering documents (references, financial info, medical checks), and preparing emotionally.
