name: Melanie's running habit for mental health
description: Melanie has taken up running as a way to destress, clear her mind, and improve her mental health.

---

Melanie has recently started running farther as a way to de-stress and clear her mind. She's found that this habit has been great for her mental health and headspace. She describes it as "a great way to destress and clear my mind" and is committed to continuing this practice because "this has been great for my mental health."

Melanie purchased new pink/purple running shoes for this activity. She views running as an important part of her self-care routine and mental wellness strategy.
