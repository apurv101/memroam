name: Melanie's interest in adoption
description: Melanie has been inspired by her friend's adoption experience to consider adopting

---

October 2023: Melanie's friend adopted a child last year after a long process. Melanie heard about the positive outcome and found it made her feel like she should consider adoption too. Caroline shared advice about getting started with adoption, including doing research, finding an adoption agency or lawyer, gathering documents (references, financial info, medical checks), and preparing emotionally for the process.
