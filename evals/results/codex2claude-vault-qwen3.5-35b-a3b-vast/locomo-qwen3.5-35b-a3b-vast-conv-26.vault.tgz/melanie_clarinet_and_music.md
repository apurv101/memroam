name: Melanie's clarinet playing and music preferences
description: Melanie plays clarinet (started young), enjoys classical music (Bach, Mozart) and modern artists like Ed Sheeran.

---

Melanie plays the clarinet, which she started playing when she was young. Music has been an important part of her life as a form of self-expression and relaxation.

**Music preferences:**
- **Classical:** Bach and Mozart
- **Modern:** Ed Sheeran's "Perfect"

**Recent musical experience:**
In August 2023, Melanie attended a live concert featuring a band called "Summer Sounds" that performed an awesome pop song. The performance was lively and fun, with everyone dancing and singing along. She enjoys how music brings people together and creates shared joyful experiences.

**Values:**
- Music as self-expression
- Music as a way to relax
- Appreciating how music connects communities
- Finding joy in live performances
