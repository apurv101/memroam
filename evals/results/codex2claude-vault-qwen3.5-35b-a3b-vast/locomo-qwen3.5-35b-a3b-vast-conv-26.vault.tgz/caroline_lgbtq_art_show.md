name: Caroline's LGBTQ art show
description: Caroline is hosting an LGBTQ-themed art show in September 2023 featuring her paintings, including a tree with sun piece inspired by an LGBTQ center visit
---
Caroline is an artist who creates paintings celebrating LGBTQ unity and strength. In late August 2023, she announced she would be hosting an LGBTQ art show the following month (September 2023).

**Notable painting:**
- **Title/subject**: A painting of a tree with a bright sun in the background
- **Inspiration**: Created after Caroline visited an LGBTQ center
- **Meaning**: She wanted to capture the unity and strength she witnessed at the center
- **Style**: Described as having vivid colors and a unified aesthetic

Caroline views her art as a way to express and celebrate the LGBTQ community's resilience and togetherness. The art show represents another avenue through which she advocates for and supports the LGBTQ community, alongside her mentorship work and public speaking.
