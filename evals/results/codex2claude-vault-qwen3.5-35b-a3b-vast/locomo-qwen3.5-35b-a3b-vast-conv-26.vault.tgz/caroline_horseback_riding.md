name: Caroline's horseback riding with her dad
description: Caroline used to go horseback riding with her dad as a child through the fields

---

Caroline has a love for horses. As a child, she used to go horseback riding with her dad. They would go through the fields and feel the wind. She remembers this as "so special" and says "I've always had a love for horses!"
