name: Caroline's guinea pig - Oscar
description: Caroline has a guinea pig named Oscar who loves vegetables, especially parsley

---

Caroline has a guinea pig named **Oscar**. Oscar is her pet and has been a great companion to her. Oscar's favorite foods are vegetables, particularly parsley. Caroline shared photos of Oscar in his cage with hay and eating parsley.
