name: Caroline's LGBTQ Advocacy and Identity
description: Caroline is part of the LGBTQ community and attends advocacy events like Pride fest
---

August 2023: Caroline shared that she had an unpleasant experience on a hike where she encountered religious conservatives who made comments that upset her. This reminded her of the ongoing work needed for LGBTQ rights.

October 2023: Caroline attended a transgender poetry reading last Friday where transgender people shared their stories through poetry. She found it empowering - it was a safe space for self-expression and celebrating identities. The room had electric energy and support. Inspired by the experience, she created a drawing of a woman in a dress representing freedom, authenticity, and embracing her womanhood.

Key points:
- Caroline identifies as part of the LGBTQ community
- She attended a Pride fest the previous year (August 2022) with supportive friends
- She values having accepting and supportive people around her
- The incident made her reflect on societal progress needed for LGBTQ rights

Caroline drew strength from her supportive community, including friends like Melanie.