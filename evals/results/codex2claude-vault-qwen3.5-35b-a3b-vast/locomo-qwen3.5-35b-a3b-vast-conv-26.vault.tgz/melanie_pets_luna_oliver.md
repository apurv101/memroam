name: Melanie's pets - Luna and Oliver
description: Melanie has a dog named Luna and a cat named Oliver who brighten her day and make her smile.

---

Melanie has two pets:
- **Luna** — a dog (pup)
- **Oliver** — a cat

Melanie describes them as "so sweet and playful" who "really liven up the house." They bring her joy and comfort, always making her smile. The pets are an important part of her daily life and contribute to her overall happiness and mental well-being.
