name: Melanie's Pottery Hobby
description: Melanie creates pottery as a form of self-expression and personal sanctuary
---

August 2023: Melanie shared creating a colorful, patterned bowl that she was proud of. She explained that painting and pottery help her:
- Express her feelings and be creative
- Find a source of comfort and sanctuary
- Connect to something that brings her happiness and fulfillment

October 2023: Melanie got hurt last month and had to take a break from pottery. She's been reading a book Caroline recommended and painting to keep her creative outlets active. She shared a painting of a sunset with pink sky and an abstract blue painting she created for calmness and tranquility.

Her art philosophy: "Each stroke carries a part of me." She creates art that catches the eye and makes people smile, driven by her personal obsession with colors and patterns.