name: Caroline's LGBTQ conference experience
description: Caroline attended a welcoming LGBTQ conference where she connected with people on similar journeys and strengthened her commitment to trans rights advocacy.

---

Two days before July 12, 2023 (around July 10), Caroline attended an LGBTQ conference. She described it as "really special" and a "welcoming environment" where she felt "totally accepted." 

At the conference, Caroline had the opportunity to meet and connect with people who've gone through similar journeys. The experience reinforced how important it is to fight for trans rights and spread awareness. She expressed deep gratitude for the LGBTQ community and how it has shown her the strength that comes from having supportive people around.

This conference further motivated Caroline's desire to make a difference, particularly in the mental health and counseling space.
