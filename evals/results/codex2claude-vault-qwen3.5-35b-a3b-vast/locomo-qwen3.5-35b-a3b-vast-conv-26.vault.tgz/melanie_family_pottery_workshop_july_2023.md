name: Melanie's family pottery workshop
description: Melanie took her kids to a pottery workshop on Friday, July 7, 2023, where they made clay sculptures including a cup with a dog face.
---
On Friday, July 7, 2023, Melanie took her children to a pottery workshop. The experience was fun and therapeutic for the whole family.

The kids were excited to get their hands dirty and make something with clay. Melanie especially enjoyed watching their creativity and imagination come to life.

**What they made:**
- Each child made their own pot
- The children created a cup with a dog face on it, which Melanie found absolutely cute

Melanie views this as a special bonding experience that allowed her to witness her children's artistic expression firsthand.
