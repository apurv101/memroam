name: John teaches siblings coding
description: In late August 2022, John shared he's been teaching his siblings programming; they're making basic games and stories
---
In late August 2022, John shared that he had been teaching his siblings how to code. This represented a natural progression from his own coding journey and his participation in a charity programming course in May 2022.

**What they're learning:**
- Starting with basic programs
- Creating simple games and stories
- John is impressed by how fast they learn
- They're having fun while learning

**John's perspective:**
- Teaching has been a fulfilling experience for him
- He's excited to see how far they can go
- Hopes they'll use their coding skills to make something cool
- Very proud of their progress

This mentorship role showed John developing skills in explaining technical concepts and supporting others' learning, building on his own foundation from April 2022 when he was taking a programming course with friends.

**Note from this conversation:** During this same late August 2022 conversation, John mentioned he was going through some difficult times and found it comforting to have James's support and friendship. This suggests this was a period when mutual support in their friendship was particularly important.
