name: John's freelance programming work
description: John is doing freelance programming for a small business website in April 2022; first professional project outside of class
---
In late April 2022, John shared that he was working on freelance programming projects to hone his coding skills. Specifically:

- **Project**: Building a website for a local small business
- **Significance**: His first professional project outside of class
- **Progress**: Learning a lot, but progress has been slow with some hiccups
- **Challenge**: Figuring out how to implement payments on the website took a while; he used resources to understand the process and was getting closer to a solution
- **Attitude**: John was determined to keep pushing through challenges

This aligns with John's philosophy of challenging himself to improve, and shows his professional development trajectory in programming.
