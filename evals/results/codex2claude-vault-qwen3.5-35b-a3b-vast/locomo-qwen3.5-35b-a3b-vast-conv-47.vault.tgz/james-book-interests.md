name: James's book interests
description: James enjoys fantasy novels and adventure books with cool art; enjoys reading in a peaceful park; purchased a fantasy collection around April 26, 2022
---
In late April 2022, James shared that three days before April 29, 2022 (around April 26), he purchased an adventure book with fantasy novels and cool art. He showed a photo of someone holding a book open to a picture of a male character.

James enjoys the fantasy genre. On April 29, 2022, John recommended "The Name of the Wind" trilogy to him, which James said he would check out.

James also showed a photo of a book set of three books on a wooden table (presumably from his collection or purchase).

**James's reading spot:**
In mid-June 2022, James shared that he enjoys reading in a peaceful park with a bench and trees. He said going to the park helps him think straight and find his inner peace. He usually brings a book and just relaxes there as an escape from reality.
