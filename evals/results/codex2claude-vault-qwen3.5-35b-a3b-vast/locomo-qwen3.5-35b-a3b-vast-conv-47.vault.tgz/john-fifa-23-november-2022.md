name: John - FIFA 23 football game
description: John got into FIFA 23 in early November 2022; enjoys online multiplayer football gaming

---

**FIFA 23:**
In early November 2022, John became hooked on FIFA 23, a football (soccer) video game. He described it as a "great football game" with the ability to play online with other players from all over the world.

**Gaming with James:**
- James wanted to try a new gaming genre (sports games)
- John suggested James practice a little first, then they could play together
- John mentioned it requires a gamepad and a sense of timing
- James said he'd go train

This expanded John's gaming repertoire beyond strategy games, CS:GO, and board/card games to include sports simulation games.
