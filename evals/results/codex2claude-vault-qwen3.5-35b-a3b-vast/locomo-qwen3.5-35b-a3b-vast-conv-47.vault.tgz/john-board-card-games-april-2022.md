name: John - Board and card games with friends
description: John plays Uno-like card game and an impostor-deduction game with friends; played a board game two days before April 29, 2022
---
In late April 2022 (conversation on April 29, 2022), John discussed several games he plays with friends:

**Uno-like card game:**
- John described a card game he plays with friends
- Features multi-colored cards with numbers
- Gameplay mechanics: place cards with same color or number on opponent's card, sometimes trade cards, sometimes draw extra cards from deck, sometimes skip a turn
- John had forgotten the name of this game during the conversation
- This matches the gameplay description of Uno

**Impostor-deduction game:**
- John plays a game where you figure out who the impostors are
- Described it as "super fun"
- He advised gathering a large group to make it more interesting
- This matches the gameplay description of Among Us or similar social deduction games

**Board game experience:**
- Two days before April 29, 2022 (around April 27), John played a board game with friends
- He found it "very exciting"
- Shared a photo of a board game with lots of cards on it
- When James asked about strategy board games, John said they're great for having fun together

John enjoys games that make him think and value the social aspect of gaming with friends.
