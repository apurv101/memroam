name: James - Pets
description: James has three dogs at home (Max, Daisy, Ned); dogs bring him joy and companionship
---
James has two dogs named Max and Daisy. He shared photos of them (tied to a fence with a leash). He mentioned the dogs when discussing the dog walking app idea with John.

In early April 2022, James adopted a new pup named Ned from a shelter in Stamford. Ned has made James's days much happier since joining the family.

**Max:**
In mid-June 2022, James shared that his dog Max is lovable and playful. Max brings James much joy, especially during tough times. Max loves swimming at the beach or lake and is a pro swimmer. Max is also great at catching frisbees in mid-air without missing. James and Max enjoy long walks together, including on a nearby trail about a mile from his house.

**Daisy's gaming companionship:**
In late April 2022, James shared that his dog Daisy likes to come lay next to him while he plays games. Daisy came and lay down next to him while he was playing a game, with a computer visible in the background. James described Daisy as his "faithful furry friend" and said their dogs are "cuddle buddies" that love to watch him gaming and often hug him.


**Dogs and skateboarding (July 2022):**
In late July 2022 (July 22, 2022), James shared that he loves skateboards and sometimes goes for a ride. He taught his dogs how to balance on a skateboard. The dogs love it - they chase after the board and run with it. James says it's a great way for them to get some exercise and that keeping active with them builds a strong bond and makes them both happy.

**Routine veterinary visit (early August 2022):**
In early August 2022, James took his puppy to the clinic for a routine examination. The puppy was also vaccinated to prevent catching seasonal canine disease.

**Road trip visit to animal sanctuary (November 2022):**
In November 2022, during a road trip with his family and dogs, James visited an animal sanctuary. He shared a photo of a man kneeling next to a rescue dog and mentioned there were many cute rescue dogs there. James thought of his and John's love of furry friends and commented that while he wanted to take all the rescue dogs home, he already has three dogs at home and believes having more than three is too much.

**Family road trip (late October - November 2022):**
James and his family went on a road trip, visiting friends Josh and Mark along the way. He shared photos of his family posing for pictures and enjoying the trip together.