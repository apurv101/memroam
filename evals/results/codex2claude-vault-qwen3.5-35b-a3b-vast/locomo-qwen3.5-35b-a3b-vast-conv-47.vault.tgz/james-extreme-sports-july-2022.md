name: James's extreme sports activities - July 2022
description: James shared involvement in extreme sports: rope jumping (150 meters) and surfing

---

**James's extreme sports engagement (early July 2022):**

After winning an online gaming tournament, James became interested in extreme sports.

**Activities:**

1. **Rope jumping** (yesterday, around July 8, 2022)
   - Highest jump: **150 meters**
   - Part of trying to take breaks from hobbies and do different things

2. **Surfing** (three days prior, around July 6, 2022)
   - Finds catching waves "so cool"
   - Describes it as strange but relaxing

**Context:**

- James mentioned this shift to John during their conversation on July 9, 2022
- James's approach to balance: taking breaks from hobbies and doing other activities
- These activities contrast with John's relaxation method (reading)
- James also enjoys reading but prefers "something more exciting" during summer