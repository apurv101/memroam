name: John's tournament second place - May 2022
description: John placed second in a local tournament on Friday before May 23, 2022, and received money as a prize

---

John participated in and placed second in a local tournament on the Friday before May 23, 2022.

**John's experience:**
- Described it as "a wild experience"
- The "competitive energy was insane"
- He was "stoked about [his] achievement"

**Prize:**
- Although he didn't win first place, he received money for second place
- He was satisfied that his effort paid off

**Trophy:**
- John shared a photo of a trophy (graduation cap on a book with a rope)
- The trophy reminds him to "always put in [his] best effort"

James congratulated John on his achievement.
