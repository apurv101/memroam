name: James completes Unity strategy game
description: In late August 2022, James completed a Unity strategy game inspired by Civilization and Total War after overcoming development challenges
---
On August 31, 2022, James shared that he had finally completed his Unity strategy game after significant time and effort. He expressed pride in his accomplishment and thanked John for his support and encouragement.

**Game details:**
- Built in Unity engine
- Strategy genre, inspired by Civilization and Total War
- James shared screenshots showing: (1) a stone building with a giant creature, (2) a person on a horse

**Development challenges:**
- Balancing game mechanics and ensuring fairness was challenging
- Required trial and error to get the game right
- James managed to reach his desired vision through persistence

**Key lessons learned:**
- Perseverance and patience are essential
- Feedback and collaboration are critical - help from others (including John) made the game better
- The experience reinforced James's pride in what he created by sticking with it

This milestone followed James's earlier game-related activities, including a football simulator course in June 2022 and various game interests documented in the memory vault.
