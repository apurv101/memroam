name: John starts dream job
description: John started his dream job next month after extensive interviews and late nights.
---
**Starting the job (early August 2022):**
John officially left his IT job after 3 years and started his new position. He described it as a tough decision but knew he had to make a change to focus on things that align with his values and passions. At first, it was scary, but he's now happy with his decision and loving the new job.

**Career aspirations:**
John is drawn to the gaming industry and wants to become a tournament organizer for various computer games in his state, particularly CS:GO and Fortnite competitions. He's already made some connections to help with this new journey and plans to gain more experience while perfecting his skills to be successful in the field.
