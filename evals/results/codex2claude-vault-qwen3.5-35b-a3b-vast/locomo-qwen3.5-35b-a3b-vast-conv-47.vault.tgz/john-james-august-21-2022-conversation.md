# James and John - Gaming and Programming August 2022

## key_points:
- John joined an online programming group last Friday (mid-August 2022)
- The group focuses on using tech for good and making a difference
- John collaborated on a project with someone from the group
- James has a gaming group they play with regularly and stream game sessions
- James has a gaming PC, keyboard, mouse, and comfortable gaming chair
- John has a gaming PC with a powerful graphics card, gaming headset, and refurbished gaming desk
- Both James and John have similar gaming chairs and keyboards
- John is hosting eSports competitions (not just learning)
- Both John and James don't hang out with their siblings much due to distance but plan gaming nights
- John is organizing a gaming night with his siblings next month (late August/early September 2022)
