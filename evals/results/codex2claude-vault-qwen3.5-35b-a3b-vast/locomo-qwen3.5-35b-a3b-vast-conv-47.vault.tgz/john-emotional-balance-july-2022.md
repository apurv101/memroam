name: John's emotional state and work-life balance - July 2022
description: John shared feelings of being overwhelmed and stressed while balancing personal and professional life

---

**John's emotional state (as of July 2022):**

- Feeling a "tug of emotion"
- **Positive feelings:**
  - Determined
  - Passionate
- **Challenging feelings:**
  - Overwhelmed
  - Stressed

**Work-life balance challenge:**

- John mentioned that "balancing personal and professional is kind of a challenge"
- Experiences tension between personal and professional life
- Seeking ways to manage this balance

**Context:**

- John shares this with James during their conversation on July 9, 2022
- This follows previous discussions about John's desire to make a positive impact through non-profit or volunteer work (as of June 2022)
- John finds relaxation through reading and entering "imaginative worlds of authors"