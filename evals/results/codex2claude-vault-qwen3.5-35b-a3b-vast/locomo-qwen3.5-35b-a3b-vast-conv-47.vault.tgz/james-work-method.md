name: James - Work Method
description: James writes down all his goals in a notebook and checks them off when done; finds it satisfying to track progress.
---
James writes down all his goals in a notebook. He finds it very satisfying to check off each one when it's done. This method helps him track his progress and gives him a great sense of accomplishment. He values creating something and seeing it come to life.
