name: John's Metal Detecting Hobby
description: John recently started metal detecting on beaches; has found coins and a gold ring.
---
John recently started a new hobby: metal detecting. He bought a metal detector and walks along beaches looking for worthwhile finds. So far, he's mostly found bottle caps, but a couple of times he's found coins, and once even a gold ring.
