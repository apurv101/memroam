name: John's Charity Programming Work May 2022
description: John created an inventory management app for a charitable foundation helping kids, using his programming skills for social good.

John volunteered his programming skills for a charitable foundation in May 2022. The foundation previously used paper records with manual inventory tracking. John created a smartphone application that:

- Centralized inventory, resources, and donations tracking
- Automated report generation for analysis
- Streamlined their operational workflows

John was inspired by the foundation's passion for helping kids and wanted to contribute his skills while also challenging himself. The experience gave him a real sense of purpose and showed him the power of technology for positive social impact.

This experience motivated John to:
- Consider volunteer roles in the non-profit sector
- Potentially pursue a career in non-profits
- Look for organizations that align with his values and passion for programming

John shared a screenshot of the system monitoring CPU performance. He felt it was rewarding to use his coding skills to make a tangible difference in the world.
