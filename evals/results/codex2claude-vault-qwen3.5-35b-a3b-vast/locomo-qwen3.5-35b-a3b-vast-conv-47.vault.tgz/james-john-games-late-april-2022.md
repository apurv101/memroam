name: John and James - Games played in late April 2022
description: John plays Assassin's Creed Valhalla; James plays a turn-based strategy game around Civilization VI
---
In late April 2022 (conversation on April 29, 2022), John and James discussed the games they were playing:

**John's games:**
- **Assassin's Creed Valhalla (AC Valhalla)**: John confirmed he was currently playing this game

**James's games:**
- **Turn-based strategy game**: James was playing a high-quality turn-based strategy game where you manage resources, lead armies, and conquer territories
  - Asked if it was Civilization VI (John recognized it)
  - Requires a lot of strategy, planning, and resource management
  - John found it sounded fun and challenging
  - James had been playing it for about a month, and it was challenging his strategy skills

**Gaming philosophy discussion:**
- Both discussed how strategy games help with problem-solving and thinking
- They found it satisfying when plans work out and they win
- James emphasized that "every move matters" in these games
