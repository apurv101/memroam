name: James - Programming Skills
description: James has skills in Python and C++ (built websites and game mods), also knows HTML/CSS; taking a programming class to refresh HTML skills.
---
James has programming experience with Python and C++. He built a website and created game mods. He tried programming in college and found it awesome. He also has some HTML and CSS experience from a few years ago. He just signed up for a programming class to refresh his HTML skills. He's always excited to combine his passions for gaming and storytelling into his projects.
