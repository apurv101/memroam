name: James and John - Meeting Plans and Projects August 26, 2022
description: James and John discussed Ned the dog, John's siblings learning programming via a text-based adventure game, James's ambition to create a Civilization-style strategy game, and plans to meet at McGee's Pub on August 27

---

On August 26, 2022, James and John had the following conversation:

**Ned the dog:**
James shared a photo of Ned on a couch, mentioning Ned came to him while he was playing on the console. John was reminiscing about Ned's adoption in April 2022 from a Stamford shelter, which was already documented.

**John's siblings and programming:**
John has been helping his younger siblings with programming since they joined a programming course. They're working together on a text-based adventure game that helps them learn coding skills while having fun. John is proud of them and hopes they might even create their own video games one day.

**James's game ambitions:**
James expressed excitement about strategy games, particularly mentioning he's "dying to create a strategy game like Civilization" because he loves how complicated and in-depth they are. He hopes one day he'll make his own awesome strategy game.

**Meeting plans:**
James asked if John was free the next day (August 27, 2022), which was John's day off. They discussed meeting at McGee's Pub instead of Starbucks, choosing to have light beer (John doesn't like dark beer). They agreed to meet at McGee's Pub tomorrow.
