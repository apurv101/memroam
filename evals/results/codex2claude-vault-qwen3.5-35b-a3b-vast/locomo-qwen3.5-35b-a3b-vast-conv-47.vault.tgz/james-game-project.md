name: James - Game Project
description: James is developing a computer game based on a childhood character he used to draw comics about; combines his passions for gaming and storytelling; inspired by The Witcher 3; has a new cutting-edge gaming system with incredible graphics
---
James is working on a computer game project he's wanted to do since childhood. As a child, he made sketches of the main character and drew comics. Now he's turning it into a computer game, which excites him greatly. He values the challenge and the accomplishment of seeing something come to life. He just got a new cutting-edge gaming system with incredible graphics that lets him connect with friends who share his passion for gaming.

**The Witcher 3 inspiration:** James cited The Witcher 3 as a major inspiration for his game development, praising its amazing world and story. This influenced his decision to create something special and pushed him to put significant effort and dedication into his own game.

**Games played (late April 2022):**
In late April 2022, James was playing a high-quality turn-based strategy game where you manage resources, lead armies, and conquer territories. He found it challenging and different from his usual games. John mentioned it sounded like Civilization VI, and James confirmed he'd been playing it for about a month. They discussed how strategy games help with problem-solving and planning skills.
