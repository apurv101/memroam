name: James - Sister
description: James has a sister whom he spends time with; they visited the ocean together and watched a sunset
---
James has a sister. In late July 2022 (July 21-22, 2022), James shared a photo of his sister and their two dogs (Max and Daisy) chilling together on a couch. James described spending time with his sister and dogs as making them happy like a family, and he said he's blessed to have a close bond with both his sister and their furry friends.

James and his sister were near the ocean and watched a wonderful sunset together. James also mentioned they went to the beach.
