name: John - CS:GO Charity Tournament May 2022
description: John organized a CS:GO charity tournament in early May 2022, raising money for a local dog shelter and cooking for the homeless.
---
John organized a CS:GO (Counter-Strike: Global Offensive) tournament with his friends in early May 2022. The event was well-attended and successfully raised money for charity.

**Cause**: The main goal was to raise funds for a dog shelter located near John's street.

**Outcome**: The tournament was successful. After donating to the dog shelter, they had leftover money which they used to buy groceries and cook food for homeless people. The homeless community was very appreciative.

**John's perspective**: He found the event rewarding and combining his gaming interests with community service. He plans to organize more similar events in the future to help the community and bring people together through friendly competition.
