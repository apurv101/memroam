name: James and John - Childhood friendship
description: James and John knew each other since elementary school, around age 10, and were into skateboarding together
---
James and John have known each other since elementary school. In July 2022, John shared a childhood photo from when they were 10 years old.

**Elementary school skateboarding (around age 10):**
- Both were really into skateboarding
- Had a group of friends who often went to the skate park together
- They would help each other learn new tricks
- Had a great time with their friends
- The friendship with those friends meant a lot to both of them

James shared a photo from this time of a small dog standing on a skateboard, recalling that they sometimes even left class early to go skateboarding. This shared childhood experience shows their friendship has a long history, predating their more recent conversations about games, coding, and hobbies.
