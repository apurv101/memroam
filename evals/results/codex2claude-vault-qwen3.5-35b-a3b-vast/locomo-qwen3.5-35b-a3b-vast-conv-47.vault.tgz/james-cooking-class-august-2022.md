name: James Cooking Class
description: James signed up for cooking classes on August 3, 2022, learning to make omelettes, meringue, and dough
---
On September 4, 2022, James shared that two days prior (August 3, 2022), he signed up for a cooking class. James noted that he never liked cooking before but wanted to learn something new.

At the first lesson, James prepared several simple dishes and got great results:
- Made an omelette successfully on his first try
- Made meringue
- Learned how to make dough

James mentioned the classes cost only $10 per class, which he considered very cheap. He expressed appreciation for John's support and hoped to treat John to his cooking creations once he learned more.
