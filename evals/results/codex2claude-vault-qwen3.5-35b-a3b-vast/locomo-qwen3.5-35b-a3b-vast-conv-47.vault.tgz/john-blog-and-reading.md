name: John - Blog and Reading
description: John started a coding blog in early June 2022; enjoys sci-fi and fantasy books; recommends The Stormlight Archive, Kingkiller Chronicle, and The Expanse
---
In mid-June 2022, John shared that he started a blog about coding the previous week. He described it as an exciting and challenging experience, and he enjoys sharing his coding journey with others while tracking his progress. John mentioned it feels scary but is a great way to connect with other coders.

**John's reading preferences:**
John is a big fan of sci-fi and fantasy books. He especially enjoys epic fantasy series with immersive world-building and intricate storylines. He mentioned that getting lost in a great story is a wonderful escape from reality.

**John's favorite book series:**
- "The Stormlight Archive"
- "The Kingkiller Chronicle"
- "The Expanse" series (for science fiction fans)

John is obsessed with how these authors create magical worlds you can escape into, and he appreciates that the characters feel really real.
