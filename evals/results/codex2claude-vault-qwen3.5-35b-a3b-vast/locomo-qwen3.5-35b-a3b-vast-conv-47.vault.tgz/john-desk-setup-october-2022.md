name: John's upgraded desk setup
description: John shared a photo of his desk with a laptop and monitor in October 2022
---
In October 2022, John shared a photo of his desk setup featuring a laptop and external monitor. This suggests John may have upgraded his workspace or gaming equipment.
