name: John's Portable Smoker Startup and Mobile Game Milestone
description: John started a portable smoker startup in mid-September 2022 and is launching his first mobile game (2D adventure with puzzles) next month
---
On September 20, 2022, John shared two major achievements with James:

**Portable Smoker Startup:**
- John started a new startup focused on portable smokers
- He had already welded one prototype from metal by mid-September 2022
- John was seeking feedback on his metalworking skills

**Mobile Game Development:**
- John achieved a major career milestone by creating his first mobile game
- The game is a 2D adventure with puzzles and exploration
- Launch scheduled for October 2022 (the following month)
- John had been working on it for several months
- He kept the project secret to protect his emotional investment in case it failed

**Learning Resources for Game Development:**
John uses multiple resources to improve his game development skills:
- Books on game design with tips and insights on puzzle creation
- Video tutorials
- Developer forums for information and ideas
- Gaming magazines (particularly one with developer interviews, tutorials, and tips)

John emphasizes that staying informed and constantly learning is key to his success.

**Shared Interests:**
Both James and John found value in the same gaming magazine as a resource for learning and staying current in game development.
