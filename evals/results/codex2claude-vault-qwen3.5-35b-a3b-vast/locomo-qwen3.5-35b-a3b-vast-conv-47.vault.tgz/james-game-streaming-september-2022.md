name: James started game streaming
description: As of mid-September 2022, James began streaming games with no details yet but hopeful it works out
---
In mid-September 2022 (conversation on September 18, 2022), James shared that he started streaming games. He mentioned there were no details yet but hoped everything would work out. John expressed support, saying he would keep his fingers crossed for James and look forward to the details.
