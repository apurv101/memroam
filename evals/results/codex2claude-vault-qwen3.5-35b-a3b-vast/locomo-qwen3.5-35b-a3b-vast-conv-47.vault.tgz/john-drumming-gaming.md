name: John - Drumming and Gaming
description: John played drums when younger but hasn't in a while; jammed with friends; plays CS:GO; attends gaming conventions and tournaments; started board games as of September 2022.
---
**Drumming (younger years):**
John used to play drums when he was younger but hasn't played in a while. He found drumming to be a fun way to let off steam. He jammed with friends before but never recorded the sessions—it was more about the experience and the moment. As of March 2022, he had about a month of drumming experience.

**Musical interests:**
- John is into electronic and rock music
- Likes jamming with friends (no recordings exist)

**Gaming activities:**
John enjoys competitive gaming and finds inspiration from watching skilled players. He attended a gaming convention where he tried out many games, met developers, and participated in a CS:GO tournament. He recently advanced to the next level in a game, which was a confidence booster.

**Games (late April 2022):**
- **Assassin's Creed Valhalla (AC Valhalla)**: Currently playing this game; found the futuristic dystopia story and world immersive with awesome graphics, despite some bugs and lag issues
- **Strategy games**: Enjoyed watching James play turn-based strategy games; finds the concept of managing resources and leading armies interesting
- **Board games**: Two days before April 29, 2022, played an exciting board game with friends
- **Card game (Uno-like)**: Plays a card game with multi-colored cards and numbers with friends where you match colors or numbers
- **Impostor-deduction game**: Plays a social deduction game with friends where you figure out who the impostors are; called it "super fun"
- **Dungeons of the Dragon**: Tried this board game a week before September 18, 2022 (around September 11) and found it very exciting

**Community and mentoring:**
John has been helping his younger siblings with programming since they joined a programming course. They're working together on a text-based adventure game that helps them learn coding skills while having fun. John is proud of them and hopes they might even create their own video games one day.
