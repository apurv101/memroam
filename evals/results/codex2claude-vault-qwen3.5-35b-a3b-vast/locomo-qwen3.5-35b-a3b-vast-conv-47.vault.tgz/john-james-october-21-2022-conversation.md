name: James and John - October 21, 2022 conversation
description: James and John caught up; John's programming seminar went well, James lost power during gaming, mother visited with army friend

---

On October 21, 2022, James and John had the following conversation:

**John's programming seminar (mid-October 2022):**
- John organized a programming seminar last week that went really well
- Great turnout and fulfilling experience sharing knowledge
- Learned new programming approaches and techniques from other developers
- Found some cool ideas to incorporate into his own work
- Hasn't tried them yet but looking forward to experimenting
- Plans to send James resources and tutorials on the new techniques

**James's gaming power outage (October 18, 2022):**
- James's apartment lost power 3 days ago
- He was in the middle of a game's big reveal
- Lost some progress because he forgot to save
- Learned to save more often as a result

**Family visit (October 19, 2022):**
- James's mother came to see him 2 days ago with her army friend
- They had fun together
- Mother's army friend is still serving but retired a long time ago
- They shared stories about their military time and their dog
- James shared a photo of himself at their age playing on their old gaming setup (Nintendo console with Mario controller)
- James mentioned playing Super Mario and The Legend of Zelda as a kid, which sparked his passion for gaming

**Gaming discussion:**
- James tried Cyberpunk 2077 yesterday and found it addictive
- John warned about the importance of choices in the game - even dialogue choices can be life-changing
- John advised James that you don't have to be friends with every character
- John promised to avoid spoilers

**Resources promised:**
- John will send James resources and tutorials on the new programming approaches he learned from the seminar
