name: James - Motivation and Gaming
description: James is motivated by video games and goal-setting; currently playing RPGs and strategy games; plays drums (started a few days before March 2022); enjoys bowling (got 2 strikes last time), VR gaming, and arcade games like slots.
---
James finds motivation and joy in video games, which keep him excited. He's currently exploring RPGs and strategy games. He uses setting small goals and tracking progress to stay motivated and focused on his hobbies and other pursuits. James is learning drums (started a few days before March 27, 2022, practicing daily). Other hobbies include bowling (recently got 2 strikes), VR gaming (found it immersive and real), and playing slot machines and arcades. He plans to try VR gaming with friend John on Saturdays.
