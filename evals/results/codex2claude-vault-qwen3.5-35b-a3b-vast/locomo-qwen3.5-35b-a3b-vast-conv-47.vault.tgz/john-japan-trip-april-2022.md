name: John's Japan trip
description: John visited Japan a few days before April 20, 2022; impressed by megacities, technology, and street food

---

**Date:** Late April 2022 (approximately April 17-18, 2022)

**Location:** Japan

**Key details:**
- John visited Japan, specifically mentioning megacities
- Impressed by:
  - Technologically advanced infrastructure
  - Huge screens on buildings
  - Street food (described as "very tasty")
- Shared a photo of a busy city street at night with people walking
- Found the experience inspiring and motivational

**Context:** John mentioned this while discussing what gives him motivation for his work. He believes that traveling gives him motivation to work further, alongside chilling with friends.
