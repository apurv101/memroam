name: Andrew and Audrey's Birdwatching Plans
description: Andrew and Audrey discussed birdwatching interests, with Andrew offering to guide Audrey and potentially going together
---
- Andrew offered to give Audrey birdwatching advice after she expressed interest in starting birdwatching
- Audrey mentioned she has a book on bird watching guides and plans to learn about common birds in her area
- Andrew shared that he has experience with bird watching and reads about ecological systems
- They discussed potentially going birdwatching together
- Andrew mentioned he would bring binoculars and a notebook to log birds on the trip
- Audrey plans to check her schedule and get back to Andrew about planning a birdwatching trip
