name: Audrey's Dog Tattoo
description: Audrey got a tattoo of her four dogs (Pepper, Pixie, Precious, Panda) on her arm.

---

In August 2023, Audrey shared that she got a tattoo of her four dogs on her arm. She said they really mean a lot to her and she wanted to have them with her wherever she goes.
