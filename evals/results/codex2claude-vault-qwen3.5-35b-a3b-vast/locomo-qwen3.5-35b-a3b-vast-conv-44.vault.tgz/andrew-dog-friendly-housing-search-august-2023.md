name: Andrew's Dog-Friendly Housing Search August 2023
description: Andrew still searching for dog-friendly housing in late August 2023; Toby is young and makes hiking challenging

---

- Andrew was still looking for a dog-friendly place to live as of late August 2023
- It's been a bit challenging to find
- Andrew wants a great place for his dogs (Toby)
- Toby is still so young, making it difficult to hike with him yet
- Andrew's been wanting to hike with Toby for a while but Toby's age is a factor
- Keep searching for the perfect dog-friendly place
