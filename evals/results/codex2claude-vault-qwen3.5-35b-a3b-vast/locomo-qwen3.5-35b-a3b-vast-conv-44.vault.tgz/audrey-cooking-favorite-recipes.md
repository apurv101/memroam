name: Audrey's Favorite Recipes
description: Audrey loves cooking; her favorite recipes are Chicken Pot Pie (family recipe from grandma) and Roasted Chicken with Mediterranean flavors
---
- Audrey loves cooking, trying new recipes, and experimenting in the kitchen
- She finds cooking therapeutic, relaxing, and a form of self-care
- Her favorite recipe is Chicken Pot Pie - it's her family's recipe that's been around for years, reminds her of her grandma's kitchen
- She also loves making Roasted Chicken with Mediterranean flavors (chicken, garlic, lemon, herbs) - her favorite comfort meal
- Garlic is her go-to ingredient - she loves the smell and taste it adds to dishes
- Her cooking style: throws on music, pours wine, and goes with the flow in the kitchen
- She shares recipes with friends and enjoys seeing them try her dishes
