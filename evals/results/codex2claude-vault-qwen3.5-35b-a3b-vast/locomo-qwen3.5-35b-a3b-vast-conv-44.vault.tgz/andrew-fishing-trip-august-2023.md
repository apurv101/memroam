name: Andrew's Fishing Trip - Mid-August 2023
description: Andrew went fishing at a nearby lake with his girlfriend during mid-August 2023; they caught fish and had a great time

---

- Mid-August 2023 (a weekend before August 24, 2023): Andrew and his girlfriend went fishing at one of the nearby lakes
- They caught a few fish
- They had a great time together
- Andrew asked Audrey if she had ever gone fishing
