name: Audrey's Dog Owners Group and Indoor Activities
description: Audrey joined a dog owners group and shares indoor activities to keep dogs mentally stimulated - puzzles, training, hide-and-seek
---
- Early November 2023 (November 4, 2023): Audrey mentioned she recently joined a dog owners group
- Purpose: To learn how to better take care of her dogs and get tips from other owners
- She meets up with other dog owners once a week for:
  - Tips from other dog parents
  - Socializing and playing together
- Audrey shared indoor activities to keep dogs mentally stimulated:
  - Puzzles
  - Training exercises
  - Hide-and-seek games
- Her dogs love all these activities and they help keep them busy indoors
- Andrew expressed interest in trying these activities with Toby and Buddy
