name: Andrew loves nature and hiking
description: Andrew finds peace and joy in visiting forests, parks, and hiking

---

In October 2023, Andrew shared that he misses nature while living in the city. Whenever he can, he tries to:
- Visit nearby parks
- Go on hikes

He described these experiences as peaceful and joyful. Andrew finds places like forests and natural landscapes to be amazing escapes that inspire him.
