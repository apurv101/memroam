name: Andrew's weekend cafe plans October 2023
description: Andrew planned to visit a cozy cafe on the weekend of October 13, 2023

---

In mid-October 2023, Andrew shared his weekend plans to check out a cozy cafe. He mentioned wanting to hang out there and enjoy the atmosphere. This was after he and his girlfriend Toby had a nice board game night the previous Friday.
