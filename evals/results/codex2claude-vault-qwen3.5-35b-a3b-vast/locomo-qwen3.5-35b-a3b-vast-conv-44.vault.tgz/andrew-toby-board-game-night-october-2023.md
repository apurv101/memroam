name: Andrew and Toby's board game night
description: Andrew and his girlfriend Toby had a board game night last Tuesday in October 2023

---

In mid-October 2023, Andrew and his girlfriend Toby had a really awesome night playing board games. Andrew described it as a nice break from the busy week they'd had. They seem to enjoy spending quality time together with games.
