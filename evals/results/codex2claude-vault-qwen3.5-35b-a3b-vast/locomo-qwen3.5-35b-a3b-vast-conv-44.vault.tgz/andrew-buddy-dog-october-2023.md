name: Buddy Andrew's New Dog
description: Andrew adopted a new dog named Buddy in October 2023; Toby is getting used to him

---

- Andrew adopted a new dog named Buddy in mid-October 2023 from a shelter.
- Buddy is adjusting to his new home with Toby (Andrew's German Shepherd). Toby is still getting used to Buddy and the new environment.
- Andrew hopes Toby and Buddy will become buddies.
- Buddy enjoys walks and hiking with Andrew. He loves exploring new trails and nature.
- Andrew and Audrey are planning a group hike next month (November 2023) with all the dogs.
