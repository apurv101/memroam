name: Audrey's Dogs
description: Audrey has four dogs including Pepper, Precious, Panda, and new puppy Pixie

---

- Acquired collars and tags for them. Has had them for 3 years. They're city dogs who enjoy exploring parks and trails on regular adventures.
- Andrew is excited to meet her dogs at the upcoming pastry party.