name: Pixie - Audrey's New Puppy
description: Audrey adopted a new puppy named Pixie who is getting along well with her other dogs

---

Audrey adopted a puppy named Pixie as a surprise for Andrew. Pixie took a few days to get used to the other dogs but now fits in great and they're all friends. Pixie loves playing and exploring. Audrey mentioned puppies take a lot of work and Pixie has been keeping them busy.
