name: Andrew's New Cooking Hobby
description: Andrew started cooking as a new hobby while searching for dog-friendly housing to de-stress and be creative
---
- Andrew got into cooking while he couldn't hike due to housing search challenges
- He's still a rookie but having fun experimenting with new recipes
- He finds cooking enjoyable, de-stressing, creative, and relaxing
- Cooking has become one of his favorite hobbies as it allows him to express creativity and provides an escape
