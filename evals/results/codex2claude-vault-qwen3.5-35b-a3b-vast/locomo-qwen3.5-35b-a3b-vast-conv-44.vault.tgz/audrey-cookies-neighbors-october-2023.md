name: Audrey's cookies for neighbors
description: Audrey baked cookies to thank her neighbors for providing dog-friendly accommodations

---

In October 2023, Audrey baked cookies and shared them with her neighbors as a thank you gesture for keeping their homes pup-friendly. It was a meaningful way for her to bring joy to the community and acknowledge the pet-friendly environment she lives in.
