name: Andrew Adopts Scout the Dog November 2023
description: Andrew adopted a new dog named Scout in November 2023, bringing his total dogs to three

---

- In mid-November 2023, Andrew adopted another dog and named Scout
- The name "Scout" was chosen for the dog's adventurous spirit
- Scout is Andrew's third dog, joining Toby (German Shepherd) and Buddy
- Andrew got essentials for Scout's comfort: a bed, toys, and puppy pads
- Andrew is creating a safe and fun space for Scout to feel secure
- Andrew and his girlfriend are taking great care of their growing family of dogs
