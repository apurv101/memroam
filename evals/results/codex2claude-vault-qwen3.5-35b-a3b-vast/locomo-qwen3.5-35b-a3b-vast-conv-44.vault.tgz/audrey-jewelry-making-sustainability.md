name: Audrey's Jewelry-Making Hobby
description: Audrey makes jewelry from recycled objects like bottle caps, buttons, and broken jewelry as a creative and sustainable hobby she started and now sells
---
- Audrey makes jewelry out of recycled objects as both a creative hobby and a small business
- She hunts down materials like bottle caps, buttons, and broken jewelry to transform into one-of-a-kind pieces
- Each piece holds a special story and has its own unique appeal
- She donates a portion of her profits to an animal shelter close to her heart
- This combines her two passions: making jewelry and making a difference in the world
- Customers enjoy her work and also support a cause they care about
