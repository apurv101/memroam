name: Audrey's Peruvian Lilies and Garden
description: Audrey has a small garden featuring Peruvian Lilies and a veggie patch; she enjoys gardening as it relaxes her and brings peace
---
- Audrey has a small garden she enjoys maintaining
- Her garden features Peruvian Lilies with bright colors and delicate petals
- She also has a veggie patch that's growing well
- She finds gardening relaxing, peaceful, and fulfilling - it feels accomplishing to watch things grow
- Peruvian Lilies are easy to care for - she just waters them and ensures they get enough sun
- Audrey's dogs enjoy playing in the garden, running around and exploring
