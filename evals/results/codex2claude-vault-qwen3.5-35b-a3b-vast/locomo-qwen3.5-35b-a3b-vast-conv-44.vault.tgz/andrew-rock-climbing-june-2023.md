name: Andrew's Rock Climbing Adventure
description: Andrew took a rock climbing class last Sunday and reached the top; he's now hooked on outdoor activities

---

- Last Sunday (5 June 2023), Andrew took a rock climbing class with friends and made it to the top—it was a fantastic experience and now he's hooked.
- Andrew found rock climbing challenging but satisfying, and he felt really proud of himself reaching the top.
- The climb was tricky, especially since he's still a newbie, but he made it with the support and cheers from his friends.
- The view from the top was stunning.
- Andrew is now planning to try more outdoor activities like kayaking and maybe bungee jumping.
- Nature pushes Andrew out of his comfort zone and he enjoys it.
