name: Audrey's four pets
description: Audrey has four pets with distinct personalities
---
Audrey has four pets ("fur babies") that are very important to her. Their personalities are:
1. The oldest one is the most relaxed, like a wise old sage
2. The second one is always ready for a game
3. The third one can be naughty but loves a good cuddle
4. The youngest one is full of life and always up for an adventure