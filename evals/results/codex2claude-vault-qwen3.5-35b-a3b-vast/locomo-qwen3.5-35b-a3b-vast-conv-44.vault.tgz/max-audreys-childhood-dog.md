name: Max Audreys childhood dog
description: Max was Audrey's childhood dog with energetic, playful personality
---
Max was Audrey's childhood dog who had lots of energy and loved playing fetch. They took long neighborhood walks together, and Max would sniff and mark his territory. Audrey grew close to Max, sharing her worries and hopes with him. He was a great listener and always there for her. Those walks in their neighborhood are some of Audrey's favorite childhood memories.