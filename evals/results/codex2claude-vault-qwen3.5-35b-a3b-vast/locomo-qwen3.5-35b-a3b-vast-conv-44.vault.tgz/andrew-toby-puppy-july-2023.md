name: Toby the Puppy
description: Andrew adopted a puppy named Toby in July 2023, who brings joy to Andrew's life despite his busy work schedule

---

- Andrew adopted a puppy named Toby in July 2023 (conversation dated July 11, 2023)
- Toby is described as a "bundle of joy"
- Andrew misses hiking and outdoor activities due to work stress, but having Toby has been a positive addition to his life
- Andrew plans to go hiking next month (August 2023) and invited Audrey and her dogs to join
