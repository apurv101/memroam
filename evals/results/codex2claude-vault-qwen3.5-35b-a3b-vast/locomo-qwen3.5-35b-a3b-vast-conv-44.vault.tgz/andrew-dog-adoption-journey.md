name: Andrew's Dog Adoption Journey
description: Andrew is actively searching for a dog to adopt, visiting shelters, browsing websites, and seeking dog-friendly housing near parks

---

- Andrew has been actively looking for a dog to adopt, browsing websites, visiting shelters, and asking friends for help.
- He values advice about matching dog size and energy level to living space; for apartment living, a smaller dog works well, but active people can consider breeds that love to play and run.
- Andrew is searching for dog-friendly housing near parks or woods to give his future dog space to run around and to stay close to nature.
- Finding pet-friendly housing in the city has been challenging for him.
- Andrew is in close contact with Audrey, who has offered suggestions and support throughout his search.
