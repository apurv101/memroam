name: Andrew's pet shelter volunteering
description: Andrew and his GF volunteered at a pet shelter on a Monday
---
Andrew and his girlfriend had a rewarding experience volunteering at a pet shelter on a Monday. They loved spending time with the animals and found it very rewarding.