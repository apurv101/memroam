name: Audrey's dogs' favorite games
description: Audrey's dogs enjoy fetch, frisbee, and meeting other dogs at the park

---

Audrey's dogs are particularly fond of:
- Fetch
- Frisbee
- Meeting and socializing with other dogs

They have a lot of energy and can keep running and playing for hours. They also love exploring and sniffing around the dog park.
