name: Toby's squirrel chase adventure
description: Toby got excited at the dog park and chased a squirrel around a tree

---

In October 2023, Andrew shared a funny story about his German Shepherd Toby at the dog park. Toby became overly excited and chased a squirrel around a tree. The squirrel simply watched from the safety of the branches while Toby ran around below. Andrew found the situation hilarious.
