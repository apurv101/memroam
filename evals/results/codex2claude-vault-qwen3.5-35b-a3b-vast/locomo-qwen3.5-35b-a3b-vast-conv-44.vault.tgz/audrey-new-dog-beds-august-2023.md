name: Audrey's New Dog Beds
description: Audrey bought new dog beds last week in August 2023; dogs love them, especially when weather cools down

---

- Last week (August 2023), Audrey bought new beds for her four dogs
- Bought them to give the dogs extra comfort as the weather was cooling down
- The dogs absolutely love the beds
- They curl up and snuggle in them like they're in a cloud
- Andrew saw photos of the dogs on their new beds - very cozy and comfy
