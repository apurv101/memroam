name: Audrey's dogs behavior issues October 2023
description: Audrey's dogs weren't acting normally in mid-October; visited animal behaviorist and using positive reinforcement training
---
- In mid-October 2023 (around Wednesday, October 18), Audrey noticed her four dogs weren't acting normally
- She made an appointment with an animal behaviorist to help understand and address their behavior issues
- The behaviorist visit went okay - initially hectic but the behaviorist checked them out and asked questions
- The behaviorist provided tips on how to handle the situation and suggested changes to their routine
- Audrey is using positive reinforcement techniques with her dogs
- The training is still a work in progress, but she's seeing some progress and they seem to be responding well
- Audrey remains devoted to keeping her dogs healthy and happy
