name: Andrew's Hiking Trail - Fox Hollow
description: Andrew hikes at Fox Hollow trail on weekends for great views; plans to hike with Audrey next month

---

⚠ no frontmatter

- Andrew hikes at Fox Hollow trail on weekends for the great views
- Plans to try the trail with Audrey next month (August 2023)
- Andrew shared a map of the trail with Audrey, noting it would be great for dogs
- The trail has lots of trees and would be safe for dogs to run around
- Andrew and Audrey agreed to make sure the trail is safe for dogs before the hike
- Andrew mentioned it's tough to find open areas where dogs can run freely without leashes