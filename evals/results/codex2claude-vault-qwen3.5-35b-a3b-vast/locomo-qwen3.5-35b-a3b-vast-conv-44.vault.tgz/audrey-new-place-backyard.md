name: Audrey's New Place with Backyard
description: Audrey moved to a new house with a bigger backyard specifically for her dogs, including a dedicated doggy play area with agility equipment and toys

---

- Audrey recently moved to a new place with a bigger backyard for her dogs.
- She set up a dedicated doggy play area in the backyard with agility equipment and toys for the dogs.
- The dogs are loving the space to run and explore, sniff out new smells.
- Andrew recommended a doggy daycare near him that has a big indoor space for dogs to play.
