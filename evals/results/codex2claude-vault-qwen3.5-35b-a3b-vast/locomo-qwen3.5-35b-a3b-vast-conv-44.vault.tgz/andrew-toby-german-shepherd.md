name: Toby is a German Shepherd
description: Andrew's dog Toby is a German Shepherd, known for being smart and loyal; Andrew plans to hike with him

---

- Andrew's dog Toby is a German Shepherd, adopted in July 2023
- Toby is described as smart and loyal - typical traits of the breed
- Andrew hopes to take Toby hiking as German Shepherds are good hiking companions
- Andrew wants to build a deep bond with Toby similar to Audrey's connection with her dogs
- Andrew is concerned about not limiting Toby's growth or taking him out too little
- Advice given to Andrew for city-dog ownership: ensure enough time and energy, as German Shepherds need lots of attention and walks to offset their energy
