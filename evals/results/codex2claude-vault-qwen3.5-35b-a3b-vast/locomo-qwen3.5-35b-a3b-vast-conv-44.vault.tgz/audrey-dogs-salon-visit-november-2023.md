name: Audrey's Dogs Salon Visit November 2023
description: Audrey took her dogs to a pet salon on November 17, 2023 - they were excited and looked cute after grooming

---

- On Friday, November 17, 2023, Audrey took her fur kids to a pet salon
- The dogs were psyched and their tails were wagging like crazy
- It took a while for them to calm down after the salon visit
- They looked very cute after their grooming with shiny coats
- Audrey always worries about her dogs in new places, but they were really good at the salon
