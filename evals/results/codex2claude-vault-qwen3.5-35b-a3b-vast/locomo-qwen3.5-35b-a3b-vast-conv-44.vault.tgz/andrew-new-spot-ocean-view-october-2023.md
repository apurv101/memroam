name: Andrew's new spot with ocean view
description: Andrew discovered a new spot with a great view and vibe close to a dog park

---

In October 2023, Andrew discovered a new spot that had opened recently. He described it as having "a sick view and vibe." The location is notable because there's a great dog park nearby, making it potentially accessible for dog owners like Andrew and Audrey. Andrew mentioned wanting to check out a cozy cafe there on the weekend.
