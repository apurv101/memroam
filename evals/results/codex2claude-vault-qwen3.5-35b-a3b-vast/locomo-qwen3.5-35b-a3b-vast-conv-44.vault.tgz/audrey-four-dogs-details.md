name: Audrey's Four Dogs Details
description: Audrey has four dogs - two Jack Russell mixes and two Chihuahua mixes, all 3 years old, named Pepper, Precious, Panda, and Pixie
---
- Audrey has four dogs total, all 3 years old
- Two are Jack Russell mixes and two are Chihuahua mixes (all mutts)
- Their names are Pepper, Precious, Panda, and Pixie
- They're well-loved and make a great pack
- They enjoy running and playing fetch
- They had a doggy playdate on a Friday which was crazy but fun
- Andrew noticed them running in a field with a ball and in a dog bed on a couch
- Audrey describes them as giving her love and happiness, calling them her universe
