name: Audrey's potential future dog tattoo
description: Audrey might get another dog tattoo if she decides to adopt another dog

---

In October 2023, Audrey mentioned that she's satisfied with her current dog tattoos for now, which include her four dogs and sunflowers. However, she expressed that she might get another tattoo if she decides to get another dog someday. This would be a way to commemorate the new addition to her dog family.
