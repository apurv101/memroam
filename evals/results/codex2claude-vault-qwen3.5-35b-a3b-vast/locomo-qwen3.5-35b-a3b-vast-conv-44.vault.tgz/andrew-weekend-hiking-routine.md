name: Andrew's Weekend Hiking Routine
description: Andrew hikes at least once per weekend at a new nearby open space; nature is therapeutic for him and he enjoys sharing the peaceful feeling through photos
---
- Andrew found a new open space nearby for hiking and tries to escape the city at least once a weekend - it's his much-needed break.
- Nature is deeply therapeutic for Andrew. He finds peace and invigoration in greenery and mountain views, and he tries to capture these moments through photography to share the calming feeling with others.
- Andrew enjoys spreading positivity and motivating others to find their own peace - he sees it as a ripple effect of good vibes.
- Andrew took photos during recent hikes including a lake and mountains at sunset, and a mountain range with sunset in the background.
