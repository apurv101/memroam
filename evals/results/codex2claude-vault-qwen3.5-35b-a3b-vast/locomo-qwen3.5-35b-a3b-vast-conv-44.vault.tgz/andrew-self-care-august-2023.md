name: Andrew's Self-Care Activities August 2023
description: Andrew's stress management routine includes morning coffee and lunch walks to recharge during tough work period

---

- Work has been tough and stressful
- Finding balance with outdoor activities has been challenging
- Andrew added simple self-care activities to his day:
  - Grabbing coffee in the morning
  - Going for a walk at lunch
- These small moments help him recharge and chill out
- Animals inspire Andrew - he appreciates how they find joy in simple things
