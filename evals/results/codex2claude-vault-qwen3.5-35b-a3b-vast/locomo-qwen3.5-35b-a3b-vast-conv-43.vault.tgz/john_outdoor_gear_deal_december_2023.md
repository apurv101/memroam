name: John's outdoor gear company deal
description: John signed a deal with a renowned outdoor gear company and completed a forest photoshoot in December 2023

---

# John's Outdoor Gear Deal (December 2023)

**Timeline:** Late December 2023 (deal signed "last week" before December 19, 2023)

- Signed a deal with a renowned outdoor gear company
- The deal involved hiking and outdoor gear
- Photoshoot took place in a gorgeous forest location
- The photoshoot went really well
- Photographer captured shots of John doing outdoor activities
- John described the experience as "amazing"

**Notes:** This is separate from his mid-July 2023 Nike shoe/gear deal. Represents another endorsement opportunity in the outdoor/sports gear space.
