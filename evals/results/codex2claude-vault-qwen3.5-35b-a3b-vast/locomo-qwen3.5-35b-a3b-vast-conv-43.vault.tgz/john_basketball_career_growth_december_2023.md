name: John's basketball career and endorsements
description: John playing pro basketball under a year, getting endorsements and marketing himself
---
# John's Basketball Career Growth (December 2023)
- John has been playing professionally for just under a year
- Described it as a wild ride that's been great
- On the court: improving overall game
- Off the court: got endorsement deals
- Learning to market himself and boost his brand
- Finds it rewarding to see all areas progress
