name: Tim joins travel club
description: Tim joined a travel club interested in different cultures and countries
---
# Tim's Travel Club (December 2023)
- Tim joined a travel club in early December 2023
- He shared a photo of a map of Westendell on a wall
- Tim has always been interested in different cultures and countries
- He's excited to meet new people and learn about what makes them unique
