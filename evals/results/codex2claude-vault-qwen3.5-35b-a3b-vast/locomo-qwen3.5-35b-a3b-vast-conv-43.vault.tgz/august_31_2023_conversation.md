name: August 31, 2023 conversation
description: Tim shared job rejection and first class presentation; John's soup cooking; Tim's Universal Studios trip plans; John's NYC subway experience
---

## Tim's updates (August 31, 2023)
- **Job rejection**: Tim didn't get a summer job he wanted, which was disappointing but he's staying positive
- **Class presentation**: Gave a presentation in class yesterday; was nervous but considers it progress and a small win
- **Universal Studios trip**: Planning to visit Universal Studios next month (September 2023) for the first time; especially excited about the Harry Potter attractions
- **Cooking interest**: Enjoys experimenting with spices

## John's updates (August 31, 2023)
- **Soup cooking**: Made a butternut squash soup recently with sage; improvised the recipe rather than following one
- **NYC trip**: Had some initial trouble navigating the subway during his NYC trip, but figured it out after someone helped explain it

## Conversation highlights
- Mutual encouragement around personal challenges and achievements
- Tim appreciates John's encouragement about the job rejection
- Both expressed excitement about their respective upcoming plans
