name: Autographed basketball friendship gift
description: John received an autographed basketball from teammates as a symbol of friendship

---

John's teammates gave him an autographed basketball when they reconnected on August 15, 2023. The ball serves as:
- A sign of their friendship and all the love they have for each other
- A reminder of their bond and the support from teammates
- A connection to why John started playing basketball and his journey
- A source of motivation to stay strong and give his all

John shared a photo of the autographed basketball sitting on a table with Tim during their conversation.
