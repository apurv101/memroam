name: John's team motivation strategies
description: John's advice on motivating teammates and creating positive team environment
---
# John's Team Motivation Strategies (December 2023)
When motivating others on his basketball team, John believes in:
- Showing care for teammates
- Celebrating their achievements
- Providing constructive feedback
- Reminding them of the bigger goal
- Creating a positive environment
- Giving pep talks before games
- Using personal experiences to inspire others
- Setting an example by working hard
