name: Tim's interests and collection
description: Tim is passionate about fantasy literature, has a bookshelf collection, and writes articles for an online magazine; owns a MinaLima picture from the Harry Potter films; is a hiking club member and Minnesota Timberwolves fan

---

Tim is a fantasy literature enthusiast who joined a fantasy literature forum. He has a substantial book collection and keeps a picture from MinaLima—the design studio that created props for the Harry Potter films—on his bookshelf. This serves as a reminder and escape for him. He plans to visit more Harry Potter-related places in the future.

**Harry Potter fandom (October 2023):**
- Tim owns a MinaLima picture from the Harry Potter films on his bookshelf
- Plans to visit more Harry Potter-related places in the future
- Attended a UK Harry Potter conference in early October 2023, describing it as "incredible" and like a "magical family"
- The conference made him feel inspired and connected to fantasy fans worldwide
- Has a Harry Potter-themed Christmas tree and plays Harry Potter themes on piano

**Writing for an online magazine (August 2023):**
- Discovered a writing opportunity on a fantasy lit forum
- Shared his article ideas with the magazine and they accepted them
- Is writing articles about different fantasy novels, studying characters, themes, and making book recommendations
- Finds it rewarding to spread his love of fantasy through writing
- Favorite books to write about include Harry Potter and Game of Thrones

**Hiking club and basketball (October 2023):**
- Tim joined a hiking club
- Supports the Minnesota Timberwolves and admires LeBron James for his skills and leadership
