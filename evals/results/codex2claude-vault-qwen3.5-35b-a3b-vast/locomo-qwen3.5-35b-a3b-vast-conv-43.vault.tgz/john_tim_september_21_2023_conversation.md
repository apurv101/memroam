name: John-Tim September 2023 conversation
description: John and Tim discuss John's team trip plans, Edinburgh suggestion, and book recommendations

---

On September 21, 2023, John and Tim had a conversation about:

**Team Trip Planning:**
- John and his new teammates are planning a team trip for October 2023
- They're exploring destinations together
- Tim recommended Edinburgh, Scotland with a photo showing a city clock tower at sunset

**Edinburgh Recommendation:**
- Tim suggested Edinburgh as having a "magical vibe"
- Noted it's the birthplace of Harry Potter
- Highlighted the city's history and architecture
- John found it to be a worthy consideration

**Book Recommendations:**
- John asked for book recommendations for the trip
- Tim recommended a fantasy novel by Patrick Rothfuss
- John shared a photo of his bookshelf
- Both John and Tim enjoy "The Alchemist" by Paulo Coelho

**Basketball Career Context:**
- John continues playing professional basketball
- Focusing on improving shooting and being a consistent performer
- Looking into endorsements and building his brand
- Considering life after basketball, including starting a foundation and doing charity work
