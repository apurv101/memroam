name: John and Tim October 17, 2023 conversation
description: John shares his experience mentoring younger basketball players; Tim shares a sunset photo from the Smoky Mountains; discussion about reading books
---
John and Tim caught up on October 17, 2023:

**John's mentoring role:**
- John is now mentoring younger players on his team
- Finds it rewarding to share skills and knowledge
- Mentoring helps him stay involved in the game during off-season
- Challenges include adapting to different personalities, but finds it fulfilling to watch them develop and reach goals
- Some players see him as a mentor; he provides advice and support on and off the court
- Enjoys being a positive role model

**Tim's photo:**
- Shared a sunset photo over a mountain range with trees
- Took the photo during a trip to the Smoky Mountains last year (2022)
- John appreciated the photo

**Reading discussion:**
- Tim is reading books alongside school studies, finding a good balance
- Tim was reading a book John mentioned and got hooked on it
- John hasn't had much time to read but picked up a book after their previous conversation and has been enjoying it
