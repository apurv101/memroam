name: John's basketball team involvement
description: John actively plays on a basketball team, attends team dinners and outings to build unity and camaraderie

John is an active member of a basketball team. He participates in regular games and practices with them. The team has strong bonds - they have team dinners, outings, and games together. John values the camaraderie they build both on and off the court. The team recently played against a top team in a tough game and won. This team involvement is an ongoing part of John's life as of December 2023.
