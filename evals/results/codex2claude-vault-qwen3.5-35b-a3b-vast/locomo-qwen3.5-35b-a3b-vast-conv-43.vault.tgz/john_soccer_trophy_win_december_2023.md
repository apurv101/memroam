name: John's soccer trophy win
description: John shared a photo of a trophy he won after dedication and effort
---
# John's Trophy Win (December 2023)
- John won a trophy after putting in significant time and energy
- He shared a photo of himself sitting on the ground with the trophy
- John reflected that it feels great to achieve something after dedication and effort
- He emphasized that it's all about dedication and effort
