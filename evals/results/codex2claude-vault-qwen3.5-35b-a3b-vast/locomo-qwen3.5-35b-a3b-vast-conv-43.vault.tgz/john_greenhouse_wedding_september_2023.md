name: John's greenhouse wedding
description: John had a small intimate wedding ceremony in a greenhouse venue during COVID-19 safety protocols, with special moments like his bride walking down the aisle and candlelit first dance

---

John and his girlfriend got married last week of September 2023 in a greenhouse venue. The ceremony was smaller and more intimate due to the times, following COVID safety protocols.

Key moments:
- Seeing his bride walking down the aisle with her face lit up - described as a magical, emotional moment
- First dance at a cozy restaurant with music and candlelight
- Even friends from his hiking club attended, even though John had only just joined

Tim shared photos of his bookshelf (filled with fantasy novels) during the conversation, and John shared photos of his basketball jersey collection.
