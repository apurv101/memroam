name: Tim's reading interests - The Wheel of Time and travel stories
description: Tim watches The Wheel of Time; reads travel stories book about Himalayas trek

**Date:** December 2023

**The Wheel of Time:**
- Tim is excited about the new TV series coming out in January 2024
- Based on a book series he loves
- Likes seeing books come to life on screen

**Travel stories book:**
- Found a book with travel stories from around the world
- Uses it to plan his next adventure
- Read a story about two hikers who trekked through the Himalayas
- The trek was described as tough but worth it - challenging terrain, altitude sickness, bad weather
- The amazing sights and story motivated him

**Related interests:**
- Visited a travel agency to see requirements for his dream trip
- Member of a hiking club
- Passionate about fantasy literature and adventure stories

---

**Conversation context:** Tim and John, December 26, 2023
