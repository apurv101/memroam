name: John's basketball win and injury recovery - December 16, 2023
description: John won a close basketball game, discussed foot injury and recovery with PT exercises
---
# John's Basketball Win and Injury Recovery (December 16, 2023)

## Recent Basketball Win
- John's team had an intense game against another team last week
- Game was close until the final buzzer
- They won in the end - John described it as "really close, but we made it"
- Winning was "such a thrill" and "an awesome moment"
- These experiences make John love the game even more

## Foot Injury
- John injured his foot not too long ago
- Had to miss some games and couldn't help his team
- The injury "sucked" because of the impact on his team

## Recovery Progress
- Doing physical therapy exercises every day
- Working with a blue ball for rehab exercises (shared photo)
- Last Friday (December 8) had a milestone moment at the gym
- Was able to jog a bit with no pain - "huge success" after being out so long
- Recovery is "going great" and "paying off" from hard work

## Celebration
- John and his wife hosted a small get-together with friends and family
- Celebrated the jogging milestone
- It was good to see everyone again and they "had a ton of fun"

## Personal Photos Shared
1. Women's basketball players holding up a trophy (team win)
2. Basketball hoop at sunset with fence (morning workout spot - reminder that journey can be awesome)
3. Person with cast on foot (the injury)
4. Man sitting on chair with blue ball (PT exercises)
5. Treadmill in room with window (gym/rehab)

## Lessons and Insights
- Staying positive and keeping pushing is key during recovery
- Support from friends and family during tough times
- Small milestones (like jogging without pain) can be huge successes
- Journey and effort make the tough times worth it
