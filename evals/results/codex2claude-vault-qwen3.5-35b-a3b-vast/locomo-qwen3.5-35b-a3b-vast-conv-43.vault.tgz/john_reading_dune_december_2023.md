name: John reading Dune
description: John is currently reading "Dune" by Frank Herbert, a story about religion and human control over ecology

As of December 8, 2023, John is reading "Dune" by Frank Herbert. He describes it as a great story about religion and human control over ecology and highly recommends it.
