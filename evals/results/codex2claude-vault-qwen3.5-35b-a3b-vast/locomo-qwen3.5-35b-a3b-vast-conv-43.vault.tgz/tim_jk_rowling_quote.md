name: Tim's J.K. Rowling quote
description: Tim's favorite J.K. Rowling quote about finding happiness in dark times
---
Tim shared this favorite J.K. Rowling quote:

"Turn on the light - happiness hides in the darkest of times."

He uses this quote to keep hope alive during tough times. Tim has been reading J.K. Rowling's works for a long time and finds her writing inspiring for his own fantasy novel.
