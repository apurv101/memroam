name: Tim's book interests
description: Tim is interested in books about friendship and loyalty, owns a book collection, recently read A Dance with Dragons

Tim has a strong interest in books. As of December 8, 2023, he just finished reading "A Dance with Dragons" by George R.R. Martin (one of the books in the Game of Thrones series - he's read all of the GoT series). He was reading a series about the power of friendship and loyalty. He has a collection of books as shown in a photo from November 2023.
