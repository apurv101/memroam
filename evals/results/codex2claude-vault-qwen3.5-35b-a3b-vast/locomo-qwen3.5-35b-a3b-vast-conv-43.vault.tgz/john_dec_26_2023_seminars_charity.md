name: John's December 2023 seminars and youth sports charity work
description: John conducted sports/fitness seminars and runs youth sports charity camp

**Date:** December 2023

**Key activities:**
- Started doing seminars to help people with sports and marketing
- Seminars went very well; aspiring pros were eager and motivated
- Supporting youth sports and fighting for fair chances in underserved communities
- Collaborating with organizations to create more opportunities for young athletes
- Organized a basketball camp for kids in his hometown last summer
- Uses influence and resources to help causes he believes in
- Believes every kid should have access to good sports programs

**Quote:** "It's amazing to see the difference sports make in people's lives."

---

**Conversation context:** John and Tim, December 26, 2023
