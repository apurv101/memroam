name: John's Chicago trip and lucky shoes - August 2023
description: John visited Chicago, praised the energy and friendly locals; owns lucky basketball shoes that symbolize his journey and resilience.

---

## John's Chicago trip (early August 2023)
- Took a trip to Chicago which he described as "amazing"
- Praised the city's energy and the friendliness of locals
- Enjoyed experiencing the culture and connecting with new people

## John's lucky basketball shoes
- Owns a pair of lucky basketball shoes kept in their original box
- Has had them since the beginning of his basketball journey
- Every mark on the shoes represents a story from his career
- The shoes symbolize resilience, determination, and his love for the game
- They remind him of his achievements and how far he's come
- Kept them through both successes and failures

## John's basketball career path
- Started playing basketball as a child, watching NBA games with his dad
- At age 10, his dad signed him up for a local league
- Played continuously through middle and high school
- Earned a college scholarship after high school
- Was drafted by an NBA team after college - "his dream come true"

## John's charity work plans (August 2023)
- Goal: Make a difference off the court through charity and inspiring others
- Teaming up with a local organization to help disadvantaged kids
- Focus areas: sports and school support for disadvantaged youth
- Hopes to use his platform to have a positive community impact
- Wants to inspire others through his charity work

## Topics discussed with Tim
- John compared Chicago's energy to being in a stadium during a game
- Both value the special connection fans feel at live sporting events
- Tim recommended "The Name of the Wind" by Patrick Rothfuss (fantasy novel about a magician and musician protagonist with strong world-building and character development)
- John added the book to his reading list
