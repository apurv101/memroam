name: John and Tim October 21, 2023 conversation
description: John and Tim discuss UK castles, Tim's fantasy writing, J.K. Rowling inspiration, John's cooking and motivational strategies
---
John and Tim caught up on October 21, 2023:

**Tim's fantasy writing:**
- Currently in the middle of writing a fantasy novel
- Finds it nerve-wracking but exciting
- Reading about castles in the UK gave him loads of ideas for his writing
- J.K. Rowling is a major source of inspiration for his work
- Has been reading her works for a long time
- Takes notes on her style for his own writing
- Admires her detail, creative storytelling, and ability to transport readers

**Favorite quote shared:**
- Tim shared J.K. Rowling quote: "Turn on the light - happiness hides in the darkest of times"
- Uses this quote to keep hope alive during tough times

**John's motivational strategies:**
- Has a whiteboard with motivational quotes and strategies for workouts
- Has a plaque on his desk that says "make it happen"
- Physical reminders help him trust his abilities and face obstacles

**John's soccer support network:**
- Teammates believe in him and support him even when he makes mistakes
- Love for improving skills keeps him going during tough times
- Team is like his second family

**John's cooking:**
- Cooking is therapy and a way to be creative
- Makes honey garlic chicken with roasted vegetables frequently
- Uses slow cooker for meals
- Always trying new recipes

**Tim's hobbies:**
- Enjoys road trips with friends and family
- Loves hiking and exploring
- Plays board games
- Enjoys curling up with books in free time
