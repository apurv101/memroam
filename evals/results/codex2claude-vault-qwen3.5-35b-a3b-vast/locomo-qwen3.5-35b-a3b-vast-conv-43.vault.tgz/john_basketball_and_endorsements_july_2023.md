name: Basketball achievements and endorsements
description: John scored 40 points (personal best), signed Nike shoe/gear deal, in talks with Gatorade and interested in Under Armour, has been surfing for 5 years.

---

In mid-July 2023, John had a major basketball milestone, scoring 40 points in a game - his highest ever. The experience was incredible, with electric atmosphere, and his team pulled off a tough win. They celebrated afterward at a restaurant, laughing and reliving the intense moments.

**Endorsement deals and networking:**
- Signed a Nike deal for basketball shoes and gear
- In talks with Gatorade for potential sponsorship
- Has always liked Under Armour and would love to work with them
- Uses contacts in the basketball industry and his marketing skills to make connections
- Networking has been key to securing these deals

**Seattle connection:**
- Heading to Seattle for a game next month (mid-August 2023)
- One of his favorite cities to explore - finds it vibrant
- Loves the city's energy, diversity, and food
- Looking forward to trying local seafood in Seattle

**Surfing:**
- Started surfing five years ago
- Loves the connection to nature that surfing provides
- Had an awesome summer with friends surfing and riding waves
- Finds being out in the water exciting and free-feeling
- Appreciates the ocean and nature

**Personal philosophy:**
- Believes being surrounded by passionate teammates creates a strong bond, like a second family
- Pushes each other to be their best
- Finds that moments of happiness and freedom are amazing
