name: John's Harry Potter trivia contest experience
description: John won a signed book prize at a charity event's Harry Potter trivia contest with Anthony in July 2023.

---

In July 2023, John attended a charity event with Anthony where they unexpectedly entered a Harry Potter trivia contest. While they did alright, there was one "super-nerd" competitor who really dominated. John emerged from the contest with a prize—a signed book featuring a picture of a person holding a bookmark, which he showed to Tim during their August 2, 2023 conversation.

John has fond memories of Tim's enthusiasm for Harry Potter and shared this story as a way to connect over their shared interest in the series.