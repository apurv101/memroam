name: John's new gym and strength training routine
description: John started training at a new gym with a basketball court; added strength training to improve his basketball performance.

---

## John's new gym (August 2023)
- Found a new gym to stay on his basketball game
- The gym has a basketball court
- Finding the right spot was challenging but worth it

## Strength training integration
- Added strength training to his routine through trial and error
- Created a schedule balancing basketball work with strength training
- Listens to his body and prioritizes rest
- Gives himself enough recovery to push during practice

## Impact on basketball performance
- Improved shooting accuracy
- Enhanced agility and speed
- Became more explosive on the court
- Gained an edge over opponents
- Boosted confidence to handle any challenge
- Overall athleticism improved

## Family time
- Family gets together regularly
- Values family moments and time with loved ones
