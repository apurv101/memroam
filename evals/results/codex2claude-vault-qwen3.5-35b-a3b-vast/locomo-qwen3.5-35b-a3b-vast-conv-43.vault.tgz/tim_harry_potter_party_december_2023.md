name: Tim's Harry Potter fandom
description: Tim attended a Harry Potter party in December 2023, wearing a Gryffindor scarf and enjoying the themed experience

Tim is a Harry Potter fan. On or before December 8, 2023, he attended a Harry Potter party where he didn't dress as a character but wore his Gryffindor scarf. He enjoyed meeting other fans and had a great time at the themed event.
