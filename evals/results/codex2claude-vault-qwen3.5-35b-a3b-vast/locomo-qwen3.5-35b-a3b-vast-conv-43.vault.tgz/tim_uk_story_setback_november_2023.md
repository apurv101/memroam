name: Tim's UK story-writing setback
description: Tim wrote a story based on his UK experiences that didn't go as planned, leading him to reflect on using lessons from setbacks to improve his storytelling
---

## Story Writing Setback (November 2023)

Tim attempted to write a story based on his experiences in the UK, but it did not go the way he wanted. This was a frustrating setback for him.

## Key Lesson: Reflection and Improvement

Tim discussed with John his approach to overcoming the writing setback:
- Reflecting on what went wrong with the story
- Finding ways to improve from the experience
- Applying a growth mindset similar to John's approach to basketball challenges

Tim recognized that looking back at mistakes and using them as learning opportunities could help him get back on track with his storytelling.

## Connection to Broader Philosophy

This aligns with Tim's overall approach to personal growth:
- Both friends use reflection on mistakes as a path to improvement
- They emphasize patience, perseverance, and owning up to mistakes
- Love and passion for their respective pursuits (writing/reading for Tim, basketball for John) keeps them motivated during tough times
