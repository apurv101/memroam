name: Nate and Joanna conversation - October 21, 2022
description: Joanna shares writing rejection and resilience; Nate discusses tournament stress and turtle hobby; backstory about the dog Tilly
---

Nate and Joanna caught up after not seeing each other lately. Joanna shared that she'd been revising and perfecting a recipe for her family that turned out tasty. Nate mentioned he's been stressed about his tournament progress with tough competitors, but his turtles always cheer him up.

Joanna shared a photo of her cat and mentioned she still has the stuffed animal dog Nate gave her on May 25, 2022. She explained she named it "Tilly" after a real dog she used to have in Michigan. They had to get rid of that dog because Joanna got allergic and couldn't hold or squeeze animals without an allergic reaction anymore. The stuffed animal helps her remember that dog and brings her joy and focus while she writes.

Nate admitted he's not sure he'll ever understand why watching his turtles slowly walk around makes him so happy, but he's glad it does.

Joanna then shared she'd had another setback - a rejection from a production company. This was for the screenplay she sent to a film contest. Nate offered encouragement, reminding her that rejections don't define her. Joanna acknowledged it's hard but said she won't let it slow her down, and she's going to keep grinding and moving ahead. Nate expressed how much he respects her ability to bounce back whenever something sad happens, reminding her she has people cheering her on.

## Key Facts

### Joanna
- **Writer** - actively pursuing film/TV opportunities
- **Another production company rejection (October 2022)** - specifically from a screenplay submitted to a film contest
- **Resilient despite setbacks** - determined to keep grinding and moving forward despite rejections
- **Named stuffed animal "Tilly"** - after a real dog from Michigan she had to give up due to allergies
- **Allergic to furry animals** - can't hold or squeeze animals without allergic reaction anymore
- **Gets focused and joyful from the Tilly stuffed animal while writing**

### Nate
- **Stressed about video game tournament progress (October 2022)** - dealing with tough competitors
- **Enjoys watching his turtles walk around** - finds it happily therapeutic even though he doesn't fully understand why
- **Supportive of Joanna** - encourages her when she faces setbacks, respects her resilience

## Shared Interests & Themes
- Pets and their emotional impact on people
- Finding joy in small things (turtles, stuffed animals)
- Creative pursuits and facing rejection (Joanna's writing)
- Competition and gaming (Nate's tournaments)
- Mutual encouragement and support in friendship

## Continuation
- Previous: [October 9, 2022 conversation](nate_joanna_october_9_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
