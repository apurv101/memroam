name: Nate and Joanna conversation - November 7, 2022
description: Nate wins Valorant tournament; Joanna finishes producer presentation and is writing a love story script inspired by a dream

November 7, 2022 - Nate and Joanna discussed:

**Nate's Gaming Achievement:**
- Won a big Valorant tournament final on Saturday, November 5th - was champion
- Described it as "the best feeling to see my name as the champion"
- Tournaments bring out strong emotions in him
- Currently preparing for other tournaments, loving the busy schedule
- Has a dedicated gaming setup with computer, two monitors, laptop, headphones, and controller - uses this to practice and compete

**Nate's Pets:**
- Has turtles that bring him joy - watching them is calming and fascinating
- Grown very fond of them
- Took them to the park recently - seeing their happy faces made it memorable

**Nate's Gaming Interests:**
- Playing "Xenoblade Chronicles" (fantasy RPG) - currently enjoying it
- Big Nintendo fan
- Friends recommended the game and it fit his taste well

**Joanna's Career:**
- Finished presentation for producers last Friday, November 4th - tough but looking good
- Writing another movie script - a love story with lots of challenges
- Idea came from a dream
- Put lots of hard work into her scripts
- Submitted a few more scripts last week (early November) - hoping to hear back, aiming for her 3rd published movie

**Joanna's Writing:**
- Writing has always been a passion of hers
- Creating stories and watching them come alive gives her happiness and fulfillment
- Writing has been a blessing for her

**Childhood & Memories:**
- Joanna's brother used to make her cute notes when they were kids
- She included a handwritten letter (reminding her of those notes) in the intro to her next movie script
- Has childhood photos - two little girls in pink dresses standing in front of a castle
- Joanna writes down her favorite memories
- Nate took his turtles to the park - mixing new with old memories is priceless
- Joanna encourages Nate to write down his favorite memories (including things his animals like)
- Nate plans to start writing down memories he shares with Joanna

**Shared Values:**
- Both feel grateful for jobs/passions they enjoy
- Support each other's dreams and encourage reaching for them
- Nate appreciates Joanna's movie recommendations - usually likes them more than random picks