name: Nate and Joanna - August 22, 2022
description: Nate mentions winning an international gaming tournament and making a living from gaming; Joanna shares positive feedback from her writers group; they exchange book recommendations

Nate and Joanna continue their conversation about their passions and work.

Nate shares that he won an international gaming tournament and is making a living from gaming. He also shows off a new fish tank for his pets.

Joanna mentions she was nervous about sharing her book with her writers group but received great feedback, which felt rewarding. She celebrates with dessert.

They discuss the importance of taking breaks for mental health and inspiration. Nate asks for book recommendations, and Joanna suggests a fantasy series. Nate shows a series he's reading and recommends another one to Joanna with "awesome battles and interesting characters."

Joanna agrees to check out Nate's recommended series.