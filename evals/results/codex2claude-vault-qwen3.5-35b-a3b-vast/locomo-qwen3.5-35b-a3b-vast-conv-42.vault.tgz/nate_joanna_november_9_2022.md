---
id: 01a05089-b17f-7c71-abae-0122709df4a1
name: Nate and Joanna conversation - November 9, 2022
description: Nate made coconut ice cream, didn't make tournament finals, creating YouTube gaming content; Joanna pitched a script to producers, writing a suspense thriller, took a sunset photo on a hike; Nate added a third turtle to his collection.
---

**Nate's updates:**
- Game tournament got pushed back, didn't make it to finals
- Trying out cooking - made homemade coconut ice cream (sprinkles changed the color)
- Getting offers from new gaming teams, thinking about joining one after next tourney
- Starting a new YouTube channel for gaming content
- Got a third turtle - saw another at a pet store, tank is big enough now for three

**Joanna's updates:**
- Worked on another script and created a plan for getting it made into a movie
- Pitched it to some producers yesterday, they really liked it
- Feeling confident and can't stop writing
- Working on a new project - a suspenseful thriller set in a small Midwestern town
- Took a sunset photo on a hike last summer near Fort Wayne

**Plans:**
- Joanna invited over to visit sometime (she's allergic to turtles, will watch from a distance)
- Nate to give turtles a bath before she comes over
- Maybe watch one of Joanna's movies together or go to the park

**Personal details:**
- Nate has a tank with three turtles now
- Joanna is allergic to turtles
- Joanna took a photo of a sunset near Fort Wayne last summer