name: Nate and Joanna conversation - January 21, 2022 (Part 2)
description: Joanna submitted screenplay to film festival; Nate made dairy-free coconut milk ice cream; Little Women recommendation

---

## Participants
- **Nate**: Creates dairy-free desserts, enjoys ice cream and cake
- **Joanna**: Writer who submitted screenplay to film festival

## Key Facts

### Joanna
- Submitted screenplay to film festival (exact date unknown, recent)
- Experienced strong emotions: relief, excitement, worry
- Hopes a producer or director will love it and get it made
- Just watched "Little Women" and highly recommends it
  - Described it as a great story about sisterhood, love, and reaching for dreams
  - Called it a "must-see"

### Nate
- Discovered he can make coconut milk ice cream at home
- Made it and found it "pretty good" and "super good"
- Described it as rich and creamy - might be his new favorite snack
- Plans to try different flavors and toppings
- Favorite dairy-free flavors: coconut milk, chocolate, mixed berry
- Made a dairy-free chocolate cake with berries the other day
- Hadn't seen any recent movies
- Accepted "Little Women" recommendation to add to watchlist

## Shared Interests
- Both enjoy experimenting with dairy-free desserts
- Nate's cooking skills impressed Joanna
- Joanna interested in trying dairy-free flavors

## Continuation
- [January 21, 2022 conversation](../nate_joanna_january_21_2022.md) - Nate won CS:GO tournament; movie preferences
- [January 23, 2022 conversation](../nate_joanna_january_23_2022.md) - Joanna finished screenplay; Nate's turtles
