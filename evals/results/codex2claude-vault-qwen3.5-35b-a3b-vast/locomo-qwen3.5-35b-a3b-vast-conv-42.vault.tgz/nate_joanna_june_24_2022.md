name: Nate and Joanna conversation - June 24, 2022
description: Gaming party success, screenplay contest submission, and vegan ice cream recipe exchange

---

## Conversation Summary

Joanna and Nate caught up after some time apart. Joanna shared that she had just submitted her recent screenplay to a film contest to get feedback. Nate celebrated this and shared about his successful gaming party where 7 people attended, with 6 expressing interest in doing it again next month. He mentioned friends enjoyed controller accessories as party favors. Nate also shared that he made vegan ice cream on Friday and enjoyed sharing it with his vegan diet group. Joanna asked for the recipe, planning to make it for her family that weekend. Nate offered to share the recipe the next day.

## Key Facts

### Nate
- Hosted a gaming party that was a great success
- 7 people attended the party, 6 said they'd want to do it again next month
- Gave friends controller accessories as party favors
- Made vegan ice cream on Friday, shared with vegan diet group
- Offered to share vegan ice cream recipe with Joanna

### Joanna
- Submitted her recent screenplay to a film contest
- Excited to get feedback on her work
- Plans to make Nate's vegan ice cream recipe for her family that weekend
- Appreciates Nate's support

## Shared Interests & Themes
- Creative pursuits and mutual encouragement (Joanna's screenplay)
- Social gatherings and community (Nate's gaming party)
- Vegan diet and cooking
- Supportive friendship and celebration of each other's activities

## Continuation
- Previous: [June 5, 2022 conversation](nate_joanna_june_5_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
