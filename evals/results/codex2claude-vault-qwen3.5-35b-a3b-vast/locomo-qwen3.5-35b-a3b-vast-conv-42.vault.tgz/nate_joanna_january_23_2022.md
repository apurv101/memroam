name: Nate and Joanna conversation - January 23, 2022
description: Joanna finished her screenplay; Nate's turtles as stress relief; Joanna's allergies

---

## Participants
- **Nate**: Video game enthusiast, has pet turtles for stress relief, plays in tournaments
- **Joanna**: Writer, finished her first screenplay, allergic to reptiles and furry animals

## Key Facts

### Joanna
- Finished her first full screenplay on Friday, January 21, 2022
- Genre: Drama and romance mix
- Printed the screenplay on January 21, 2022
- Plans to submit it to film festivals and seek producers/directors
- Feels a rollercoaster of emotions: relief, excitement, anxiety about finishing
- Bad allergies to reptiles and animals with fur (face gets puffy and itchy)
- Joys: writing (helps express feelings, create wild worlds with characters) and hanging with friends

### Nate
- Has two turtles (a turtle and a "turtleling") for 3 years
- Turtles help keep him calm during stressful or important times
- Turtles have big personalities and bring him tons of joy
- Recommends having pets/stress-relief things for times of stress
- Started hanging out with people outside his circle at tournaments
- Tournament approach: plays for fun, doesn't expect to win big, cheers on other competitors

## New Information from Previous Session
- Nate won his first CS:GO tournament in January 2022
- Both enjoy watching movies with different genre preferences (from Jan 21 conversation)
