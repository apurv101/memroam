name: Nate and Joanna conversation - April 21, 2022
description: Joanna joined a writers group and working on "Finding Home" script; Nate in 4th gaming tournament; discussed acting, books, and shared photos

---

## Conversation Summary
Joanna and Nate caught up after not talking for a while. Joanna shared exciting news about joining a writers group and her current project "Finding Home" - a script about a girl's journey to find her true home. They discussed their respective creative pursuits, with Joanna focusing on writing (her former passion was acting) and Nate preparing for his 4th gaming tournament. They shared personal photos and discussed their media preferences - Joanna enjoys dramas and emotionally-driven films, while Nate loves fantasy and sci-fi. Nate shared photos of books he enjoys, including a trilogy and another series with adventures and magic.

## Key Facts

### Joanna
- Just joined a writers group in the week leading up to April 21, 2022
- Finding the group "unbelievable" with inspirational people who support her writing
- Feeling motivated and like she finally belongs somewhere
- Working on a script called "Finding Home" about a girl's journey to find her true home
- Describes the project as rewarding and emotional
- Acting was her first passion, but she now shines in writing
- Considers herself more of a writer currently but open to possibly acting again someday
- Enjoys dramas and emotionally-driven films
- Had her first play where she forgot her lines early in her acting career - embarrassing but taught her the importance of preparation and staying in the moment
- Hasn't read the book series Nate recommended yet - plans to check it out

### Nate
- Has a gaming tournament next month - it will be his 4th one
- Feeling good about the upcoming tournament
- Loves fantasy and sci-fi movies for world-building, battles, and storytelling
- Plays video games as a way to express creativity and passion
- Enjoys book series with adventures, magic, and great characters
- Had a trilogy he considers one of his favorites - impressed by world-building, battles, and storytelling
- Shares photos regularly (notebook/creativity, food, turtles, xbox controller, books)

## Shared Interests & Themes
- Creative pursuits and self-expression
- Writing and storytelling (Joanna's current focus)
- Acting/performance (Joanna's former passion)
- Gaming and video games (Nate's passion)
- Books and reading (both enjoy)
- Sharing photos to enhance conversations
- Fantasy and sci-fi (Nate), dramas/emotional films (Joanna)
- Warm, supportive friendship where they celebrate each other's endeavors

## Relationships & Dynamics
- Longtime friends catching up regularly
- Mutually supportive and interested in each other's lives
- Share personal experiences and photos openly
- Exchange recommendations (books, etc.)
- Both pursue creative passions and encourage each other

## Continuation
- Previous: [April 17, 2022 conversation](nate_joanna_april_17_2022.md)
- [Memory Index](MEMORY.md)
