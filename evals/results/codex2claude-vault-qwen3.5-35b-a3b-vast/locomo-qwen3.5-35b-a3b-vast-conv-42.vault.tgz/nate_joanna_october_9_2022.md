name: Nate and Joanna conversation - October 9, 2022
description: Nate shares his game convention experience and new board game friends; they discuss favorite movies and living room comfort tips
---

Nate and Joanna caught up after a couple days. Nate shared about attending a game convention last Friday where he met new people outside his normal circle. While initially overwhelming, he found it rewarding and reconnected with the good times gaming brings. He made friends at the convention who share his love of games and they already planned a gaming session together.

Joanna encouraged Nate about stepping outside his comfort zone. Nate shared photos from the convention including people in costumes and a group playing Catan - a strategy board game where you build settlements and trade resources. Nate explained he doesn't get crazy competitive over games since they're his escape from life struggles, and the convention group was the same way.

Nate mentioned he mostly chills at home playing video games or watching movies. He recently watched "Inception" which blew his mind with twists and dream stuff, and has been playing "Cyberpunk 2077" nonstop for its futuristic setting and gameplay.

Joanna shared watching a classic movie with a gripping story and great actors that she rated 9-10/10. Nate explained movies take him to new worlds and fill him with emotions, plus they're great for chilling after a day. Joanna shared her comfy living room setup and Nate asked for pointers on making his own space comfortable. Joanna recommended a fluffy couch that can sit multiple people, a weighted blanket, and dimmable lights.

## Key Facts

### Joanna
- **Profession: Writer** - previously established
- **Lactose intolerant** - previously established
- **Has a comfy living room setup** - includes couch that can sit multiple people, weighted blanket, dimmable lights
- Watched a classic movie recently (October 2022) with gripping story and great actors, rated 9-10/10
- Gets super invested in small things like room comfort, finds it worth it when they make life nicer
- Likes to get invested in random little things that make life nicer

### Nate
- **Attended a game convention last Friday (early October 2022)** - met people outside his normal circle
- Initially found the convention overwhelming but rewarding
- Made friends at the convention who share his love of games; they planned a gaming session together
- **Plays Catan** - a strategy board game where you build settlements and trade resources
- Describes himself as not getting crazy competitive over games since they're his escape from life struggles
- **Recently watched "Inception"** - a movie with twists and dream stuff that blew his mind
- **Plays "Cyberpunk 2077"** - has been playing nonstop for its futuristic setting and gameplay
- **Enjoys watching movies and playing video games** at home to unwind
- Has a bookcase filled with DVDs and movies
- **Wants to make his living room more comfortable** - asked Joanna for pointers

## Shared Interests & Themes
- Both enjoy movies as an escape and emotional experience
- Games bring people together and form strong relationships
- Both value comfort and relaxation at home
- Supporting each other's hobbies and interests

## Continuation
- Previous: [September 14, 2022 conversation](nate_joanna_september_14_2022.md)
- Next: [October 21, 2022 conversation](nate_joanna_october_21_2022.md)
- [Memory Index](MEMORY.md)
