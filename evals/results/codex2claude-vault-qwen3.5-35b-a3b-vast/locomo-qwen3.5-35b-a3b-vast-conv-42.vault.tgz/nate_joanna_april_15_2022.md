name: Nate and Joanna conversation - April 15, 2022
description: Nate dyed his hair purple and shared photos; Joanna inspired by his boldness and focused on her writing projects

---

## Conversation Summary
Nate and Joanna had a warm exchange where Nate shared that he had dyed his hair purple last week, expressing excitement and pride in his bold choice. Joanna responded enthusiastically and shared a sunset photo she took while hiking, which inspired her to reflect on showing the world who we are. Joanna mentioned she's currently consumed by her writing work and hoping for good news soon.

## Key Facts

### Nate
- Dyed his hair purple in the week before April 15, 2022
- Chose the bright, bold color to stand out from regular options
- Self-described as "bright and bold - like me!"
- Shared a selfie photo showing purple hair and glasses

### Joanna
- Inspired by Nate's boldness after seeing his hair color
- Took a sunset photo while hiking that she shared with Nate
- Currently consumed by writing projects
- Hoping for good news soon regarding her writing work
- Does not have a vacation lined up at the moment

## Shared Interests & Themes
- Bold self-expression and showing the world who we are
- Photography and sharing visual moments (photos shared by both)
- Supportive friendship with enthusiastic encouragement

## Relationships & Dynamics
- Warm, mutually supportive friendship
- Both celebrate each other's life choices and experiences
- Joanna offers encouragement for Nate's projects
- Nate offers to Joanna regarding her writing work

## Continuation
- Previous: [March 24, 2022 conversation](../nate_joanna_march_24_2022.md)
