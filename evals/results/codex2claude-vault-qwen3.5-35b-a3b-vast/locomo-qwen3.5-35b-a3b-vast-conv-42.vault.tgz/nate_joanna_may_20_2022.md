name: Nate and Joanna conversation - May 20, 2022
description: Joanna shares her third writing project about loss and identity; Nate adopted a new dog named Max

---

## Conversation Summary

Nate and Joanna discussed recent life changes and creative pursuits. Nate welcomed a new family member—a dog named Max—whom he adopted and who has brought him immense joy. Joanna opened up about her ongoing creative writing, specifically her third project that explores deeply personal themes. They reflected on the importance of supportive friendships and how creative outlets provide comfort during difficult times.

## Key Facts

### Joanna
- Has allergies that prevent her from getting pets
- Describes herself as "too lazy to research alternative pets for my allergies"
- Third writing project focuses on loss, identity, and connection
- Chose to write about this because it's "really personal"
- Found the writing process scary but ultimately rewarding
- Believes meaningful stories come from personal experiences and feelings
- Writes best when being true to herself, even when it's hard
- Writing and creative projects help her through tough times
- Grateful for supportive friends who understand and appreciate her work
- Shares her work with friends who provide feedback and encouragement
- Likes writing about sadness and loss (has written about these themes before)

### Nate
- Adopted a new dog named Max (May 2022)
- Describes Max as "full of energy" and filling his life with joy
- Max is keeping his other pets active
- Enjoys seeing the joy pets bring to others
- Encouraging and supportive of Joanna's creative work
- Proud of Joanna for staying strong and being true to herself

## Shared Interests & Themes
- Pets and the joy they bring (Nate's perspective)
- Writing and creative projects as therapeutic outlets (Joanna's focus)
- Personal vulnerability and authenticity in art
- Supportive friendship dynamics
- Encouraging each other's dreams and accomplishments

## Relationships & Dynamics
- Warm, long-standing friendship with mutual encouragement
- Both share personal updates and celebrate achievements
- Nate and Joanna cheer each other on toward their goals
- Joanna values Nate's support, saying it makes her journey "way easier"
- They have a history of supporting each other's creative pursuits (per earlier conversations)

## Continuation
- Previous: [May 12, 2022 conversation](nate_joanna_may_12_2022.md)
- [Memory Index](MEMORY.md)
