name: Nate and Joanna conversation - March 18, 2022
description: Joanna finished second screenplay; turtle photos shared; allergies to cockroaches revealed

---

## Conversation Summary
Nate and Joanna caught up after some time apart. Joanna shared that she finished writing her second script and is experiencing a mix of relief, anxiety, excitement, and terror about the possibility of her work being noticed and getting made.

## Key Facts

### Joanna
- Finished her second screenplay on or before March 18, 2022
- Experiencing a complex mix of emotions: relief, anxiety, excitement, terror about her work getting noticed
- Actively doing research and networking for her scripts
- Determined to make her work happen
- Allergic to reptiles and furry animals (face gets puffy and itchy)
- Newly discovered she's also allergic to cockroaches
- Would like to get turtles but can't due to allergies
- Feels blessed to have supportive friends throughout her writing journey
- Shared a photo of a cinema ticket on a chair

### Nate
- Continues to be encouraging and supportive of Joanna's writing
- Shares photos of his two pet turtles to help Joanna relax
- Turtles: a turtle and a "turtleling"
- Draws to turtles for their uniqueness, slow pace, low-maintenance nature, and calming effect
- Keeps their area clean, feeds them properly, ensures they get enough light
- Offers to send Joanna photos of the turtles so she can watch them grow without being close

## Shared Interests
- Nate sharing turtle photos with Joanna so she can enjoy them from a distance
- Joanna being "really invested in those little guys" despite her allergies

## Relationships & Dynamics
- Nate and Joanna have a warm, supportive friendship
- Joanna feels blessed to have Nate supporting her through her writing process
- Nate consistently offers encouragement: "Just make sure you don't quit - the path forward will show up soon. You got this!"

## Continuation
- Previous: [February 25, 2022 conversation](../nate_joanna_february_25_2022.md)
