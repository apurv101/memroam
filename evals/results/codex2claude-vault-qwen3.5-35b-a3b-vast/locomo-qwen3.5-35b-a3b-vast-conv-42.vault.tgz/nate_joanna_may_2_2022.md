name: Nate and Joanna conversation - May 2, 2022
description: Joanna watched LOTR trilogy; Nate won Street Fighter tournament; Joanna shared dairy-free dessert recipes

---

## Conversation Summary
Joanna caught up with Nate after he recommended "The Lord of the Rings" trilogy, which she watched and loved. They discussed their recent activities: Nate won his second gaming tournament (Street Fighter, not CS:GO), and Joanna shared her ongoing work on a screenplay and dairy-free baking projects. Joanna made a dairy-free vanilla cake with strawberry filling and coconut cream frosting, crediting Nate's earlier coconut recommendation. Both continue to share photos frequently and support each other's creative pursuits.

## Key Facts

### Joanna
- Watched "The Lord of the Rings" trilogy after Nate's recommendation (May 2022) - called it "awesome" and probably "the greatest trilogy of all time"
- Working on a screenplay (specific title not mentioned)
- Enjoys experimenting with dairy-free dessert recipes for friends and family
- Made a dairy-free vanilla cake with strawberry filling and coconut cream frosting (shared photo May 2022)
- Uses coconut cream frosting (credited Nate's earlier coconut recommendation)
- Describes cooking and baking as her creative outlets
- Particularly enjoys "snackin' dairy-free" and making desserts just as delicious as non-dairy versions

### Nate
- Won his second gaming tournament (May 2022)
- Played a local Street Fighter tournament (not his usual CS:GO) because he plays that game a lot with friends
- Described the win as "super awesome" with "so much adrenaline" in the final match
- The other finalist shook his hand after the match
- Usually plays CS:GO
- Has a well-equipped gaming room (shared photo showing gaming setup with computer and gaming chair)
- Takes care of something ongoing (shared photo but didn't specify what)
- Has a gaming room with a computer and gaming chair

## Shared Interests & Themes
- Gaming (Nate - CS:GO and Street Fighter)
- Creative pursuits (Joanna - screenplays and dairy-free baking; Nate - gaming)
- Sharing photos to enhance conversations
- Longtime friends with a warm, supportive dynamic
- Both encourage and celebrate each other's achievements
- Exchange recommendations (Nate recommended LOTR and coconut products to Joanna)

## Relationships & Dynamics
- Warm, supportive friendship with regular catch-ups
- Celebrate each other's accomplishments enthusiastically
- Share personal milestones (tournament wins, creative projects)
- Openly share photos of their lives
- Mutual encouragement and appreciation

## Continuation
- Previous: [April 21, 2022 conversation](nate_joanna_april_21_2022.md)
- [Memory Index](MEMORY.md)
