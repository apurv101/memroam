name: Nate and Joanna conversation - September 14, 2022
description: Nate shares his vegan cooking show debut; they discuss dairy-free recipes including coconut ice cream and chocolate desserts
---

Joanna and Nate caught up after a long time. Joanna shared that her laptop crashed last week and she lost all her work, which was devastating as a writer. She now uses an external drive for backups. Nate shared that he recently debuted his own cooking show, where he taught vegan ice cream recipes. They exchanged several dairy-free dessert recipes and photos.

## Conversation Summary

Nate and Joanna reconnected after not talking for a while. Joanna opened by sharing frustrating news - her laptop crashed last week and she lost all her work. As a writer, she described her laptop as "half of her lifeline" and losing progress was a major blow. Fortunately, she now has an external drive for backups and vows never to go through that again.

Nate shared exciting news - last Monday (around September 8), he taught people vegan ice cream recipes on his own cooking show. He admitted it was nerve-wracking to put himself out there, but it was a blast. He also picked up new recipes. His favorite from the show is coconut milk ice cream - smooth, creamy with a tropical coconut twist, and dairy-free for those with lactose intolerance or who want vegan options. He showed a photo of the ice cream.

Joanna mentioned she's also into dairy-free desserts - lactose intolerant. Last Friday she made a deeeelish dessert with almond milk. She asked Nate if he had favorite dairy-free sweet treats.

## Key Facts

### Joanna
- **Profession: Writer** - explicitly stated, laptop is "half of her lifeline"
- **Lactose intolerant** - confirmed again in this conversation
- Had a laptop crash last week (early Sept 2022) and lost all work
- Now uses external drive for backups to prevent future data loss
- Enjoys experimenting with dairy-free desserts
- Made a dessert with almond milk last Friday (early Sept 2022)
- Favorite treats:
  - **Chocolate raspberry tart** - almond flour crust, chocolate ganache, fresh raspberries
  - **Dairy-free chocolate cake with raspberries** - made with almond flour, coconut oil, chocolate and raspberries; favorite for birthdays and special days
  - **Blueberry coconut dessert with gluten-free crust** - made with blueberries, coconut milk, and gluten-free crust

### Nate
- **Profession: Chef / Cooking show host** - hosts his own cooking show
- **Last Monday (Sept 8, 2022)**: Debuted teaching vegan ice cream recipes on his cooking show
- Describes the experience as "nerve-wracking but a blast"
- Favorite dishes:
  - **Coconut milk ice cream** - smooth, creamy, tropical twist, dairy-free
  - **Dairy-free chocolate mousse** - super creamy, tastes like the real thing
- Interested in learning Joanna's baking recipes

## Shared Interests & Themes
- Both enjoy dairy-free, lactose-friendly desserts
- Passionate about sharing recipes and cooking together
- Creative expression through food
- Supporting each other's projects (Joanna's writing, Nate's cooking show)

## Continuation
- Previous: [September 5, 2022 conversation](nate_joanna_september_5_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
