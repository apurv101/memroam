name: Nate and Joanna conversation - July 10, 2022
description: Nate won his fourth gaming tournament; Joanna shares road trip inspiration for new movie and her debut book project

---

## Conversation Summary

Nate shared exciting news about winning his fourth video game tournament on Friday, noting it was an online competition and he's proud he can make money doing what he loves. Joanna congratulated him and mentioned she took a road trip to Woodhaven, a small Midwest town, for research on her next movie. She explored the town's scenery, historic buildings, and discovered a library with an old book collection from the 1900s containing stories and sketches about the town and its people. This sparked ideas for her next script, which she noted is different from her previous work but has great potential. Joanna also revealed she started writing a book since her movie did well - a deep emotional story exploring loss, redemption, and forgiveness. This would be her first time publishing a book. She mentioned her movie had been published, indicating she had previously published work. The conversation was warm and supportive, with both encouraging each other's creative endeavors.

## Key Facts

### Nate
- Won his fourth video game tournament on Friday, July 8, 2022
- Competition was online
- Makes money doing what he loves (gaming)
- Supportive friend who encourages Joanna's creative work

### Joanna
- Went on a road trip to Woodhaven, a small Midwest town, for movie research
- Discovered a library with a cool old book collection from the 1900s
- Found inspiration from the town's history and old stories for her next script
- Started working on a book exploring themes of loss, redemption, and forgiveness
- This is her first book project; she hasn't published a book before
- Had a previously published movie

## Shared Interests & Themes
- Mutual support and encouragement in creative pursuits
- Finding inspiration in real-life stories and experiences
- Creative expression and artistic growth
- Pride in accomplishments and celebrating each other's wins

## Continuation
- Previous: [May 25, 2022 conversation](nate_joanna_may_25_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
