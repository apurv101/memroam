name: Nate and Joanna conversation - April 17, 2022
description: Nate shared dairy-free ice cream recipe with lactose-intolerant Joanna; discussed hiking trails and nature; photos of Nate's turtles and cooking

---

## Conversation Summary
Nate and Joanna caught up after not talking in a while. Joanna shared that she's been reading a lot and found a beautiful hiking trail in her hometown. Nate mentioned he's curious about hiking trails near his place. They discussed how nature is inspiring and a way to reset and find peace. Nate shared that spending time with his pets and engaging in hobbies is his way of finding peace, and they discussed how small things have powerful effects on happiness. Nate shared photos of his turtles and a bowl of sprinkles with ice cream. Joanna expressed love for his turtles and interest in his ice cream making. Nate shared his dairy-free ice cream recipe, and Joanna mentioned she's lactose intolerant. Joanna plans to try making it that evening.

## Key Facts

### Joanna
- Lactose intolerant
- Has been reading a lot in the week leading up to April 17, 2022
- Found a gorgeous hiking trail in her hometown
- Nature is her haven - finds it calming, inspiring, and a way to reset
- Worries and stress seem to vanish when in nature
- Loves Nate's turtles
- Interested in making dairy-free ice cream

### Nate
- Has pets (turtles)
- Has loads of books he hasn't read in years
- Has a nice hiking trail just north of where he lives
- Spends time with his pets and engages in hobbies to take a break from reality
- Shares a kitchen with his turtles sometimes - brings them in so they can watch him make food
- Makes his own dairy-free ice cream
- Has a recipe for dairy-free ice cream using coconut milk, vanilla extract, sugar, and salt

## Shared Interests & Themes
- Nature and hiking
- Small things that bring happiness and peace
- Food and cooking (especially dairy-free desserts)
- Pets (Nate has turtles)
- Reading/books (both have books they want to read)
- Friendship and catching up

## Relationships & Dynamics
- Warm friendship with mutual enjoyment of each other's company
- Nate and Joanna share personal moments (photos, recipes)
- Supportive of each other's activities and interests
- Joanna appreciates Nate's turtle photos and cooking
- Nate is happy to share recipes

## Continuation
- Previous: [April 15, 2022 conversation](nate_joanna_april_15_2022.md)
- [Memory Index](MEMORY.md)
