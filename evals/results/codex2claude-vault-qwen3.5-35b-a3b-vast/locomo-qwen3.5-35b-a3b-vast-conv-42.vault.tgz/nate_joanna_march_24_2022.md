name: Nate and Joanna conversation - March 24, 2022
description: Joanna had writing audition; Nate in intense video game tournament; bookshelf inspiration spot shared; writing advice exchanged

---

## Conversation Summary
Nate and Joanna caught up after some time apart. Joanna shared that she had a writing gig audition the day before and is feeling mixed emotions of excitement and anxiety. Nate mentioned he's participating in an intense video game tournament. They exchanged supportive words and writing advice.

## Key Facts

### Joanna
- Had an audition on March 23, 2022 for a writing gig
- Feeling mixed emotions: excited but anxious about the outcome
- Bookshelf filled with books and magazines is her go-to place for writing inspiration
- Helps her stay sharp and motivated
- Encouraged Nate to follow his writing dreams despite the challenges

### Nate
- Currently participating in an intense video game tournament
- Described it as "INTENSE" with a lot of adrenaline
- Seeking writing advice from Joanna
- Appreciated Joanna's support and kind words
- Committed to keeping working hard on his writing goals

## Shared Interests
- Writing as a passion/career pursuit
- Joanna's bookshelf as a source of inspiration

## Relationships & Dynamics
- Warm, supportive friendship with consistent encouragement
- Nate seeks Joanna's advice on writing
- Joanna offers thoughtful guidance about pursuing writing

## Continuation
- Previous: [March 18, 2022 conversation](../nate_joanna_march_18_2022.md)
