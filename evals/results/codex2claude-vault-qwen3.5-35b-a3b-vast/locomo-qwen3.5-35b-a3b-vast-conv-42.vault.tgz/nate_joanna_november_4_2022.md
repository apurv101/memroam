name: Nate and Joanna conversation - November 4, 2022
description: Conversation about Joanna's producer meetings and Nate's gaming, plus dessert sharing plans

November 4, 2022 - Nate and Joanna discussed:

**Joanna's Career:**
- Set up meetings with movie producers about her script
- The producers were interested in elements of self-discovery in her work
- Joanna writes stories about finding courage and taking risks
- Had an early story from age 10 about a brave little turtle

**Nate's Interests:**
- Helps friends reset high scores at international gaming tournaments
- Loves turtles and finds their resilience inspiring
- Recently made lactose-free ice cream using coconut milk

**Personal Connection:**
- Joanna plans to visit Nate tomorrow
- Joanna will bring her chocolate and raspberry cake recipes
- They will share desserts together
