name: Nate and Joanna conversation - February 25, 2022
description: Nate shared ice cream creation; Joanna writing new screenplay inspired by personal loss and self-discovery

---

## Conversation Summary
Nate and caught up after some time apart. Nate shared about making ice cream for a friend. Joanna discussed her ongoing screenwriting journey, revealing she's started a new screenplay while waiting to hear back about her first submission.

## Key Facts

### Nate
- Made chocolate and vanilla swirl ice cream for a friend who loved it
- Has an ice cream dessert recipe using coconut milk (dairy-free)
- Offers to share his dairy-free coconut milk ice cream recipe with Joanna
- Enjoys making desserts ("I'm all about these desserts")

### Joanna
- Cannot have dairy
- While waiting to hear back about her first screenplay, started writing another one
- New screenplay topic: a thirty-year-old woman's journey of self-discovery after a loss
- Plot elements include a road trip for healing and personal growth
- The screenplay is inspired by her own personal experiences and journey of self-discovery
- Describes the main character as dealing with "tough stuff: loss and trying to figure out who they are"

## Relationships & Dynamics
- Both express genuine support for each other's creative endeavors
- Joanna's screenwriting projects seem emotionally significant to her (both are described as "my own story")
- They maintain a warm, encouraging friendship

## Continuation
- Previous: [February 7, 2022 conversation](../nate_joanna_february_7_2022.md)
- Next: Pending
