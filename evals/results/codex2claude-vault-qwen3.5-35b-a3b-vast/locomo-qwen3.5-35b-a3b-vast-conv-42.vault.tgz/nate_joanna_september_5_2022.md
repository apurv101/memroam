name: Nate and Joanna - September 5, 2022
description: Joanna reveals she's lactose intolerant and is experimenting with dairy-free desserts; Nate shares a gaming tournament setback; they discuss baking together

---

## Conversation Summary

Nate and Joanna caught up after a long time. Nate shared that he's been hanging out with turtles in a pond, which has been helpful for him recently. He also mentioned experiencing a setback in a video game tournament - he didn't do well despite trying, but he's trying to stay positive about it.

Joanna shared that she's been tinkering with old recipes and finding comfort in being creative. She's been tweaking a dessert recipe to make it tastier and more accessible, experimenting with flavors like chocolate, raspberry, and coconut. 

Joanna revealed that she's lactose intolerant, so she's been trying out dairy-free options like coconut or almond milk instead of dairy. She described it as a fun challenge to make yummy treats that suit everyone's diets. She shared that she made dairy-free chocolate coconut cupcakes with raspberry frosting, and mentioned she's been making various desserts that work for everyone's diets - cookies, pies, cakes, and more.

Nate mentioned that he's a fellow Chef and would love to join Joanna in the kitchen sometime, noting that baking and cooking brings them together. They exchanged tips on dairy-free baking, with Nate suggesting dairy-free margarine or coconut oil as butter substitutes.

## Key Facts

### Joanna
- **Is lactose intolerant** - newly revealed fact
- Being a Chef
- Revising old recipes and experimenting with new ones
- Finding comfort and creativity in baking
- Has been tweaking a dessert recipe to be tastier and more accessible
- Experiments with flavors: chocolate, raspberry, coconut
- Makes dairy-free desserts using coconut or almond milk instead of dairy
- Made dairy-free chocolate coconut cupcakes with raspberry frosting
- Bakes various desserts (cookies, pies, cakes) that work for different diets

### Nate
- Enjoys watching turtles in a pond - it's been helpful recently
- Participates in video game tournaments
- Experienced a recent setback in a tournament (didn't do well despite trying)
- Trying to stay positive about gaming setbacks
- Is a fellow Chef
- Interested in baking and cooking with Joanna
- Knowledgeable about dairy-free baking substitutes (dairy-free margarine, coconut oil)

## Shared Interests & Themes
- Baking and cooking together
- Bringing people together through food
- Supporting each other's creative pursuits
- Finding comfort in creative outlets

## Continuation
- Previous: [August 22, 2022 conversation](nate_joanna_august_22_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
