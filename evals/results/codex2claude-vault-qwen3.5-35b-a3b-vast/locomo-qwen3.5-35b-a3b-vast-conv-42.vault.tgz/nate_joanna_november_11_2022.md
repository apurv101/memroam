---
id: 01a05089-b17f-7c71-abae-0122709df4a2
name: Nate and Joanna conversation - November 11, 2022
description: Joanna filming her movie from road-trip script; Nate shows turtle photos from Tampa beach trip, experiments with coconut milk ice cream flavors
---

**November 11, 2022** - Nate and Joanna caught up:

**Joanna's Big Breakthrough:**
- Finally filming her own movie based on the road-trip script
- Had pitched the script to producers and it got greenlit
- Every day on set feels awesome and full of potential
- One of the actors told her how much she liked the script - gave Joanna chills and was a really exciting moment

**Nate's Turtle Adventures:**
- Took his turtles to the beach in Tampa yesterday
- Shares photos showing turtles in various settings - fish tank, turtle in sink with reflection, turtle on a log in pond
- Turtles bring him peace in the craziness of life
- Loves seeing them soaking in the sun and having them around - they make him feel calm
- Turtles don't require much looking after, which is great

**Shared Moments:**
- Nate experimenting with coconut milk ice cream flavors right now
- Made colorful bowls of homemade coconut milk ice cream with mix-ins
- Says turtles are like zen masters that remind him to slow down and appreciate small things in life

**Personal Details:**
- Joanna filming her own movie
- Nate has turtles that he finds peaceful and calming
- Nate likes experimenting with dairy-free ice cream flavors
- Joanna is allergic to turtles (from earlier conversation on Nov 9)