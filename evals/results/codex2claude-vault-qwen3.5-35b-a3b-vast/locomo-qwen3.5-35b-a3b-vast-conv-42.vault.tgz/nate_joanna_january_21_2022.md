name: Nate and Joanna conversation - January 21, 2022
description: Nate won a CS:GO tournament; both enjoy movies with different genre preferences

---

## Participants
- **Nate**: Video game enthusiast, enjoys action and sci-fi movies
- **Joanna**: Writer, enjoys reading, nature, dramas and romcoms

## Key Facts

### Nate
- Won first video game tournament in January 2022
- Game: Counter-Strike: Global Offensive (team shooter)
- Hobbies: Playing video games, watching movies
- Favorite movie genres: Action and sci-fi (loves the effects)

### Joanna
- Hobbies: Writing, reading, watching movies, exploring nature
- Favorite movie genres: Dramas and romcoms (loves getting immersed in feelings and plots)
- Favorite film: A romantic drama about memory and relationships
  - First watched around 3 years prior (circa 2019)
  - Owns a physical copy
  - Has seen it a few times
  - Likes the concept and acting

## Shared Interests
Both enjoy watching movies, though they have different genre preferences.

## Continuation
- [January 23, 2022 conversation](../nate_joanna_january_23_2022.md) - Joanna finished her screenplay; Nate's turtles
