name: Nate and Joanna conversation - June 5, 2022
description: Joanna shares her screenplay appeared on screen; discusses favorite superheroes; Nate shares his Iron Man figure; Joanna shows family photo on cork board
---

## Conversation Summary

Joanna shared exciting news that her screenplay work appeared on the big screen the day before - a nerve-wracking but inspiring experience. They discussed favorite superheroes: Nate's top pick is Iron Man (he has a figure that reminds him to keep working on goals), while Joanna loves Spider-Man for Peter Parker's relatable struggles between hero and person. She appreciates any superhero's unique story and powers. Joanna also showed Nate her cork board filled with inspiring quotes, photos, and keepsakes - including a family photo that reminds her of love and encouragement. Nate expressed interest in starting his own cork board and recommended it to Joanna.

## Key Facts

### Joanna
- Wrote bits for a screenplay that appeared on the big screen on June 4, 2022
- Finds seeing her words come alive nerve-wracking but inspiring
- Spider-Man is a favorite superhero - relates to Peter Parker's struggles between hero and person
- Suggests everyone has rad superhero stories and powers
- Has a cork board with inspiring quotes, pictures, photos, and keepsakes
- Shows a family photo on her cork board that reminds her of love and encouragement from her family
- Values family support highly

### Nate
- Favorite superhero is Iron Man - loves the tech and sarcastic humor
- Has an Iron Man toy figure that reminds him of something he loves
- Keeps the figure in his room as a reminder to keep working on his goals
- Found Joanna's cork board inspiring and considered starting his own

## Shared Interests & Themes
- Superheroes and what they represent
- Personal motivations and inspiration boards
- Creative work and seeing it come to life
- Family support and encouragement
- Goal-setting and staying motivated

## Continuation
- Previous: [May 25, 2022 conversation](nate_joanna_may_25_2022.md)
- Next conversation to be recorded
- [Memory Index](MEMORY.md)
