name: Gina's Fashion Internship
description: Gina accepted a part-time fashion internship at an international company, combining her passion for fashion with her dance background.
---
Gina was accepted for a fashion internship as of May 27, 2023. It's a part-time position in the fashion department of an international company. She's feeling both excited and nervous about this opportunity, recognizing it as a big change but approaching it with an upbeat attitude and eagerness to learn as much as she can. This internship follows her design internship interview on May 10, 2023, and represents another step in her journey of blending fashion and dance.
