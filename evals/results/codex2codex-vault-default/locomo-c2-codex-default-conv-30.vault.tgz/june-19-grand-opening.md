name: June 19, 2023 - Dance Studio Grand Opening
description: Jon's dance studio grand opening is tomorrow (June 19, 2023); he's excited and Gina promises to be there
---
On June 19, 2023 (conversation dated 10:04 am on June 19, 2023), Jon shared that the official grand opening of his dance studio is the following day. He's been working hard to make everything just right and is excited for the launch.

**Jon's updates:**
- Took a short trip to Rome last week to clear his mind before this big moment
- The studio is nearly ready with young dancers already practicing there
- He's feeling good and ready to give it his best after what he calls a "wild ride"

**Gina's response:**
- Congratulated Jon and praised how amazing the studio looks
- Encouraged him to savor the moment and capture the joy that dance brings
- Shared photos of people in dance studios to show her support
- Promised to be right by his side at the grand opening to make great memories together

**Photos shared in conversation:**
1. A group of young dancers in the dance studio
2. A photo of a group of people in a dance studio (from Gina)
3. A man in native costume giving another man a high five

Both Jon and Gina expressed excitement about the upcoming grand opening and looking forward to making memorable moments together. Jon thanked Gina for always having his back and said her pride and support mean a lot.
