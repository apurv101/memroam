name: Jon's Dance Studio Expansion Plans
description: Jon is expanding his dance studio through social media growth, school partnerships, and hosting a competition.
---
Jon is expanding his dance studio's presence through multiple channels. He's growing his social media presence and offering workshops and classes to local schools and community centers. Additionally, he's hosting a dance competition the following month (February 2023) to showcase local talent and bring more attention to his studio. He's seeing progress from all this work and the dancers are excited. He sees it as fulfilling to give people a place to express themselves through dance. He invited Gina to attend the upcoming competition event.
