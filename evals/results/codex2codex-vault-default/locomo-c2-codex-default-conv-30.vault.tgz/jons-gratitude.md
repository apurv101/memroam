name: Jon's Gratitude for Gina's Support
description: Jon expresses deep gratitude for Gina's encouragement and emotional support during his career transition.
---
Jon expresses sincere gratitude to Gina for being there for him during his career transition from banking to dance studio ownership. He repeatedly thanks her for her help with staying motivated and emphasizes that her support means a lot to him. He acknowledges that her encouragement has made a huge difference and feels great having her in his corner.
