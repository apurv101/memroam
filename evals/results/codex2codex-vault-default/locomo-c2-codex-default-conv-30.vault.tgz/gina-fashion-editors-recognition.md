name: Gina Noticed by Fashion Editors
description: Gina was noticed by fashion editors during her internship, leading to exciting but pressure-filled attention.
---
As of July 9, 2023, Gina shared that she was noticed by fashion editors during her internship. This attention has been "amazing but kinda scary" with "a lot of pressure to keep going up." The recognition represents a significant milestone in her fashion career, coming after her fashion internship that started in late May 2023.
