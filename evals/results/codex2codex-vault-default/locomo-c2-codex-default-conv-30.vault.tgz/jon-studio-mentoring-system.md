name: Jon's Studio Mentoring and Organization Systems
description: Jon provides one-on-one dance mentoring and uses various organizational tools to track progress and stay motivated.
---
Jon's dance studio offers more than just classes and workshops—he provides one-on-one mentoring and training to help dancers reach their full potential. He views the studio as a place of support and encouragement where dancers can grow.

To stay organized and motivated, Jon uses multiple systems:
- A clipboard with notepad attached for tracking tasks
- A notebook with calendar for setting goals, tracking achievements, and identifying areas for improvement
- A color-coded whiteboard system to visualize goals and tokenize successes

He color-codes achievements on his whiteboard to easily track progress and stay motivated. This visual system keeps him focused on his goals and reminds him why he's working hard to make his studio dreams happen.

Jon values mentorship deeply, having experienced firsthand how guidance and support can help people shine. He believes a mentor can do wonders and passes that wisdom on to his dancers.
