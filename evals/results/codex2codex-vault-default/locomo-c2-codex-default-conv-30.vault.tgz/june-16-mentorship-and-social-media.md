name: June 16 - Business Mentorship and Social Media Progress
description: Jon received business mentorship and shared dance videos on social media; Gina offered marketing advice and encouraged resilience
---
On June 16, Jon and Gina discussed their business progress:

Jon mentioned getting mentored by an amazing business person the previous day, which was inspiring and increased his enthusiasm for chasing his dreams. He was also promoting his business and staying committed despite challenges.

Gina shared marketing advice for Jon's business, recommending social media channels and working with influencers for broader reach. Jon reported that he had already started following this advice by posting dance videos on social media, which was creating some stir.

Gina emphasized key entrepreneurial advice: stay passionate, focused, and resilient. She acknowledged that challenges would come but stressed believing in yourself and staying open to learning and improving. Jon expressed appreciation for Gina's encouragement, saying it motivated him to keep going.

Gina shared a photo from her dancing past to remind Jon that failures lead closer to success and that tough roads can be worth it. Jon found the photo inspiring and reminded him of his love for performing.

The conversation reinforced their mutual support pattern, with Gina continuing to encourage Jon's determination and passion for dance while Jon expressed gratitude for having Gina's support.
