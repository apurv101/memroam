name: Jon's Networking Philosophy
description: Jon believes in proactive networking, attending events to create opportunities rather than waiting for them to come naturally.
---
Jon adopted a proactive approach to networking, choosing to attend networking events to "make things happen." He sees this as taking control of his circumstances rather than waiting for opportunities to arrive naturally. This mindset shift came during his job search after losing his banking job, reflecting his determination and focus on building momentum for his dance studio business.
