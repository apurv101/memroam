name: Written Planning as Motivation Tool
description: Jon uses written plans and goals to maintain motivation and focus during his career transition.
---
Jon tracks all his plans by writing them down, finding that seeing his goals written on paper helps keep him motivated and focused on what needs to be done. He acknowledges the path won't be easy but believes it will pay off. Gina reinforced this approach, noting that tracking plans and goals is like having "a picture of all your progress."
