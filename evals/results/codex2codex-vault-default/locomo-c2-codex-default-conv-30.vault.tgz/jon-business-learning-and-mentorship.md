name: Jon's Business Learning and Mentorship Goals
description: Jon is actively learning marketing and analytics tools for his dance studio business and wants to mentor aspiring dancers.
---
As of July 9, 2023, Jon shared that after losing his job (which was "a bummer"), he pushed himself to take the plunge and go for his business dreams. He has started learning "all these marketing and analytics tools to push the biz forward today." Jon also expressed excitement about guiding and mentoring aspiring dancers on their dreams, seeing himself as a potential mentor and guide in the dance community.
