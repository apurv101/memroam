name: Gina's Design Internship Interview
description: Gina had an interview for a design internship, showing her interest in design alongside her fashion-dance clothing business.
---
Gina had an interview for a design internship on May 10, 2023 (the day before this conversation). This represents a new step in her entrepreneurial journey, combining her interests in design, fashion, and dance.
