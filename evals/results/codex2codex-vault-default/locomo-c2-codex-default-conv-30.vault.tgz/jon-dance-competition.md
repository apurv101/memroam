name: Jon's Upcoming Dance Competition
description: Jon is preparing for a dance competition in February 2023 and is rehearsing new routines.
---
Jon is preparing for a dance competition near him in February 2023 (next month from late January 2023). He sees it as a great chance to show his skills and hopefully get recognition from the dance community. He's working on new dance routines and rehearsing hard for the show. Jon is passionate about dancing, which brings him joy and fulfillment. He shared a photo of a woman in a gray dress doing a trick (possibly related to his show routines). He's determined to do his best and make those who support him proud.
