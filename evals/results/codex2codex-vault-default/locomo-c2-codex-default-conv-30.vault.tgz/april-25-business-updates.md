name: April 25 Business Updates
description: Jon attended a dance studio fair and got leads; Gina started an online clothing store after job loss
---
On April 24, Jon attended a fair to showcase his dance studio. The experience was stressful but rewarding — he got some possible leads and learned that running a business takes confidence and resilience.

On or around April 25, Gina shared that she started her own online clothing store after losing her job. She described it as a tough but rewarding journey, saying it was the perfect way to take control of her own destiny.

Gina's advice for staying motivated: focus on the big goal and why you're doing it, get help from supportive people, and "dance it out."
