name: Gina's Store Inspiration
description: Gina started her online clothes store to blend her passion for fashion trends and dance.
---
Gina is passionate about fashion trends and finding unique pieces. She started her online clothes store in January 2023 to blend her love for dance and fashion, which she felt was a perfect match. She was dreaming of starting the store for a while before launching it.