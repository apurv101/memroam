name: Gina's Video Presentation and Mentorship
description: Gina developed a video presentation teaching how to style her fashion pieces and had a mentor when learning to dance.
---
Gina developed a video presentation to teach how to style her fashion pieces. She plans to share it with Jon later.

Gina had a mentor when she was learning to dance, which gave her appreciation for the power of mentorship. This personal experience informs how she supports Jon and understands the value of having someone to guide and encourage you through challenging journeys.
