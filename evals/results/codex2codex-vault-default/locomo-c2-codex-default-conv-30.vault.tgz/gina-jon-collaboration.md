name: Gina and Jon Collaboration
description: Gina is offering to help Jon with marketing strategies, social media content creation, and account management for his dance studio.
---
As of July 21, 2023, Gina is offering to collaborate with Jon on his dance studio's marketing efforts. Her support includes:
- Helping with marketing strategies to reach the target audience
- Creating social media content (dance clips and related content)
- Managing his social media accounts
- Posting on Instagram and TikTok to reach a younger demographic
- Collaborating with local influencers or dance communities

This collaboration represents a continuation of their supportive relationship, with Gina applying lessons from her own business challenges (such as sourcing trendy pieces and networking) to help Jon succeed with his dance studio venture.
