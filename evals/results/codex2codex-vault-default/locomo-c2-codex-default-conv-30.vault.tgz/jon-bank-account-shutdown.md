name: Jon's Bank Account Shutdown
description: Jon shut down his bank account as a tough decision to help his business grow.
---
Jon had to shut down his bank account as a tough decision he needed to make for his business. While it was difficult, he believed it would help his business grow. He's handling the changes hard but staying positive and looking ahead. This was a significant change in his entrepreneurial journey as he builds his dance studio business after leaving his banking career.
