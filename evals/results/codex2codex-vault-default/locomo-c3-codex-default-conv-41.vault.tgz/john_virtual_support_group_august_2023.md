name: John's virtual support group for military advocates
description: John organized a virtual support group in August 2023, recruiting family and friends to advocate for the military

---

On August 3, 2023, John shared with Maria that he had asked family and friends to join a virtual support group he is a part of, where they advocate for the military.

**Key details:**
- The group is virtual and focused on supporting the military
- John successfully recruited family and friends to join as advocates
- John described it as "awesome seeing so many people coming together to back the courageous people serving our nation"
- This reflects John's continued passion for veterans and military service, consistent with his prior involvement in veterans' rights activities

**Context:**
This builds on John's established pattern of military and veteran advocacy, including his military aptitude testing, veterans petition project, and participation in veterans' marching events in July 2023.
