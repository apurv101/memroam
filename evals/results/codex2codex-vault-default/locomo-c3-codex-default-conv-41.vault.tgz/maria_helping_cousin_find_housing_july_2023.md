name: Maria helps cousin find housing
description: In early July 2023, Maria is helping her cousin find a new place after having to leave in a hurry

---

In early July 2023, Maria is supporting her cousin who went through a difficult transition. Her cousin had to leave her previous place and find new housing in a hurry, which has been very stressful for her.

Maria has been actively helping her cousin find a safe, cozy new home. She has been looking at various options, including examining rows of houses and visiting housing facilities like portable home parking lots. Maria is seeking resources and organizations that could help her cousin during this challenging time.

Maria believes strongly that a safe home is key to wellbeing and is dedicated to supporting her family member through this difficult transition.
