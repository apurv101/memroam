name: John's veterans petition project
description: John started a petition project in May 2023 to support military veterans, showing his ongoing passion for their rights and appreciation
---

In May 2023, John is working on a project to support military veterans by getting a petition going. He describes it as rewarding but stressful.

His motivation:
- Always been passionate about veterans and their rights
- Last week (mid-May 2023), realized again how much veterans have done for the country
- Wanted to show his appreciation in a meaningful way
- This is his way of giving back to those who have served

John's goals for the project:
- Let veterans know their hard work is appreciated
- Make veterans' lives better through advocacy
- Ensure veterans are supported and valued in the community

John is also passionate about making a real difference for veterans, drawing motivation from their continued support and excitement about the initiative.
