name: Maria joins church in May 2023
description: Maria joined a nearby church in early May 2023 seeking community connection and faith
---

In early May 2023, Maria shared with John that she recently joined a nearby church. Her motivations:

- Wanted to feel closer to a community
- Seeking connection to her faith
- Looking for a sense of belonging

She described her church experience so far as "really great."
