name: Touching moment with lonely girl at shelter
description: Maria sat with and comforted an 8-year-old girl who was alone and sad at the shelter, creating a meaningful connection
---

During a volunteer event at the homeless shelter (January 2023), Maria noticed an 8-year-old girl sitting all alone, looking very sad. The girl had no other family. Maria sat with her, talked to her, and was able to provide comfort and a listening ear.

By the end of their conversation, they were laughing and having a good time together. This moment was particularly impactful for Maria - it showed her the real difference she could make just by being present and compassionate.

This experience reinforced why volunteering matters and made a lasting impression on Maria.
