name: John's job loss and career transition
description: John lost his mechanical engineering job in mid-2023 and is transitioning to a hardware role at a tech company
---
In mid-2023 (before August 2023), John's mechanical engineering company closed unexpectedly, resulting in job loss. He described it as "really rough" and something he "never saw coming."

The job loss, while challenging, became a catalyst for exploring opportunities in the tech industry. John mentioned he had "been looking into some opportunities in the tech industry for a while now" and saw this as potentially "the change I need."

By early August 2023, John was pursuing a promising opportunity: a job at a tech company's hardware team that would utilize his mechanical engineering skills. He described the transition as feeling "different" but recognized it as a "great opportunity to learn and contribute."

Maria's encouragement and support played a meaningful role in helping John navigate this difficult transition and maintain a positive outlook.
