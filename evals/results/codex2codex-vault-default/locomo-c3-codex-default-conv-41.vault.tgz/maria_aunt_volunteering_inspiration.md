name: Maria's aunt inspired her volunteering
description: Maria's aunt used to help Maria's family when they were struggling, which inspired Maria to volunteer and give back
---

Maria's decision to volunteer was inspired by her aunt, who believed in the power of volunteering. When Maria's family was going through difficult times, her aunt helped them out. This personal experience with receiving support during hardship shaped Maria's values and motivated her to help others in similar situations.

This family tradition of giving back makes volunteering deeply personal for Maria - she's paying forward the kindness she received.
