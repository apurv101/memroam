name: Maria's 5K charity run for homeless shelter
description: Maria participated in a 5K charity run for a homeless shelter in late March 2023
---
In late March 2023, Maria participated in a 5K charity run benefiting a homeless shelter. She described it as "awesome" and found it deeply rewarding.

What made the experience special for Maria:
- Being surrounded by people united for the same cause
- The energy and sense of unity among participants
- A reminder of why she's passionate about charity work
- Seeing the impact of collective action

This event reinforced Maria's commitment to charity work and community service. She shared that there's something special about the energy when people come together for a shared cause.
