name: Maria's church friends picnic in mid-June 2023
description: Maria had a picnic with church friends last weekend in mid-June 2023, playing charades and scavenger hunt
---

Last weekend (mid-June 2023), Maria had a picnic with some friends from church. 

The picnic details:
- They met under trees in a park-like setting
- They played games including charades and a scavenger hunt
- They brought drinks, snacks, and yummy food
- Everyone had a good laugh and enjoyed each other's company

The experience was great for Maria and helped strengthen her connections with her church community.
