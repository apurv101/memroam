name: John promoted to assistant manager
description: John received a promotion to assistant manager in mid-June 2023 after overcoming self-doubt and other obstacles
---
In mid-June 2023 (between June 12 and June 16), John received a promotion to assistant manager. He described it as something that had been a long time coming and said he was over the moon about it.

**The promotion:**
- John was excited when he found out
- He feels all his hard work has paid off
- Views it as a stepping stone for bigger things

**A symbol of his journey:**
John shared a photo of a trophy that commemorates his journey. The trophy sits on a black surface and represents:
- All the obstacles he had to overcome
- A reminder of the challenges faced and how far he's come

**Challenges John faced:**
- Technology-related hurdles
- Workplace issues
- Self-doubt (worst challenge) - there were moments when he questioned if he was on the right track

**What helped him overcome obstacles:**
- Support at home (family)
- His own grit and perseverance
- Believing in himself
- Knowing he had loved ones supporting him

John expressed pride in what he achieved and views the promotion as a reward for all the hustle and hardship he went through - a reminder that he's on the right path.
