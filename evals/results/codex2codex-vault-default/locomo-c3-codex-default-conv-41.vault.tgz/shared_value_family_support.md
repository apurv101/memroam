name: Family as support system
description: Key insight from conversation: family is the most important thing and biggest support through good and bad times
---
Shared value between John and Maria (from conversation on May 4, 2023):

Family is the most important thing and provides the biggest support. They're there for you through good times and bad, having each other's back.

For John, the family boot camp experience demonstrated this - they support each other during workouts by cheering each other on and providing emotional support outside them.

For Maria, even with a small family, she relies on them for strength during tough times.

Key insight: Having a support system is key to staying motivated and reaching goals. It's great to have family on your journey with you.
