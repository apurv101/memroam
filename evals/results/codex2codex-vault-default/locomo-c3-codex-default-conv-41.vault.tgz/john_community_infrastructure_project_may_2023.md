name: John plans community infrastructure project
description: In May 2023, John announced plans to start a community project focused on road improvements and infrastructure in his neighborhood
---

In May 2023, John discussed with Maria his plans to start a community project focused on improving local infrastructure. Key concerns include:

- Roadways full of potholes that are dangerous for drivers and damaging to cars
- Need for better housing and living conditions
- Importance of stable infrastructure services (recently experienced a power outage)

John specifically mentioned wanting to work on improving West County, his old area. He and Maria agreed to work together to get community backing for these improvements.
