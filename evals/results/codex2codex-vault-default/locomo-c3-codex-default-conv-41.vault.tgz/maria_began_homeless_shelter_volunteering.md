name: Maria's motivation for homeless shelter volunteering
description: Maria began volunteering at a homeless shelter about a year ago after witnessing a family struggling on the streets

---

Maria started volunteering at the homeless shelter approximately one year before August 2023 (around August 2022) after a formative experience that motivated her to take action.

**The inciting incident:**
- Maria witnessed a family struggling on the streets
- The experience made her want to help
- She reached out to the shelter to ask if they needed volunteers
- They welcomed her and it has been a fulfilling experience since then

**Her perspective on the work:**
- Describes it as "really fulfilling"
- Acknowledges the work can be tough
- Knowing she can make a difference keeps her motivated despite challenges
- Strongly believes in the impact of small acts of kindness

**Context:**
This memory provides the origin story of Maria's ongoing volunteer work at the homeless shelter, which continues through at least August 2023. This motivation aligns with her values of compassion and service, and she has maintained consistent involvement including dropping off baked goods in late July 2023 and planning to continue volunteering through August 2023.
