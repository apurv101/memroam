name: Finding balance through self-care
description: Maria's approach to balance: taking care of self physically, emotionally, and mentally through exercise, music, and time with loved ones
---
Maria's approach to finding balance in life:

- Takes care of herself physically, emotionally, and mentally
- Activities include: exercise, music, spending time with loved ones
- This helps her stay positive

She believes taking care of yourself helps us be strong for life's tough times, something she learned the hard way. A bit of joy is definitely important in life.
