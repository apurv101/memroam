name: Work-life balance philosophy
description: Shared belief between John and Maria that balancing work and family time is crucial for well-being
---
John and Maria discussed work-life balance during their conversation on June 16, 2023.

**John's perspective:**
- John works during regular work hours but sometimes brings work home
- He finds it challenging to balance everything
- He tries to organize his time and make sure he's there for the important things
- Believes it's all about finding balance and making those moments count
- Takes time off for family - believes it helps people stay connected and appreciate simple things

**Maria's perspective:**
- Finding balance is crucial
- Taking time for ourselves and the important people in our lives is vital
- Emphasizes the importance of special family times

**Shared values:**
- Both believe in the importance of taking time for ourselves and family
- They appreciate that life is great because of these special family times
- They enjoy creating memories together and appreciate the simple things

This philosophy is reflected in their shared vacation memories and their commitment to family time despite busy schedules.
