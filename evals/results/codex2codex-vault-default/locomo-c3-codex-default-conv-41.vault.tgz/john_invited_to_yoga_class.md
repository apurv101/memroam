name: John invited to yoga class by colleague Rob
description: John's colleague Rob invited him to a beginner's yoga class in late February 2023

---

In late February 2023, John shared with Maria that his colleague Rob had invited him to a beginner's yoga class. This was significant because Maria already practices aerial yoga, and yoga represented a new fitness interest for John as he balanced his political campaign with maintaining physical well-being.

The invitation came during a period when John was actively pursuing his campaign, making this a timely suggestion for stress relief and community building.
