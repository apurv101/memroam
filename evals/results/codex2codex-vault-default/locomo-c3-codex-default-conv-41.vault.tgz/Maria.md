name: Maria
description: Maria's grandma passed away late Feb 2023, volunteers at homeless shelter, planning ring-toss fundraiser, built connections through compassion/listening, went hiking with church friends in late June 2023, joined gym in June 2023 and does kundalini yoga, involved in car accident in July 2023, helping cousin find housing, inspired by Laura's gratitude letter, plans to volunteer at shelters in August 2023, dropped off baked goods at shelter in late July 2023
---
In late February 2023, Maria's grandma passed away. It's been a difficult time, but she's trying to stay positive.

- Still volunteers at the homeless shelter, building connections by listening and showing compassion
- Takes a trip to England a few years ago, was mesmerized by the castles in London
- Created a shadow box with a castle photo and a painting of a castle on a hill inspired by London's architecture
- Values making memories with family and friends, draws inspiration from her own childhood memories with siblings

Maria is active in community service and fitness:
- Volunteers at the homeless shelter
- Donated her old car to a homeless shelter she volunteers at
- Planning a ring-toss tournament for the homeless shelter's fundraiser later this month (May 2023)
- Excited to see the impact the fundraiser will make
- Started doing aerial yoga
- In June 2023, joined a gym - enjoying the welcoming atmosphere and sticking to her workout routine
- Has goals to get stronger and improve endurance
- Trying kundalini yoga as part of her fitness activities
- Keeps fit with various workout classes
- Family is small but loves quality time with friends
- Friend activities: watching movies, hiking, game nights at her place
- Makes peach cobbler
- Took a sunset photo at the beach last month (December 2022) - felt peaceful and connected to nature
- Became friends with a fellow volunteer at the homeless shelter
- Takes notes about local politics in her notebook

- In July 2023, was involved in a car accident when another driver ran a red light and hit her; fortunately everyone was okay
- Actively helping her cousin find new housing in early July 2023 after her cousin had to leave in a hurry
- Was inspired by a gratitude letter from Laura, a shelter resident, about the impact they made on her life
- Believes strongly that small acts of kindness can make a big difference
- In late June 2023, went hiking with church friends. The experience was:
  - Uplifting and refreshing
  - Provided an opportunity to make connections, laugh, and enjoy nature
  - Reaching the top was amazing with breathtaking views
  - Gave her a sense of peace and feeling connected to something special
- Plans to volunteer at shelters in August 2023
- In late July 2023 (around July 31), Maria dropped off baked goods at the homeless shelter where she volunteers. She felt "more motivated than ever to help people" after the experience.
- She took a photo of a group of people standing around a table with food, noting it reminded her that "being kind matters."
- Maria believes strongly in small acts of kindness making a difference and is committed to continuing her volunteer work.