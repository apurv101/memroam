name: John and Maria's tech for good convention
description: John attended a tech convention with colleagues passionate about using technology for community good in late March 2023

---

**Date:** April 18, 2023 (conversation about event from last month)

John attended a convention with his colleagues the previous month (late March 2023). The group is described as being "all passionate about using tech for good in their community."

At the convention, they:
- Connected with like-minded people
- Swapped ideas about technology for community change
- Brainstormed together
- Stayed motivated and energized

John described the energy in the room as "infectious" and the experience as "awesome." Being surrounded by motivated, like-minded individuals gave him "renewed energy and a purpose" and inspired him to "make a bigger difference."

Maria also shared photos from the convention showing:
- Two men standing next to each other at the convention
- A group of people sitting around a table
- A table with a map of a city on it
