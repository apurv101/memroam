name: John volunteers at school career fair
description: John volunteered at a career fair at a local school in late March 2023, helping students with limited resources
---
In late March 2023, John volunteered at a career fair at a local school. He described the experience as "incredible" and deeply rewarding.

What John observed:
- How lack of resources affects children's dreams and opportunities
- The importance of community support in helping kids reach their potential

John was inspired to continue supporting such initiatives, noting the need for community members to help those who need it most. He felt it was important to keep "pushing for the kids" and recognized the difference individuals can make by getting involved.

John also shared a photo of a heart-shaped sign that said "Always look on the bright side of life," which he felt represented how kids can achieve their dreams with the right help and support.
