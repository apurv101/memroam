name: John started weekend yoga class
description: John began attending a beginner's weekend yoga class with a colleague in early April 2023
---
In early April 2023, John started attending a beginner yoga class on weekends with a colleague. He described it as "awesome" and said he feels great mentally and physically after each session.

John had been wanting to try yoga for a while and finally took the plunge. The class focuses on fundamentals like poses and breathing, which he finds helps him relax and increase flexibility. He noted the positive effects on his wellbeing from simple stretching and breathing.

John praised the instructor for:
- Ensuring proper form on poses
- Encouraging students to listen to their bodies
- Creating a relaxed, welcoming environment for everyone

Yoga has become part of John's daily routine, not just for physical benefits but also for the peace of mind and mindfulness it brings.
