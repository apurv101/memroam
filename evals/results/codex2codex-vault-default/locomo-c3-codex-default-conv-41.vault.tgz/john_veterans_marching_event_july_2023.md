name: John's veterans marching event
description: In early July 2023, John participated in a marching event for veterans' rights, showing his ongoing support for the military

---

In early July 2023 (around July 2-3), John participated in a marching event for veterans' rights. He has always had a great respect for the military and wanted to show his support for those who have served.

The event was inspiring for John - he felt motivated being around others who shared his values and passion for supporting veterans. He expressed that standing up for what we believe in is important, and he finds it meaningful to show support for veterans however he can.

This event was another example of John's long-standing commitment to veterans' issues, which includes his petition project from May 2023 and the veterans community gathering he and Maria hosted in mid-May 2023. The marching event reminded John of how much sacrifice military members make and strengthened his resolve to continue advocating for veterans' rights.
