name: Maria's church friends community work
description: In August 2023, Maria started community work with church friends, reinforcing her values of kindness and compassion
---
In early August 2023, Maria took up community work with friends from her church. She described the experience as "super rewarding."

This volunteer work aligns with Maria's broader values of kindness and compassion. During their conversation, she reflected on how "these moments remind me of how important kindness and compassion are."

Maria has consistently sought out opportunities to serve others, including her work at the homeless shelter. Her engagement with her church community represents another facet of her commitment to making a positive difference in her community.
