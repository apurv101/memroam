name: John Joins Fire-Fighting Brigade
description: John joins fire-fighting brigade and participates in community fundraiser raising canned food, toiletries, and clothes over two hours to help local fire station.

---

On August 16, 2023, John shared that he joined the fire-fighting brigade and was excited to be involved and help his community. He was impressed with the brigade's dedication and teamwork.

They organized a two-hour community fundraiser where they raised canned food, toiletries, and clothes to help out. The donations helped purchase a brand new fire truck. John found the experience deeply satisfying and felt a strong sense of purpose and passion, describing it as his "true calling."
