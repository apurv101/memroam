name: Family boot camp routine
description: John and his family started boot camps in April 2023, working out 3x/week together
---
In April 2023, John and his family started attending boot camps together. They work out three times a week, which has resulted in:

- More energy for the whole family
- Gains in strength and endurance
- Kids getting excited about staying active

The family supports each other during workouts by cheering each other on and providing emotional support outside of workouts. This shared activity has been a great bonding experience, though John acknowledges it hasn't been easy. They're all committed to creating healthy habits together.
