name: Growth through stepping out of comfort zone
description: Shared lesson: pushing boundaries and trying new things helps us grow, learn, and discover capabilities
---
John and Maria's shared philosophy (from conversation on May 4, 2023):

Pushing boundaries and stepping out of comfort zones is how we grow and find out what we're really capable of. It's a journey of self-exploration - it can be hard but it's so worth it.

Trying new things takes guts and can be rewarding. It helps us grow and learn more about ourselves. We've got the right attitude to take on harder things in life, which helps us keep improving.

This is a never-ending journey of learning and growth, blessed that they both have this mindset in their lives.
