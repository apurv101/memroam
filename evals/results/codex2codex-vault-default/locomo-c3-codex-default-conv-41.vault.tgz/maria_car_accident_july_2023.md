name: Maria's car accident
description: In July 2023, Maria was involved in a car accident when another vehicle ran a red light and hit her; fortunately everyone was okay

---

In early July 2023, Maria was involved in a car accident while out and about. Another driver ran a red light and collided with her vehicle. Fortunately, everyone involved was okay despite the scary incident.

Maria shared photos of the damaged car on a flatbed with her friend John. The accident happened the day before their conversation on July 3, 2023.
