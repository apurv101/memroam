name: Maria joins gym and does kundalini yoga
description: Maria joined a gym in June 2023, enjoying the welcoming atmosphere and sticking to her workout routine
---
On June 16, 2023, Maria shared that she had joined a gym the previous week. She described it as a super positive experience:

- The atmosphere is welcoming and supportive
- She's sticking to her workout routine consistently
- The people at the gym are awesome
- She has fitness goals to get stronger and improve her endurance
- She's trying kundalini yoga as part of her fitness activities

This was a new commitment for Maria at the time of the conversation.
