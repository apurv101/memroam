name: John's family military cemetery visit
description: In early August 2023, John's family had a meaningful experience visiting a military memorial that deeply impacted his children

---

In early August 2023 (approximately August 2-3, 2023), John's family visited a military cemetery/memorial, which proved to be a profoundly meaningful experience for his children.

**The experience:**
- John's family visited a military memorial/cemetery
- The experience was described as "meaningful" and made an impact on his kids
- John's children were "awestruck and humbled" by what they witnessed

**Impact on John's children:**
- They were awestruck by the experience
- Felt humbled by what they saw
- This created a memorable teaching moment about military service

**John's reflection:**
- The visit was meaningful for John's family as a whole
- He views it as important to show younger generations how to respect and appreciate those who served their country
- Believes it's important to teach children about veterans and what they did for the nation

**Shared values with Maria:**
Maria agreed that it's super important to teach kids about veterans and that younger generations should remember and appreciate those who served. John echoed this, saying "Showing them how to respect and appreciate those who served our country is important."

**Context:**
This family visit aligns with John's established commitment to military and veteran advocacy, including his virtual support group for military advocates, veterans petition project, and participation in veterans' events. It demonstrates his desire to instill these values in his own children, particularly his one-year-old son Kyle.
