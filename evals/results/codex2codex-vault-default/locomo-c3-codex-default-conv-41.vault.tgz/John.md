name: John
description: John has one-year-old son Kyle, lost pet Max, retaken military aptitude test with great results, pursuing volunteering for country and joined fire-fighting brigade in July 2023, participated in first rescue mission saving a family from burning building, working on veterans petition project, enjoys family park activities and violin concert, promoted to assistant manager in June 2023, frequents a gym with diverse workout classes
---
John's pet Max passed away recently. He's finding comfort in good memories and is grateful for support from friends.
In March 2023, John had a picnic with his wife and kids. His one-year-old son Kyle is adorable.

- The family goes to the park a few times a week for bonding and play
- They attended a violin concert last week (late February 2023) that the whole family enjoyed
- Retook the military aptitude test in late February 2023 with great results
- Decided to volunteer for his country after discussing with supportive family and friends
- Describes parenting as "a wild ride" full of ups and downs, with love and happiness outweighing challenges
- Came up with family activities like walks, picnics, and finding local events

John's interests and goals:
- Does kickboxing for fitness and stress relief
- Plans to enter local politics
- Focus areas: improving education and infrastructure in the community
- Recently returned from a family road trip (December 2022)
- Involved in a school building project that received funding
- Networking with people for campaign input, inspired by stories about making education better
- Family is his rock and motivation - has a picnic, playground, and dinner photos
- Family activities: climbing, sliding, playing games at playground
- Family made pizza together
- Practices taekwondo
- Joined a service-focused online group last week (December 2022) - emotional and inspiring experience
- Group events: gave food/supplies at homeless shelter, organized toy drive for kids in need
- Brainstorming projects to help underserved communities: education access, mentorship, job training, resume building
- Recently failed military aptitude test and has been feeling stressed
- Had a car accident with broken windshield on way home last week - stayed calm, asked for assistance, made it home safely
- Uses watching sunsets to calm down and appreciate small things in life
- Actively pursuing local politics - talking to community leaders, learning about neighborhood needs and hopes
- Has a community meeting next week to discuss education and infrastructure upgrades
- Always been passionate about veterans and their rights
- In May 2023, working on a petition project to support military veterans
- Hosted a small party with veterans in mid-May 2023 for story-sharing and community building
- In mid-June 2023, received a promotion to assistant manager after overcoming significant obstacles including self-doubt, tech issues, and workplace challenges
- Views the promotion as a stepping stone for bigger things and earned through perseverance and support from family
- In early July 2023, participated in a marching event for veterans' rights; always has great respect for the military and wants to show support
- Found the event inspiring, being surrounded by others who shared his values and passion for supporting veterans
- In late July 2023, frequents a gym/studio with a chill vibe and awesome instructors. The gym offers:
  - Yoga (described as challenging but peaceful)
  - Kickboxing
  - Circuit training
  - Weight training
- Enjoys trying new classes to push himself and mix up his exercise routine
- Plans to suggest the gym to Maria if she's interested in trying it
- In late July 2023, John joined a fire-fighting brigade. The training was intense and taxing but really rewarding, and it changed his view on helping others.
- On their first call-out (around July 31, 2023), the team responded to a burning building and successfully saved a family. John describes it as chaotic but says they pulled together and he got a surge of energy and purpose.
- John found the camaraderie and trust among fire brigade teammates similar to his time in the military, saying "it's a bond I haven't felt since my time in the military." He described them as becoming like family to him.
- He views the work as fulfilling and meaningful, serving and protecting the community with people who have different skills and talents that all contribute.
- Maria continued volunteering at the homeless shelter and shared a photo of a group of people around a table with food, noting it reminded her that being kind matters.

