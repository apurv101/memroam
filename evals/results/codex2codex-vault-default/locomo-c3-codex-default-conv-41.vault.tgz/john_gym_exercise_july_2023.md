name: John's new gym and exercise routine
description: In late July 2023, John frequents a gym with a chill vibe offering yoga, kickboxing, circuit training, and weight training classes
---
In late July 2023, John shared that he's been going to a gym/studio with a chill vibe and awesome instructors. The place offers a variety of classes that keep his workouts interesting:

- Yoga (described as challenging but peaceful)
- Kickboxing
- Circuit training
- Weight training (found it challenging but peaceful, similar to yoga)

John enjoys trying new classes as a way to push himself and mix up his exercise routine. He encouraged Maria to try it if she's interested.
