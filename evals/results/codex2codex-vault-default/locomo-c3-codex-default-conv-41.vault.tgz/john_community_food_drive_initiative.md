name: John's community food drive initiative
description: John started a food drive in early Feb 2023 for people who lost their jobs due to unemployment
---

In early February 2023, John started helping out with a food drive specifically aimed at helping people who lost their jobs due to unemployment in their community.

His motivation came from:
- Seeing firsthand the effect unemployment has on neighbors
- A decision to act and help in tough economic times
- A desire to make a difference through community food drives

The food drive was well-received:
- They were overwhelmed by the community response
- Many volunteers signed up to help
- They've been holding recent events to distribute food

John shared photos of:
- The food drive event at a food bank
- A thanksgiving potluck that was organized
- Volunteers at recent events

This initiative aligns with John's broader interest in public service and helping underserved communities.
