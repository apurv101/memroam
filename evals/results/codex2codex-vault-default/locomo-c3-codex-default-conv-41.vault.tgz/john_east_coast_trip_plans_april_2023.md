name: John's East Coast trip plans
description: John announced plans to visit the East Coast during April 2023 conversation with Maria

---

**Date:** April 18, 2023

During a conversation with Maria, John mentioned that he was planning a trip to the East Coast. This came up naturally as they were catching up about what's going on in each other's lives.

No further details were shared about the specific destination, timing, or purpose of the trip.
