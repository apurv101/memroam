name: John's determination despite campaign setbacks
description: John continues running for office in May 2023 despite previous unsuccessful campaigns, motivated by community impact
---

John's May 2023 conversation with Maria highlighted his continued commitment to running for office despite previous unsuccessful campaigns. He described it as:

- "Can't let go of my dream to make a difference in my community"
- Feeling it was "a dream come true"
- Acknowledging it's "tough" but motivated by Maria's support
- Determined to keep going and "make a real difference"

This conversation reflects his resilient, persistent nature when pursuing community improvement, even in the face of past setbacks. He specifically mentioned wanting to work on improving West County, his old area.
