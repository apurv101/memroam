name: John organizes 5K charity run for veterans
description: John organized a 5K charity run in late July 2023 to raise funds for veterans and their families, also supporting domestic abuse awareness
---
In late July 2023, John organized and set up a 5K charity run in his neighborhood to raise funds for veterans and their families.

The event required significant effort on John's part:
- Getting sponsors through outreach to multiple businesses via different channels
- Coordinating with the city for permits and logistics
- Spreading the word to build community participation

The event was successful, with what John described as a "great turnout" and a good amount of funds raised. He emphasized that "seeing everyone come together to support our veterans made it worth it."

Additionally, John mentioned that the event included support for a local organization that helps victims of domestic abuse. They raised awareness and funds for this cause as well, working with the organization at the event.

Maria responded positively to John's initiative, calling it "awesome" and saying it's "an honor to know someone like you who takes initiative." She found the photo from the event "powerful."

This event builds on John's established pattern of supporting veterans through various initiatives, including his petition project, community gatherings, and participation in veterans' marching events throughout 2023.
