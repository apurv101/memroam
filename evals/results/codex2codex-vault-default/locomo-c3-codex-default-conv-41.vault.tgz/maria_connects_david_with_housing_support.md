name: Maria connects David with housing support
description: Maria met David at a Feb 2023 charity event and connected him with a local organization providing homeless housing and support
---

During a charity event in early February 2023, Maria had a meaningful conversation with a man named David who was experiencing homelessness.

David shared his story of hardship and how he ended up in difficult circumstances. This conversation was humbling for Maria and reinforced her belief that everyone has their own story and deserves understanding.

After their conversation, Maria took action to help:
- She connected David with a nearby organization that offers housing and support for homeless individuals
- She hoped he would find the help he needed

This experience was part of why Maria found the charity event so rewarding - not just serving meals, but helping people find the specific resources they need.
