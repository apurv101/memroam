name: Shared lesson on teaching children about service and gratitude
description: On August 3, 2023, John and Maria discussed the importance of teaching younger generations to respect and appreciate those who serve their country

---

During a conversation on August 3, 2023, John and Maria reflected on the importance of educating younger generations about military service and gratitude.

**The discussion:**
John had recently taken his family to a military cemetery/memorial where his children were "awestruck and humbled" by the experience. Maria imagined how visiting a military memorial would make her feel humble as well.

**Key shared beliefs:**
- It's important for younger generations to remember and appreciate those who served
- Teaching kids about veterans and what they did for the nation is essential
- Showing children how to respect and appreciate those who served their country matters
- These experiences create meaningful teaching moments about gratitude and service

**Broader context:**
This discussion occurred while John was actively organizing a virtual support group for military advocates (recruiting family and friends) and Maria was continuing her volunteer work at the homeless shelter. Their conversation highlighted how both were living out their values and seeking to instill them in the next generation - John through direct experiences with his children, and Maria through her ongoing service work and the example she sets.

**Lesson learned:**
Shared experiences that connect children with those who have served can create lasting impressions of humility, gratitude, and respect. These moments matter for building a culture of appreciation for service and sacrifice.
