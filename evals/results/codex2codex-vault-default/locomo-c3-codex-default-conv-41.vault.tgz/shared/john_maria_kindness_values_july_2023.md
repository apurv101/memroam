name: Shared commitment to kindness and service
description: John and Maria discussed their mutual dedication to helping their community through volunteering and service work in July 2023

---

On July 31, 2023, John and Maria discussed their ongoing commitment to community service and making a positive difference.

John shared that he had joined a fire-fighting brigade, describing it as "such a great feeling to do something to give back to my community!" He mentioned that the training was intense but rewarding, and it changed his perspective on helping others.

Maria had just dropped off baked goods at the homeless shelter where she volunteers, expressing she was "more motivated than ever to help people." She shared a photo of a group of people gathered around a table with food, noting it reminded her that "being kind matters."

Both reinforced their belief that:
- Small acts of kindness can make a real difference
- Community service is fulfilling and meaningful
- Having supportive teams and friends who can rely on each other makes a huge impact
- Helping others brings purpose and fulfillment

John mentioned that the bond he's formed with his fire brigade teammates reminds him of his time in the military, saying "it's a bond I haven't felt since my time in the military."

Maria continued her volunteer work at the homeless shelter, building connections through compassion and listening, while John was beginning his new role serving and protecting his community through the fire brigade.