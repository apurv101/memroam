name: John's daughter Sara
description: John has a daughter named Sara; they took a family trip last year for her birthday
---
In June 2023 conversation, John shared that a family photo was taken during a trip last year for his daughter Sara's birthday. The photo shows the family posing on a train track in the fall. Sara is a source of motivation for John's community work.
