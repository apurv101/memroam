name: Maria and mom cooking together
description: Maria and her mom made a dinner spread with salads, sandwiches, and homemade desserts
---
Maria and her mom made a dinner together featuring:
- Salads
- Sandwiches
- Homemade desserts

Maria's favorite is the banana split sundae, which she enjoys after a day of volunteering as a little moment of joy and balance.
