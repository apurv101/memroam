name: John visits veterans hospital in mid-June 2023
description: John visited a veteran's hospital in mid-June 2023 and was deeply moved by meeting elderly veteran Samuel
---

In mid-June 2023 (last week before July 17), John visited a veteran's hospital. This visit was eye-opening and meaningful for him.

Key points from the visit:
- John met amazing people at the hospital
- He heard stories from an elderly veteran named Samuel that were both inspiring and heartbreaking
- The veterans' resilience filled John with hope
- The visit reminded John why he wanted to join/connect with the military
- It made him appreciate what he has and the need to give back

This experience reinforced John's commitment to supporting veterans and deepened his desire to connect with military communities.
