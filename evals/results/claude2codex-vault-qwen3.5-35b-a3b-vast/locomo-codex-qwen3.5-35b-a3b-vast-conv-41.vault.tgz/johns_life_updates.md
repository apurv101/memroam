name: John's Life Updates
description: Key updates about John's fitness journey, family life, and recent loss of family dog Max

# Family & Fitness Journey
- Started attending boot camps with family last month (April 2023)
- Works out together 3 times per week
- Observed improvements: more energy, gains in strength and endurance
- Kids getting excited about staying active - great for bonding
- Family provides mutual support - cheering each other on during workouts, emotional support outside workouts
- John made apple pie for his kids recently
- **August 2023: Volunteering as a mentor at a local school** - finds it very rewarding to help students; students showing real improvement in confidence and skills
- **Promoted to assistant manager (June 2023)** - sees it as stepping stone for bigger things
- **Commemorative trophy received** - symbolizes overcoming obstacles including self-doubt
- Faced tech issues, workplace challenges, and internal self-doubt
- Attributes success to home support and personal grit
- **Trying rock climbing** as a way to push limits
- **Struggling with work-life balance** - works regular hours, sometimes brings work home
- **Values organization and prioritization** - emphasizes finding balance and making moments count
- Max, the family dog, passed away after 10 years (June 2023)
- Family coping with loss, finding comfort in cherished memories
- Max taught lessons about unconditional love and loyalty
- John considering adopting a rescue dog to honor Max's memory and teach children about responsibility and compassion
- Maria volunteers at local dog shelter and offered support

# Values & Activism
- **Strong respect for the military** - deeply values their sacrifice and wants to show support
- **July 2023: Veterans rights activism** - participated in a marching event for veterans' rights
- **July 7, 2023: Community flood response** - flood hit John's old area, causing home damage; organizing community meeting to discuss solutions
- **Motivated by shared values** - finds inspiration and motivation being around like-minded people
- **Believes in standing up for beliefs** - important to try and make a difference through activism
- **Finds motivation in community** - reminded of importance of trying to make a difference through activism
- **Values kindness and compassion** - finds meaning in supporting others and making a positive impact

# Personal Philosophy
- Family is the most important thing - they're his biggest support
- Believes in having each other's backs through good times and bad
- Values working through challenges together
- **Believes in helping those in need** - committed to supporting friends like Maria and her cousin

# Conversation Context
- Conversation with Maria on May 4, 2023 at 3:18 pm
- John shares photos: white board with workout list, family photo in park, banana split ice cream, mountain with lake view
