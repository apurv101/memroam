---
id: 01a0507d-e3a5-7748-8ab4-42a625d2929c
name: John & Maria's Conversation (July 31, 2023)
description: John shares his fire-fighting brigade experience and first call-out; Maria shares her homeless shelter baking donations
---
# John & Maria's Conversation - July 31, 2023

**Maria:** Hey John, I'm doing ok - hope you are too. Some interesting stuff has been going on; last week I dropped off that stuff I baked at the homeless shelter. It was great and I'm more motivated than ever to help people.

**John:** Hey Maria, that's awesome! I'm really inspired by your drive to make a difference. You mentioned your work at the homeless shelter last time and it made me think of how I could help too, so I just joined a fire-fighting brigade. It's such a great feeling to do something to give back to my community!

**Maria:** Wow John, joining the fire brigade? That's great! How's it been so far?

**John:** [shares a photo: a photo of a firefighter's gear laid out on the floor] Thanks, Maria! It's been tough, but really rewarding. The training was intense and taxing, but it changed my view on helping others. Last Sunday we had our first call-out, and it was intense. We responded to a situation and our team worked together to help those in need. Seeing their relief was awesome.

**Maria:** Wow, John! What was it like being part of that rescue mission?

**John:** It was chaotic when we arrived, but we pulled together. I got a surge of energy and purpose, and we were able to save a family from a burning building. It was wild, but knowing we made a difference made it worth it.

**Maria:** Wow John, that's intense! Helping out like that takes guts - it's inspiring to hear about the difference you made.

**John:** Thanks, Maria! It was an adrenaline rush, and I couldn't have done it without them. We trust and rely on one another, and it's great to know that we have each other's backs. They've become like family to me.

**Maria:** Sounds great, John! It must feel incredible to have a supportive team like that.

**John:** Yeah, it really does feel helpful, Maria. We have different skills and talents, but they all contribute to serving and protecting our community. And it's a bond I haven't felt since my time in the military.

**Maria:** Glad you've found that same strong bond. Having friends you can rely on makes a huge difference.

**John:** Yeah, Maria! It's nice to know we're all in this together, striving to keep our community safe. I find it fulfilling and meaningful.

**Maria:** [shares a photo: a photography of a group of people standing around a table with food] Yeah John! It feels great to help people, and you're so awesome for it! Here's a shot I got when I volunteered. Reminds me being kind matters!

**John:** That's a cool photo, Maria! Small acts like that can really make a difference. Keep it up!

**Maria:** Thanks John! I totally agree, so I'm gonna keep it up.

**John:** Way to go, Maria! Keep on being positive and making a difference. You're doing great!

**Maria:** Thanks John! Your support means a lot to me. I'll definitely keep on going. Talk to you soon!
