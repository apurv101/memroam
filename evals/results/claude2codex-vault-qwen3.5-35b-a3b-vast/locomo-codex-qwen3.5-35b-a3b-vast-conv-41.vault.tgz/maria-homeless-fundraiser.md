---
id: 01a0507b-fb0c-7639-b319-56fb155ce921
name: Maria's Homeless Shelter Fundraiser
description: Maria's fundraising event for homeless shelter
---

# Maria's Homeless Shelter Fundraiser

Maria is planning a fundraising event for a homeless shelter.

Event details:
- Activity: Ring-toss tournament
- Purpose: Fundraiser for homeless shelter
- Timeline: Planned for "later this month" (May 2023, from conversation dated May 20, 2023)
- Maria is excited about the potential impact of the event

**July 2023 Update: Personal incident**
- Maria was hit by a car that ran a red light while out volunteering
- Her car was severely damaged and had to be put on a flatbed
- Fortunately, everyone was okay
- Despite this setback, she continues her shelter volunteer work

This was mentioned in a conversation with John on May 20, 2023, where they discussed their mutual commitment to community service and helping others.