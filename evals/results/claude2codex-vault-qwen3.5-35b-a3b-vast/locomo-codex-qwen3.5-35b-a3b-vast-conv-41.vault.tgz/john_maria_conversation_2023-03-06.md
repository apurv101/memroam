name: John and Maria conversation - March 6, 2023
description: Conversation between John and Maria on March 6, 2023

**Date:** March 6, 2023, 6:03 PM

**Key Events & Information:**

**Maria:**
- Her grandma passed away last week (late February 2023) - this has been really hard for her
- Volunteering at a homeless shelter
- Building connections through listening and showing compassion
- Created a painting of a castle on a hill (inspired by a trip to London, England)
- Has a shadow box with a castle in it (travel memory from London)
- Loved doing similar things with her siblings when young

**John:**
- Has a one-year-old son named Kyle
- Has a wife
- Two children total (Kyle and a young girl)
- Goes to the park with his family a few times a week for family bonding
- Recently rettook an aptitude test with great results
- Considering volunteering/serving his country (discussed with family and friends who are supportive)
- Took his family to a violin concert last week
- Finds fun family activities: walks, picnics, local events

**Relationship:**
- Good friends who support each other
- Both involved in community service activities
- John is supportive of Maria during her loss
- They share photos and discuss family life

**Memorable details:**
- John's kids enjoy the playground, especially swinging
- Maria's castle art is a reminder of London's history and grace
- Both value making memories together and building real connections
