name: John and Maria conversation - August 3, 2023
description: Discussion about volunteer work - John's military advocacy and Maria's homeless shelter volunteering

## Conversation Summary (6:20 pm, August 3, 2023)

**John's Military Advocacy:**
- Organizes a virtual support group for the military
- Invited family and friends to join as advocates for service members
- Family recently visited a military memorial with meaningful impact
- His kids were awestruck and humbled by the experience
- John emphasizes importance of teaching younger generations to respect veterans

**Maria's Homeless Shelter Volunteering:**
- Started volunteering about a year ago
- Motivated after witnessing a struggling family on the streets
- Reached out to shelter and began volunteering
- Considers it a fulfilling experience
- Received a heartfelt gratitude note from Cindy, a shelter resident
- Acknowledges challenges but staying motivated knowing she makes a difference

**Shared Values:**
- Both discuss the importance of community support
- Agree on teaching younger generations about service and helping others
- Emphasize the power of teamwork and collective impact