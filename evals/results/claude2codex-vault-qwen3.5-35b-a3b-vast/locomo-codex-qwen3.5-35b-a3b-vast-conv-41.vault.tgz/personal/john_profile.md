name: John - Personal Profile
description: Community advocate passionate about education and infrastructure
---

**Identity:** John, a community advocate working to improve neighborhoods through education and infrastructure initiatives.

**Work Focus:**
- Passionate about how education and infrastructure shape communities
- Actively works to address negative effects of lacking infrastructure in neighborhoods
- Sometimes experiences doubt about impact but continues due to family motivation

**Sources of Inspiration:**
- Family is his primary motivator
- Exercise
- Spending time with friends
- Nature/walks

**Personal Notes:**
- Takes weekly walks to disconnect and find peace
- Values appreciating nature (especially sunsets)
- Has a daughter named Sara
- Takes time to "take a break and breathe"

---
**Key Quotes:**
"It's so sad how they can stunt growth in neighborhoods, but it also drives me to do what I can to make it better."
"When times get hard, I look at it and remember why I'm doing what I'm doing."