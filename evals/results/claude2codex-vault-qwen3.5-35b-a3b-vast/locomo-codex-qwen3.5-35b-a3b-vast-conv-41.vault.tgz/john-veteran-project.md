---
id: 01a0507b-f603-7638-8ef8-f210c324146f
name: John's Veteran Support Project
description: John's initiative to support military veterans
---

# John's Veteran Support Project

John has been working on a project to support military veterans and their rights. 

Key details:
- Starting a petition to support veterans
- Passionate about veterans' rights and appreciation
- Hosted a small party inviting veterans to share their stories
- Events focused on creating connections, camaraderie, and community among veterans
- Shared photos showing: a parking lot with flag and flowers, and a man shaking hands with a soldier in uniform
- Events took place around late May 2023 (photos from "last Friday" referenced)

The project aims to show appreciation for veterans' service and support, making their lives better in the community.