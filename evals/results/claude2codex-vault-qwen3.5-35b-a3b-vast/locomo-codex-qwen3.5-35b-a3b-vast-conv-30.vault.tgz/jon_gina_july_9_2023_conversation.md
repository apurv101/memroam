name: Jon & Gina conversation
description: Jon & Gina chat on July 9, 2023

---
name: Jon & Gina conversation
description: Jon & Gina chat on July 9, 2023
date: 2023-07-09
---

**Gina:** [shares a photo: a photo of a mannequin in a room with a wood wall] Hey Jon! Long time no chat! How's the dance studio? Last week was wild, I got noticed by fashion editors and it's been amazing but kinda scary. Everything's exciting but it's a lot of pressure to keep going up!

**Jon:** Hey Gina! Congrats on the fashion editors reach-out, that's awesome! Dance practice has been fun and exhausting. I'm gonna stay determined and make my own path by going full-time with my biz idea.

**Gina:** Just remember that sometimes stumbling blocks can be opened doors. Keep going!

**Jon:** Thanks! Your support and encouragement means a lot. Losing my job was a bummer, but it pushed me to take the plunge and go for my biz dreams. Started to learn all these marketing and analytics tools to push the biz forward today. It's been tricky, but I'm up for the challenge and I'm gonna make this work!

**Gina:** Go get 'em, Jon!

**Jon:** I'm also excited to guide and mentor aspiring dancers on their dreams.

**Gina:** [shares a photo: a photo of a drawing of a couple dancing] Wow, Jon! That's awesome. Loving what you do and bringing joy to others is so rewarding. You're definitely the perfect mentor & guide. Your positivity and determination will make your dance studio a hit!

**Jon:** Thanks, Gina - really appreciate your words and encouragement! Dance has the power to bring us together and create sweet moments. Moments like this remind me why I'm chasing my dream and keep me pushing through any struggles.

**Gina:** Take comfort in knowing you've got a solid community cheering you on, me included. Keep on pushing!

**Jon:** Feeling supported by all of you means so much. It gives me the oomph to keep chasing my dreams. Your faith in me is priceless - I won't let you down!

**Gina:** Don't let anything stop you. You have potential!

**Jon:** Thanks, Gina! Your faith in me is a real boost. I'm gonna make my dreams come true!

**Gina:** Keep pushing and you'll get there. Your dreams are so close!

**Jon:** Thanks, Gina! I won't quit, even when it's hard. I'm gonna make it!

**Gina:** You got this, Jon! Don't let the bumps in the road bring you down. Keep going and make your dreams a reality! I'm rooting for you!

**Jon:** [shares a photo: a photo of a chalkboard with a quote written on it] Thanks, Gina! Your belief in me means the world. I'm not gonna let anything or anyone stop me. I'll keep pushing and make my dreams come true. Thanks for being a great friend. You rock!

**Gina:** Hey Jon, glad I could help! Always here to cheer you on.

**Jon:** [shares a photo: a photo of a drawing of a smiley face floating in the water] Thanks! Glad that you are on my side.

**Gina:** Sure, see ya. Bye!

**Jon:** Bye!

**Gina:** ;)

---
**Key points from this conversation:**
- Gina got noticed by fashion editors, which is amazing but also brings pressure
- Jon is planning to go full-time with his dance studio business idea
- Jon lost his job which pushed him to pursue his business dreams
- Jon is learning marketing and analytics tools to advance his business
- Jon wants to mentor aspiring dancers
- Gina and Jon share a supportive, encouraging friendship
