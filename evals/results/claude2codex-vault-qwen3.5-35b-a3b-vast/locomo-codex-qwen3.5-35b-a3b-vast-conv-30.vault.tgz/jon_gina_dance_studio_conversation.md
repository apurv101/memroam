name: Jon and Gina - Clothing & Dance Studio Business Plans
description: Conversation from Jan 29, 2023 about Gina's clothing store launch and Jon's dance studio search, including travel updates

## Date: January 29, 2023

## People:
- Jon: Looking to open a dance studio
- Gina: Launched her own clothing store

## Career Updates:
- Gina launched her clothing store and started an ad campaign to grow the business on or before Jan 29, 2023
- Jon is actively searching for a spot for his dance studio, with focus on location, natural light, size, and floor quality

## Shared Interests:
- Both passionate about contemporary dance
- Dance serves as their stress relief and passion

## Travel Updates:
- Jon: Visited Paris (January 29, 2023)
- Gina: Visited Rome once (no recent travel mentioned)

## Dance Studio Details:
- Jon is looking for a downtown location with great natural light
- Floor: Planning to use Marley flooring for its grip, durability, and ease of cleaning
- Jon wants to ensure the floor has enough bounce for safe dancing

## Clothing Store:
- Gina launched her own clothing store
- Started an ad campaign to grow the business
- Finds entrepreneurship scary but rewarding

## Photos Shared:
1. Gina's clothing store display
2. Jon's potential dance studio location (blue floor, pink wall)

## Notes:
- Jon mentioned going to Paris "yesterday" (referring to Jan 28, 2023)
- Gina has only visited Rome once
- Both express mutual encouragement and support for each other's entrepreneurial journeys
