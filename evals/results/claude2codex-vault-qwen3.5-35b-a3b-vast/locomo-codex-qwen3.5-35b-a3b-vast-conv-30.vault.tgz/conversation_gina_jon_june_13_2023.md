---
id: 01a05078-e266-78b5-b9cf-f495fd113a29
name: conversation_gina_jon_june_13_2023
description: Jon discusses dance studio prep and organizational methods
---

# Jon & Gina Conversation - June 13, 2023 (8:29 PM)

**Jon:** Thanks for being there for me and believing in me, Gina. I'm prepping for my dance studio more than ever.

**Gina:** Proud of you for starting your own business! It takes strength to stay hopeful. She has developed a video presentation to teach how to style fashion pieces. She shared several photos:
- A photo of a group of young girls in blue outfits posing for a picture
- A photo of a skeleton and a trophy on a black cloth
- A photo of a group of people in a dance class
- A photo of a person holding a paper bag with a bird picture

**Jon:** It's been so inspiring to work with our young dancers, seeing their passion and commitment. Opening the dance studio's been a great experience - I want it to be a place of support and encouragement for all our dancers.

**Gina:** Starting this studio isn't just a business, it's a place for dancers to grow.

**Jon:** Besides the dance classes and workshops, I'm offering one-on-one mentoring and training to help dancers reach their full potential.

**Gina:** Your one-on-one mentoring and training will really push dancers to reach their goals. She mentioned she had a mentor too when learning how to dance.

**Jon:** A mentor can do wonders. Guidance and support can help dancers really shine. He shared:
- A photo of a clipboard with a notepad attached to it
- A photo of a notebook with a calendar on it (used to stay organized and motivated, sets goals, tracks achievements, helps find areas to improve)
- A photo of a group of markers sitting on top of a white surface (used to stay on track, visualize goals, tokenize successes)
- Color-coding achievements to easily track progress and stay motivated
- A photo of a cork board with pictures and words on it
- A photo of a quote on a white sheet with a rainbow of light

**Gina:** Staying positive is very important. Reminds Jon to keep going for his dreams and not quit.

**Jon:** He won't give up - will keep pushing and working to make his dreams happen. Thanks for the support!
