name: Jon and Gina - Online Store Launch and Mutual Support
description: Jon and Gina discuss Gina launching her online clothing store combining fashion and dance, and Jon starting his own business after losing his job. They encourage each other through challenges.
date: 2023-03-16

---

Jon and Gina had a conversation on March 16, 2023 about their entrepreneurial journeys.

**Gina's News:**
- Lost her job at DoorDash, making things tough
- Successfully launched her online clothing store
- Store combines her passions for fashion trends and dance
- Shares a photo of computer screen showing book and shoes (likely inventory/products)

**Jon's Situation:**
- Also recently lost his job
- Started hitting the gym last week to stay on track with his venture
- Started his own business but facing challenges
- Shares a photo of laptop on table (likely working on his business)

**Key Themes:**
- Both entrepreneurs facing similar challenges after job losses
- Mutual encouragement and support
- Gina's determination inspiring Jon
- They see themselves as partners on different paths, rooting for each other
- Focus on chasing dreams, supporting each other, and celebrating achievements
- Both view their entrepreneurial journey as a rollercoaster worth it in the end
- End with celebratory toast to new heights and challenges

Gina expressed being passionate about fashion trends, unique pieces, and blending dance with fashion. Jon mentioned that starting his business has been tough but he's determined to make it work despite facing new challenges.
