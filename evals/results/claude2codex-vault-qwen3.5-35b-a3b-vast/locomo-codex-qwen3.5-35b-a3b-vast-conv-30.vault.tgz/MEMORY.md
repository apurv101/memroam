# conv-30 — memory index

- [conversation_gina_jon_9_feb_2023.md](conversation_gina_jon_9_feb_2023.md) — ⚠ no frontmatter
- [conversation_gina_jon_june_13_2023](conversation_gina_jon_june_13_2023.md) — Jon discusses dance studio prep and organizational methods
- [jon_gina_april_25_2023_conversation.md](jon_gina_april_25_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_april_3_2023_conversation.md](jon_gina_april_3_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_april_9_2023_dance_studio.md](jon_gina_april_9_2023_dance_studio.md) — ⚠ no frontmatter
- [jon_gina_dance_studio_conversation.md](jon_gina_dance_studio_conversation.md) — ⚠ no frontmatter
- [jon_gina_feb_1_2023_conversation.md](jon_gina_feb_1_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_feb_4_2023_conversation.md](jon_gina_feb_4_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_july_21_2023_conversation.md](jon_gina_july_21_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_july_23_2023_conversation.md](jon_gina_july_23_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_july_9_2023_conversation.md](jon_gina_july_9_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_june_16_2023_conversation.md](jon_gina_june_16_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_june_21_2023_conversation.md](jon_gina_june_21_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_march_16_2023_conversation.md](jon_gina_march_16_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_march_23_2023_conversation.md](jon_gina_march_23_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_may_11_2023_conversation.md](jon_gina_may_11_2023_conversation.md) — ⚠ no frontmatter
- [jon_gina_may_27_2023_conversation.md](jon_gina_may_27_2023_conversation.md) — ⚠ no frontmatter
- [session_2023-06-19_jon_dance_studio.md](session_2023-06-19_jon_dance_studio.md) — ⚠ no frontmatter
