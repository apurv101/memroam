name: Jon and Gina - May 27, 2023 Conversation
description: Gina's fashion internship acceptance & Jon's dance studio business plan

---

**Gina:** Hey Jon! Long time no talk! A lot's happened - I just got accepted for a fashion internship!

**Jon:** Congrats, Gina! That's awesome news about the fashion internship. 🎉 So stoked for you. Where is the internship and how're you feelin' about it?

**Gina:** [shares a photo: a photo of a laptop computer with a logo on the screen] Thanks! I'm excited and kinda nervous. Gonna be a big change. It's part-time position in the fashion department of an international company.

**Jon:** [shares a photo: a photo of a book with a yellow and green cover] Way to go, Gina! You really stepped up. What's your plan for the future?

**Gina:** Thanks! I'm a mix of excited and scared to get into fashion, but I'm trying to stay upbeat and learn as much as I can. What about you? Got something new?

**Jon:** I'm currently reading "The Lean Startup" and hoping it'll give me tips for my biz.

**Gina:** It sounds great! Could it spark any ideas for your dance studio?

**Jon:** [shares a photo: a photo of a white board with a list of dates on it] Yeah, the book got me thinking about building a focused and efficient business. Adapting and tweaking from customer feedback is important too, so I'm gonna try it out!

**Gina:** Woah, Jon, that whiteboard's got a bunch of good ideas! How you gonna keep track and stay on schedule with those dates?

**Jon:** Thanks, Gina! It helps me keep track of ideas and milestones. Gives me a visual of my progress and keeps me organized.

**Gina:** Nice idea! Having something visual can help with organizing and motivation. What're you working on currently?

**Jon:** I'm wrapping up the business plan and looking for investors. My passion for the project and belief in its success are driving me.

**Gina:** Wow, Jon! Impressed by your commitment. How's the hunt for investors going?

**Jon:** Thanks! Searching for investors has been tough, but I'm staying hopeful. It's all a process and I'm learning a ton.

**Gina:** Yeah Jon, you've got the right attitude! Keep learning and growing through it all. Keep going!

**Jon:** [shares a photo: a photo of a pink sign with a message on it] Thanks! I really appreciate your help. I'm gonna keep on going and never quit.

**Gina:** Keep it up!

**Jon:** Thanks! Your words really mean a lot. Don't worry, I won't let anything get me down.

**Gina:** Go Jon! Obstacles are inevitable, but you can do awesome things. Keep going!

---

**Key Takeaways:**
- Gina accepted a part-time fashion internship at an international company; feeling excited and nervous
- Jon reading "The Lean Startup" to apply lessons to his dance studio business
- Jon using a whiteboard to track ideas and milestones for his business plan
- Jon actively seeking investors for his dance studio venture
- Strong mutual support and encouragement throughout the conversation