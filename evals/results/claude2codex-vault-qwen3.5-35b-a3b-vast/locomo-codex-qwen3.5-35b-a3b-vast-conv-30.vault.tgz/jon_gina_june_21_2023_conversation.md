name: Jon and Gina - June 21, 2023 Conversation
description: Gina shares her new clothing store and limited edition collection; Jon discusses job loss, networking events, and business planning with mutual encouragement and resilience
---
Gina: [shares a photo: a photo of a woman in a black hoodie posing for a picture] Hey Jon, what's been up? Some pretty cool stuff happened since we talked. I have acquired some new unique pieces for my store.
Jon: Congrats on your store, Gina! Happy for you! It looks sick - is it a unique piece you're selling?
Gina: [shares a photo: a photo of a hoodie with a camouflage print on it] Thanks! This hoodie isn't for sale, it's from my own collection. I made a limited edition line last week to show off my style and creativity - it was tough but worth it!
Jon: What gave you the idea?
Gina: This design reminds me of the grit it takes to stand out and face challenges.
Jon: That's awesome, Gina! Yesterday I chose to go to networking events to make things happen. It's been tough but I'm staying determined and focused.
Gina: Way to go, Jon! Attending those networking events takes guts and drive. Keep it up!
Jon: Thanks! It's been tough going since I lost my job, but I'm sure investing my time in my business will pay off eventually. I really appreciate your help.
Gina: [shares a photo: a photo of a notepad with a pen and a pen on it] No worries, Jon! You got this! Let me know if you need anything.
Jon: Your help matters to me. I am writing all my plans down.
Gina: Nice work! Tracking your plans and goals is key. It's like a picture of all your progress.
Jon: Thanks, Gina! Seeing my goals written down on paper really helps keep me motivated and focused on what I have to do. I know it won't be easy, but I'm sure it'll pay off. Thanks for the support!
Gina: [shares a photo: a photo of a sign that says never give up never give up never] No worries, Jon! When things get rough, keep persevering and keep working hard. You'll get there! Don't quit!
Jon: Thanks, Gina! That sign reminds me to never give up, however hard things get. I'll keep going!
Gina: Believe in yourself and keep going. You can do it!
Jon: [shares a photo: a photo of a bulletin board with pictures of people and words] Thanks! I'm feeling confident and won't give up. Your support means a ton to me.
