name: Jon and Gina - July 23, 2023 Dance Studio Encouragement
description: Jon and Gina discuss dance studio business plans and mutual encouragement with "Just do it" quotes.

---
Jon: Hey Gina! We haven't talked in a few days. Been rehearsing hard and working on business plans. It's been stressful, but dancing has kept me going.
Gina: [shares a photo: a photo of a group of dancers on a stage with their arms in the air] Hey Jon! Remember, just do it! You should get to the point where anyone else would quit and you're not going to stop there. No, what are you waiting for? Do it! Just do it!
Jon: Ha, ha! Thanks, Gina. Sounds familiar, who do those words belong to?
Gina: It's Shia Labeouf!
Jon: Ahhahha, really!? Yea, that definitely him.
Gina: [shares a photo: a photo of three girls in ballet costumes sitting on a desk] Hah, yeah!) But really having a creative space for dancers is so important. Last Friday at dance class with a group of friends I felt it. Your studio will be a go-to spot for self-expression. Keep up the good work and don't forget your passion for dance.
Jon: Thanks, Gina! Your words of encouragement keep me motivated. Can't wait 'til my studio starts welcoming dancers of all ages and backgrounds!
Gina: I'm so happy to see my words motivating you, Jon. <3
Jon: Thanks a ton, Gina! Your help and encouragement mean a lot. Your support will help me make it happen.
Gina: You're welcome, Jon! I'm here to support you. Every step's getting you closer to your dream. Never give up! You're doing great.
Jon: Thanks, Gina! I won't quit. I'm gonna keep going, whatever comes my way.
Gina: Remember Jon, Just do it!
Jon: Ah ha ha, yeah, JUST DOING IT!
Gina: That's the spirit! Bye!
