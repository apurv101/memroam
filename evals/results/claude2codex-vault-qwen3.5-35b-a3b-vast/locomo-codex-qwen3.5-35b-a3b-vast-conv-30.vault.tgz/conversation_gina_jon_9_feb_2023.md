name: Gina and Jon - Conversation 9 Feb 2023
description: Conversation between Gina (fashion store owner) and Jon (dance studio owner) on Feb 8, 2023

## Key Details
**Gina:**
- Runs a fashion online store
- Teamed up with a local artist for cool designs
- Got inspired by fashion magazines
- Took the risk to pursue her business vision
- Has a tattoo (a few years old) that stands for "freedom - dancing without worrying what people think"
- Values taking risks and following passions

**Jon:**
- Runs his own dance studio
- Former banker who left his secure 9-5 to pursue dance
- Aims to turn his dancing passion into a business
- Loves helping dancers of all ages and levels express themselves
- Juggles dance and business goals successfully

## Themes from conversation:
- Both value risk-taking as essential for growth
- Both support each other's dreams and businesses
- Dancing as freedom and self-expression for both
- Juggling passion projects with business ventures
- Mutual encouragement and pep talks

## Important moment:
Jon shared that taking risks got him out of his banking job. He's determined to make his dance studio work despite difficulties. Gina has been supportive, reminding him she's always there for him.

Jon later shared a photo with a cartoon character and quote about fear - he stayed optimistic about his studio business.