name: Jon and Gina - Dance Studio Launch & Design Internship Interview
description: Conversation from May 11, 2023 about Jon launching his dance studio after job loss and Gina's design internship interview

## Date: May 11, 2023

## People:
- Jon: Opened his own dance studio after losing his job
- Gina: Had interview for design internship

## Career Updates:
- Jon lost his job which gave him the push to start his dream business: his own dance studio
- Jon is currently working on opening the dance studio - things are looking up
- Gina had an interview for a design internship on May 10, 2023 (yesterday from conversation date)
- Gina's interview went great

## Personal Backgrounds:
- Dance has been Jon's stress-buster since childhood - it's where he feels most alive
- Gina also uses dance as her stress fix - worries vanish when she starts dancing
- Both consider dance essential to their lives, like "air" or "second nature"

## Business Details:
- Jon wants to create a space for people to dance and express themselves
- This has been Jon's dream for a long time
- Jon is excited about stepping into the unknown after losing his job
- Both express mutual support for each other's entrepreneurial/dream-chasing journeys

## Shared Activities:
- Jon is practicing dance routines to stay focused and motivated
- Jon offered to send Gina a video of one of his routines
- Gina expressed interest in watching Jon's routine

## Photos Shared:
1. Photo of a woman in a short skirt with hands on hips (shared by Jon)

## Notes:
- Jon lost his job which was the catalyst for finally pursuing his dance studio dream
- Both have a deep passion for dance and see it as essential to their wellbeing
- They maintain a supportive friendship where they encourage each other's ventures
- Jon will keep Gina updated on the dance studio progress
- Gina feels proud of Jon and is excited to see his video