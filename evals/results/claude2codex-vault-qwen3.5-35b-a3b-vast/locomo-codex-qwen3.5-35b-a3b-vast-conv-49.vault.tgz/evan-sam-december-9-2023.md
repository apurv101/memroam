name: Evan and Sam Conversation - December 9, 2023
description: Evan shares exciting news - his partner is pregnant, plans for family reunion next summer, family motto "Bring it on Home" from Banff trip
---
Evan and Sam conversation from 1:45 pm on December 9, 2023.

**Key Topics:**

- **Evan's Partner Is Pregnant**: Evan shared the amazing news that his partner is expecting. He's excited and a bit nervous, noting it's been a while since he had a toddler around. He recalls the joy when his first child was born and looks forward to witnessing "the miracle of life."

- **Family Values**: Evan's family is "his rock." He has a family memories collage on his desk featuring birthdays, holidays, and vacations.

- **Family Motto**: The sign in the center of the collage says "Bring it on Home" - from a family trip to Banff. It's their family motto reminding them of the importance of togetherness no matter where they are.

- **Upcoming Plans**: Evan mentioned they're planning a big family reunion next summer, which will be a perfect opportunity to add more photos to their collage.

**Quotes:**
- "My family means the world to me. They're my rock."
- "It's our family's motto, always reminding us of the importance of togetherness, no matter where we are."
- "Looking forward to witness the miracle of life and build more memories with my family!"
