name: Evan - August 7, 2023
description: Conversation transcript from August 7, 2023 between Evan and Sam about health journey, family, and recent Canada trip

---

## Key Facts from Conversation

### Evan
- **Recent trip to Canada**: Went last week (late July 2023), met a Canadian woman there - described as "something out of a movie," incredible and makes him feel alive/energized
- **Health journey**: Working on health for two years now (started around 2021), has had ups and downs but doing his best
- **Health issues**: Dealing with health issues lately, which has been tough but makes him appreciate good moments more
- **Family**: Has kids - they bring him lots of joy especially through hard times; family motivates him to stay healthy
- **Fitness watch**: Uses a smart/fitness watch that tracks progress well and serves as a constant visual reminder to keep going
- **Ginger snaps**: Has a weakness for them
- **Motivators**:
  - Thirst for adventure on interesting hikes
  - A bonsai tree that symbolizes strength and resilience; taking care of it motivates him through tough times
- **Philosophy**: Believes small things matter, consistency and perseverance will get us far; every little thing we do for ourselves helps in the long run

### Sam
- **Health issues**: Dealing with health problems that make it hard to fully enjoy things
- **Considering fitness watch**: Thinking of ordering similar ones to Evan's
- Shares encouragement and support with Evan

### Shared Topics
- Health and wellness journey
- Fitness motivation
- Family as motivation
- Finding what keeps you motivated (large or small things)
- Consistency, perseverance, resilience

---

Conversation Date: August 7, 2023 (7:52 pm)
