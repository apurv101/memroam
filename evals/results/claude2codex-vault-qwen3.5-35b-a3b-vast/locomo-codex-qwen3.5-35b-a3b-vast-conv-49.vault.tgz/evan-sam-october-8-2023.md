---
id: conv-oct-8-2023
name: Evan and Sam conversation, October 8, 2023
description: Sam receives health warning about weight; decides to start weightlifting with Evan's encouragement and advice
---

## Key Points from Conversation (October 8, 2023)

### Sam's Health Concern
- Went for check-up on Monday (October 2, 2023)
- Doctor said his weight is a serious health risk
- If changes aren't made soon, it can get worse
- Has been having a hard time dealing with this news
- Made jokes about it before, but it's really hitting him now

### Sam Decides to Start Working Out
- Evan shared photo of himself doing squats on a gym machine
- Mentioned he started lifting weights one year ago
- Described it as a journey, was a struggle at first but seeing gains
- Sam expressed interest in trying it out

### Evan's Advice for Getting Started
- Start with good form and technique
- Find a trainer to help avoid injuries while building strength
- Start with something small, increase intensity as you get stronger
- Stay consistent with workout routine

### Mutual Support & Encouragement
- Sam said he's going to find someone to help him
- Evan encouraged him to keep pushing, stay positive
- Shared photos (gym workout, motivational note) to inspire
- Sam appreciates Evan's support
- Evan emphasized taking it slow, being patient with yourself
- Both staying motivated and believing in themselves

### Outcome
- Sam is staying positive and committed to making changes
- Evan continues to provide ongoing encouragement
- Sam promised to keep Evan posted on his progress
