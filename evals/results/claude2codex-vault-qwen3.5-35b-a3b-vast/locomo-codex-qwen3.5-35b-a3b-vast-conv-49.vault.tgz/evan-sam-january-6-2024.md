name: Evan and Sam - January 6, 2024
description: Conversation on January 6, 2024 - Evan's marriage announcement to extended family, family support, lasagna dinner, diet plan, and Canada honeymoon plans
---
1:32 pm on 6 January, 2024

Evan: [shares a photo: a photo of a man and a woman standing on a rocky beach] Hey Sam, guess what? My partner and I told our extended fam about our marriage yesterday – it was so special! We've been totally overwhelmed by all their love and support.
Sam: Congrats on the news, Evan! You two look so happy in the pic. These moments make life so wonderful; super stoked for you!
Evan: Thanks, Sam! It was an awesome moment, and I feel really lucky to have found someone who gets me. Plus, our families are really happy for us - that's the best part!
Sam: Wow, Evan. It's awesome that you've found someone who gets you! Having your family's support must feel great.
Evan: Definitely, family support is so important. Knowing they're happy about our marriage is awesome and so comforting.
Sam: Yeah, it's awesome to have that support. It definitely brings more happiness and joy.
Evan: Yeah Sam, that means a lot to me. Our bond just keeps getting stronger and it brings such a good feeling to our lives. Family really is everything.
Sam: Agree, Evan! Family is everything - they bring so much love and happiness. They're always there for us no matter what. I'm grateful for their support and love.
Evan: For sure, Sam. That's what makes family so special. They bring so much love and happiness. It's great having their support and knowing they're always there for us. I feel really fortunate to have their never-ending love and support.
Sam: Yeah, definitely, Evan. We both have amazing families that are always there for us. Always a blessing.
Evan: Yeah, Sam. Our families give us so much joy, support, and love. They're a real blessing! I don't know what I'd do without them.
Sam: Hey, Evan. My family has been my rock through everything. Don't know what I'd do without them.
Evan: [shares a photo: a photo of a group of people sitting at a table with food] Yeah, they are our rock. We're blessed to have them.
Sam: Wow, you guys are awesome! What's cooking tonight?
Evan: Thanks, Sam! We're having a family get-together tonight and enjoying some homemade lasagna. Super excited! By the way, I've started a new diet—limiting myself to just two ginger snaps a day. What's on your menu tonight?
Sam: [shares a photo: a photo of a plate of food with bread and meat] That's a great discipline, Evan! We're keeping it light tonight, just some homemade lasagna. Can't compete with your ginger snap limit though!
Evan: Oh this must be very hearty and delicious, well I'll have to stick to the diet plan, even with the family gathering!
Sam: [shares a photo: a photo of a pie with raspberries and limes on top] Yeah, the lasagna was pretty awesome, but check out what I had for dessert, I'm sure you're drooling!
Evan: Looks yummy! Did you make that?
Sam: No, I didn't make it. This is actually a pic from my cousin's wedding. It's super special.
Evan: [shares a photo: a photo of a wedding cake with candles and flowers on a table] Wow Sam! Weddings are indeed special. This looks great, yum!
Sam: Ooh, nice cake! Reminds me of special occasions. Do you have any upcoming plans?
Evan: [shares a photo: a photo of a stream running through a snowy forest filled with snow] Thanks Sam! We're off to Canada next month for our honeymoon. So excited to create some awesome memories. Looking forward to exploring the beautiful snowy landscapes there.
Sam: Wow, that looks great! What are your plans for the trip?
Evan: We're planning to ski, try the local cuisine, and enjoy the beautiful views. We're really excited!
Sam: [shares a photo: a photo of a container of french fries covered with caramel] Sounds amazing, Ev! Skiing, trying local dishes, and enjoying the breathtaking views - the perfect honeymoon. Have an incredible time creating unforgettable memories!
Evan: Yeah, Sam! Gonna try some poutine while we're there - can't wait!
Sam: Never tried it? Can't say I blame you, it's kind of a Canadian thing. Let me know how you like it!
Evan: Sure thing, Sam! Let's see if it lives up to the hype. I'll let you know what happens!
Sam: Yeah, Evan! Let me know all about it. Don't forget the details!
Evan: Cool, Sam. I'll keep you posted. Talk soon!
Sam: Awesome, Evan! Catch you soon. Have a great trip!
Evan: Thanks, Sam! Catch you later. Have a great one!
