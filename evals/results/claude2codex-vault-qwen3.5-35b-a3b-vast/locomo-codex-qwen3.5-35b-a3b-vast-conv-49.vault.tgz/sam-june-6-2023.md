name: Conversation with Sam - June 6, 2023
description: Evan and Sam discuss health journeys after Evan's heart scare; Sam agrees to try healthier choices and Evan offers workout help

---

**Evan** shared a photo of himself holding medicine after a heart palpitation incident. This was a serious wake-up call about his lifestyle. He's been trying to eat less processed food and sugary snacks (though he still loves ginger snaps), and has been extra careful with his health.

**Sam** shared a photo of vegetables and milk, mentioning they've been trying to eat healthier.

Evan encouraged Sam to consider swapping soda for flavored seltzer water and candy for dark chocolate with high cocoa content. Sam agreed to try these changes.

**Sam** had a frustrating experience at the supermarket with all the self-checkout machines being broken.

Evan shared a photo of himself working out (man with beard holding dumbbell) and offered to help Sam get started with basic exercises. Sam thanked him and they agreed to continue supporting each other's health journeys.

---

**Key points:**
- Evan experienced a health scare (heart palpitations) that motivated lifestyle changes
- Sam is gradually becoming more health-conscious, agreeing to try healthier alternatives
- Both committed to supporting each other on their health journeys
- Evan offered to help Sam with exercise
- Sam had a minor frustration with broken self-checkout machines at the supermarket
