---
id: conv-sept-11-2023
name: Evan and Sam conversation, September 11, 2023
description: Sam's diet progress, cravings triggers, and planning a painting session
---

## Key Points from Conversation (September 11, 2023)

### Sam's Health Journey
- Working on making healthier choices through diet
- Posted before/after body transformation photo to motivate others
- Still struggles with occasional cravings for sugary drinks and snacks
- Triggers for cravings: stress, boredom, seeking comfort
- Feeling that progress has been "kinda wild" - up and down ride

### Evan's Creative Outlet
- Uses painting as a way to de-stress
- Also enjoys going for drives when stressed
- Shares artwork including:
  - Painting of sunset over body of water
  - Painting of mountain range with a horse

### Plans Made
- Sam wants to try painting to help with stress/relaxation
- Evan offering to help Sam get started with painting
- Equipment recommendations for beginners:
  - Acrylic paints
  - Brushes
  - Canvas or paper
  - Palette for mixing colors
- **Painting session scheduled for next Saturday (September 16, 2023)**
- Both excited about the creative activity

### Mutual Support
- Both encouraging each other to make better health choices
- Evan appreciates Sam's motivation and progress
- Sam appreciates Evan's support and offers to help with painting