---
id: 01a050a3-3c9d-7a58-a917-a06d27cc506a
name: Evan and Sam Conversation - October 17, 2023
description: Sam's gastritis scare; fitness discussions; plans for hiking together
---

## Date: October 17, 2023, 1:50 PM

### Sam's Health Scare
- Had a severe stomachache and ended up in the ER last weekend
- Diagnosed with **gastritis** - a wake-up call to prioritize health
- Decided to adopt a more nutritious diet and get regular exercise
- Phone has been giving her trouble, adding to stress

### Evan's Updates
- Been focusing on fitness - it's been beneficial for his overall well-being
- Had another encounter with a lost tourist recently - seems like helping tourists is becoming a recurring theme in his life
- Was at the gym yesterday, gaining strength

### Fitness Discussion
- Sam wants to get into exercise but finds getting started hard
- Evan shared motivation tips:
  - Set specific goals (distance to run, number of push-ups)
  - Find exercises you enjoy
  - Get an exercise buddy for fun and accountability

### Plans
- They plan to go **hiking together soon**
- Sam shared a photo of hiking shoes on a couch (excited to get fit)
- Both express enthusiasm about the upcoming hike as a way to bond and appreciate nature

### Mutual Support
- Both appreciate each other's support
- Express commitment to being there for each other
- Plan to stay in touch and check on each other
