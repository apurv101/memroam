---
id: conv-oct-6-2023
name: Evan and Sam conversation, October 6, 2023
description: Evan discusses knee injury recovery, watercolor painting hobby, and unexpected adventure; Sam shares healthy eating habits and journaling
---

## Key Points from Conversation (October 6, 2023)

### Evan's Knee Injury & Recovery
- Messed up knee playing basketball with kids last week (around late September)
- Has a cast on leg, can't do intense workouts
- Physical therapy has helped some
- Doing easy exercises to keep the knee strong
- Misses being active outdoors and going on adventures like last year with family

### Evan's New Hobby: Watercolor Painting
- Started watercolor painting to keep busy while healing
- Finds it chill and relaxing, great way to express emotions
- Good stress reliever
- Paints what's on his mind or what he's feeling
- Recent paintings shared:
  - **Sunset painting**: Inspired by a vacation a few years back, stunning colors
  - **Cactus painting in the desert**: Inspired by a road trip last month

### Evan's Unexpected Adventure (2 weeks ago)
- Helped a lost tourist find their way
- Ended up taking an unexpected tour around the city
- Described it as a blast and a nice adventure

### Sam's Healthy Eating Journey
- Started eating healthier
- Shared a photo of a bowl of fruit as example

### Sam's Creative Expression
- Expresses himself through writing
- Writes in journal and does creative writing
- Finds it therapeutic, helps sort out feelings and make sense of things
- Describes it like having a conversation with himself

### Sam's Phone Issue
- New phone's navigation app keeps malfunctioning
- Making getting around a bit of a challenge
- Evan recommended updating the phone

### Mutual Support
- Both encouraging each other
- Sam asked about staying active while Evan heals
- Evan offered advice about the phone