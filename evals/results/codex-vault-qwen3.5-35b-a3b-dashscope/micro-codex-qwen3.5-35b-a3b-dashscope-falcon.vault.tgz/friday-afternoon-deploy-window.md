---
id: 01a04e7b-ab35-7960-9b59-fc03aab60284
name: friday-afternoon-deploy-window
description: Deployments occur Friday afternoons following change-review calls.
---
# Deployment Schedule

Falcon deployments are scheduled for **Friday afternoons**, immediately following the change-review call.