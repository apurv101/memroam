---
id: 01a04e7b-ab38-7e71-bada-b678523d4868
name: contractor-budget-q2026
description: $40k contractor budget allocated for this half.
---
# Contractor Budget

The Falcon project has a **$40k contractor budget** allocated for this half.