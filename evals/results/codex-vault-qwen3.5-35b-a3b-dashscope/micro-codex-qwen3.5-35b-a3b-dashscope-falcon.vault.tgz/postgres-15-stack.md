---
id: 01a04e7b-ab2b-758a-87be-d50ee73c886f
name: postgres-15-stack
description: Service runs on Postgres 15 database.
---
# Database Stack

The Falcon service runs on **Postgres 15**.