---
id: 01a04e7b-f492-7b00-a7c0-f959045c76e4
name: deploy-schedule
description: Deployments moved from Friday to Wednesday mornings to reduce weekend incidents.
---

## Change Summary

- **Date**: 2026-05-21
- **Previous schedule**: Friday deployments
- **Current schedule**: Wednesday mornings
- **Reason**: Too many weekend incidents following Friday deploys

The deploy window was shifted proactively after observing a pattern of weekend-on-call incidents tied to Friday releases.
