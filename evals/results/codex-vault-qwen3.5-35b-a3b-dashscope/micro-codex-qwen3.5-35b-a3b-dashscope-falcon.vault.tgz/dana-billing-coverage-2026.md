---
id: 01a04e7b-cba5-74da-9600-d0b0b744ac89
name: dana-billing-coverage-2026
description: Dana owns billing service while Marco is on parental leave through end of 2026.
---

Marco is on parental leave starting next week (2026-04-17). Dana has taken over the billing service ownership for this duration, expected through the end of 2026.

**Context:**
- Previous owner: Marco
- Coverage period: From 2026-04-17 through end of 2026
- Service: Billing