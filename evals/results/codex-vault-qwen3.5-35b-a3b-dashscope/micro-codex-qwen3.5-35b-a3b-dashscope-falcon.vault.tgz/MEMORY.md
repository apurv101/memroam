# falcon — memory index

- [contractor-budget-q2026](contractor-budget-q2026.md) — $40k contractor budget allocated for this half.
- [dana-billing-coverage-2026](dana-billing-coverage-2026.md) — Dana owns billing service while Marco is on parental leave through end of 2026.
- [deploy-schedule](deploy-schedule.md) — Deployments moved from Friday to Wednesday mornings to reduce weekend incidents.
- [falcon-search-p95-latency-target](falcon-search-p95-latency-target.md) — Falcon search endpoint p95 latency target is 200ms against staging in eu-west-1.
- [friday-afternoon-deploy-window](friday-afternoon-deploy-window.md) — Deployments occur Friday afternoons following change-review calls.
- [postgres-15-stack](postgres-15-stack.md) — Service runs on Postgres 15 database.
- [postgres-16-migration](postgres-16-migration.md) — Migration to Postgres 16 completed; no longer using Postgres 15.
- [project-falcon-codename](project-falcon-codename.md) — Internal codename for the API rewrite project is "Falcon".
- [team-service-ownership](team-service-ownership.md) — Marco owns billing service; user owns gateway service.
