---
id: 01a04e7b-cbaa-75a3-8fae-e17df98bb738
name: falcon-search-p95-latency-target
description: Falcon search endpoint p95 latency target is 200ms against staging in eu-west-1.
---

**Target:**
- Metric: p95 latency
- Value: 200ms
- Scope: Search endpoint
- Environment: Staging

**Note:** The staging cluster is deployed in eu-west-1.