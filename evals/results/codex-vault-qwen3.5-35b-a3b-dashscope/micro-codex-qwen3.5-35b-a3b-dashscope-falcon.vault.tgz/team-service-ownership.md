---
id: 01a04e7b-ab36-7fbb-b7ba-449dc618d47f
name: team-service-ownership
description: Marco owns billing service; user owns gateway service.
---
# Team Service Ownership

Service ownership within the Falcon project:
- **Marco**: Billing service
- **User (you)**: Gateway service