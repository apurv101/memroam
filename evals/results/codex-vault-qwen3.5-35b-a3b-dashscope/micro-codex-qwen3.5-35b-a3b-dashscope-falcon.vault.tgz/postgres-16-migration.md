---
id: 01a04e7b-e672-7003-beb6-fe590b199f0f
name: postgres-16-migration
description: Migration to Postgres 16 completed; no longer using Postgres 15.
---

## Migration Details

- **Date**: 2026-05-21
- **Status**: Complete
- **Previous version**: Postgres 15
- **Current version**: Postgres 16

All Falcon services now run on Postgres 16. The migration was successful with no ongoing dependencies on Postgres 15.
