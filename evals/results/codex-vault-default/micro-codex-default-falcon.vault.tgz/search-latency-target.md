---
id: 01a04df6-a2a3-7378-aa0b-0287aefd9d79
name: search-latency-target
description: Falcon's staging search endpoint has a committed 200 ms p95 latency target.
---
Falcon is committed to a **200 ms p95 latency target** for the **search endpoint**, measured against **staging** for now.
