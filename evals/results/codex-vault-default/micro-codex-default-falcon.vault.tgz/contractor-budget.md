---
id: 01a04df6-4606-7e8a-96a4-efc5e658cf18
name: contractor-budget
description: Falcon has a $40,000 contractor budget for the current half-year as of 2026-03-02.
---
As of **2026-03-02**, Falcon has a **$40,000 contractor budget** for the current half-year.