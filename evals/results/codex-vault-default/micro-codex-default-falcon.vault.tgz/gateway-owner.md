---
id: 01a04df6-4604-74b5-9200-ba12ce121414
name: gateway-owner
description: The user owns Falcon's gateway.
---
The user owns Falcon’s gateway.