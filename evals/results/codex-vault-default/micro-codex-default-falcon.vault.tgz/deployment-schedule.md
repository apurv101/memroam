---
id: 01a04df6-45ff-7537-97ca-1ca5fc5e8ddd
name: deployment-schedule
description: Falcon deploys Wednesday mornings; Friday deploys were discontinued due to weekend incidents.
---
As of 2026-05-21, Falcon deployments occur on **Wednesday mornings**. Friday deploys were discontinued because they caused too many weekend incidents.