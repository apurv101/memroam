---
id: 01a04df6-45f0-7149-8c2b-9471871dc669
name: project-codename
description: The internal API rewrite is codenamed Falcon, and project documentation should use that codename.
---
The internal API rewrite is codenamed **Falcon**. Use “Falcon” as the project name in documentation.