---
id: 01a04df6-4602-78c9-8aad-47be8416495a
name: billing-owner
description: Dana is covering Falcon's billing service while Marco is on parental leave, expected from mid-April through the end of 2026.
---
**Dana** is covering Falcon’s billing service while **Marco** is on parental leave. The handoff starts the week of 2026-04-13 and is expected to last through the end of 2026.