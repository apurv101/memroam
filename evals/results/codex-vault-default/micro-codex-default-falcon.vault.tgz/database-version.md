---
id: 01a04df6-45f5-7e92-8673-e2215f072a83
name: database-version
description: Falcon runs entirely on PostgreSQL 16; the migration off PostgreSQL 15 is complete.
---
As of 2026-05-21, Falcon runs entirely on **PostgreSQL 16**. The migration off PostgreSQL 15 is complete.