# falcon — memory index

- [billing-owner](billing-owner.md) — Dana is covering Falcon's billing service while Marco is on parental leave, expected from mid-April through the end of 2026.
- [contractor-budget](contractor-budget.md) — Falcon has a $40,000 contractor budget for the current half-year as of 2026-03-02.
- [database-version](database-version.md) — Falcon runs entirely on PostgreSQL 16; the migration off PostgreSQL 15 is complete.
- [deployment-schedule](deployment-schedule.md) — Falcon deploys Wednesday mornings; Friday deploys were discontinued due to weekend incidents.
- [gateway-owner](gateway-owner.md) — The user owns Falcon's gateway.
- [project-codename](project-codename.md) — The internal API rewrite is codenamed Falcon, and project documentation should use that codename.
- [search-latency-target](search-latency-target.md) — Falcon's staging search endpoint has a committed 200 ms p95 latency target.
- [staging-region](staging-region.md) — Falcon's staging cluster is hosted in AWS eu-west-1.
