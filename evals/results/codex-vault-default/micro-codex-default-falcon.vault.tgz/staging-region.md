---
id: 01a04df6-a2a6-74a6-99d3-2fab0351feb2
name: staging-region
description: Falcon's staging cluster is hosted in AWS eu-west-1.
---
Falcon’s staging cluster is hosted in AWS **eu-west-1**.
