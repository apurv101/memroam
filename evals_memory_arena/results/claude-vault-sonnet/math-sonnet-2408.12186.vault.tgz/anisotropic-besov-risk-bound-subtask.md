---
id: 01a050af-eca5-7036-9842-fb0d7ba84476
name: anisotropic-besov-risk-bound-subtask
description: Solved anisotropic-Besov generalization of the risk bound — bar R(hat Theta) <~ N^{-2 tilde-alpha} + N log N/n + N^2 log N/T for n >~ N log N, matching isotropic rate when tilde-alpha = alpha/d
metadata:
  type: project
---

Subtask: for $\alpha\in\mathbb{R}_{>0}^d$ with $\widetilde\alpha>1/p$, $\mathcal F^\circ=\mathcal U(B_{p,q}^\alpha(\mathcal X))$ (anisotropic Besov ball), $\mathcal X$-density $\rho_{\mathcal X}$ bounded above/below, independent wavelet coefficients with $\mathbb E[\beta_{k,\ell}]=0$, $\mathbb E[\beta_{k,\ell}^2]\lesssim 2^{-k\underline\alpha(2+1/\widetilde\alpha)}k^{-2}$ for all $k\ge0,\ell\in I_k^{d,\alpha}$ — upper bound $\bar R(\widehat\Theta)$ for $n\gtrsim N\log N$.

**Result:**
$$\bar R(\widehat\Theta)\;\lesssim\;N^{-2\widetilde\alpha}+\frac{N\log N}{n}+\frac{N^2\log N}{T},\qquad n\gtrsim N\log N,$$
and under optimal tuning $N\asymp n^{1/(2\widetilde\alpha+1)}$, $T\gtrsim n^{(2\widetilde\alpha+2)/(2\widetilde\alpha+1)}$, this gives $\bar R(\widehat\Theta)\lesssim n^{-2\widetilde\alpha/(2\widetilde\alpha+1)}$ (up to logs).

**Structure:** this is the direct anisotropic-Besov analogue of [[minimax-rate-theorem-fN-threshold]] (the isotropic Hölder-ball version): same three-term decomposition (approx error + in-context gen $N\log N/n$ + pretraining gen $N^2\log N/T$), same $n\gtrsim N\log N$ threshold, with the isotropic approximation rate $N^{-2\alpha/d}$ replaced by $N^{-2\widetilde\alpha}$ (here $\widetilde\alpha$ plays the role of the effective anisotropic smoothness-to-dimension ratio, i.e. setting $\widetilde\alpha=\alpha/d$ in the isotropic case exactly recovers $N^{-2\alpha/d}$ and the final rate $n^{-2\alpha/(2\alpha+d)}$). Confirms $\widetilde\alpha$ is the paper's anisotropic analogue of $\alpha/d$.

**Notation note:** this subtask was solved *without* needing the explicit definitions of $\omega_{k,\ell}^{d,\alpha}$/$I_k^{d,\alpha}$ that blocked earlier subtasks (see [[unresolved-omega-kl-notation]]) — the coefficient moment bound (given directly in the problem statement) was enough to redo the approximation-error and stochastic-error calculations by analogy with the isotropic case, without unpacking the basis construction itself. That notation is still unresolved for subtasks that need the refinement/two-scale relation explicitly.
