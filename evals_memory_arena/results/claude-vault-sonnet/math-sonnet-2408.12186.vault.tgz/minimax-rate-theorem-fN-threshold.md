---
id: 01a050a1-e4c8-776e-b1bc-9a1a8a3c98b4
name: minimax-rate-theorem-fN-threshold
description: Solved f(N)=N log N threshold (Assumption 4) for the 3-term risk bound (DNN approx + in-context gen + pretraining gen) to yield minimax rate n^{-2alpha/(2alpha+d)}
metadata:
  type: project
---

Subtask: under Assumption 4, find $f(N)$ such that $n \gtrsim f(N)$ implies
$$\bar R(\widehat\Theta) \lesssim N^{-2\alpha/d}\;(\text{DNN approx}) + \frac{N\log N}{n}\;(\text{in-context gen}) + \frac{N^2\log N}{T}\;(\text{pretraining gen}),$$
and consequently $T\gtrsim n^{(2\alpha+2d)/(2\alpha+d)}$, $N\asymp n^{d/(2\alpha+d)}$ gives the minimax rate $n^{-2\alpha/(2\alpha+d)}$ (up to log).

**Result:** $f(N) = N\log N$, i.e. the theorem holds once $n \gtrsim N\log N$.

**Derivation:** comes from requiring the whitened empirical feature-covariance concentration term (see [[whitened-gram-matrix-concentration-bound]]: $\frac{B_N\log N}{n}+\frac{B_N^2\log^2N}{n^2}$) to be $O(1)$/well-behaved. This is consistent with — and resolves — the open item in that memory: under **Assumption 4** in this paper, $B_N = O(N)$ (a.s. bound on the whitened feature norm $\|\Sigma_{\Psi,N}^{-1/2}\psi^\circ\|_2^2$). This was *inferred* as Assumption 4's natural content, not confirmed verbatim against the paper text — verify wording if this resurfaces.

**Consistency check performed:** plugging $N\asymp n^{d/(2\alpha+d)}$ into $f(N)=N\log N$ gives $O(n^{d/(2\alpha+d)}\log n) = o(n)$, so the $n\gtrsim f(N)$ condition holds automatically at the optimal scaling. All three risk terms reduce to $n^{-2\alpha/(2\alpha+d)}$ (up to log) under this $N$ scaling, and matching the pretraining term reproduces exactly $T\gtrsim n^{(2\alpha+2d)/(2\alpha+d)}$ — strong internal check.

**Still open:** exact statement of "Assumption 4" is not recorded verbatim in memory (only its inferred content, $B_N=O(N)$). If a future subtask needs to cite it precisely, ask the user or locate the paper text.
