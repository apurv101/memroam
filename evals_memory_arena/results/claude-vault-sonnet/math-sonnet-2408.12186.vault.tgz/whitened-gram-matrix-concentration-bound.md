---
id: 01a05090-ebb6-7d49-8f86-917bd0d3f764
name: whitened-gram-matrix-concentration-bound
description: Solved bound on E_X[||Sigma_Psi,N^{-1/2} (Psi°Psi°^T/n) Sigma_Psi,N^{-1/2} - I_N||_op^2] via matrix-Bernstein second-moment bound
metadata:
  type: project
---

Target quantity: $\E_{\bX}\left[\left\|\Sigma_{\Psi,N}^{-1/2}\frac{\Psi^{\circ}_{\ubar N:\bar N}\Psi^{\circ\top}_{\ubar N:\bar N}}{n}\Sigma_{\Psi,N}^{-1/2}-\bI_N\right\|_{op}^2\right]$, i.e. concentration of the whitened empirical Gram/covariance matrix of features $\Psi^\circ_{\ubar N:\bar N}$ (indices $\ubar N$ to $\bar N$) around identity.

**Approach:** whiten the features, $\bphi := \Sigma_{\Psi,N}^{-1/2}\psi^\circ$, so each sample contributes a rank-1 (mean-zero, after centering) term to $\bZ=\sum_i \bS_i$ with $\bS_i \propto \bphi_i\bphi_i^\top - \E[\bphi_i\bphi_i^\top]$, then apply [[matrix-bernstein-second-moment-bound]] directly.

**Result (conditional on an a.s. bound $\|\bphi\|_2^2 \le B_N$ on the whitened feature norm):**

$$\E_{\bX}\left[\left\|\Sigma_{\Psi,N}^{-1/2}\frac{\Psi^{\circ}_{\ubar N:\bar N}\Psi^{\circ\top}_{\ubar N:\bar N}}{n}\Sigma_{\Psi,N}^{-1/2}-\bI_N\right\|_{op}^2\right]\lesssim \frac{B_N\log N}{n}+\frac{B_N^2\log^2N}{n^2}.$$

**Open item for next session:** $B_N$ (a.s. bound on $\|\Sigma_{\Psi,N}^{-1/2}\psi^\circ\|_2^2$) was introduced in this session as a new symbol — it was not already present in memory. Confirm whether the paper already defines this quantity under a different name/notation (e.g. an effective-rank or whitened-norm assumption tied to $\Sigma_{\Psi,N}$), and reconcile before writing this into the manuscript. Also double check the sub-Gaussian variance term $v(\bZ)$ reduces to exactly $B_N$ (vs. some other functional of $\Sigma_{\Psi,N}$) under the whitening — this was asserted but not re-verified against the general lemma's variance statistic in this session.

**Partial resolution:** a later subtask used $B_N = O(N)$ under "Assumption 4" to derive the threshold $f(N)=N\log N$ for the full minimax-rate theorem — see [[minimax-rate-theorem-fN-threshold]]. This was inferred as Assumption 4's natural content, not confirmed verbatim against the paper.
