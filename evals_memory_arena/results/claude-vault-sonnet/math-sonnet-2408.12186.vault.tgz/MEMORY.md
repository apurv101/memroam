# 2408.12186 — memory index

- [anisotropic-besov-risk-bound-subtask](anisotropic-besov-risk-bound-subtask.md) — Solved anisotropic-Besov generalization of the risk bound — bar R(hat Theta) <~ N^{-2 tilde-alpha} + N log N/n + N^2 log N/T for n >~ N log N, matching isotropic rate when tilde-alpha = alpha/d
- [matrix-bernstein-second-moment-bound](matrix-bernstein-second-moment-bound.md) — Solved bound on E[(1/n^2)||Z||_op^2] for sum of independent zero-mean bounded-op-norm random matrices, via matrix Bernstein tail integration
- [metric-entropy-bound-FN-clipped-dnn](metric-entropy-bound-FN-clipped-dnn.md) — Solved bound on metric entropy V(F_N, ||.||_L^infty, epsilon) for F_N = clipped product of N ReLU-DNN coordinate networks, used to satisfy Assumption 3
- [minimax-rate-theorem-fN-threshold](minimax-rate-theorem-fN-threshold.md) — Solved f(N)=N log N threshold (Assumption 4) for the 3-term risk bound (DNN approx + in-context gen + pretraining gen) to yield minimax rate n^{-2alpha/(2alpha+d)}
- [unresolved-covering-number-notation](unresolved-covering-number-notation.md) — Subtask "bound V(S_N, ||.||_op, delta)" left unresolved — S_N and V(.) notation undefined in memory, need definitions before solving
- [unresolved-omega-kl-notation](unresolved-omega-kl-notation.md) — 5x recurring blocker — omega_{k,l}^{d,alpha} / I_k^{d,alpha} / anisotropic norm undefined in memory; ask user for core definitions up front before next subtask
- [unresolved-risk-bound-subtask](unresolved-risk-bound-subtask.md) — Subtask "upper bound inf_Theta R(Theta) under Assumptions 1,2,3" left unresolved — Assumptions 1-3 and definitions of S_N, F_N, R(Theta) undefined in memory
- [whitened-gram-matrix-concentration-bound](whitened-gram-matrix-concentration-bound.md) — Solved bound on E_X[||Sigma_Psi,N^{-1/2} (Psi°Psi°^T/n) Sigma_Psi,N^{-1/2} - I_N||_op^2] via matrix-Bernstein second-moment bound
