---
id: 01a0508a-0bad-7722-aa82-c03971439f67
name: matrix-bernstein-second-moment-bound
description: Solved bound on E[(1/n^2)||Z||_op^2] for sum of independent zero-mean bounded-op-norm random matrices, via matrix Bernstein tail integration
metadata:
  type: project
---

For $\bS_1,\dots,\bS_n\in\RR^{N\times N}$ independent, $\E{\bS_i}=0$, $\|\bS_i\|_{op}\le L$ a.s., $\bZ=\sum_i \bS_i$, and matrix variance statistic
$v(\bZ)=\max\{\|\sum_i \E{\bS_i\bS_i^\top}\|_{op}, \|\sum_i \E{\bS_i^\top\bS_i}\|_{op}\}$, the established bound is:

$$\E\left[\frac{1}{n^2}\|\bZ\|_{op}^2\right] \lesssim \frac{v(\bZ)\log N + L^2\log^2 N}{n^2}.$$

**Derivation:** Start from the matrix Bernstein tail bound $P(\|\bZ\|_{op}\ge t)\le 2N\exp(-t^2/(2v+\tfrac23 Lt))$ (referred to as "Theorem A.2" in the working session — re-derive or locate the exact source in the current paper draft, since that label is only meaningful within that session's document numbering, not a persistent external reference).

Split the exponent via $\tfrac{t^2}{2v+\tfrac23Lt}\ge \tfrac{t}{2}\min(t/2v,\,3/2L)$ into a sub-Gaussian regime ($2Ne^{-t^2/4v}$) and a sub-exponential regime ($2Ne^{-3t/4L}$). Integrate $E[X^2]=\int_0^\infty 2t\,P(X\ge t)\,dt$ separately for each regime, splitting at the threshold where the exponential factor equals $1/(2N)$: this yields $O(v\log N)$ from the Gaussian part and $O(L^2\log^2 N)$ from the exponential part.

**Sanity check used:** setting $N=1$ should recover the scalar Bernstein second-moment bound $E[Z^2]\lesssim v+L^2$ (note: at $N=1$ the $\log N$ factors vanish, so this check confirms the bound's structure/leading constants rather than the log-factor scaling itself).

**Open thread for future sessions:** confirm whether this bound (with the $\log N$ and $\log^2 N$ factors) is tight/matches what's needed elsewhere in the paper, and whether "Theorem A.2" should be replaced with a proper internal citation once the derivation is written into the manuscript.

**Used in:** applied to bound whitened-feature Gram matrix concentration, see [[whitened-gram-matrix-concentration-bound]].
