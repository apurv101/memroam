---
id: 01a0509e-1f92-7aba-b171-4519d6a73775
name: metric-entropy-bound-FN-clipped-dnn
description: Solved bound on metric entropy V(F_N, ||.||_L^infty, epsilon) for F_N = clipped product of N ReLU-DNN coordinate networks, used to satisfy Assumption 3
metadata:
  type: project
---

**Subtask solved:** For any $\delta_N>0$, Assumption 3 is satisfied by taking
$$\FF_N = \{\Pi_{B_N'}\circ\phi \mid \phi=(\phi_j)_{j=1}^N,\ \phi_j\in\FF_\textup{DNN}(L,W,S,M)\}$$
where $\Pi_{B_N'}$ projects onto the centered ball of radius $B_N'=O(\sqrt N)$ in $\RR^N$, and each $\phi_j$ is a ReLU network with depth $L=O(\log N+\log\delta_N^{-1})$, width $W=O(1)$, sparsity $S=O(1)$, weight bound $M=O(1)$.

**Result — upper bound on metric entropy:**
$$\VV(\FF_N,\|\cdot\|_{L^\infty},\epsilon)\ \le\ NS\log\!\left(\frac{L(M\vee1)^{L-1}(W+1)^{2L}\sqrt N}{\epsilon}\right)\ \lesssim\ N\log\!\left(\frac{N}{\delta_N\,\epsilon}\right)$$

**Derivation sketch:**
1. $\Pi_{B_N'}$ is non-expansive (projection onto a convex set) ⇒ suffices to cover the un-clipped product class $\{(\phi_j)_{j=1}^N\}$.
2. Take coordinatewise $\epsilon/\sqrt N$-covers of $\FF_\textup{DNN}(L,W,S,M)$ in each coordinate; combine via Cauchy–Schwarz to get an $\epsilon$-cover of the $N$-fold product in $\|\cdot\|_{L^\infty}$ (really an $\ell^2$-type combination across the $N$ coordinates).
3. A standard covering-number lemma for sparse ReLU networks (referenced in the paper as Lemma C.6) bounds each coordinate's covering number by $S\log(L(M\vee1)^{L-1}(W+1)^{2L}/\epsilon')$ for cover radius $\epsilon'$.
4. Plug in $\epsilon'=\epsilon/\sqrt N$, and $W,S,M=O(1)$, $L=O(\log N+\log\delta_N^{-1})$ to get the final simplified rate.

**Why this matters for the project:** This resolves part of [[unresolved-risk-bound-subtask]] — it gives an explicit construction of $\FF_N$ (function/readout class) and confirms Assumption 3 concerns a metric-entropy/covering-number condition on $\FF_N$ under $\|\cdot\|_{L^\infty}$, controlled via depth $L$ scaling with $\log N$ and $\log\delta_N^{-1}$. Still missing: full statements of Assumptions 1 and 2, and definitions of $\mathcal{S}_N$, $\Theta$, $R(\Theta)$.

**How to apply:** When later subtasks reference "Assumption 3" or need the entropy of $\FF_N$, reuse this bound directly rather than re-deriving. If $\mathcal{S}_N$/Assumptions 1–2 get defined in a future session, update [[unresolved-risk-bound-subtask]] accordingly.
