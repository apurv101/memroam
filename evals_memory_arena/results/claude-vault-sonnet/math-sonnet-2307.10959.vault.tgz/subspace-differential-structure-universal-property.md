---
id: 01a050ac-0de0-78dd-b909-6b7462ddc326
name: subspace-differential-structure-universal-property
description: Subspace diff. structure F_N on N⊂M has the expected initial/universal property w.r.t. inclusion i:N→M — proof needs a topology-fix trick
metadata:
  type: project
---

**Result.** For a differential space $(M,\scF)$ and subset $(N,\scF_N)$ with the
induced/subspace differential structure, and any smooth $\varphi:(Y,\scG)\to M$
with $\varphi(Y)\subset N$, the corestriction $\varphi:(Y,\scG)\to(N,\scF_N)$
is smooth. I.e. $\scF_N$ satisfies the expected initial/universal property
w.r.t. the inclusion $i:N\hookrightarrow M$.

**Proof technique (the subtle point).** The naive candidate structure
$\{h:N\to\R \mid h\circ\varphi\in\scG\}$ does NOT generally satisfy the
topology condition (1) of the differential-space definition — e.g. fails when
$Y$ is a single point, where that set becomes *all* real functions on $N$.
Fix: intersect with $\tau_N$-continuity, i.e. use
$\scH=\{h:N\to\R \mid h\circ\varphi\in\scG,\ h\ \tau_N\text{-continuous}\}$.
This $\scH$ is a genuine differential structure containing $A=\scF|_N$
(restrictions of $M$'s structure), so by minimality of the generated
structure $\scF_N=\langle A\rangle \subseteq \scH$, giving $h\circ\varphi\in\scG$
for all $h\in\scF_N$ — exactly smoothness into $(N,\scF_N)$.

**Lesson for this project:** when proving a subset/pullback of functions is a
differential structure (or verifying a candidate structure works), always
check condition (1) (generates the right topology) separately — candidates
built purely from a factorization/compatibility condition can satisfy the
"smooth compatibility" requirement while violating the topology axiom,
especially in degenerate cases (e.g. $Y$ a point, or more generally small/thin
$Y$). Intersecting with $\tau_N$-continuity is the general fix pattern.
