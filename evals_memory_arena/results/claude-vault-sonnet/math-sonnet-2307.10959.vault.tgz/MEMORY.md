# 2307.10959 — memory index

- [derivation-inverse-formula](derivation-inverse-formula.md) — For a derivation w on a C^infty-ring with ab=1, w(b) = -b^2 w(a); derived from chain rule giving w(1)=0 and Leibniz rule
- [derivation-restriction-chain-rule](derivation-restriction-chain-rule.md) — For M⊂R^n with induced structure F, derivation v on F, and h∈C^∞(W) on open nbhd W of M, v(h|_M) = Σ_i (∂h/∂x_i)|_M · v(x_i|_M)
- [nested-subspace-generated-structure-transitivity](nested-subspace-generated-structure-transitivity.md) — For K⊆N⊆M in a differential space, ⟨F|_K⟩ = ⟨⟨F|_N⟩|_K⟩ — generated subspace structure is transitive/independent of intermediate subset
- [result-flow-uniqueness-subset-Rn](result-flow-uniqueness-subset-Rn.md) — For (M,F) diffeomorphic to a subset of R^n and derivation v:F->F, v has exactly one (at most one) flow
- [subspace-differential-structure-universal-property](subspace-differential-structure-universal-property.md) — Subspace diff. structure F_N on N⊂M has the expected initial/universal property w.r.t. inclusion i:N→M — proof needs a topology-fix trick
