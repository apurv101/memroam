---
id: 01a050b0-b12c-7297-b675-2f725cea8600
name: nested-subspace-generated-structure-transitivity
description: For K⊆N⊆M in a differential space, ⟨F|_K⟩ = ⟨⟨F|_N⟩|_K⟩ — generated subspace structure is transitive/independent of intermediate subset
metadata:
  type: project
---

**Result.** Let $(M,\scF)$ be a differential space and $K\subseteq N\subseteq M$.
Then
$$\langle \scF|_K\rangle = \langle\langle \scF|_N\rangle|_K\rangle,$$
i.e. the generated (subspace) differential structure on $K$ is the same
whether computed directly from $\scF$ restricted to $K$, or by first forming
the subspace structure on $N$ and then restricting/generating on $K$. This is
the transitivity property of the subspace-differential-structure construction
for nested subsets.

**Proof idea.** Combine monotonicity/idempotency of the generating operator
$\langle\cdot\rangle$ with the universal property in
[[subspace-differential-structure-universal-property]]: the inclusion
$K\hookrightarrow M$ factors through $N$, and its smoothness as a map into
$(N,\mathcal F_N)$ (where $\mathcal F_N=\langle\scF|_N\rangle$) forces
$\mathcal F_N|_K\subseteq\mathcal F_K$ (with $\mathcal F_K=\langle\scF|_K\rangle$),
giving the inclusion $\langle\langle\scF|_N\rangle|_K\rangle\subseteq\langle\scF|_K\rangle$;
the reverse inclusion is immediate since $\scF|_K\subseteq\langle\scF|_N\rangle|_K$.

**Practical upshot:** subspace differential structure is well-behaved under
composition of subset inclusions — no need to worry about "which intermediate
subset" is used when computing induced structures on nested subsets.
