---
id: 01a050b7-b627-7712-b8fe-1583a3b39493
name: result-flow-uniqueness-subset-Rn
description: For (M,F) diffeomorphic to a subset of R^n and derivation v:F->F, v has exactly one (at most one) flow
metadata:
  type: project
---

**Statement.** Let $(M,\mathcal F)$ be a differential space diffeomorphic to a subset of some $\mathbb R^n$, and $v:\mathcal F\to\mathcal F$ a derivation. Then $v$ has **exactly one flow** — i.e. flows on such spaces are unique when they exist (uniqueness, not existence, is the content of the claim; the subtask as posed was answered as "exactly one").

**Derivation:** Transport $v$ across the diffeomorphism to a derivation on the subset of $\mathbb R^n$; uniqueness of the (maximal) flow there follows from the referenced Lemma 3.21, and the transport-back argument mirrors Corollary 3.22 in this paper's numbering.

**Why:** Established as a named result (paper's own Corollary numbering references Lemma 3.21) — treat as available for reuse rather than re-derive, but note the Lemma 3.21 / Corollary 3.22 statements themselves were not captured verbatim in this session, only cited.

**How to apply:** If a later subtask needs flow existence/uniqueness on a differential space embeddable in $\mathbb R^n$, cite this result directly. If deeper justification is needed, ask the user to paste the text of Lemma 3.21 (flow uniqueness on subsets of $\mathbb R^n$) so it can be stored verbatim — it was not captured this session. Related: [[derivation-restriction-chain-rule]], [[derivation-inverse-formula]] (both concern derivations on subspaces of $\mathbb R^n$ in this same paper).
