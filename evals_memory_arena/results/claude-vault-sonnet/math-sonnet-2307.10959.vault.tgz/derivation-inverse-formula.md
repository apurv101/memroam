---
id: 01a050b2-dcd3-7411-8584-2b87f236ea90
name: derivation-inverse-formula
description: For a derivation w on a C^infty-ring with ab=1, w(b) = -b^2 w(a); derived from chain rule giving w(1)=0 and Leibniz rule
metadata:
  type: project
---

**Result.** Let $\scA$ be a $\cin$-ring, $w:\scA\to\scA$ a derivation, and
$a,b\in\scA$ with $ab=1$ (so $b=a^{-1}$). Then
$$w(b) = -b^2\,w(a).$$

**Derivation technique (reusable pattern).** Derivations on a $\cin$-ring
satisfy the chain rule w.r.t. the structure maps: for smooth $h:\R^n\to\R$,
$$w(h_\scA(a_1,\dots,a_n)) = \sum_i \big(\partial h/\partial x_i\big)_\scA(a_1,\dots,a_n)\cdot w(a_i).$$
Two useful special cases follow immediately from this:
- $h\equiv 1$ (0-ary) $\Rightarrow w(1)=0$.
- $h(x,y)=xy$ $\Rightarrow$ ordinary Leibniz rule $w(ab)=a\,w(b)+b\,w(a)$.

Combining these two special cases with $ab=1$ gives $a\,w(b)+b\,w(a)=0$;
multiplying by $b$ and using $ba=1$ yields $w(b)=-b^2w(a)$ — i.e. once $w(1)=0$
and Leibniz are available, computations with derivations on $\cin$-rings reduce
to ordinary commutative-ring manipulations, no need to invoke the general
chain rule again.

**Practical upshot:** when a subtask asks to compute $w(\text{something built
from invertible elements})$, first extract $w(1)=0$ and Leibniz from the
general chain-rule axiom, then compute purely algebraically as in ordinary
calculus (this case exactly reproduces $d(1/a) = -a^{-2}da$).
