---
id: 01a050b5-21db-7811-ae2c-3a1caf8760c9
name: derivation-restriction-chain-rule
description: For M⊂R^n with induced structure F, derivation v on F, and h∈C^∞(W) on open nbhd W of M, v(h|_M) = Σ_i (∂h/∂x_i)|_M · v(x_i|_M)
metadata:
  type: project
---

For $M\subset\mathbb R^n$ with induced differential structure $\mathcal F$ (functions on $M$ that locally extend to smooth functions on $\mathbb R^n$), $W\subset\mathbb R^n$ open neighborhood of $M$, $v:\mathcal F\to\mathcal F$ a derivation, and $h\in C^\infty(W)$:

$$v(h|_M) = \sum_{i=1}^n \left(\frac{\partial h}{\partial x_i}\right)\Big|_M \; v(x_i|_M)$$

**Derivation:** extend $h$ to $H\in C^\infty(\mathbb R^n)$ agreeing with $h$ near $M$ via a smooth cutoff supported in $W$; apply the derivation chain-rule to $H$ in ambient coordinates $x_1,\dots,x_n$; the result depends only on $h$'s partial derivatives restricted to $M$, independent of extension choice.

**Why:** This is the standard tool for computing derivations on subspace differential structures $\mathcal F$ (induced from $\mathbb R^n$) in terms of ambient coordinate functions $x_i|_M$ — reduces an abstract derivation on $\mathcal F$ to values $v(x_i|_M)$, i.e. a "tangent vector"-like description.

**How to apply:** Use whenever a later subtask needs to compute or characterize derivations on $M\subset\mathbb R^n$ (e.g. showing derivations correspond to tangent vectors, or computing $v$ on specific functions given via ambient smooth extensions). Pairs with [[derivation-inverse-formula]] (chain-rule consequences for derivations) and the subspace structure lemmas [[nested-subspace-generated-structure-transitivity]], [[subspace-differential-structure-universal-property]].
