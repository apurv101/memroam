---
id: 01a050a6-9532-7194-8db0-713d869f5598
name: result-weighted-rad-upper-bound-wi-ni-over-n
description: "Paper 2312.05134: upper bound on Rad~_{{n_i}} via choosing w_i = n_i/N in Delta(k), under n_i >= 12 log(2k) per group — solved from scratch, NOT verified against paper's exact def of Rad~ or its constant"
metadata:
  type: project
---

Subtask: for $\{n_i\}_{i=1}^k$ with $n_i \ge 12\log(2k)$ for all $i$, taking $w\in\Delta(k)$ with $w_i = n_i/N$ (where $N=\sum_l n_l$), upper bound $\widetilde{\mathsf{Rad}}_{\{n_i\}_{i=1}^k}$.

**Answer given this session (low confidence on exact constant/form):**
$$\widetilde{\mathsf{Rad}}_{\{n_i\}_{i=1}^k} \le C\sqrt{\frac{d}{N}}$$
with $d = \mathrm{VCdim}(\mathcal H)$, $C$ universal, $N=\sum_i n_i$.

**Mechanism:** $w_i = n_i/N$ minimizes $\sum_i w_i^2/n_i$ over $\Delta(k)$ (Cauchy–Schwarz, minimum value $1/N$), which collapses the weighted Rademacher complexity to that of one pooled sample of size $N$ — no explicit $k$-dependence in the leading rate. The per-group threshold $n_i \ge 12\log(2k)$ is a concentration/union-bound requirement (over $k$ groups) for the high-probability version of the argument, not a contributor to the leading rate itself.

**IMPORTANT CAVEAT:** this was derived from scratch via generic weighted-VC/Rademacher chaining — this session's memory did not contain (and did not retrieve/verify against) the paper's literal formal definition of $\widetilde{\mathsf{Rad}}_{\{n_i\}}$. The rate $\sqrt{d/N}$ and the Cauchy–Schwarz optimality-of-$w_i\propto n_i$ mechanism are likely structurally correct, but the exact constant $C$, whether a $\log k$ term also appears additively, and whether the paper's $\widetilde{\mathsf{Rad}}$ even depends on VC dimension $d$ in this form should be checked against the paper before reuse in later subtasks.

**How to apply:** if a later subtask reuses this result, first verify against the actual paper text/definition of $\widetilde{\mathsf{Rad}}$ (see [[result-weighted-rad-scaling-bound]] for the other known structural fact about $\widetilde{\mathsf{Rad}}$, which also notes the formal definition was never saved). If verified, update this memory to remove the caveat and firm up the constant.
