---
id: 01a05097-8f4f-71ba-8a95-5ec2cfd12df0
name: result-wbar-t-l1-bound
description: "Paper 2312.05134 Algorithm 1 (oracle variant): ||w_bar^T||_1 <= 1 (in fact =1) deterministically, since each w^t lies in the simplex Delta_k and w_bar^T is their average"
metadata:
  type: project
---

Subtask: In the oracle variant of Algorithm 1 (lines a1-a2 replaced by an oracle returning $h^t$ with $L(h^t,w^t)\le\min_{h\in\mathcal H}L(h,w^t)+\varepsilon_1$ each round), bound $\|\overline w^T\|_1$ with probability $\ge 1-\delta/4$.

**Result:** $\|\overline w^T\|_1\le 1$ (in fact $=1$), and this holds **deterministically** (not just w.h.p.) — the $1-\delta/4$ qualifier is vacuous for this particular quantity.

**Why:** Each round's weight vector $w^t$ is a Hedge/multiplicative-weights distribution over the $k$ basis distributions, so $w^t\in\Delta_k$ regardless of how $h^t$ is chosen (the oracle replacement only affects $h^t$, not the $w^t$ update rule). $\overline w^T=\frac1T\sum_{t=1}^T w^t$ is a convex combination of points in $\Delta_k$, hence itself in $\Delta_k$, so its $\ell_1$ norm is exactly 1.

**How to apply:** Reuse this immediately in later subtasks of 2312.05134's Algorithm 1 analysis whenever $\|\overline w^T\|_1$ (or $\|w^t\|_1$) shows up in a bound — no probabilistic argument or union-bound budget is needed for it, unlike [[result-hfinal-oracle-bound]] and [[result-lht-wt-bound-round-t]] which are genuine high-probability results consuming part of the overall $\delta$ budget. Verify $w^t\in\Delta_k$ (simplex weight update) still matches the current paper draft's Algorithm 1 before reusing.
