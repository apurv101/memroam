---
id: 01a050b3-6fef-7264-b600-451ccbb1463c
name: result-lht-wt-bound-algorithm3
description: "Paper 2312.05134 Algorithm 3: with prob >= 1-delta/4, L(h^t,w^t) <= min_h L(h,w^t) + eps/50 for all rounds t, under Assumption~rad (Rademacher-complexity analogue of Algorithm 1's weighted-VC assumption) — NOT verified against paper, reconstructed by analogy"
metadata:
  type: project
---

Subtask: bound $L(h^t,w^t)$ for all $1\le t\le T$ in **Algorithm 3** of paper 2312.05134, under Assumption~\ref{assump:rad}.

**Result given:** With probability at least $1-\delta/4$, for all $1\le t\le T$:
$$L(h^t,w^t)\le \min_{h\in\mathcal H}L(h,w^t)+\varepsilon/50$$

Identical statement and constant to [[result-lht-wt-bound-round-t]] (the Algorithm 1 version, which uses weighted-VC uniform convergence). The Algorithm 3 answer was produced by analogy — same proof shape (uniform convergence over $\mathcal H$ via a weighted-Rademacher-complexity bound instead of weighted-VC, combined with $h^t$ being the empirical minimizer) — **not by reading an actual statement of Assumption~\ref{assump:rad} or Algorithm 3 from the paper**, since neither was present in memory or supplied in-session. A memory-write attempt during the session was blocked/failed, which is why this is being persisted now instead.

**Caveat (important):** The exact content of Assumption~\ref{assump:rad} and Algorithm 3 (how they differ operationally from Algorithm 1 / the weighted-VC assumption) is unverified. Before reusing this result or building on it further:
1. Confirm Assumption~\ref{assump:rad} actually gives a bound of the same functional form as the weighted-VC assumption used for Algorithm 1 (i.e., that swapping VC-dim for Rademacher complexity is the *only* difference).
2. Confirm the $\varepsilon/50$ constant carries over unchanged — it was copied from the Algorithm 1 result, not re-derived from Assumption~rad's specific constants.
3. If Algorithm 3 differs from Algorithm 1 beyond the complexity measure used (e.g. different weight update rule, different per-round sample sizes), this bound likely needs rederivation.

**How to apply:** Treat as a provisional/likely-correct placeholder for the Algorithm 3 analogue of [[result-lht-wt-bound-round-t]]. If a future session has access to the actual text of Assumption~rad and Algorithm 3, re-verify and update this memory (or delete it in favor of a verified version) rather than trusting it blindly.
