---
id: 01a0509f-3a78-7667-8e6c-e98cdd365fe2
name: result-weighted-rad-scaling-bound
description: "Paper 2312.05134: bound on (sum n_i)*Rad~_{n_i} in terms of (sum m_i)*Rad~_{m_i} for two arbitrary sample-size vectors {n_i}, {m_i}, proved via monotonicity + subadditivity of g({n_i}):=(sum n_i)*Rad~_{n_i}"
metadata:
  type: project
---

For any two groups of positive integers $\{n_i\}_{i=1}^k$ and $\{m_i\}_{i=1}^k$:

$$\left(\sum_{i=1}^k n_i\right)\widetilde{\mathsf{Rad}}_{\{n_i\}_{i=1}^k}\ \le\ \left\lceil \max_{1\le i\le k}\frac{n_i}{m_i}\right\rceil\cdot\left(\sum_{i=1}^k m_i\right)\widetilde{\mathsf{Rad}}_{\{m_i\}_{i=1}^k}.$$

**Proof technique:** define $g(\{n_i\}) := (\sum_i n_i)\,\widetilde{\mathsf{Rad}}_{\{n_i\}}$ and show two structural properties of $g$:
- **Monotonicity**: adding samples cannot decrease $g$ (Jensen's inequality applied to the convex max defining the Rademacher-type complexity).
- **Subadditivity**: splitting the $n_i$ samples into independent blocks whose sizes sum to $n_i$ gives $g(\text{combined}) \le \sum(\text{block } g\text{'s})$, via $\max(A+B) \le \max A + \max B$.

Combining these: cover each $n_i$ by $\lceil n_i/m_i \rceil$ blocks of size $\le m_i$ (padding via monotonicity), then subadditivity across the $\lceil \max_i n_i/m_i\rceil$ "rounds" of blocks gives the stated bound.

**Why:** this is a general scaling/comparison lemma for the paper's weighted empirical Rademacher-type complexity $\widetilde{\mathsf{Rad}}$ across different sample-size allocations $\{n_i\}$ vs $\{m_i\}$ — likely used to compare complexity terms when sample sizes per group change between rounds/settings.

**How to apply:** if a later subtask needs to relate $\widetilde{\mathsf{Rad}}_{\{n_i\}}$-type quantities for two different sample-size vectors, reuse this $g$-monotonicity/subadditivity technique rather than re-deriving from scratch.

Note: exact formal definition of $\widetilde{\mathsf{Rad}}_{\{n_i\}}$ was not re-stated/saved here — if a future session needs it verbatim, check the paper's Algorithm 1 context ([[result-hfinal-oracle-bound]], [[result-Lht-wt-bound-round-t]], [[result-wbar-T-L1-bound]] are the other known pieces of this paper's machinery).
