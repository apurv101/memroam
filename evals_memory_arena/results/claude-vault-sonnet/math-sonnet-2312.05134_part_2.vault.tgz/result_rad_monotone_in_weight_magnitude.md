---
id: 01a050af-2d45-7b83-8bbc-9d6157857095
name: result-rad-monotone-in-weight-magnitude
description: "Paper 2312.05134: E_sigma[max_{f in L} sum_i sigma_i w^1_i f_i] <= E_sigma[max_{f in L} sum_i sigma_i w^2_i f_i] whenever |w^1_i|<=|w^2_i| pointwise — coordinatewise weight-magnitude monotonicity of Rademacher-type complexity"
metadata:
  type: project
---

**Lemma.** For $\mathcal L \subseteq \mathbb R^n$ and $w^1, w^2 \in \mathbb R^n$ with $|w^1_i| \le |w^2_i|$ for all $i \in [n]$:

$$\mathbb E_{\{\sigma_i\}}\Big[\max_{f\in\mathcal L}\sum_{i=1}^n \sigma_i w^1_i f_i\Big]\ \le\ \mathbb E_{\{\sigma_i\}}\Big[\max_{f\in\mathcal L}\sum_{i=1}^n \sigma_i w^2_i f_i\Big].$$

**Proof technique:**
1. Symmetrization: since each $\sigma_i$ is a fair sign, replacing $w_i$ by $|w_i|$ (fixed sign flips) does not change the law of the expectation, so WLOG $w^1, w^2 \ge 0$ and $w^1_i \le w^2_i$.
2. Write $w^1_i = t_i w^2_i$ with $t_i = |w^1_i|/|w^2_i| \in [0,1]$ (handle $w^2_i=0 \Rightarrow w^1_i=0$ separately, trivial).
3. The map $t \mapsto \mathbb E_\sigma[\max_f \sum_i \sigma_i t_i w^2_i f_i]$ is convex in $t\in[0,1]^n$ (max of linear functions, then expectation preserves convexity).
4. A convex function on the cube $[0,1]^n$ attains its max over any line/point comparison at extreme points; combined with monotonicity in each $t_i$ (increasing $t_i$ toward 1 can only increase the expected max, by a direct coupling/Jensen argument), the value at $t=\mathbf 1$ (i.e., $w^2$) dominates the value at any $t\in[0,1]^n$ (i.e., $w^1$).

**Why:** general-purpose monotonicity lemma for Rademacher-type complexities under pointwise weight-magnitude domination — complements [[result-weighted-rad-scaling-bound]], which handles comparing different *sample-size* allocations rather than different *weight magnitudes*. Likely used in the paper to bound a weighted Rademacher complexity by one with simpler/larger weights (e.g., replacing data-dependent weights with a uniform or worst-case bound).

**How to apply:** if a later subtask needs to bound $\mathbb E_\sigma[\max_f \sum_i \sigma_i w_i f_i]$ by swapping in a dominating weight vector, cite this lemma directly rather than re-deriving the symmetrization + convexity argument.
