---
id: 01a0508a-283b-732c-9ca8-8b491004a219
name: result-lht-wt-bound-round-t
description: "Paper 2312.05134 Algorithm 1: with prob >= 1-delta/4, L(h^t,w^t) <= min_h L(h,w^t) + eps/50 for all rounds t, via weighted-VC uniform convergence + optimality of h^t for empirical loss"
metadata:
  type: project
---

Subtask: bound $L(h^t,w^t)$ for all $1\le t\le T$ in Algorithm 1 of paper 2312.05134.

**Result:** With probability at least $1-\delta/4$, for all $1\le t\le T$:
$$L(h^t,w^t)\le \min_{h\in\mathcal H}L(h,w^t)+\varepsilon/50$$

**Proof idea:** Use a weighted-VC uniform-convergence bound on the empirical weighted loss $\widehat L^t$ (relying on $n_i^t\ge \Tone w_i^t/2$, i.e. sample counts per group/bucket are at least half the weight-scaled expectation), combined with the fact that $h^t$ is chosen to minimize $\widehat L^t(\cdot,w^t)$ over $\mathcal H$ — so its empirical loss is within the uniform-convergence slack of the true minimizer's true loss.

**Why:** This is one step in a larger union-bound argument (the $\delta/4$ budget suggests this is one of ~4 failure events being combined for an overall $1-\delta$ guarantee across the algorithm's analysis).

**How to apply:** In later sessions working on 2312.05134's Algorithm 1 analysis, this bound on $L(h^t,w^t)$ is available to plug into subsequent regret/convergence arguments — treat it as an established lemma rather than re-deriving from scratch. If notation for $\mathcal H$, $w^t$, $n_i^t$, or the $\varepsilon/50$ constant changes in later subtasks, verify against the current paper draft before reusing.
