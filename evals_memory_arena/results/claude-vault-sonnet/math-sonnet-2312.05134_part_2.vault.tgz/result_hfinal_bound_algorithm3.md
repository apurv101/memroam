---
id: 01a050b7-6c66-7f6c-9fa4-77a4ce906c9c
name: result-hfinal-bound-algorithm3
description: "Paper 2312.05134 Algorithm 3: under Assumption 3, w.p. >= 1-delta, max_i E_{D_i,h^final}[loss] <= min_h max_i E_{D_i}[loss] + eps/50 + sqrt(ln k/(2T)) — NOT verified against paper, reconstructed by analogy to Algorithm 1"
metadata:
  type: project
---

Subtask: Suppose Assumption 3 holds, let $h^{\mathsf{final}}$ be the output of **Algorithm 3**. Bound $\max_{1\le i\le k}\mathbb E_{(x,y)\sim\mathcal D_i,h^{\mathsf{final}}}[\ell(h^{\mathsf{final}},(x,y))]$ w.p. $\ge 1-\delta$.

**Result given:**
$$\max_{1\le i\le k}\mathbb E_{(x,y)\sim \mathcal D_i,\,h^{\mathsf{final}}}[\ell(h^{\mathsf{final}},(x,y))]\;\le\;\min_{h\in\mathcal H}\max_{1\le i\le k}\mathbb E_{(x,y)\sim\mathcal D_i}[\ell(h,(x,y))]\;+\;\frac{\varepsilon}{50}\;+\;\sqrt{\frac{\ln k}{2T}}$$

Derivation chains three facts: (1) [[result-lht-wt-bound-algorithm3]] (per-round bound $L(h^t,w^t)\le\min_h L(h,w^t)+\varepsilon/50$, the only probabilistic step), (2) a deterministic Hedge/multiplicative-weights no-regret guarantee over the $k$ groups, (3) $h^{\mathsf{final}}$ = uniform mixture over $h^1,\dots,h^T$ so $\mathbb E_{\mathcal D_i,h^{\mathsf{final}}}[\ell]=\frac1T\sum_t L(h^t,\mathcal D_i)$ exactly.

Same functional form as [[result-hfinal-oracle-bound]] (Algorithm 1's analogous theorem) with $\varepsilon_1=\varepsilon/50$.

**Caveat (important, inherited from [[result-lht-wt-bound-algorithm3]]):** Neither Assumption 3's exact statement nor Algorithm 3's exact steps were available in-session; this was reconstructed purely by analogy to Algorithm 1's proof structure and result. Before reusing:
1. Verify Assumption 3 is indeed the Rademacher-complexity analogue of Algorithm 1's weighted-VC assumption, and that it's the *only* structural difference between Algorithm 3 and Algorithm 1.
2. Verify the $\varepsilon/50$ constant against Assumption 3's actual constants (not re-derived, copied from Algorithm 1).
3. Verify whether $\delta$ here should be split (e.g. $\delta/4$) if this is one of several failure events combined via union bound elsewhere in the paper — [[result-hfinal-oracle-bound]] and [[result-lht-wt-bound-algorithm3]] both use $\delta/4$ budgets, but this subtask's prompt asked for overall $1-\delta$ directly.

**How to apply:** Treat as a provisional final theorem for Algorithm 3, parallel to [[result-hfinal-oracle-bound]] for Algorithm 1. Re-verify against the actual paper text if/when Assumption 3 and Algorithm 3 become available in a future session.
