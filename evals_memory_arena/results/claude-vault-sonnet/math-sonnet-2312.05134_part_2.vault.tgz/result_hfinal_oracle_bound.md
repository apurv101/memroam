---
id: 01a0508f-8d69-76cd-b5a5-388c0bd3bb43
name: result-hfinal-oracle-bound
description: "Paper 2312.05134 Algorithm 1 (oracle variant): if lines a1-a2 replaced by an eps_1-approx oracle for h^t, then w.p. >= 1-delta/4, max_i L(h^final,basis_i) <= min_h max_i L(h,basis_i) + eps_1 + sqrt(ln k / (2T))"
metadata:
  type: project
---

Subtask: In Algorithm 1 of paper 2312.05134, suppose lines a1-a2 (the step computing $h^t$) are replaced by an oracle returning $h^t$ satisfying $L(h^t,w^t)\le \min_{h\in\mathcal H}L(h,w^t)+\varepsilon_1$ each round $1\le t\le T$. Bound $\max_{1\le i\le k}L(h^{\mathsf{final}},\mathsf{basis}_i)$ w.p. $\ge 1-\delta/4$.

**Result:**
$$\max_{1\le i\le k}L(h^{\mathsf{final}},\mathsf{basis}_i)\;\le\;\min_{h\in\mathcal H}\max_{1\le i\le k}L(h,\mathsf{basis}_i)\;+\;\varepsilon_1\;+\;\sqrt{\frac{\ln k}{2T}}.$$

**Why:** This generalizes [[result-lht-wt-bound-round-t]] (which is the special case $\varepsilon_1=\varepsilon/50$ from the exact-minimization version of lines a1-a2). The $\sqrt{\ln k/(2T)}$ term is the standard multiplicative-weights / no-regret-vs-best-fixed-action regret bound over $k$ basis distributions after $T$ rounds; $h^{\mathsf{final}}$ is the algorithm's aggregated/averaged output over the $T$ rounds' $h^t$'s and $w^t$'s.

**How to apply:** In later sessions extending Algorithm 1's analysis to an oracle-based (approximate ERM) variant, this is the analog of the standard exact-oracle guarantee — reuse it as an established lemma. Setting $\varepsilon_1=0$ (or the paper's exact $\varepsilon/50$ constant) should recover the original algorithm's bound; verify constants/notation ($k$, $T$, $\mathsf{basis}_i$, $\delta/4$ budget) against the current paper draft before reusing, since $\delta/4$ suggests this is one of ~4 failure events combined via union bound for an overall $1-\delta$ guarantee.
