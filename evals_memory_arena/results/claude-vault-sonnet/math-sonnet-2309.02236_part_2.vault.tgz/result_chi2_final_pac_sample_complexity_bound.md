---
id: 01a050e7-cd1b-7ccf-9af0-cf2846931861
name: result-chi2-final-pac-sample-complexity-bound
description: "Paper 2309.02236: solved final PAC sample-complexity bound N_chi2 such that N>=N_chi2 implies max_s |V^R_{pi_N*,f}(s) - V^R_{pi*,f}(s)| <= epsilon w.p. >=1-delta, for chi2-uncertainty robust MDPs (Algorithm 1)"
metadata:
  type: project
---

Subtask: for the $\chi^2$-divergence uncertainty set, give an asymptotic upper bound $N_{\chi^2}$ such that for all $N\ge N_{\chi^2}$,
$$\max_s\big|V^{\text R}_{\pi_N^*,f}(s)-V^{\text R}_{\pi^*,f}(s)\big|\le\epsilon$$
w.p. $\ge1-\delta$, where $\pi^*$ is robust-optimal for true nominal dynamics $f$ and $\pi_N^*$ is robust-optimal for the learned nominal dynamics $\hat f_N$ (Algorithm 1), $\delta\in(0,1)$, $\epsilon\in(0,\tfrac1{1-\gamma})$.

**Solved bound:**
$$N_{\chi^2}=\mathcal O\!\left(\frac{d^{3}\,(1+2\rho)^2\,\Gamma_{Nd}\,\beta_N^2(\delta)}{\sigma^2(1-\gamma)^8\,\epsilon^{4}}\right)$$

**Derivation:**
1. Optimality of $\pi^*$ under $f$ turns the max-abs gap into a one-sided difference $V^{\text R}_{\pi^*,f}-V^{\text R}_{\pi_N^*,f}\ge0$.
2. Adding/subtracting $V^{\text R}_{\pi^*,\hat f_N}$ and $V^{\text R}_{\pi_N^*,\hat f_N}$, and using optimality of $\pi_N^*$ under $\hat f_N$ (so the cross term is $\le0$), bounds the gap by the sum of two fixed-policy term-(i)-type gaps: $(i)_{\chi^2}(\pi^*)+(i)_{\chi^2}(\pi_N^*)$.
3. Each $(i)_{\chi^2}(\hpi)$ is bounded via [[result-chi2-ball-tv-bound]] (the $\chi^2$-ball analogue of [[result-robust-value-function-estimation-error-bound]]'s KL-based term-(i) bound), converted from TV to $\ell_2$-mean-gap via Pinsker + Gaussian KL, then to the Lemma-4 confidence width $\Delta_N^{\max}(\delta)=\sqrt d\,\beta_N(\delta)\max\sigma_N(s,a,i)$, then chained through the $\gamma$-contraction of the robust Bellman operator (paper's Lemma 8), giving $(i)_{\chi^2}(\hpi)\le\frac{\gamma}{1-\gamma}c_2(\rho)M\sqrt{\Delta_N^{\max}(\delta)/2\sigma}$, $c_2(\rho)=\sqrt{1+2\rho}$, $M=1/(1-\gamma)$.
4. Substituting the standard kernel/GP confidence-width scaling $\sigma_N(s,a,i)\le d\sqrt{2e\Gamma_{Nd}/N}$ (same scaling underlying $N'(\rho,\psa)$ in [[result-softmin-kl-ball-sample-complexity-bound]]) and inverting $\le\epsilon$ for $N$ gives the boxed rate.

**Key structural point:** because the $\chi^2$ dual bound (step 3) enters through a **square root** of the TV/estimation gap (Hölder-$\tfrac12$, not Lipschitz, unlike the KL case), the final exponent is $\epsilon^{-4}$ rather than the $\epsilon^{-2}$ seen in the KL-ball result [[result-softmin-kl-ball-sample-complexity-bound]]. This is a genuine structural difference between $\chi^2$ and KL uncertainty sets, not an algebra artifact. As $\rho\to0$, the $(1+2\rho)^2\to1$ prefactor shrinks consistent with the ball degenerating to a point.

Note: relies on $\beta_N(\delta)$, $\Gamma_{Nd}$, Lemma 4/Lemma 8 definitions established earlier in-session (not independently re-verified here); re-check against source paper if unavailable in a future session.
