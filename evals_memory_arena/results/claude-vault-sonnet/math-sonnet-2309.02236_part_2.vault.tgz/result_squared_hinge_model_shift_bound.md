---
id: 01a050dd-6f04-7b83-9d12-6d81f9251fcd
name: result-squared-hinge-model-shift-bound
description: "Paper 2309.02236: solved bound on |E_psa[(-V(s')+eta)_+^2] - E_pnsa[(-V(s')+eta)_+^2]| for fixed V but different Gaussian nominal models (true f vs. estimated fhat_n), with eta in [0, c2(rho)M/(c2(rho)-1)]"
metadata:
  type: project
---

Subtask: for $V:\mathcal S\to[0,1/(1-\gamma)]$, $\alpha>0$, $\pnsa=\mathcal N(\hat f_n(s,a),\sigma^2 I)$, $\psa=\mathcal N(f(s,a),\sigma^2 I)$, $\eta\in[0,\frac{c_2(\rho)M}{c_2(\rho)-1}]$ with $c_2(\rho)=\sqrt{1+2\rho}$, $M=1/(1-\gamma)$, bound
$$\big|\mathbb E_{\psa}[(-V(s')+\eta)_+^2]-\mathbb E_{\pnsa}[(-V(s')+\eta)_+^2]\big|.$$

This is the model-shift counterpart to [[result-squared-hinge-expectation-lipschitz-bound]] (which is Lipschitz-in-$V$ for a fixed model) and reuses the Stein's-identity technique from [[result-gaussian-softmin-expectation-bound]] (which is model-shift but for $g=e^{-V/\alpha}$).

**Solved bound:**
$$\Big|\mathbb E_{\psa}[(-V(s')+\eta)_+^2]-\mathbb E_{\pnsa}[(-V(s')+\eta)_+^2]\Big|\;\le\;\frac{\eta^2\sqrt d}{\sigma}\,\big\|\hat f_n(s,a)-f(s,a)\big\|_2\;\le\;\frac{\sqrt d}{\sigma}\Big(\frac{c_2(\rho)M}{c_2(\rho)-1}\Big)^{2}\big\|\hat f_n(s,a)-f(s,a)\big\|_2.$$

**Proof approach:** define $G(\mu)=\mathbb E_{\mathcal N(\mu,\sigma^2 I)}[g(s')]$ for $g(s')=(\eta-V(s'))_+^2\in[0,\eta^2]$ (bounded since $V\ge0$). By the Stein-type identity $\nabla_\mu G(\mu)=\sigma^{-2}\mathbb E_\mu[g(s')(s'-\mu)]$, and since $g\in[0,\eta^2]$, $\|\nabla_\mu G(\mu)\|_2\le \eta^2\sqrt d/\sigma$ — a deterministic Lipschitz bound in $\mu$. Then $|G(f(s,a))-G(\hat f_n(s,a))|\le \frac{\eta^2\sqrt d}{\sigma}\|\hat f_n(s,a)-f(s,a)\|_2$, and finally substitute the worst-case bound on $\eta$ to get the second, $\eta$-free inequality.

**How to apply:** this is the general pattern — for any bounded scalar transform $g=\phi(V)$ with $\|\phi\|_\infty\le B$, the model-shift gap $|\mathbb E_{\psa}[\phi(V)]-\mathbb E_{\pnsa}[\phi(V)]|\le \frac{B\sqrt d}{\sigma}\|\hat f_n(s,a)-f(s,a)\|_2$ via the same Stein's-identity argument (only the bound $B$ on $\phi$ changes: $B=1$ for $e^{-V/\alpha}$, $B=\eta^2$ here for $(\eta-V)_+^2$).
