---
id: 01a050d9-4ab1-7c52-8ce5-fd74af03f73d
name: result-squared-hinge-expectation-lipschitz-bound
description: "Paper 2309.02236: solved bound on |E_psa[(-V'(s')+eta)_+^2] - E_psa[(-V(s')+eta)_+^2]| for V,V': S->[0,1/(1-gamma)], used for a term involving a squared-hinge (CVaR/quantile-type) transform of the value function"
metadata:
  type: project
---

Subtask: for value functions $V,V':\mathcal S\to[0,1/(1-\gamma)]$, bound
$$\Big|\mathbb E_{\psa}[(-V'(s')+\eta)_+^2]-\mathbb E_{\psa}[(-V(s')+\eta)_+^2]\Big|.$$

Solution: the map $x\mapsto (-x+\eta)_+^2$ is Lipschitz on $[0,1/(1-\gamma)]$ with constant $2\eta_+$ (where $\eta_+=\max(\eta,0)$), since its derivative w.r.t. $x$ has magnitude $2(\eta-x)_+\le 2\eta_+$. Applying this pointwise and taking expectation over $s'\sim\psa$ gives

$$\Big|\mathbb E_{\psa}[(-V'(s')+\eta)_+^2]-\mathbb E_{\psa}[(-V(s')+\eta)_+^2]\Big|\le 2\eta_+\,\|V-V'\|_\infty.$$

When $\eta\in[0,1/(1-\gamma)]$ (the relevant range in this paper), this specializes to
$$\frac{2}{1-\gamma}\|V-V'\|_\infty.$$

**Why:** this is a companion lemma to the softmin/dual bounds already in this project's memory ([result-gaussian-softmin-expectation-bound], [result-softmin-dual-alpha-to-zero-limit], [result-chi2-ball-tv-bound]) — the squared-hinge term $(-V+\eta)_+^2$ likely arises from a CVaR- or quantile-based robust objective (dual variable $\eta$), analogous to how $e^{-V/\alpha}$ arises in the KL/softmin duals.

**How to apply:** reuse this Lipschitz-constant argument (derivative bound $\Rightarrow$ pointwise Lipschitz $\Rightarrow$ expectation bound) for any future subtask asking to bound differences of $\mathbb E_{\psa}[\phi(V(s'))]-\mathbb E_{\psa}[\phi(V'(s'))]$ for a fixed scalar function $\phi$ — just compute $\sup|\phi'|$ over the value range $[0,1/(1-\gamma)]$.
