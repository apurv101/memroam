---
id: 01a050c7-36a8-79bc-a6d4-6fbb3dbb383e
name: result-softmin-kl-ball-sample-complexity-bound
description: "Paper 2309.02236: solved bound on max_s |inf_{KL<=rho} E_p[V] under P_fhat_n(s,hpi_n(s)) - inf_{KL<=rho} E_p[V] under P_f(s,hpi_n(s))|, giving explicit sample-complexity thresholds N'(rho,psa), N''(rho,psa)"
metadata:
  type: project
---

Subtask: for any $V:\mathcal S\to[0,1/(1-\gamma)]$, bound
$$\max_{s}\Big|\inf_{KL(p\|P_{\hat f_n}(s,\hat\pi_n(s)))\le\rho}\mathbb E_{s'\sim p}[V(s')]-\inf_{KL(p\|P_f(s,\hat\pi_n(s)))\le\rho}\mathbb E_{s'\sim p}[V(s')]\Big|$$
with probability $1-\delta$, for $n$ large enough.

**Solved result:** for $n>\max\{N'(\rho,\psa),N''(\rho,\psa)\}$ (max over all $(s,a)$), with probability $\ge 1-\delta$ the quantity above is $\le \tau$, where

- $N'(\rho,\psa)=\mathcal O\Big(\dfrac{\beta_n^2(\delta)\,2e d^2\Gamma_{nd}}{\big(\frac{\kappa-e^{-\rho}}{2}\big)^2}\Big)$
- $N''(\rho,\psa)=\mathcal O\Big(\dfrac{4M^2 e^{2M/\underline\alpha}\,\beta_n^2(\delta)\,2ed^2\Gamma_{nd}}{(\rho\tau)^2}\Big)$
- $\overline\alpha=M/\rho$, $M=1/(1-\gamma)$, $\underline\alpha=\alpha^*/2$ with $\alpha^*=\arg\max_{\alpha\ge0}\{-\alpha\log(\mathbb E_{P_f}[e^{-V/\alpha}])-\alpha\rho\}$
- $\kappa$: defined via $\Pr_{s'\sim\mathcal N(f(s,a),\sigma^2 I)}\{s'\in\mathbb R^d: Y=V(s')=\mathrm{ESI}(Y)\}>e^{-\rho}$ (essential-infimum-attaining-set probability mass condition)
- $\tau$: the log-ratio Lipschitz constant from $\big|\log(\mathbb E_{P_{\hat f_n}}[e^{-V/\alpha}]/\mathbb E_{P_f}[e^{-V/\alpha}])\big|\le e^{M/\alpha}\big|\mathbb E_{P_{\hat f_n}}[e^{-V/\alpha}]-\mathbb E_{P_f}[e^{-V/\alpha}]\big|$

**Proof sketch:**
1. Strong duality rewrites each $\inf_{KL\le\rho}\mathbb E_p[V]$ as a softmin dual: $\sup_{\alpha\ge0}\{-\alpha\log(\mathbb E[e^{-V/\alpha}])-\alpha\rho\}$.
2. Sup-difference inequality bounds the gap between the two duals by the gap in the inner log-expectation term, uniformly over $\alpha$.
3. $N'$ restricts/localizes the effective dual range to $\alpha\in[\underline\alpha,\overline\alpha]=[\alpha^*/2, M/\rho]$ — this is where the $\kappa$ vs. $e^{-\rho}$ margin condition and [[result-softmin-dual-alpha-to-zero-limit]] (the $\alpha\to0$ ESI limit) come in, ensuring the maximizing $\alpha^*$ doesn't collapse to 0 and the dual optimum is well-approximated on this bounded range.
4. On that localized range, apply the $\tau$ log-ratio Lipschitz bound together with [[result-gaussian-softmin-expectation-bound]] (the Gaussian $|\mathbb E_{P_{\hat f_n}}[e^{-V/\alpha}]-\mathbb E_{P_f}[e^{-V/\alpha}]|$ bound, which supplies the $\beta_n(\delta)$, $d$, $\Gamma_{nd}$ terms) to get an explicit finite-$n$ error bound.
5. $N''$ is obtained by inverting that finite-$n$ bound to require it be $\le\tau$, giving the final sample-complexity threshold (the $e^{2M/\underline\alpha}$ factor comes from converting the log-ratio bound back through $\alpha\in[\underline\alpha,\overline\alpha]$).

Together with [[result-robust-value-function-estimation-error-bound]] this is an alternative (softmin-dual, rather than contraction/Lipschitz) route to bounding a term-(i)-type nominal-dynamics estimation-error gap; the two derivations should be reconciled/compared if both appear in the final paper writeup.

Note: relies on definitions of $\beta_n(\delta)$, $\Gamma_{nd}$, $\hat\pi_n$, $\psa$ established earlier in-session (not independently re-verified here) — re-check against source paper if unavailable in a future session.
