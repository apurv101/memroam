---
id: 01a050e2-4af8-7a21-819a-a7d5ec209da4
name: result-squared-hinge-model-shift-sqrt-sup-bound
description: "Paper 2309.02236: solved bound on max_V max_{s,a} sup_{eta in [0,c2(rho)M/(c2(rho)-1)]} |E_psa[(-V(s')+eta)_+^2] - E_pnsa[(-V(s')+eta)_+^2]|^{1/2}"
metadata:
  type: project
---

Subtask: for $\mathcal V=\{V:\mathcal S\to[0,1/(1-\gamma)]\}$, $c_2(\rho)=\sqrt{1+2\rho}$, $M=1/(1-\gamma)$, bound
$$\max_{V\in\mathcal V}\max_{s,a}\sup_{\eta\in[0,\frac{c_2(\rho)M}{c_2(\rho)-1}]}\Big\{\big|\mathbb E_{\psa}[(-V(s')+\eta)_+^2]-\mathbb E_{\pnsa}[(-V(s')+\eta)_+^2]\big|^{1/2}\Big\}.$$

This is a direct corollary of [[result-squared-hinge-model-shift-bound]]: take that bound (which is already $V$-free and increasing in $\eta$), evaluate at $\eta=\eta_{\max}=\frac{c_2(\rho)M}{c_2(\rho)-1}$ (the sup over $\eta$), take $\max_{s,a}$, then square-root.

**Solved bound:**
$$\max_{V\in\mathcal V}\max_{s,a}\sup_{\eta\in[0,\eta_{\max}]}\Big\{\big|\mathbb E_{\psa}[(-V(s')+\eta)_+^2]-\mathbb E_{\pnsa}[(-V(s')+\eta)_+^2]\big|\Big\}^{1/2}\;\le\;\eta_{\max}\cdot\frac{d^{1/4}}{\sqrt\sigma}\Big(\max_{s,a}\big\|\hat f_n(s,a)-f(s,a)\big\|_2\Big)^{1/2},$$
where $\eta_{\max}=\frac{c_2(\rho)M}{c_2(\rho)-1}$.

**Proof approach:** since [[result-squared-hinge-model-shift-bound]]'s bound $\frac{\eta^2\sqrt d}{\sigma}\|\hat f_n(s,a)-f(s,a)\|_2$ doesn't depend on $V$, $\max_V$ is free (no extra work). It's increasing in $\eta\ge0$ so the sup is at $\eta=\eta_{\max}$. Square-rooting $\eta_{\max}^2\frac{\sqrt d}{\sigma}\|\cdot\|_2$ gives $\eta_{\max}\frac{d^{1/4}}{\sqrt\sigma}\|\cdot\|_2^{1/2}$; taking $\max_{s,a}$ of the remaining norm term last is equivalent (order of max/sqrt doesn't matter since sqrt is monotonic).

**How to apply:** this sqrt-sup-max wrapper pattern (max over V free since parent bound is V-independent; sup over $\eta$ at right endpoint since bound increasing in $\eta$; sqrt commutes with max) likely recurs for other terms in this paper built from squared-hinge or similar bounded transforms — check whether the parent bound is monotonic in the relevant sup variable before assuming endpoint evaluation.
