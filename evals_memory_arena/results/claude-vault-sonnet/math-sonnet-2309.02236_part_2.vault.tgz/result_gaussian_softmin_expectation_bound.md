---
id: 01a050bc-57f9-72be-88f0-0a9220356bad
name: result-gaussian-softmin-expectation-bound
description: "Paper 2309.02236: solved bound on |E_{P_fhat}[e^{-V/alpha}] - E_{P_f}[e^{-V/alpha}]| for Gaussian transition models with shared covariance sigma^2 I — the core lemma underlying term (i)'s proof"
metadata:
  type: project
---

Subtask: for any $V:\mathcal S\to[0,1/(1-\gamma)]$ and any $\alpha>0$, upper bound
$$\big|\mathbb E_{s'\sim P_{\hat f_n}(s,a)}[e^{-V(s')/\alpha}]-\mathbb E_{s'\sim P_f(s,a)}[e^{-V(s')/\alpha}]\big|$$
where $P_{\hat f_n}(s,a)=\mathcal N(\hat f_n(s,a),\sigma^2 I)$ and $P_f(s,a)=\mathcal N(f(s,a),\sigma^2 I)$ (same covariance, different means).

**Solved bound (probability $\ge 1-\delta$):**
$$\Big|\mathbb E_{P_{\hat f_n}}[e^{-V/\alpha}]-\mathbb E_{P_f}[e^{-V/\alpha}]\Big| \;\le\; \frac{\sqrt d}{\sigma}\,\beta_n(\delta)\,\max_{i\in[d]}\sigma_n(s,a,i)$$

(Note: derived $\sqrt d/\sigma$ as the Lipschitz constant, not $d/\sigma$ — double-check this factor if reconstructing, since a stray $\sqrt d$ vs $d$ slipped between the derivation and the final answer text in-session.)

**Proof approach:**
1. Define $G(\mu):=\mathbb E_{s'\sim\mathcal N(\mu,\sigma^2 I)}[e^{-V(s')/\alpha}]$ for $g:=e^{-V/\alpha}\in[0,1]$ (bounded since $V\ge 0$).
2. Stein-type identity: $\nabla_\mu G(\mu) = \sigma^{-2}\,\mathbb E_{\mu}[g(s')(s'-\mu)]$.
3. Since $g\in[0,1]$ and $(s'-\mu)\sim\mathcal N(0,\sigma^2 I)$, bound $\|\nabla_\mu G(\mu)\|_2 \le \sigma^{-1}\sqrt d$ (using $\mathbb E\|s'-\mu\|_2\le\sqrt d\,\sigma$ type argument) — this gives a **deterministic, $\alpha$-independent** Lipschitz bound $\sqrt d/\sigma$ on $\mu\mapsto G(\mu)$, valid for every $\alpha>0$ simultaneously.
4. Apply mean value / Lipschitz bound: $|G(\hat f_n(s,a))-G(f(s,a))|\le \frac{\sqrt d}{\sigma}\|\hat f_n(s,a)-f(s,a)\|_2$.
5. Plug in the paper's Lemma 4 confidence bound $\|\hat f_n(s,a)-f(s,a)\|_2\le\sqrt d\,\beta_n(\delta)\max_i\sigma_n(s,a,i)$ (same Lemma 4 used in [[result-robust-value-function-estimation-error-bound]]).

Terms: $d$ = state dimension; $\sigma^2 I$ = shared transition-noise covariance; $\beta_n(\delta)$, $\sigma_n(s,a,i)$ = confidence-width terms from Lemma 4; $\alpha$ = softmin/robustness temperature parameter (does not appear in final bound — a key feature, since this expression arises inside a $\sup_\alpha$ or $\inf_\alpha$ over the robust Bellman dual).

Likely role in the paper: this expectation-gap bound is the building block for translating the "Gaussian mean-shift under learned vs. true dynamics" step into the term-(i) bound in [[result-robust-value-function-estimation-error-bound]] (used inside the dual/exponential-twisting form of the robust Bellman operator, which is why $e^{-V/\alpha}$ appears rather than $V$ directly).
