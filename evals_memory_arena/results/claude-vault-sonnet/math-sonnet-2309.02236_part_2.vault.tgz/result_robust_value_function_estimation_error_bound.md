---
id: 01a050ac-9655-7db6-ba5b-a9ff26cbc10d
name: result-robust-value-function-estimation-error-bound
description: "Paper 2309.02236: solved bound on (i) = |V^R_{hpis,f}(s) - V^R_{hpis,f_hat_n}(s)|, the gap between robust value functions of policy hpis under true vs. learned nominal dynamics"
metadata:
  type: project
---

Subtask: upper bound $(i):=|V^{\text{R}}_{\hpis,f}(s)-V^{\text{R}}_{\hpis,\hat{f}_{n}}(s)|$, the robust value function gap of a fixed policy $\hpis$ evaluated under the true nominal dynamics $f$ vs. the learned nominal dynamics $\hat f_n$.

**Solved bound (probability $\ge 1-\delta$):**

$$(i)\;\le\;\frac{\gamma L_V\sqrt d}{1-\gamma}\Big(\beta_n(\delta)\sup_{s,a}\max_{i\in[d]}\sigma_n(s,a,i)+\frac{1}{\sqrt n}\Big)$$

**Proof approach:**
1. Contraction split of the robust Bellman operator (referenced in-paper as Lemma 8) separates the value-function gap into a term controlled by the discrepancy between the $f$- and $\hat f_n$-centered uncertainty balls.
2. Translation-invariance of the $f$-divergence uncertainty ball under the additive-noise transition model: since $P_f(s,a)$ and $P_{\hat f_n}(s,a)$ are both Gaussians with the same shift (only the mean/nominal-dynamics estimate differs), any $p$ feasible for the $P_f(s,a)$-ball maps to a translate feasible for the $P_{\hat f_n}(s,a)$-ball.
3. Combine with Lemma 4's confidence bound (giving $\beta_n(\delta)$, $\sigma_n(s,a,i)$ terms) and Assumption 1's discretization bound (giving the $1/\sqrt n$ term).

Terms: $L_V$ = state-Lipschitz constant of $V^R_{\hpis,\hat f_n}$; $\gamma$ = discount factor; $d$ = state dimension; $\beta_n(\delta)$, $\sigma_n(s,a,i)$ = confidence-width terms from Lemma 4; $n$ = sample size.

Note: this bound was derived largely from context established earlier in the session (Lemma 8, Lemma 4, Assumption 1 statements) which were not independently re-verified against the paper text in this memory — if those lemma statements are unavailable in future sessions, this bound's derivation cannot be fully reconstructed and should be re-checked against the source paper.
