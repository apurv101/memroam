---
id: 01a050c0-f249-7e6b-add1-fef29ecfc325
name: result-softmin-dual-alpha-to-zero-limit
description: "Paper 2309.02236: solved upper bound on lim_{alpha->0}[-alpha*log(E_{P_f}[e^{-V/alpha}]) - alpha*rho] = ess inf V(s') over s'~P_f(s,a) (in fact equality holds)"
metadata:
  type: project
---

Subtask: for $V:\mathcal S\to[0,1/(1-\gamma)]$, $Y=V(s')$, $s'\sim P_f(s,a)$, upper bound
$$\lim_{\alpha\to 0}\Big[-\alpha \log\big(\mathbb E_{s'\sim P_{f}(s,a)}[e^{-V(s')/\alpha}]\big)-\alpha \rho\Big].$$

This is the $\alpha\to0$ limit of the entropic/exponential-twisting dual objective that appears in [[result-gaussian-softmin-expectation-bound]] and (presumably) [[result-robust-value-function-estimation-error-bound]]'s robust Bellman operator — $\rho$ is a fixed robustness-radius parameter, independent of $\alpha$.

**Solved bound:**
$$\lim_{\alpha\to 0}\Big[-\alpha \log\big(\mathbb E_{s'\sim P_{f}(s,a)}[e^{-V(s')/\alpha}]\big)-\alpha \rho\Big]\;\le\;\operatorname*{ess\,inf}_{s'\sim P_f(s,a)}V(s').$$

Equality in fact holds (standard softmin$\to$hardmin limit) — the reverse inequality $-\alpha\log\mathbb E[e^{-V/\alpha}]\ge \operatorname{ess\,inf}V$ holds for every $\alpha>0$ directly from $V\ge \operatorname{ess\,inf}V$ a.e.

**Proof sketch:**
1. Let $m=\operatorname{ess\,inf}_{s'\sim P_f(s,a)}V(s')$. For any $\epsilon>0$, the set $\{V<m+\epsilon\}$ has positive probability $p_\epsilon>0$ under $P_f$ (fixed, independent of $\alpha$).
2. Lower-bound the expectation by restricting to that set: $\mathbb E[e^{-V/\alpha}]\ge p_\epsilon\, e^{-(m+\epsilon)/\alpha}$, so $-\alpha\log\mathbb E[e^{-V/\alpha}]\le -\alpha\log p_\epsilon+(m+\epsilon)$.
3. Send $\alpha\to0$: both $-\alpha\log p_\epsilon\to0$ and $-\alpha\rho\to0$ (since $\rho$ fixed), leaving $\le m+\epsilon$.
4. Send $\epsilon\to0$.

Role in the paper: this is the $\alpha\to0$ endpoint of the robust-value dual objective indexed by temperature $\alpha$ — shows the dual recovers the worst-case (essential infimum) value as the robustness/entropic-regularization parameter vanishes, i.e. the entropic-DRO dual interpolates between the nominal expectation ($\alpha\to\infty$) and worst-case/robust value ($\alpha\to0$).
