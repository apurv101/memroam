---
id: 01a050d2-2c07-7997-aa7c-b0a062e8a594
name: result-chi2-ball-tv-bound
description: "Paper 2309.02236: solved bound on max_s |inf_{chi2<=rho} E_p[V] under P_fhat_n(s,hpi_n(s)) - inf_{chi2<=rho} E_p[V] under P_f(s,hpi_n(s))| in terms of TV distance between the two nominal models"
metadata:
  type: project
---

Subtask: for any $V:\mathcal S\to[0,1/(1-\gamma)]$, $c_2(\rho)=\sqrt{1+2\rho}$, $M=1/(1-\gamma)$, bound
$$\max_{s}\Big|\inf_{\chi^2(p\|P_{\hat f_n}(s,\hat\pi_n(s)))\le\rho}\mathbb E_{p}[V]-\inf_{\chi^2(p\|P_f(s,\hat\pi_n(s)))\le\rho}\mathbb E_p[V]\Big|$$

**Solved result:**
$$\le c_2(\rho)\,M\,\max_{s}\sqrt{\mathrm{TV}\big(P_{\hat f_n}(s,\hat\pi_n(s)),\,P_f(s,\hat\pi_n(s))\big)}$$
equivalently $\frac{\sqrt{1+2\rho}}{1-\gamma}\max_s\sqrt{\mathrm{TV}(P_{\hat f_n},P_f)}$. This is $\le c_2(\rho)M$ (consistent since $V\in[0,M]$) and $\to0$ as $P_{\hat f_n}\to P_f$.

**Proof sketch:**
1. Dual form of the chi-square-constrained infimum (Lemma 13 of the paper, with $H=-V$, $k=k_*=2$, $\eta\to-\eta$): $\inf_{\chi^2(p\|P_0)\le\rho}\mathbb E_p[V]=\sup_{\eta\in\mathbb R}\{\eta-c_2(\rho)\sqrt{\mathbb E_{P_0}[(\eta-V)_+^2]}\}$.
2. $|\sup_\eta g_1-\sup_\eta g_2|\le\sup_\eta|g_1(\eta)-g_2(\eta)|$ reduces the target to $c_2(\rho)\sup_\eta\big|\sqrt{\mathbb E_{P_1}[(\eta-V)_+^2]}-\sqrt{\mathbb E_{P_2}[(\eta-V)_+^2]}\big|$.
3. **Key step — do NOT use naive Cauchy-Schwarz** (bounding via $\sqrt{\chi^2(P_1\|P_2)}\cdot\|\cdot\|$ type argument): it diverges as $\eta\to\infty$ since $(\eta-V)_+^2$ is unbounded in $\eta$. Instead use a maximal-coupling/Minkowski argument: since $x\mapsto(\eta-x)_+$ is 1-Lipschitz for every fixed $\eta$, coupling $P_1,P_2$ maximally (optimal TV coupling) gives a bound **uniform in $\eta$**: $M\sqrt{\mathrm{TV}(P_1,P_2)}$ (using $V,\eta\in[0,M]$ effectively, or more precisely that $(\eta-V)_+$ is bounded by $M$ on the relevant range).

This is the exact chi-square analogue of [[result-softmin-kl-ball-sample-complexity-bound]] (same overall proof shape — dual form, sup-difference inequality, then bound the inner gap — but chi-square's dual is a $\sup_\eta$ of a *soft-hinge* expression rather than KL's softmin/log-exp dual, and the inner gap is closed via TV/maximal-coupling+Lipschitz rather than the log-ratio/Gaussian-MGF route used for KL). Likely feeds into the same term-(i)-type nominal-dynamics estimation-error bound as [[result-robust-value-function-estimation-error-bound]], but for the chi-square-divergence robust MDP formulation instead of KL.

**Methodological note (reusable):** when bounding $|\sup_\eta g_1(\eta)-\sup_\eta g_2(\eta)|$ where $g_i(\eta)=\eta-c\sqrt{\mathbb E_{P_i}[\phi(\eta-V)]}$ for some fixed Lipschitz-in-$V$ $\phi$ (e.g. $\phi=(\cdot)_+^2$), prefer a maximal-coupling/Lipschitz argument over Cauchy-Schwarz/$\chi^2$-based bounds — the latter tend to blow up as $\eta$ ranges over $\mathbb R$ while the coupling argument stays uniform in $\eta$.
