---
id: 01a050d6-968c-7b47-afc5-6dc97269fc62
name: gd-convex-smooth-tradeoff-bound
description: Proved bound for convex beta-smooth risk under GD with eta<=1/beta: (||w_t-u||^2)/(2 eta t) + Risk(w_t) <= Risk(u) + ||w_0-u||^2/(2 eta t), all u.
metadata:
  type: project
---

Solved in this session (2502.13283_part_2). Same statement and proof already exist in `2502.13283_part_1/gd-convex-smooth-tradeoff-bound.md` — this appears to be a shared/recurring subtask across the two parts of the same paper's working sessions (project 2502.13283).

**Result.** For every $\uB$ and every $t\ge 1$, with GD step $\wB_{s+1}=\wB_s-\eta\grad\eRisk(\wB_s)$, $\eRisk$ convex and $\beta$-smooth, $\eta\le 1/\beta$:
$$
\frac{\|\wB_t-\uB\|^2}{2\eta t} + \eRisk(\wB_t) \;\le\; \eRisk(\uB) + \frac{\|\wB_0-\uB\|^2}{2\eta t}.
$$

**Proof sketch.**
1. Descent lemma ($\eta\le1/\beta$) $\Rightarrow$ $\eta^2\|\grad\eRisk(\wB_s)\|^2 \le 2\eta(\eRisk(\wB_s)-\eRisk(\wB_{s+1}))$, and $\eRisk(\wB_s)$ is non-increasing in $s$.
2. Expand $\|\wB_{s+1}-\uB\|^2$, use convexity ($\la\grad\eRisk(\wB_s),\wB_s-\uB\ra\ge \eRisk(\wB_s)-\eRisk(\uB)$) plus step 1 to get one-step contraction:
$$\|\wB_s-\uB\|^2-\|\wB_{s+1}-\uB\|^2 \ge 2\eta(\eRisk(\wB_{s+1})-\eRisk(\uB)).$$
3. Use monotonicity to replace $\eRisk(\wB_{s+1})$ by $\eRisk(\wB_t)$ for all $s+1\le t$, then telescope $s=0,\dots,t-1$ and divide by $2\eta t$.

**Downstream relevance (from part_1 notes):** this one-step contraction inequality is the key tool for bounding $\|\wB_t-\uB\|$ for a chosen comparator $\uB$ (e.g. a truncated optimum $\wB^*_{0:k}$) — see part_1's `wt-to-truncated-optimum-distance-bound-UNSOLVED` and `excess-risk-bound-at-stopping-time` for how it's applied (and where the application was left unverified). Worth checking if part_2 hits the same downstream subtask.
