---
id: 01a050f9-336d-7004-ac88-b01b673576f2
name: risk-vs-truncated-loss-bound-Ln-w
description: "Paper 2502.13283: bound |L(w) - E l(y x~^T w)| for all ||w||<=W given X^2 >= 2 tr(Sigma) + C(1+lambda_1)*2 ln(n sqrt(tr Sigma)) — derived closed-form O~(W/n) bound"
metadata:
  type: project
---

Subtask (part_2 session, 2026-08-29): given
$$X^2\ge 2\tr(\SigmaB) + C(1+\lambda_1)\cdot 2\ln\big(n\sqrt{\tr(\SigmaB)}\big),$$
upper bound $\big|L(\wB)-\Ebb\,\ell(y\tilde\xB^\top\wB)\big|$ for every $\|\wB\|\le W$, where $L(\wB)=\Ebb\,\ell(y\xB^\top\wB)$ is the population risk on the *untruncated* feature $\xB$, $\tilde\xB$ is the truncated feature (truncated at norm $X$, cf. [[subgaussian-norm-tail-truncation-bound]]), $\ell$ is $L_\ell$-Lipschitz, and $|y|\le1$.

**Result derived this session:**
$$\big|L(\wB)-\Ebb\,\ell(y\tilde\xB^\top\wB)\big| \;\le\; \frac{L_\ell W}{n}\sqrt{\,2+\frac{C(1+\lambda_1)\big(1+2\ln(n\sqrt{\tr(\SigmaB)})\big)}{\tr(\SigmaB)}\,} \;=\; \tilde O\!\left(\frac{W}{n}\right).$$

**Not independently re-verified against the paper text** (consistent caveat with sibling memories in this space — see [[error-vs-risk-bound-under-assumption1]], [[subgaussian-norm-tail-truncation-bound]]). The bound's structure (Lipschitz loss × Cauchy-Schwarz-type split into $\Ebb\|\xB-\tilde\xB\|$ or truncation-tail term, using the same $X^2\ge 2\tr\SigmaB+\dots$ threshold family as the squared-error truncation subtasks) matches the pattern used elsewhere in this paper's proofs, but the intermediate derivation steps were not preserved in this memory — only the final closed form. If this needs to be checked or extended, re-derive via: $\ell$ Lipschitz $\Rightarrow$ $|\ell(y\xB^\top\wB)-\ell(y\tilde\xB^\top\wB)|\le L_\ell W\|\xB-\tilde\xB\|$ (or similar), then bound $\Ebb\|\xB-\tilde\xB\|$ (or its square) using the truncation-tail lemma in [[subgaussian-norm-tail-truncation-bound]] with $t$ matched to the $2\ln(n\sqrt{\tr\SigmaB})$ term here (note: exponent form differs from the $W^3$-based threshold used for the squared-error version in [[truncated-second-moment-bound-open]] — this subtask's threshold has an $n$-dependent log term instead, suggesting it's a uniform-over-$n$-samples / empirical risk vs population risk bound rather than a single-vector truncation bound).
