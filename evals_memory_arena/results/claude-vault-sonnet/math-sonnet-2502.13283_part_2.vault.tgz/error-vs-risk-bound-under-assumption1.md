---
id: 01a050e2-6db0-76d1-aaa5-3e9724e323b8
name: error-vs-risk-bound-under-assumption1
description: "Paper 2502.13283: bound error(w)-min error via risk(w)-min risk = ||w-w*||_Sigma^2, and lower-bound min risk, min error given ||w*||_Sigma<~1 — NOT verified against paper, Assumption 1 reconstructed as well-specified linear/GLM model with square loss risk"
metadata:
  type: project
---

**Context:** subtask stated "Under Assumption 1, w* = argmin risk(.) and w* in argmin error(.)." Neither Assumption 1's exact statement, nor precise definitions of $\error(\cdot)$ (a 0–1/classification-type error, distinct from the square-loss $\risk(\cdot)$ used elsewhere in this project — see [[gd-convex-smooth-tradeoff-bound]], [[excess-risk-bound-at-stopping-time]] in part_1) nor the $\SigmaB$-norm were available in memory or supplied in-session. I reconstructed Assumption 1 as the well-specified linear/GLM model $\Ebb[y\mid\xB]=\wB^{*\top}\xB$, with $\risk$ = population square loss and $\error$ = 0–1 classification error (presumably $y\in\{\pm1\}$, prediction $\sign(\wB^\top\xB)$). **This is a guess, not confirmed against the paper — verify next session if this subtask resurfaces or is built upon.**

**Result given (unverified against source):**

Part (1): for every $\wB\in\Hbb$,
$$\error(\wB)-\min\error \;\le\; \sqrt{\risk(\wB)-\min\risk} \;=\; \|\wB-\wB^*\|_\SigmaB.$$

Part (2): with $\|\wB^*\|_\SigmaB\le c_0\lesssim1$ ($c_0<1$),
$$\min\risk\ge 1-c_0^2\gtrsim1,\qquad \min\error\ge\frac{1-c_0}{2}\gtrsim1.$$

Both derived from the exact identity $\risk(\wB)-\min\risk=\|\wB-\wB^*\|_\SigmaB^2$ (bias-variance decomposition under the assumed well-specified model) plus a sign-mismatch argument for $\error$ and Cauchy–Schwarz.

**Flag for next session:** if this project (2502.13283, part_2) continues to use $\error(\cdot)$/$\SigmaB$-norm notation, try to pin down the paper's actual Assumption 1 and precise definitions of $\risk$, $\error$, $\SigmaB$-norm before reusing this result — it was produced without access to those definitions.
