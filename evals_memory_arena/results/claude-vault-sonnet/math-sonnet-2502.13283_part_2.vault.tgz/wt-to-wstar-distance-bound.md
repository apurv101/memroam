---
id: 01a05100-c6ae-7f36-ba4c-651a789526c1
name: wt-to-wstar-distance-bound
description: Solved (this session) the previously-open subtask of bounding ||w_t-w*|| under GD, eta<=1/beta, when eRisk(w*)<=eRisk(w_{t-1}) — resolves part_1's wt-to-truncated-optimum-distance-bound-UNSOLVED
metadata:
  type: project
---

**Setting:** $\beta:=C_0(1+\tr(\SigmaB)+\lambda_1\ln(1/\delta)/n)$, $\eta\le1/\beta$, $t$ such that $\eRisk(\wB^*)\le\eRisk(\wB_{t-1})$.

**Result (w.p. $\ge1-\delta$):**
$$\|\wB_t-\wB^*\|\;\le\;2\|\wB_0-\wB^*\|+\eta\|\grad\eRisk(\wB^*)\|.$$
(If $\wB_0=\mathbf0$: $\|\wB_t-\wB^*\|\le2\|\wB^*\|+\eta\|\grad\eRisk(\wB^*)\|$.)

**Proof sketch** (uses the one-step contraction inequality from [[gd-convex-smooth-tradeoff-bound]] with comparator $\uB=\wB^*$):
1. GD is monotone-decreasing in $\eRisk$ under $\eta\le1/\beta$, so the hypothesis $\eRisk(\wB^*)\le\eRisk(\wB_{t-1})$ propagates: $\eRisk(\wB_s)\ge\eRisk(\wB^*)$ for all $s\le t-1$.
2. Contraction inequality $\Rightarrow$ RHS $\ge0$ for $s=0,\dots,t-2$ $\Rightarrow$ $\|\wB_s-\wB^*\|$ non-increasing up to $s=t-1$, giving $\|\wB_{t-1}-\wB^*\|\le\|\wB_0-\wB^*\|$.
3. The last step $t-1\to t$ isn't covered by monotonicity (this is the gap that was previously left open). Close it directly: triangle inequality + $\beta$-smoothness of $\grad\eRisk$ give $\|\wB_t-\wB^*\|\le\|\wB_{t-1}-\wB^*\|+\eta\|\grad\eRisk(\wB_{t-1})\|\le\|\wB_{t-1}-\wB^*\|+\eta(\|\grad\eRisk(\wB^*)\|+\beta\|\wB_{t-1}-\wB^*\|)$, and $\eta\beta\le1$ gives $\|\wB_t-\wB^*\|\le2\|\wB_{t-1}-\wB^*\|+\eta\|\grad\eRisk(\wB^*)\|$.
4. Combine 2+3.

**Resolves:** part_1's `wt-to-truncated-optimum-distance-bound-UNSOLVED` and firms up the norm-control step ($\|\wB_t\|\le2\|\wB^*\|$-type claim) asserted but unverified in part_1's `excess-risk-bound-at-stopping-time`. Same argument, comparator here is the untruncated $\wB^*$ rather than $\wB^*_{0:k}$ — check next session whether the truncated-optimum version needs any extra step beyond substituting $\uB=\wB^*_{0:k}$.

**Open/left symbolic:** the additive term $\eta\|\grad\eRisk(\wB^*)\|$ was not bounded further (presumably $O(1/\sqrt n)$ via concentration of the empirical gradient at $\wB^*$) — worth resolving if a fully explicit rate is needed downstream.
