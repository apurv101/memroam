---
id: 01a050db-bc34-71d7-98c8-7439fdb84257
name: subgaussian-norm-tail-truncation-bound
description: Same subtask (bound E[xx^T 1{||x||>X}] given tail bound Pr(||x||>=X)<=exp(-t)) solved in part_1 — see 2502.13283_part_1/subgaussian-norm-tail-truncation-bound.md for full derivation.
metadata:
  type: project
---

Solved again in this session (2502.13283_part_2), confirming it's the same recurring subtask as part_1. Result: with $t\ge 2\ln(4C_1(1+\lambda_1^{3/2}W^3))$,
$$\Ebb[\xB\xB^\top\ind{\|\xB\|>X}] \prec \frac{1}{C_1}I_d \quad\text{(strict PSD order)}.$$

Full layer-cake proof sketch and open notational caveats (what exactly $W$ is, and whether $2\tr(\SigmaB)+C(1+\lambda_1)(t+1)=O(\lambda_1^{3/2}W^3)$ is verified) are in `2502.13283_part_1/subgaussian-norm-tail-truncation-bound.md` — don't re-derive, just reuse that.

See also [[gd-convex-smooth-tradeoff-bound]] for another subtask duplicated verbatim across part_1 and part_2 of this same paper's sessions — reinforces that part_1 and part_2 memory spaces should both be checked for any subtask on this paper (2502.13283).
