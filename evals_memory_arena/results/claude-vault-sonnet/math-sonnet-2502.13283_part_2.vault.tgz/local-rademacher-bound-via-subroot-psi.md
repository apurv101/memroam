---
id: 01a050e9-93f3-7baa-91b2-1ef6cfeb2c54
name: local-rademacher-bound-via-subroot-psi
description: "Paper 2502.13283: bound E rad_n{f in F: L^2 E(f(x~)-f*(x~))^2 <= r} <= psi(r)/(BL), trivial rearrangement of sub-root psi's defining property from Lemma B.4 — NOT verified against paper, F left abstract"
metadata:
  type: project
---

Subtask: Upper bound $\mathbb E\,\mathrm{rad}_n\{f\in\mathcal F: L^2\,\mathbb E(f(\tilde x)-f^*(\tilde x))^2\le r\}$.

Solution given (this session, part_2): this isn't a derivation — $\psi$ is *defined* (background "Lemma B.4") as a sub-root function satisfying
$$\psi(r)\ge BL\,\mathbb E\,\mathrm{rad}_n\{f\in\mathcal F: L^2\,\mathbb E(f(\tilde x)-f^*(\tilde x))^2\le r\}$$
so dividing by $BL$ ($B\ge1$, $L>0$) gives the bound $\psi(r)/(BL)$ directly. Flagged this feeds into the Talagrand-concentration/localization step producing final excess-risk bound $705\,r/B + (11L+27B)\ln(1/\delta)/n$.

**Why worth recording:** $\mathcal F$ was left abstract in this subtask (no covering number / VC dimension given), so no sharper bound is possible generically. Flagged to the user that if $\mathcal F$ is later instantiated as the linear/GLM class from Part 1 (weights $\|\wB\|\le W$, $\Sigma=\mathbb E[\tilde x\tilde x^\top]$, cf. [[error-vs-risk-bound-under-assumption1]]), a concrete sub-root $\psi(r)=c\,L\sqrt{r\,\mathrm{tr}(\Sigma)/n}$-type bound would be the natural next step — user has not yet confirmed this is wanted.

**How to apply:** If a future session in this project asks to instantiate $\psi(r)$ concretely for the linear/GLM class, build it from $\mathrm{tr}(\Sigma)$-based Rademacher complexity of the norm ball rather than re-deriving the abstract inequality above.
