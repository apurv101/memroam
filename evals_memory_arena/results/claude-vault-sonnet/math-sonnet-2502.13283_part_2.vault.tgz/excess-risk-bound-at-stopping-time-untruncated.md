---
id: 01a05106-3006-7549-8162-da25d81f5ba9
name: excess-risk-bound-at-stopping-time-untruncated
description: "Paper 2502.13283: final excess population risk bound risk(w_t)-min risk at GD stopping time eRisk(w_t)<=eRisk(w*)<=eRisk(w_{t-1}), untruncated w* (||w*||<infty), assuming ||w*||>~1, lambda_1<~1, tr(Sigma)>~1 — w.p. >=1-delta bound is O(||w*||sqrt(tr(Sigma)/n) + sqrt(ln(1/delta)/n))"
metadata:
  type: project
---

**Setting:** Same as [[wt-to-wstar-distance-bound]] (GD, $\eta$ as in thm:gd:upper-bound, stopping time $t$ with $\eRisk(\wB_t)\le\eRisk(\wB^*)\le\eRisk(\wB_{t-1})$), but here $\wB^*$ is the *untruncated* optimum ($\|\wB^*\|<\infty$, arbitrary index $k$), with simplifying scale assumptions $\|\wB^*\|\gtrsim1$, $\lambda_1\lesssim1$, $\tr(\SigmaB)\gtrsim1$.

**Result (w.p. $\ge1-\delta$):**
$$\risk(\wB_t)-\min\risk \;\le\; C\left(\|\wB^*\|\sqrt{\frac{\tr(\SigmaB)}{n}}+\sqrt{\frac{\ln(1/\delta)}{n}}\right).$$

**Relation to other memories:** this is the untruncated-$\wB^*$ counterpart of part_1's `excess-risk-bound-at-stopping-time` (which used $\wB^*_{0:k}$ and had leftover term $2C_1(2L_\ell\|\wB^*_{0:k}\|\sqrt{\tr(\SigmaB)/n}+\sqrt{\ln(1/\delta)/n})$ plus $\risk(\wB^*_{0:k})-\min\risk$). Here $\wB^*_{0:k}=\wB^*$ effectively (no truncation bias term), and the scale assumptions ($\|\wB^*\|\gtrsim1$, $\lambda_1\lesssim1$, $\tr(\SigmaB)\gtrsim1$) let the constants absorb lower-order terms, collapsing to the single clean rate above. Built on [[wt-to-wstar-distance-bound]] and [[gd-convex-smooth-tradeoff-bound]].

**Caveat:** derived without being able to re-verify exact constants against the paper's thm:gd:upper-bound statement in this session; treat $C$ as an unspecified absolute constant. If a later session needs the precise constant or the non-simplified (no $\gtrsim1$ assumptions) form, redo using the leftover open item in [[wt-to-wstar-distance-bound]] (bounding $\eta\|\grad\eRisk(\wB^*)\|$ explicitly, presumably $O(1/\sqrt n)$).
