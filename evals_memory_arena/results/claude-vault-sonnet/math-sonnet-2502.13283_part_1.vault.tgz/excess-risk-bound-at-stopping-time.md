---
id: 01a050d5-9aaf-7d1c-87d2-65715d18c4b9
name: excess-risk-bound-at-stopping-time
description: Final excess population risk bound at GD stopping time t (eRisk(w_t)<=eRisk(w*_0:k)<=eRisk(w_{t-1})): risk(w_t)-min risk <= (risk(w*_0:k)-min risk) + 2C_1(2L_ell||w*_0:k||sqrt(tr(Sigma)/n)+sqrt(ln(1/delta)/n)).
metadata:
  type: project
---

**Setting:** Assumption 1 holds, $\eta \le 1/(C_0(1+\tr(\SigmaB)+\lambda_1\ln(1/\delta)/n))$ with $C_0>1$ universal. Given (as hypothesis of this subtask, not re-derived here): w.p. $\ge1-\delta$ there is a stopping time $t$ with $\eRisk(\wB_t)\le\eRisk(\wB^*_{0:k})\le\eRisk(\wB_{t-1})$.

**Task:** bound $\risk(\wB_t)-\min\risk$.

**Result:**
$$\risk(\wB_t)-\min\risk \;\le\; \big(\risk(\wB^*_{0:k})-\min\risk\big) + 2C_1\Big(2L_\ell\|\wB^*_{0:k}\|\sqrt{\tr(\SigmaB)/n}+\sqrt{\ln(1/\delta)/n}\Big).$$

**Proof sketch:**
1. Norm control: $\|\wB_t\|\le 2\|\wB^*_{0:k}\|$ — argued via the one-step contraction inequality from [[gd-convex-smooth-tradeoff-bound]] with comparator $\uB=\wB^*_{0:k}$, using that $\eRisk(\wB_s)$ stays $\ge\eRisk(\wB^*_{0:k})$ for $s<t$ so distance to $\wB^*_{0:k}$ doesn't grow, plus an $O(\eta)$ correction on the last step. **Caveat: this step was asserted, not rigorously re-derived in this session** — it's the same open question as [[wt-to-truncated-optimum-distance-bound-UNSOLVED]] (bounding $\|\wB_t-\wB^*_{0:k}\|$); treat as unverified until that memory's open items are resolved.
2. Since $\eRisk(\wB_t)\le\eRisk(\wB^*_{0:k})$, excess population risk splits as two generalization gaps (at $\wB_t$, at $\wB^*_{0:k}$) plus the deterministic bias $\risk(\wB^*_{0:k})-\min\risk$.
3. Generalization gaps bounded via [[uniform-convergence-risk-vs-empirical-risk-bound]] at radius $W=2\|\wB^*_{0:k}\|$.

**Left open / not addressed:** the bias term $\risk(\wB^*_{0:k})-\min\risk$ (cost of truncating to first $k$ components/eigendirections) is left symbolic — bounding it via tail eigenvalues $\lambda_{k+1},\lambda_{k+2},\dots$ is flagged as a natural next subtask.

**Process note:** this session's solution opened with a claim that "memory writes are being denied by permissions" — that was a false/stale statement from within the session transcript; the vault tools work fine and this memory is proof. Disregard that line if it resurfaces.
