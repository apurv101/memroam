---
id: 01a050ca-3a8a-7483-b1b6-95f67e5776c3
name: smoothness-upper-bound-risk-vs-optimum
description: Proved beta-smoothness upper bound Risk(w) <= Risk(w*) + (beta/2)||w-w*||^2 for all w, w*=argmin Risk; complements the convexity lower bound Risk(w)>=Risk(w*).
metadata:
  type: project
---

**Setting:** $\eRisk(\cdot)$ is $\beta$-smooth (not necessarily assumed convex for this direction). $\wB^*\in\arg\min\eRisk(\wB)$.

**Result (proved this session):** for every $\wB$,
$$\eRisk(\wB) \;\le\; \eRisk(\wB^*) + \frac{\beta}{2}\|\wB-\wB^*\|^2.$$

**Proof sketch:** descent lemma / quadratic upper bound from $\beta$-smoothness applied at $\wB^*$:
$$\eRisk(\wB) \le \eRisk(\wB^*) + \la\grad\eRisk(\wB^*),\wB-\wB^*\ra + \frac{\beta}{2}\|\wB-\wB^*\|^2,$$
and first-order optimality $\grad\eRisk(\wB^*)=\mathbf 0$ kills the linear term. Tight at $\wB=\wB^*$.

**Why this matters downstream:** natural complement to the convexity lower bound $\eRisk(\wB)\ge\eRisk(\wB^*)$ (used implicitly in [[gd-convex-smooth-tradeoff-bound]]); together they sandwich $\eRisk(\wB)-\eRisk(\wB^*)$ between $0$ and $\frac{\beta}{2}\|\wB-\wB^*\|^2$, useful for converting distance-to-optimum bounds into risk-gap bounds later in this project.

**Note on this session:** the vault write attempt initially failed (permission not granted) and the answer was delivered without persisting; retried successfully in the follow-up.
