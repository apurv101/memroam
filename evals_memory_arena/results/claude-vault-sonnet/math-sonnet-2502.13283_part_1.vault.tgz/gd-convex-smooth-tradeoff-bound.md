---
id: 01a050b1-3906-78d0-be5a-5ffcfa6175b7
name: gd-convex-smooth-tradeoff-bound
description: Proved bound for convex beta-smooth risk under GD with eta<=1/beta: (||w_t-u||^2)/(2 eta t) + Risk(w_t) <= Risk(u) + ||w_0-u||^2/(2 eta t), all u.
metadata:
  type: project
---

**Setting:** $\eRisk(\cdot)$ convex and $\beta$-smooth; GD iterates $\wB_{s+1} = \wB_s - \eta \grad\eRisk(\wB_s)$ with $\eta \le 1/\beta$.

**Result (proved this session):** for every $\uB$ and $t \ge 1$,
$$\frac{\|\wB_t - \uB\|^2}{2\eta t} + \eRisk(\wB_t) \;\le\; \eRisk(\uB) + \frac{\|\wB_0 - \uB\|^2}{2\eta t}.$$

**Proof sketch:**
1. Descent lemma ($\beta$-smoothness + $\eta\le1/\beta$) $\Rightarrow$ $\eRisk(\wB_s)$ non-increasing, and $\eta^2\|\grad\eRisk(\wB_s)\|^2 \le 2\eta(\eRisk(\wB_s)-\eRisk(\wB_{s+1}))$.
2. Expand $\|\wB_{s+1}-\uB\|^2$, use convexity ($\la\grad\eRisk(\wB_s),\wB_s-\uB\ra \ge \eRisk(\wB_s)-\eRisk(\uB)$) + step 1 $\Rightarrow$ one-step contraction $\|\wB_s-\uB\|^2 - \|\wB_{s+1}-\uB\|^2 \ge 2\eta(\eRisk(\wB_{s+1})-\eRisk(\uB))$.
3. Telescope $s=0,\dots,t-1$; monotonicity of $\eRisk(\wB_s)$ lets each RHS term be replaced by $2\eta(\eRisk(\wB_t)-\eRisk(\uB))$; rearrange and divide by $2\eta t$.

**Why this matters downstream:** holds for *every* $\uB$ (e.g. $\uB=\wB^*$ or a truncation $\wB^*_{0:k}$), so minimizing the RHS over $\uB$ trades off approximation error $\eRisk(\uB)$ against the initialization term $\|\wB_0-\uB\|^2/(2\eta t)$ — this is the standard mechanism used to get fast-rate / adaptive bounds in later steps of this project.

**Notation:** $\eRisk$ = risk/objective functional, $\wB_t$ = GD iterate at step $t$ (bold w), $\uB$ = arbitrary comparator, $\Hbb$ = ambient (Hilbert) space.
