---
id: 01a050b6-9118-7704-a786-32915fa21555
name: subgaussian-norm-tail-truncation-bound
description: Derived E[xx^T 1{||x||>X}] <~ 1/C_1 I_d from the sub-Gaussian-type tail bound Pr(||x||>=X)<=exp(-t), given C_1>1 and t large enough; W confirmed to be a ||w||<=W norm bound (see later subtask).
metadata:
  type: project
---

**Setting:** Given constant $C>1$ such that for every $X^2 \ge 2\tr(\SigmaB) + C(1+\lambda_1)t$,
$$\Pr(\|\xB\|\ge X) \le \exp(-t), \quad t>1.$$

**Task solved this session:** for every $C_1>1$, with $t \ge 2\ln(4C_1(1+\lambda_1^{3/2}W^3))$, bound $\Ebb[\xB\xB^\top \ind{\|\xB\|>X}]$.

**Result / proof sketch:**
1. Layer-cake: $\Ebb[\|\xB\|^2\ind{\|\xB\|^2>a}] = a\Pr(\|\xB\|^2>a) + \int_a^\infty \Pr(\|\xB\|^2>s)\,ds$, with $a=X^2$ set at the threshold so $\Pr(\|\xB\|\ge X)\le e^{-t}$ exactly.
2. Integrating the exponential tail gives $\int_{X^2}^\infty \Pr(\|\xB\|^2\ge s)ds \le C(1+\lambda_1)e^{-t}$.
3. Combine: $\Ebb[\|\xB\|^2\ind{\|\xB\|>X}] \le \big(2\tr(\SigmaB)+C(1+\lambda_1)(t+1)\big)e^{-t}$.
4. Matrix version via $\xB\xB^\top \preceq \|\xB\|^2 I_d$: same bound times $I_d$.
5. Plug in $t\ge 2\ln(4C_1(1+\lambda_1^{3/2}W^3))$, so $e^{-t}\le 1/[16C_1^2(1+\lambda_1^{3/2}W^3)^2]$. The extra factor of $4$ (16 squared) is what buys strict (not just $\le$) inequality once the numerator is absorbed.
6. **Final boxed answer (conditional on norm-equivalence):** if $W$ is defined elsewhere in the source paper so that $2\tr(\SigmaB)+C(1+\lambda_1)(t+1) = O(\lambda_1^{3/2}W^3)$ (i.e. $W$ controls growth of $\tr\SigmaB$ and $\lambda_1 t$), the bound collapses to
$$\Ebb[\xB\xB^\top\ind{\|\xB\|>X}] \prec \frac{1}{C_1}I_d.$$

**Partial resolution (from a later subtask in this session):** a subsequent subtask states "for every $\wB$ such that $\|\wB\|\le W$" — so $W$ is indeed a norm bound on the weight vector $\wB$, not an effective-dimension/paper-specific width parameter. This confirms the reading in point 6 is plausible but the precise relation $2\tr(\SigmaB)+C(1+\lambda_1)(t+1)=O(\lambda_1^{3/2}W^3)$ is still not verified against the source text — still worth checking. See [[population-vs-truncated-risk-lipschitz-bound]] for the related follow-on result.

**Notation:** $\xB$ = random vector, $\SigmaB=\Ebb[\xB\xB^\top]$ presumably, $\lambda_1$ = top eigenvalue of $\SigmaB$, $\tr(\SigmaB)$ = trace, $C,C_1$ = universal constants, $W$ = undefined width/scale parameter (see gap above).
