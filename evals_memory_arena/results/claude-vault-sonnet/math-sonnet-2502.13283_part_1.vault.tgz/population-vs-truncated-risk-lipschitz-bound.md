---
id: 01a050bd-698b-7c88-bd9b-4f42c441f4eb
name: population-vs-truncated-risk-lipschitz-bound
description: Bound on |L(w) - E[loss on truncated x]| for ||w||<=W using Lipschitz loss and the tail bound from subgaussian-norm-tail-truncation-bound; flags unresolved ambiguity about whether L(w) is population or empirical risk.
metadata:
  type: project
---

**Setting:** Continues directly from [[subgaussian-norm-tail-truncation-bound]]. Given $X^2 \ge 2\tr(\SigmaB) + C(1+\lambda_1)\cdot 2\ln(n\sqrt{\tr(\SigmaB)})$ (i.e. $t = 2\ln(n\sqrt{\tr(\SigmaB)})$), and $\tilde\xB = \xB\ind{\|\xB\|\le X}$ (truncated feature).

**Task solved this session:** for every $\wB$ with $\|\wB\|\le W$, bound $|L(\wB) - \Ebb\,\ell(y\tilde\xB^\top\wB)|$.

**Result (assuming $L(\wB)$ = population risk on untruncated $\xB$, $\ell$ is $L_\ell$-Lipschitz, $|y|\le 1$):**
$$\big|L(\wB)-\Ebb\,\ell(y\tilde\xB^\top\wB)\big| \le \frac{L_\ell W}{n}\sqrt{2+\frac{C(1+\lambda_1)\big(1+2\ln(n\sqrt{\tr(\SigmaB)})\big)}{\tr(\SigmaB)}} = \tilde O(W/n).$$

Derivation idea: Lipschitz loss difference $\le L_\ell |y| \cdot |(\xB-\tilde\xB)^\top\wB| \le L_\ell W\|\xB-\tilde\xB\|$ on the event $\|\xB\|>X$ (else zero), then Cauchy-Schwarz / Jensen using $\Ebb[\|\xB\|^2\ind{\|\xB\|>X}]$ from the tail-truncation bound, plugging in $t=2\ln(n\sqrt{\tr\SigmaB})$ so $e^{-t}=1/(n^2\tr\SigmaB)$, producing the explicit $1/n$ rate.

**Resolved:** a later subtask uses distinct symbols $\risk(\wB)$ (population) and $\eRisk(\wB)$ (empirical) and asks to bound $\sup_{\|\wB\|\le W}|\risk(\wB)-\eRisk(\wB)|$ directly via a Rademacher/McDiarmid uniform-convergence argument — confirming $L(\wB)$ above was indeed intended as population risk. See [[uniform-convergence-risk-vs-empirical-risk-bound]] for that result.
