---
id: 01a050ce-3fdd-7466-901d-a4441434da4a
name: uniform-convergence-risk-vs-empirical-risk-bound
description: Final uniform convergence bound sup_{||w||<=W}|risk(w)-eRisk(w)| <= C1(L_ell W sqrt(tr(Sigma)/n) + sqrt(ln(1/delta)/n)) w.p. 1-delta, via truncation + Rademacher/McDiarmid.
metadata:
  type: project
---

**Setting:** Continues from [[subgaussian-norm-tail-truncation-bound]] and [[population-vs-truncated-risk-lipschitz-bound]]. $\risk(\wB)$ = population risk, $\eRisk(\wB)$ = empirical risk over $n$ samples, $\ell$ is $L_\ell$-Lipschitz, $|y|\le1$, $\SigmaB=\Ebb[\xB\xB^\top]$.

**Task solved this session:** for $C_1>1$ sufficiently large, bound $\sup_{\|\wB\|\le W}|\risk(\wB)-\eRisk(\wB)|$ w.p. $\ge 1-\delta$.

**Result:**
$$\sup_{\|\wB\|\le W}\big|\risk(\wB)-\eRisk(\wB)\big| \le C_1\left(L_\ell W\sqrt{\frac{\tr(\SigmaB)}{n}}+\sqrt{\frac{\ln(1/\delta)}{n}}\right).$$

**Proof idea:** truncate $\xB$ at threshold $X$ chosen via $t=\ln(2n/\delta)$ in the sub-Gaussian tail bound from [[subgaussian-norm-tail-truncation-bound]], so that: (i) empirical truncation error vanishes w.p. $\ge1-\delta/2$; (ii) the deterministic population truncation gap (from [[population-vs-truncated-risk-lipschitz-bound]]-style argument) is lower order; (iii) the resulting bounded truncated loss class admits a standard Rademacher-complexity/McDiarmid uniform-convergence bound with $\Rad_n \le L_\ell W\sqrt{\tr(\SigmaB)/n}$.

**Resolves prior ambiguity:** confirms the flag in [[population-vs-truncated-risk-lipschitz-bound]] — the paper does distinguish population risk $\risk(\wB)$ from empirical risk $\eRisk(\wB)$ as separate symbols; this subtask is the uniform-convergence (generalization gap) result tying the two together, not a restatement of the earlier truncation-only bound.
