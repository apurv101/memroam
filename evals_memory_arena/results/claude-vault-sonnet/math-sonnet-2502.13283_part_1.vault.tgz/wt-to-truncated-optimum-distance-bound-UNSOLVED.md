---
id: 01a050c4-0da1-7ed4-9ee7-c35d728a0690
name: wt-to-truncated-optimum-distance-bound-UNSOLVED
description: Subtask asking to bound ||w_t - w*_0:k|| under eta<=1/beta (beta involving tr(Sigma), lambda_1 ln(1/delta)/n) was NOT actually solved in that session — no derivation was given, only a placeholder reply. Redo from scratch.
metadata:
  type: project
---

**Subtask (verbatim setup):** $\beta := C_0(1+\tr(\SigmaB)+\lambda_1\ln(1/\delta)/n)$ for a sufficiently large constant $C_0>1$. Assume $\eta \le 1/\beta$ and $t$ is such that $\eRisk(\wB^*_{0:k}) \le \eRisk(\wB_{t-1})$. With probability $\ge 1-\delta$, upper bound $\|\wB_t - \wB^*_{0:k}\|$.

**Status: unsolved.** The assistant's recorded "solution" for this subtask was not a derivation at all — it just asked whether to save/verify, with no bound produced. Do not treat this subtask as complete; re-derive it.

**Likely approach (not verified, just a starting hypothesis for next session):** This looks like a direct application of the one-step contraction inequality from [[gd-convex-smooth-tradeoff-bound]] (proved earlier in the same project) with comparator $\uB = \wB^*_{0:k}$:
$$\|\wB_{s}-\uB\|^2 - \|\wB_{s+1}-\uB\|^2 \ge 2\eta(\eRisk(\wB_{s+1})-\eRisk(\uB)).$$
Applying at $s=t-1$ with $\eRisk(\wB_{t-1}) \ge \eRisk(\wB^*_{0:k})$ (the given hypothesis) does NOT immediately give a nonnegative RHS since the inequality needs $\eRisk(\wB_t)$, not $\eRisk(\wB_{t-1})$, compared to $\eRisk(\uB)$ — this gap needs to be checked (monotonicity of $\eRisk(\wB_s)$ from the descent lemma may bridge $\wB_{t-1}\to\wB_t$, or the argument may instead be a stopping-time / induction argument that concludes $\|\wB_t-\wB^*_{0:k}\|\le\|\wB_0-\wB^*_{0:k}\|$ by never letting risk cross below $\eRisk(\wB^*_{0:k})$ for steps $<t$). Also need to fold in the "$1-\delta$" probability — $\beta$'s definition already bakes in a $\lambda_1\ln(1/\delta)/n$ term, so $\beta$ itself is presumably a high-probability smoothness constant (established elsewhere in the source paper, not yet located in this vault) rather than something requiring a fresh concentration argument here.

**Open items for next session:**
1. Confirm/derive how the per-step condition $\eRisk(\wB^*_{0:k})\le\eRisk(\wB_{t-1})$ connects to the contraction inequality to get a clean bound (candidate answer: $\|\wB_t-\wB^*_{0:k}\| \le \|\wB_0-\wB^*_{0:k}\|$).
2. Find where in the source paper $\beta$ (as defined here, with the $\lambda_1\ln(1/\delta)/n$ term) is shown to be a valid $1-\delta$ high-probability smoothness/curvature bound — likely ties to [[subgaussian-norm-tail-truncation-bound]] and [[population-vs-truncated-risk-lipschitz-bound]].

**Update from later session:** [[excess-risk-bound-at-stopping-time]] needed (and asserted, without rigorous derivation) the related claim $\|\wB_t\|\le 2\|\wB^*_{0:k}\|$ using essentially this same contraction argument. Still unverified rigorously — resolving this memory's open items would also firm up that later result.
