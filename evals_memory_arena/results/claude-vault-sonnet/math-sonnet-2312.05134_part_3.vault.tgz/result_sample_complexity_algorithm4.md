---
id: 01a050d0-18a4-7f67-8ccb-582d2eb7bc6d
name: result-sample-complexity-algorithm4
description: "Paper 2312.05134 Algorithm 4: w.p. >= 1-delta/2, total sample complexity N = O(ln(k|L|)/eps^4 * [(k|L|+d)ln(k|L|d/eps) + ln(1/delta)]) — NOT verified against paper, derived from [[result-hfinal-bound-algorithm4]] by picking T=Theta(ln(k|L|)/eps^2) rounds times per-round budget T_1 for weighted uniform convergence"
metadata:
  type: project
---

Solved subtask: asymptotic upper bound (w.p. >= 1-delta/2) on total sample complexity of Algorithm 4 in paper 2312.05134.

**Answer:**
$$N = O\!\left(\frac{\ln(k|\mathcal L|)}{\varepsilon^4}\Big[(k|\mathcal L|+d)\,\ln\tfrac{k|\mathcal L| d}{\varepsilon}+\ln\tfrac1\delta\Big]\right)$$

Derivation: start from [[result-hfinal-bound-algorithm4]] (excess risk bound with eps/50 + sqrt(ln(k|L|)/(2T)) term). Take T = Theta(ln(k|L|)/eps^2) rounds so the sqrt term is O(eps). Multiply by per-round sample budget T_1 = O((k|L| ln(k|L|/eps) + d ln(k|L|d/eps) + ln(1/delta))/eps^2) needed for the weighted uniform-convergence step each round. N = T * T_1.

**Caveat (important, carried from [[result-hfinal-bound-algorithm4]]):** the underlying excess-risk bound was reconstructed by analogy to Algorithm 3, NOT verified against the actual paper text for Algorithm 4. Also flagged an alternative: if Algorithm 4 actually samples per-round only over [k] (not k|L|), the rate would instead be O(ln(k|L|)/eps^4 * [(k+d)ln(kd/eps) + ln(1/delta)]). Whoever picks this up next should verify against the paper which regime is correct before trusting the k|L| vs k distinction.

**SUPERSEDED:** confirmed wrong on the exact rate/parameters — the paper's real sample complexity is $(d+k\log R)\min\{\log R,k\}/\varepsilon^2\cdot\mathrm{poly}\log(k,d,1/\varepsilon,1/\delta,\log R)$ with rate $\varepsilon^{-2}$, not $\varepsilon^{-4}$, and no bare $k|\mathcal L|$ term. See [[result-hfinal-population-bound-verified]] for the verified version; use that one going forward.
