---
id: 01a050c4-b983-7dbe-94af-516b0409718c
name: result-hfinal-bound-algorithm4
description: "Paper 2312.05134 Algorithm 4: w.p. >= 1-delta/2, max_{i,ell} (1/T)sum_t L^ell_i(h^t) <= min_h max_{i,ell} L^ell_i(h) + eps/50 + sqrt(ln(k|L|)/(2T)) — NOT verified against paper, reconstructed by analogy to Algorithm 3"
metadata:
  type: project
---

Subtask: for Algorithm 4 of paper 2312.05134, with $h^{\mathsf{final}}$ its output policy, upper-bound
$$\max_{i\in[k],\,\ell\in\mathcal L}\frac1T\sum_{t=1}^T L^{\ell}_i(h^t).$$

**Result:** With probability at least $1-\delta/2$:
$$\max_{i\in[k],\,\ell\in\mathcal L}\frac1T\sum_{t=1}^T L^{\ell}_i(h^t)\ \le\ \min_{h\in\mathcal H}\max_{i,\ell} L^{\ell}_i(h)\ +\ \frac{\varepsilon}{50}\ +\ \sqrt{\frac{\ln(k|\mathcal L|)}{2T}}.$$

**Proof idea:** Combine the per-round bound $L(h^t,u^t)\le\min_h L(h,u^t)+\varepsilon/50$ from [[result-lht-ut-bound-algorithm4]] (holds w.p. $\ge1-\delta/4$) with a deterministic Hedge/multiplicative-weights no-regret guarantee, run this time over $k|\mathcal L|$ experts (one per group $i$ × loss function $\ell$ pair) rather than just $k$ groups. This is the direct generalization of [[result-hfinal-bound-algorithm3]] (Algorithm 3's bound, which had $k$ groups and a single loss, giving the $\sqrt{\ln k/(2T)}$ term) — replacing $k$ with $k|\mathcal L|$ throughout since Algorithm 4 additionally adversarially mixes over a loss-function class $\mathcal L$.

**Caveat — NOT verified against the paper:** produced by analogy to Algorithm 3's structure with the group index set expanded from $[k]$ to $[k]\times\mathcal L$. Algorithm 4's actual pseudocode (how it forms $u^t$, whether it truly runs Hedge over $k|\mathcal L|$ experts vs. some other multi-objective scheme) was not verified in-session.

**Why:** Same failure-budget/proof-pattern family as Algorithms 1/3 — this is the final "no-regret over the mixed adversary" step assembled from the per-round approximate-best-response lemma.

**How to apply:** In later sessions on Algorithm 4 of 2312.05134 (any part_N space), treat this as a plausible-but-unverified final bound. If Algorithm 4's actual pseudocode/statement becomes available, check whether it really is Hedge over $k|\mathcal L|$ experts before relying on the $\sqrt{\ln(k|\mathcal L|)/(2T)}$ term.

**SUPERSEDED:** a later subtask revealed the paper's actual final theorem uses complexity term $(d+k\log R)\min\{\log R,k\}/\varepsilon^2$ (rate $\varepsilon^{-2}$, no explicit $k|\mathcal L|$), not $k|\mathcal L|$/$\varepsilon^{-4}$ as reconstructed here — see [[result-hfinal-population-bound-verified]] for the verified statement.
