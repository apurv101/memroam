---
id: 01a050bc-2327-778f-beb9-490138824552
name: result-lht-wt-bound-round-t
description: "Paper 2312.05134 Algorithm 1: with prob >= 1-delta/4, L(h^t,w^t) <= min_h L(h,w^t) + eps/50 for all rounds t, via weighted-VC uniform convergence + optimality of h^t for empirical loss"
metadata:
  type: project
---

Subtask: bound $L(h^t,w^t)$ for all $1\le t\le T$ in Algorithm 1 of paper 2312.05134.

**Note:** This subtask and its solution are identical to one already solved in the `2312.05134_part_2` project space — see `2312.05134_part_2/result_Lht_wt_bound_round_t.md` for the full writeup. Duplicated here (in `2312.05134_part_3`) since that is a different vault space.

**Result:** With probability at least $1-\delta/4$, for all $1\le t\le T$:
$$L(h^t,w^t)\le \min_{h\in\mathcal H}L(h,w^t)+\varepsilon/50$$

**Proof idea:**
1. Sample-size invariant: $\widehat w_i^t \ge w_i^t/2$ by construction, so $n_i^t=\lceil T_1 \widehat w_i^t\rceil \ge T_1 w_i^t/2$ for all $i,t$.
2. Weighted-VC uniform convergence (union bound over an $\varepsilon_1/k$-net of $\Delta(k)$, giving the $k\log(k/\varepsilon_1)$ term, plus standard VC bound giving $d\log(kd/\varepsilon_1)$, plus $\log(1/\delta)$) with
   $$T_1=\frac{4000(k\log(k/\varepsilon_1)+d\log(kd/\varepsilon_1)+\log(1/\delta))}{\varepsilon_1^2},\quad \varepsilon_1=\varepsilon/100$$
   gives, w.p. $\ge 1-\delta/4$, simultaneously for all $t,h$: $|\widehat L^t(h,w^t)-L(h,w^t)|\le\varepsilon_1$.
3. $h^t\in\arg\min_h \widehat L^t(h,w^t)$, so $\widehat L^t(h^t,w^t)\le \widehat L^t(h^\star,w^t)$ for $h^\star=\arg\min_h L(h,w^t)$.
4. Chain: $L(h^t,w^t)\le \widehat L^t(h^t,w^t)+\varepsilon_1\le \widehat L^t(h^\star,w^t)+\varepsilon_1\le L(h^\star,w^t)+2\varepsilon_1=\min_h L(h,w^t)+\varepsilon/50$.

**Why:** This is one step in a larger union-bound argument (the $\delta/4$ budget suggests this is one of ~4 failure events being combined for an overall $1-\delta$ guarantee across the algorithm's analysis).

**How to apply:** In later sessions working on 2312.05134's Algorithm 1 analysis (in any part_N space), this bound on $L(h^t,w^t)$ is available to plug into subsequent regret/convergence arguments — treat it as an established lemma rather than re-deriving from scratch. If notation for $\mathcal H$, $w^t$, $n_i^t$, or the $\varepsilon/50$ constant changes in later subtasks, verify against the current paper draft before reusing.
