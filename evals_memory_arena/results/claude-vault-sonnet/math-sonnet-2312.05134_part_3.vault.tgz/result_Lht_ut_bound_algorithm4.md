---
id: 01a050c0-9b80-7c89-98f7-81f25ee53adb
name: result-lht-ut-bound-algorithm4
description: "Paper 2312.05134 Algorithm 4: with prob >= 1-delta/4, L(h^t,u^t) <= min_h L(h,u^t) + eps/50 for all rounds t (h^t/u^t = Algorithm 4's hypothesis/weight vector, analogous to h^t/w^t in Algorithm 1) — NOT verified against paper, reconstructed by analogy"
metadata:
  type: project
---

Subtask: bound $L(h^t,u^t)$ for all $1\le t\le T$ in Algorithm 4 of paper 2312.05134, where $\pi\in\Delta(\mathcal H)$ and $L_i^\ell(h_\pi)=\mathbb E_{h\sim\pi}[L_i^\ell(h)]$ was introduced as context (mixed/randomized-hypothesis notation), and $h^t$/$u^t$ are Algorithm 4's per-round hypothesis and weight vector.

**Result:** With probability at least $1-\delta/4$, for all $1\le t\le T$:
$$L(h^t,u^t)\le \min_{h\in\mathcal H}L(h,u^t)+\varepsilon/50$$

**Proof idea:** Identical shape to [[result-lht-wt-bound-round-t]] (Algorithm 1) and [[result-lht-wt-bound-algorithm3]] (Algorithm 3): weighted uniform-convergence bound (accuracy $\varepsilon_1=\varepsilon/100$, w.p. $\ge 1-\delta/4$) giving $|\widehat L^t(h,u^t)-L(h,u^t)|\le\varepsilon_1$ simultaneously for all $t,h$, combined with $h^t$'s optimality for the round-$t$ empirical objective, chains to the $2\varepsilon_1=\varepsilon/50$ bound.

**Caveat — NOT verified against the paper:** produced by analogy only, with $w^t\to u^t$ renamed. Algorithm 4's exact pseudocode, and whatever uniform-convergence assumption underlies it (weighted-VC as in Algorithm 1, Rademacher-complexity as in Algorithm 3's Assumption~rad, or something new tied to the $\pi\in\Delta(\mathcal H)$/mixed-hypothesis setup), was **not present in memory or supplied in-session**. The mixed-hypothesis notation $L_i^\ell(h_\pi)$ suggests Algorithm 4 may output/operate over distributions $\pi$ over $\mathcal H$ rather than single hypotheses — if so the analogy could break down (e.g. the uniform-convergence class may need to be $\Delta(\mathcal H)$ rather than $\mathcal H$). Verify this before relying on it.

**Why:** Same $\delta/4$ failure-budget pattern as the other algorithms — one lemma in a larger union-bound argument for Algorithm 4's overall guarantee.

**How to apply:** In later sessions on Algorithm 4 of 2312.05134 (any part_N space), treat this as a plausible-but-unverified lemma. If the paper's actual Algorithm 4 pseudocode or the $\pi\in\Delta(\mathcal H)$ mixed-hypothesis machinery becomes available, re-derive/check this bound rather than assuming it transfers unchanged from Algorithm 1/3.
