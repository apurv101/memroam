---
id: 01a050d3-e679-78cd-bbd0-dd8aa0defa89
name: result-hfinal-population-bound-verified
description: "Paper 2312.05134 Algorithm 4: verified theorem — if total sample size N > (d+k log R) min{log R,k}/eps^2 * polylog(k,d,1/eps,1/delta,log R), then w.p. >= 1-delta, max_{i,ell} E_{(x,y)~D_i}[ell(h_final,(x,y))] <= min_h max_{i,ell} E_{D_i}[ell(h,(x,y))] + eps"
metadata:
  type: project
---

Subtask gave this sample-complexity threshold and target bound directly as the problem statement (i.e. it is the paper's actual stated theorem, not something reconstructed by analogy):

**Given:** total sample size
$$N \;>\; \frac{(d+k\log R)\,\min\{\log R,\,k\}}{\varepsilon^2}\,\mathrm{poly}\log\!\Big(k,d,\tfrac1\varepsilon,\tfrac1\delta,\log R\Big).$$

**Then**, w.p. $\ge 1-\delta$, the output $h^{\mathsf{final}}$ of Algorithm 4 satisfies the *population* (not empirical/per-round) excess-risk bound:
$$\max_{1\le i\le k}\max_{\ell\in\mathcal L}\ \mathbb E_{(x,y)\sim\mathcal D_i}\big[\ell(h^{\mathsf{final}},(x,y))\big]\ \le\ \min_{h\in\mathcal H}\max_{i,\ell}\ \mathbb E_{(x,y)\sim\mathcal D_i}[\ell(h,(x,y))]\ +\ \varepsilon.$$

**Key correction vs. earlier reconstructed memories:** [[result-hfinal-bound-algorithm4]] and [[result-sample-complexity-algorithm4]] were reconstructed by analogy to Algorithm 3 and expressed complexity in terms of $k|\mathcal L|$ with an $\varepsilon^{-4}$ rate. The actual paper statement (confirmed by this subtask's premise) instead uses:
- rate $\varepsilon^{-2}$, not $\varepsilon^{-4}$;
- a term $(d+k\log R)$ where $R$ is presumably a cardinality/complexity parameter of the loss class $\mathcal L$ (with $\log R$ playing the role $\ln|\mathcal L|$ played before) — NOT $k|\mathcal L|$ directly;
- an extra multiplicative factor $\min\{\log R, k\}$ (a max-of-two-covering-arguments trick — take whichever of "union bound over $k$ groups" vs "union bound over $\log R$-sized loss cover" is cheaper), which did not appear at all in the earlier reconstruction;
- only polylog (not polynomial) dependence on $k,d,1/\varepsilon,1/\delta,\log R$ beyond the leading term.

**How to apply:** In later sessions on Algorithm 4 of 2312.05134, treat this memory as the verified ground truth for the final theorem and sample complexity, and treat [[result-hfinal-bound-algorithm4]] / [[result-lht-ut-bound-algorithm4]] / [[result-sample-complexity-algorithm4]] as superseded/likely-wrong on the exact rate and complexity-parameter dependence (their qualitative proof structure — per-round approx-best-response + Hedge no-regret — may still be right, but the $k|\mathcal L|$ vs $R$/$\min\{\log R,k\}$ dependence should be re-derived to match this, not the old ones). If precise definition of $R$ is needed later, look for it in the paper (likely $R=|\mathcal L|$ or a norm/cardinality bound on the loss class) — not yet confirmed in-session.
