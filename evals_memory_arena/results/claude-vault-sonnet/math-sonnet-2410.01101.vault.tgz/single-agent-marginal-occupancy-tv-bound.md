---
id: 01a050af-2a53-7dd5-83c4-8a0a96deece1
name: single-agent-marginal-occupancy-tv-bound
description: Solved corollary bound for E_rho[sum_{s_j,a_j}|d^{pi_j}_h(s_j,a_j|spub)-hd^{pi_j}_h(s_j,a_j|spub)|] for any single-agent policy pi_j, all h in [H]: same rate H*sqrt(log(|Q|/delta)/M), no N dependence
metadata:
  type: project
---

**Setting:** Same as [[occupancy-measure-total-variation-bound-policy-product]], but now for a single agent $j\in[N]$ with single-agent policy $\pi_j$, where $d^{\pi_j}_h(s_j,a_j|\spub)$ is the marginal occupancy measure over just agent $j$'s (private) state-action pair.

**Result:** For any $j\in[N]$, any single-agent policy $\pi_j$, and all $h\in[H]$:
$$\mathbb E_{\spub\sim\rho}\Big[\sum_{s_j,a_j}\big|d^{\pi_j}_h(s_j,a_j|\spub)-\hd^{\pi_j}_h(s_j,a_j|\spub)\big|\Big]\lesssim H\sqrt{\frac{\log(|\Qc|/\delta)}{M}}.$$

Same rate as the joint-policy bound — **no extra dependence on $N$**.

**Proof sketch:** Extend $\pi_j$ to any full joint policy $\pi=(\pi_j,\pi_{-j})$; then $d^{\pi_j}_h(\cdot|\spub)$ is exactly the marginal of $d^\pi_h(\cdot|\spub)$ onto agent $j$'s coordinates. Marginalizing can only shrink $\ell_1$ error (triangle inequality: $\sum_{s_j,a_j}|P_j-Q_j|\le\sum_{\bs,\ba}|P-Q|$ when $P_j,Q_j$ are marginals of $P,Q$), so the single-agent sum is upper-bounded by the joint quantity from [[occupancy-measure-total-variation-bound-policy-product]], which already carries the same $H\sqrt{\log(|\Qc|/\delta)/M}$ rate.

**How to apply:** Use directly as an established corollary whenever a later subtask in paper 2410.01101 needs to control the true-vs-MLE-estimated gap for a single agent's marginal occupancy measure (rather than the full joint policy) — e.g. in per-agent regret decompositions.
