---
id: 01a050bc-d1fe-7cec-909d-426e7390c042
name: performance-difference-lemma-deviation-value
description: Solved closed form for hV^{mu'_i∘pi_{-i}}-hV^{mu_i∘pi_{-i}} (deviation value difference for two policies of agent i against same pi_{-i}) via performance-difference lemma
metadata:
  type: project
---

**Subtask:** Given joint policy $\pi_{-i}$ for agents other than $i$, and any two policies $\mu_i,\mu'_i$ for agent $i$, express $\hV^{\mu'_i\circ\pi_{-i},\hr}_{i,1}(\spub,s_{i,1})-\hV^{\mu_i\circ\pi_{-i},\hr}_{i,1}(\spub,s_{i,1})$, using the $\hV,\hQ$ Bellman recursion of [[deviation-value-bellman-recursion]].

**Solution:** Since both $\mu_i,\mu'_i$ are composed with the *same* $\pi_{-i}$, this is exactly the single-agent Kakade–Langford performance-difference lemma applied to the layered MDP over $x_h=(\spub_h,s_{i,h})$ induced by the hat-model $(\hr,\hP,\hd^{\pi_{-i}})$:

$$\hV^{\mu'_i\circ\pi_{-i},\hr}_{i,1}(\spub,s_{i,1})-\hV^{\mu_i\circ\pi_{-i},\hr}_{i,1}(\spub,s_{i,1})=\sum_{h=1}^{H}\mathbb{E}_{x_h\sim \hd^{\mu'_i\circ\pi_{-i}}_h(\cdot\mid\spub,s_{i,1})}\Big[\big\langle\hQ^{\mu_i\circ\pi_{-i},\hr}_{i,h}(x_h,\cdot),\,\mu'_{i,h}(\cdot\mid x_h)-\mu_{i,h}(\cdot\mid x_h)\big\rangle\Big]$$

where $\hd^{\mu'_i\circ\pi_{-i}}_h(\cdot\mid\spub,s_{i,1})$ is the layer-$h$ occupancy measure over $(\spub_h,s_{i,h})$ induced by playing $\mu'_i\circ\pi_{-i}$ (under the hat-model) starting from $(\spub,s_{i,1})$, and the inner product is over agent $i$'s action $a_i$ at $x_h$.

**How to apply:** Base identity for regret/best-response-gap decompositions for individual agent $i$ (e.g. bounding $\max_i \mathrm{Gap}_i$, see [[gap-max-i-bound-final-rate-blocked]]) — sets $\mu'_i$ to a best response and $\mu_i=\pi_i$ (or vice versa) to turn value gaps into sums of expected Q-advantage/inner-product terms over layers.
