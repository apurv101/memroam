---
id: 01a05099-01b6-743f-b9e6-87c1cee8b3b4
name: chi2-regularized-policy-gradient-regret-bound
description: Per-x regret bound for chi^2-regularized regularized policy gradient (p^{t+1} solves KL-Bregman + chi^2(.,nu) prox step) in terms of D_x(mu,nu), chi^2(mu,nu), and eta*B^2*T
metadata:
  type: project
---

Setup: losses $l^t:\mathcal{X}\times\mathcal{Y}\to[0,B]$, reference policy $\nu$, $p^1=\nu$, and update
$$p^{t+1}(x)=\arg\min_{p\in\Delta_{\mathcal Y}} -\langle l^t(x,\cdot),p\rangle+\lambda\chi^2(p,\nu(x))+\tfrac1\eta D_x(p,p^t).$$

Result (per $x\in\mathcal{X}$, for all policies $\mu$):
$$\sum_{t=1}^{T}\langle l^t(x),\mu(x)-p^t(x)\rangle+\lambda\sum_{t=1}^{T+1}\chi^2(p^t(x),\nu(x))\;\le\;\frac1\eta D_x(\mu(x),\nu(x))+\lambda T\,\chi^2(\mu(x),\nu(x))+\frac{\eta B^2 T}{2}.$$

Assumes $D_x$ is 1-strongly convex w.r.t. $\|\cdot\|_1$ (e.g. $D_x=\mathrm{KL}$), used to get the standard $\eta B^2/2$ per-round mirror-descent/FTRL regret term from bounded losses.

**Why:** Solved subtask in paper 2410.01101; this is a per-$x$/per-context online-mirror-descent-style regret bound for a chi-square-regularized policy gradient scheme, likely a building block toward a global (integrated over $x$, or population-level) regret or sample-complexity bound in a later subtask. Structurally this is the standard regularized-FTRL regret decomposition (linearized loss regret + telescoping regularizer term), with the chi^2 term playing the role of an extra regularizer alongside the Bregman/KL proximal term.

**How to apply:** Reuse this bound directly (or its per-step derivation via the three-point identity, see [[f_x-gradient-inner-product-three-point-identity]]) whenever a later subtask needs to bound cumulative regret / suboptimality of $p^t$ against a comparator $\mu$ under this same chi^2+Bregman regularized update. If the later subtask changes the regularizer or update rule, re-derive rather than assuming this exact form still applies.
