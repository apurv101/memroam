---
id: 01a05088-c161-770b-bc3a-063f5b5e3e4d
name: chi2-cauchy-schwarz-bound
description: Lemma bounding E_{d1}[f] by E_{d2}[f] + sqrt(chi2(d1,d2))*sqrt(E_{d2}[f^2]) via Cauchy-Schwarz on the likelihood ratio
metadata:
  type: project
---

For two distributions $d^1, d^2 \in \Delta(\mathcal{Z})$ and any function $f$ on $\mathcal{Z}$:

$$\mathbb{E}_{z\sim d^1}[f(z)] \;\leq\; \mathbb{E}_{z\sim d^2}[f(z)] \;+\; \sqrt{\chi^2(d^1,d^2)}\cdot\sqrt{\mathbb{E}_{z\sim d^2}[f(z)^2]}$$

Derivation sketch: write $\mathbb{E}_{d^1}[f] - \mathbb{E}_{d^2}[f] = \mathbb{E}_{d^2}\left[\left(\frac{d^1(z)}{d^2(z)} - 1\right) f(z)\right]$, then apply Cauchy-Schwarz under $d^2$ to split this into $\sqrt{\mathbb{E}_{d^2}[(d^1/d^2 - 1)^2]} \cdot \sqrt{\mathbb{E}_{d^2}[f^2]}$, and recognize the first factor as $\sqrt{\chi^2(d^1,d^2)}$ by definition of chi-squared divergence.

**Why:** This is a lemma proved in a working session on paper 2410.01101; later subtasks in the project may reuse or build on it.

**How to apply:** Use directly when a later subtask needs to bound an expectation under one distribution in terms of an expectation (and second moment) under a reference distribution, controlled by their chi-squared divergence.
