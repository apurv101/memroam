---
id: 01a0508e-b6f4-75fc-a1e5-31cb13929f7c
name: f_x-gradient-inner-product-three-point-identity
description: Closed form for <grad f_x(p1)-grad f_x(p2), p3(x)-p1(x)> via the Bregman three-point identity for per-x convex functions f_x
metadata:
  type: project
---

For $i\in[N]$, $p_1,p_2,p_3:\mathcal{X}\to\Delta_{\mathcal{Y}}$, and any $x\in\mathcal{X}$, with $f_x$ a convex function on $\Delta_{\mathcal{Y}}$ (per-$x$ potential) and Bregman divergence $D_{f_x}(u,v) = f_x(u)-f_x(v)-\langle\nabla f_x(v),u-v\rangle$:

$$\left\langle \nabla f_{x}(p_1)-\nabla f_{x}(p_2),\,p_3(x)- p_1(x)\right\rangle = D_{f_x}\big(p_3(x),p_2(x)\big) - D_{f_x}\big(p_3(x),p_1(x)\big) - D_{f_x}\big(p_1(x),p_2(x)\big)$$

This is the standard Bregman three-point identity applied at $(a,b,c) = (p_3(x), p_1(x), p_2(x))$: $\langle \nabla f_x(b) - \nabla f_x(c), a-b\rangle = D_{f_x}(a,c) - D_{f_x}(a,b) - D_{f_x}(b,c)$. Verified by direct expansion (all bare $f_x$ terms cancel).

**Why:** Solved subtask in paper 2410.01101; likely a building block for a regret/potential-function argument involving three iterates/policies $p_1,p_2,p_3$ evaluated pointwise at $x$.

**How to apply:** Reuse directly whenever a later subtask needs to expand this exact inner product (or its negation / with relabeled $p_1,p_2,p_3$) — just match the general three-point identity to the specific argument order requested.
