---
id: 01a05092-c3bb-7dee-a33d-1b78d47d6e43
name: anova-decomposition-orthogonality-error-bound
description: Standardized (ANOVA-style) decomposition components are mutually L2-orthogonal, so a global L2 error bound eps on f-hat splits into per-component bounds of eps each via Pythagoras
metadata:
  type: project
---

**Setting:** Functions $\fs,\hf$ with interaction rank $K$ each admit a "standardized decomposition" (Lemma 3 of this paper) into components $\{g_{j_1,\dots,j_k}\}$, $\{\hg_{j_1,\dots,j_k}\}$ for $0\le k\le K-1$ and index subsets $j_1<\cdots<j_k\subseteq[W]$. Let $\Delta_S := g_S - \hg_S$ for each subset $S$.

**Result:** If $\E_{x\sim p,\,y_1\sim p_1(\cdot|x),\dots,y_W\sim p_W(\cdot|x)}[(\fs-\hf)^2]\le\eps$, then for every subset $S=\{j_1,\dots,j_k\}$,
$$
\E_{x\sim p,\,y_{j_1}\sim p_{j_1}(\cdot|x),\dots,y_{j_k}\sim p_{j_k}(\cdot|x)}[\Delta_S^2] \le \eps.
$$

**Why:** The standardized decomposition is constructed so each component has zero conditional mean in every one of its arguments (the defining "standardization"/ANOVA property from Lemma 3). This makes distinct components $\Delta_S$ mutually orthogonal in $L^2$ under the product sampling measure — cross terms $\E[\Delta_S\Delta_{S'}]$ vanish for $S\ne S'$ because one can always condition out a variable present in the symmetric difference. This gives the Pythagorean identity
$$\E[(\fs-\hf)^2] = \sum_{S} \E[\Delta_S^2] \le \eps,$$
and since every term is nonnegative, each individual term is bounded by $\eps$ (in fact by the full sum, so the bound $\eps$ is not tight per-term but is what's asked for/needed downstream).

**How to apply:** Use this whenever a later subtask needs per-interaction-order or per-subset error control derived from a global $L^2$ approximation guarantee between two functions admitting this decomposition (e.g. bounding lower-order interaction terms, or building up union-bound / concentration arguments term-by-term over subsets $S$). The orthogonality/Pythagoras argument is the key mechanical step — cite it rather than re-deriving from scratch.
