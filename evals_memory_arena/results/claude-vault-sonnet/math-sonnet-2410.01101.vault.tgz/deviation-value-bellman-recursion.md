---
id: 01a050b4-da1e-739b-b660-bc3e75435956
name: deviation-value-bellman-recursion
description: Bellman recursion definitions for single-agent deviation value/Q functions hV,hQ under mu_i∘pi_{-i} in the public/private-state MDP (uses hat-model hr,hP,hd)
metadata:
  type: project
---

**Setting:** Public state $\spub\in\Spub$, private state $s_i\in\Sc_i$ for agent $i$, joint policy $\pi_{-i}$ for all agents except $i$, deviation policy $\mu_i$ for agent $i$. $\hr_{i,h}$, $\hP_h$ denote (estimated/hat) reward and transition models; $\hd^{\pi_{-i}}_h(\cdot\mid\spub)$ is the occupancy measure over other agents' private states induced by $\pi_{-i}$ conditioned on $\spub$ (see [[occupancy-measure-total-variation-bound-policy-product]]).

**Definitions** (for all $i\in[N],h\in[H],\spub,s_i,a_i$):

$$
\hV^{\mu_i\circ\pi_{-i},\hr}_{i,h}(\spub,s_i)=\mathbb{E}_{a_i\sim \mu_{i,h}(\cdot\mid\spub,s_i)}\Big[\hQ^{\mu_i\circ\pi_{-i},\hr}_{i,h}(\spub,s_i,a_i)\Big]
$$

$$
\hQ^{\mu_i\circ\pi_{-i},\hr}_{i,h}(\spub,s_i,a_i)=\hr_{i,h}(\spub,s_i,a_i)+\mathbb{E}_{s_{-i}\sim \hd^{\pi_{-i}}_h(\cdot\mid\spub),\,a_{-i}\sim\pi_{-i,h},\,(\spub',s_i')\sim\hP_h}\Big[\hV^{\mu_i\circ\pi_{-i},\hr}_{i,h+1}(\spub',s_i')\Big]
$$

with boundary condition $\hV^{\mu_i\circ\pi_{-i},\hr}_{i,H+1}\equiv0$.

This is the standard multi-agent Bellman recursion for agent $i$'s single-agent deviation value, in the public/private-state factorization. Recovers on-policy value functions when $\mu_i=\pi_i$.

**How to apply:** Reuse as the base definition whenever later subtasks in paper 2410.01101 build regret/gap decompositions, best-response computations, or Bellman-consistency arguments for individual agent deviations (e.g. [[gap-max-i-bound-final-rate-blocked]] likely relies on this Gap_i notion being built from $\hV$/$\hQ$ here).
