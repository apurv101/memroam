---
id: 01a050ac-154e-7d2b-b889-f71d571258da
name: occupancy-measure-total-variation-bound-policy-product
description: Solved bound for E_rho[sum_{s,a}|d^pi_h(s,a|spub)-hd^pi_h(s,a|spub)|] for any policy product pi, all h in [H]: <~ H*sqrt(log(|Q|/delta)/M)
metadata:
  type: project
---

**Setting:** $\rho$ a distribution over public states $\spub$; $\pi$ any policy product; $d^\pi_h(\bs,\ba|\spub)$ the true occupancy measure over (private) state-action pairs at step $h$ conditioned on $\spub$, $\hd^\pi_h$ its estimate under an MLE-learned model. $\Qc$ is the model/transition function class used for MLE, $M$ the number of transition samples, $\delta$ the failure probability, $H$ the horizon.

**Result:** For any policy product $\pi$ and all $h\in[H]$:
$$\mathbb E_{\spub\sim\rho}\Big[\sum_{\bs,\ba}\big|d^\pi_h(\bs,\ba|\spub)-\hd^\pi_h(\bs,\ba|\spub)\big|\Big]\lesssim H\sqrt{\frac{\log(|\Qc|/\delta)}{M}}.$$

**Proof sketch:** (1) Same-policy reduction — since both $d^\pi_h$ and $\hd^\pi_h$ use the *same* policy $\pi$, the action-marginal factor cancels in the TV-distance comparison, leaving only the transition-model mismatch to bound. (2) A telescoping simulation-lemma argument decomposes the per-step state-occupancy error across the $h$ transition steps taken so far, contributing the factor of $H$ (worst case at $h=H$). (3) Each per-step term is bounded via "Lemma 14" of this paper (an MLE transition-estimation bound, i.e. $\mathbb E[\mathrm{TV}(P,\hat P)]\lesssim\sqrt{\log(|\Qc|/\delta)/M}$-type guarantee) combined with Jensen's inequality to pass the expectation over $\rho$ inside.

**Caveat:** "Lemma 14" (the MLE transition bound) and the precise definitions of $\Qc$, $M$, and the public/private state split ($\spub$ vs $\bs$) are referenced here but not separately stored in memory — if a later session needs the exact statement/constants of Lemma 14, it isn't captured yet and would need to be pulled from the paper draft again.

**How to apply:** Reuse this bound directly as an established lemma when later subtasks in paper 2410.01101 need to control the gap between true and MLE-estimated occupancy measures for a fixed policy product across the horizon (e.g. in regret decompositions or simulation-lemma-style arguments). See also [[chi2-cauchy-schwarz-bound]] for a related TV/chi2-based bounding technique used elsewhere in this paper.
