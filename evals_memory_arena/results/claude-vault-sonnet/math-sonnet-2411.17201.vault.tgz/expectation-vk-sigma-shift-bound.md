---
id: 01a05100-dcf3-73f2-878d-193521249955
name: expectation-vk-sigma-shift-bound
description: Solved closed form for E_b[v_k(b) sigma(z+b)] where v(b) = -1/2 k(k-1)(k-2)(1-b)^{k-3} 1{b in [0,1]}/mu(b)
metadata:
  type: project
---

For $v(b) = -\tfrac12 k(k-1)(k-2)(1-b)^{k-3}\cdot\frac{\mathbf 1_{b\in[0,1]}}{\mu(b)}$, the expectation $\EE_b[v_k(b)\sigma(z+b)]$ is a $C^1$ piecewise function of $z$:

$$
\EE_b[v_k(b)\sigma(z+b)] =
\begin{cases}
0 & z\le -1\\
-\tfrac{k}{2}(1+z)^{k-1} & -1\le z\le 0\\
-\tfrac{k}{2}\big[(k-1)z+1\big] & z\ge 0
\end{cases}
$$

i.e. a shifted power $(1+z)^{k-1}$ on $[-1,0]$, continued for $z\ge0$ by its own tangent line at $z=0$ (so the function and its derivative match at $z=0$, giving global $C^1$).

**Note:** $\mu(b)$ (presumably the density of $b$, weighting $v_k(b)$ to invert it against) was not itself re-defined in this memory — if a future subtask needs $\mu(b)$'s explicit form, get it from the user/paper rather than assuming; here it cancelled/was implicit in the derivation. This notation ($v_k$, $\mu(b)$, activation $\sigma(z+b)$ with $b$ integrated over $[0,1]$) is distinct from the $\sigma_2$/random-feature-kernel notation in [[kernel-concentration-bound-K0-m2]] and [[quadratic-harmonic-sigma2-concentration]] — likely a different part of the paper (activation-representation / Taylor-remainder-via-Beta-density trick using the $k$-th derivative kernel $(1-b)^{k-3}$).
