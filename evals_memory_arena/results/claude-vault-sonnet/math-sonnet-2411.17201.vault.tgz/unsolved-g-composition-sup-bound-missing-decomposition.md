---
id: 01a0510b-b8d8-7de3-8c93-fd67c2193880
name: unsolved-g-composition-sup-bound-missing-decomposition
description: Subtask "bound sup_{x in D2} |g(B*h^(1)(x)) - g(p(x))| given m2,n>=Cd^4" was left unsolved — same missing decomposition as A_1/A_2/A_3/D_1/D_2/D_3, plus g's Lipschitz assumption/constant was never confirmed
metadata:
  type: project
---

Subtask: with high probability, upper bound $\sup_{\bx\in\cD_2}|g(\bB^\star\mathbf h^{(1)}(\bx))-g(\bp(\bx))|$, given $m_2,n\ge Cd^4$.

This is the natural "final assembly" step of the project: the target inside $g(\cdot)$, $\bB^\star\mathbf h^{(1)}(\bx)-\bp(\bx)$, is exactly what the decomposition $A_1+A_2+A_3+D_1(+D_{1,1},D_{1,2})+D_2+D_3$ (see [[recurring-blocker-decomposition-definitions-2411-17201]]) is presumed to sum to. Could not solve because:
1. The decomposition equation/definitions are still missing (as in all prior blocked subtasks).
2. It is unknown whether/how $g:\mathbb R^{d_2}\to\mathbb R$ is assumed Lipschitz (constant name, e.g. $L_g$) — this is the natural bridge $|g(u)-g(v)|\le L_g\|u-v\|$ from the vector-difference bound to the scalar bound asked for here, but no such assumption has been confirmed in-session.

Proposed approach once definitions are available: triangle inequality + Lipschitzness,
$$|g(\bB^\star\mathbf h^{(1)}(\bx))-g(\bp(\bx))|\le L_g\|\bB^\star\mathbf h^{(1)}(\bx)-\bp(\bx)\|\le L_g(|A_1|+|A_2|+|A_3|+\|D_1\|+\|D_2\|+\|D_3\|)$$
then plug in each term's already-established rate (still all unsolved per [[recurring-blocker-decomposition-definitions-2411-17201]]) and take sup over $\bx\in\cD_2$ with a union bound over the probabilities.

**Why:** No response was given to the user for this subtask beyond asking for the missing decomposition and $g$'s Lipschitz assumption.

**How to apply:** Next session, if this subtask resurfaces, do not re-derive from scratch — get the decomposition/definitions/Lipschitz constant from the user once (per [[recurring-blocker-decomposition-definitions-2411-17201]]), then assemble via the triangle-inequality approach above using whatever rates were established for $A_1,A_2,A_3,D_1,D_2,D_3$.
