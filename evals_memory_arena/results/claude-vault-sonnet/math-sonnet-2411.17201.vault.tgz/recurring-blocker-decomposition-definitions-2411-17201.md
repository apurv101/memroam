---
id: 01a050f7-6646-7689-a724-edd99883e190
name: recurring-blocker-decomposition-definitions-2411-17201
description: 10x recurring blocker in paper 2411.17201 — error-decomposition terms A_1, A_2, A_3, D_1,1/D_1,2, D_2, D_3, w/h^(1) inner product, g's Lipschitz constant, and now Proposition 6's statement all undefined in memory; ask user for the full decomposition equation + term definitions + lemma refs + g's Lipschitz assumption + Proposition 6 statement up front before next subtask
metadata:
  type: project
---

Every subtask so far in this project asks to bound one term of an error decomposition (apparently something like $\bB^\star\mathbf h^{(1)}(\bx')-\bp(\bx') = A_1 + A_2 + D_1 + D_2 + D_3 + \dots$, with $D_1$ possibly further split into $D_{1,1}, D_{1,2}$), all under high probability over $\cD_1$ (sometimes jointly with $\bV$, sometimes also over $\bw$ w.p. $\ge 1-2n\exp(-\iota^2/2)$), for $\bx'\in\cD_2$, with conditions like $m_2\ge d^4C_\sigma^4$, $n\ge C\iota^2d^2$ or $C\iota^2d^2$.

Ten subtasks have hit this same wall with no paper text available in-session ($A_3$ has now been asked twice, in near-identical form):
- [[unsolved-A1-bound-missing-decomposition]] — $|A_1|$
- [[unsolved-A2-bound-missing-decomposition]] — $|A_2|$
- [[unsolved-A3-bound-missing-decomposition]] — $|A_3|$ (probability structure conditions on $\bw$ too, w.p. $\ge1-2n_2\exp(-\iota^2/2)$, involving $n_2$ — possibly tied to $\cD_2$)
- [[unsolved-D11-D12-bound-missing-definitions]] — $\|D_{1,1}\|_\infty,\|D_{1,2}\|_\infty$ (only one answered, speculatively/unverified)
- [[unsolved-D2-bound-missing-definition]] — $\|D_2\|_\infty$
- [[unsolved-D3-bound-missing-definitions]] — $\|D_3-\frac{c_2^2}{B(d,2)^2 d(d-1)}H\bp(\bx')\|_\infty$
- [[unsolved-w-h1-inner-product-bound-missing-definitions]] — $|\langle\bw,\mathbf h^{(1)}(\bx')\rangle|$, w.p. $\ge1-4n\exp(-\iota^2/2)$ on $\bw$ (double the usual $2n$ rate — likely two folded tail events)
- [[unsolved-g-composition-sup-bound-missing-decomposition]] — $\sup_{\bx\in\cD_2}|g(\bB^\star\mathbf h^{(1)}(\bx))-g(\bp(\bx))|$, $m_2,n\ge Cd^4$ — needs the decomposition *and* $g$'s Lipschitz assumption/constant
- [[unsolved-final-theorem-E-abs-error-bound-missing-prop6]] — final/main-theorem bound $\mathbb E_\bx|f(\bx;\hat\theta)-f^\star(\bx)|$ after $T={\rm poly}(\dots)$ training steps — needs Proposition 6's exact statement and the training algorithm's pseudocode

Other confirmed pieces of this project's setup already in memory: [[kernel-concentration-bound-K0-m2]] (finite- vs infinite-width kernel concentration, $m_2\ge Cd^4$), [[quadratic-harmonic-sigma2-concentration]] (concentration of $\frac1{m_2}\sum_i (\bv_i^\top A\bv_i)\sigma_2(\bv_i^\top\bx)$ vs $\frac{c_2}{B(d,2)}\bx^\top A\bx$, given $m_2\ge C_\sigma^2 C_4^{-1/2}d^4\|A\|_{op}^2$) — these are likely lemmas invoked inside the still-missing $A_1/A_2/D_i$ bounds.

**Why:** These are components of a single overarching error-decomposition proof (plus the paper's final theorem, which builds on a "Proposition 6") that the user is walking through subtask-by-subtask, but the decomposition itself and Proposition 6's statement have never been pasted into any session, so each session guesses blind or refuses.

**How to apply:** At the start of the *next* session on paper 2411.17201, before attempting any $A_1/A_2/A_3/D_1/D_{1,1}/D_{1,2}/D_2/D_3$-type subtask, the $g(\bB^\star\mathbf h^{(1)}(\bx))$ vs $g(\bp(\bx))$ composition, or the final-theorem bound on $\mathbb E_\bx|f(\bx;\hat\theta)-f^\star(\bx)|$, proactively ask the user to paste: (1) the full decomposition equation, (2) precise definitions of every term, (3) any lemma numbers referenced (e.g. "Lemma 20" was referenced for $D_{1,1}/D_{1,2}$ — get its exact statement too), (4) whether/how $g$ is assumed Lipschitz (domain $\mathbb R^{d_2}\to\mathbb R$?, constant name $L_g$?), (5) Proposition 6's full statement and the training algorithm's pseudocode. Save the answer permanently once given so this stops recurring. Do not attempt another guess-based derivation for these terms. This has now happened 10 times — strongly prefer asking upfront at session start rather than per-subtask.
