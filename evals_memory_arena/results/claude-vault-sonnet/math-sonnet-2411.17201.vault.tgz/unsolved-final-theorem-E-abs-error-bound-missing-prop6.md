---
id: 01a05110-580c-7da2-8914-bf5add2a8df8
name: unsolved-final-theorem-E-abs-error-bound-missing-prop6
description: Subtask "give asymptotic bound on E_x|f(x;hat theta)-f*(x)| for hat theta = output of Algorithm training algo after T=poly(...) steps, n_1,m_2=Omega~(d^4)" was answered only schematically — no verified closed form, because Proposition 6's exact statement/RHS was never pasted into memory
metadata:
  type: project
---

This is the paper's apparent main/final theorem: given hyperparameters $(\epsilon,\eta_1,\eta_2,\lambda_1,\lambda_2)$ and $n_1,m_2=\widetilde\Omega(d^4)$, bound $\mathbb E_{\bx}[\,|f(\bx;\hat\theta)-f^\star(\bx)|\,]$ for $\hat\theta$ the output of Algorithm "training algo" after $T={\rm poly}(n_1,n_2,m_1,m_2,d)$ steps.

The answer given in-session was only a proof *sketch*, not a verified closed-form bound:
1. Convexity of $\mathcal L_2$ in the last layer ⟹ poly(T)-step training tracks a $\theta^\star$ constructed in "Proposition 6".
2. Empirical→population concentration under $n_1,m_2=\widetilde\Omega(d^4)$.
3. Cauchy–Schwarz converts squared-loss bound to $L^1$ bound: final answer = $\sqrt{\text{RHS of Proposition 6}}$, evaluated at $\hat\theta$.

No exact statement of Proposition 6 (its RHS, in terms of $d, n_1, n_2, m_1, m_2$, etc.) is stored anywhere in this project's memory, so step 3's final expression could not be written out concretely — the "boxed" answer given to the user was a symbolic placeholder ($\sqrt{\text{Prop 6 RHS}}$), not an evaluated bound.

**Why:** This is the 10th instance of [[recurring-blocker-decomposition-definitions-2411-17201]] — subtasks in this project keep referencing paper-internal objects (here, "Proposition 6", and the training "Algorithm training algo") whose exact statements were never captured in memory, forcing guesswork.

**How to apply:** Before attempting this subtask again (or any subtask citing "Proposition 6" or the training algorithm's pseudocode), ask the user to paste: (1) Proposition 6's full statement (assumptions + RHS bound expression), (2) Algorithm training algo's pseudocode (what $\eta_1,\eta_2,\lambda_1,\lambda_2,\epsilon$ control, what $T$ steps means, SGD vs GD, which loss $\mathcal L_2$). Once given, save permanently and evaluate the $\sqrt{\text{Prop 6 RHS}}$ expression concretely rather than leaving it symbolic.
