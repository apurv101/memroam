---
id: 01a050e4-701a-79e3-a154-78380125e1bb
name: kernel-concentration-bound-K0-m2
description: Concentration bound |K0_m2 - K0| between finite-width and infinite-width kernel for sigma2 layer, given m2 >= C d^4
metadata:
  type: project
---

For the second-layer kernel $K^{(0)}_{m_2}(\bx,\bx')=\frac{1}{m_2}\langle \sigma_2(\bV\bx),\sigma_2(\bV\bx')\rangle$ vs infinite-width $K^{(0)}(\bx,\bx')=\EE_{\bv\sim\text{Unif-}\mathbb{S}^{d-1}(\sqrt d)}[\sigma_2(\bv^\top\bx)\sigma_2(\bv^\top\bx')]$, when $m_2\ge Cd^4$, with high probability over $\bw,\bV,\cD$, uniformly for $\bx\in\cD_1,\bx'\in\cD_2$:

$$|K^{(0)}_{m_2}(\bx,\bx')-K^{(0)}(\bx,\bx')| = O\!\left(\frac{\iota}{d^4}\right),\quad \iota=\Theta(\log(dn_1n_2m_1m_2)).$$

**Derivation approach:** scalar Bernstein inequality on the i.i.d. sum over the $m_2$ neurons defining $K^{(0)}_{m_2}$.
- Boundedness: $|\sigma_2|\le C_\sigma$ (Assumption 4 of the paper).
- Variance proxy: 4th-moment bound $\EE[\sigma_2^4]\le C_4/d^4$ (Assumption 4, via rotational invariance of $\bv$ on the sphere + Cauchy–Schwarz) gives variance $O(1/d^4)$.
- Union bound over the $n_1 n_2$ pairs $(\bx,\bx')$ is absorbed into $\iota$.
- Bernstein gives two-term bound $\sqrt{\iota/(d^4 m_2)} + \iota/m_2$; using $m_2\ge Cd^4$ collapses this to $O(\iota/d^4)$ (the first term dominates and simplifies since $m_2 \gtrsim d^4$).

This is the standard technique for bounding finite-width vs. infinite-width kernel deviation in this paper — likely reused for other kernel layers (e.g. an analogous first-layer $K^{(0)}_{m_1}$ bound with $m_1\ge Cd^{?}$). Check for a companion result with the same structure.
