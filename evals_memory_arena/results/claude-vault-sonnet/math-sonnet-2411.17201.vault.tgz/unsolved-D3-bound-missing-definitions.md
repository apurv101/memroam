---
id: 01a050f4-e678-7bb5-bfe4-d04588908d99
name: unsolved-D3-bound-missing-definitions
description: Subtask "bound ||D_3 - c2^2/(B(d,2)^2 d(d-1)) H p(x')||_inf given m2,n>=Cd^4" was left unsolved — no record of what D_3, H, or p(x') are
metadata:
  type: project
---

A subtask asked to upper-bound $\|\bD_3-\frac{c_2^2}{B(d,2)^2 d(d-1)}\cdot \bH \bp(\bx')\|_\infty$ with high probability over $\cD_2$, for any $\bx'\in\cD_2$, given $m_2,n\ge Cd^4$. The session had **no record** of:

1. What $\bD_3$ is (matrix/vector, index set, which decomposition it belongs to — e.g. sibling of $D_1, D_2$ in some error decomposition $\hat f - f^* = D_1+D_2+D_3+\dots$).
2. What $\bH$ and $\bp(\bx')$ denote — plausibly a Hessian-like matrix and a feature/moment vector evaluated at $\bx'$, but this is unconfirmed guesswork.
3. Any lemma number in the paper this bound is meant to invoke.

The coefficient $\frac{c_2^2}{B(d,2)^2 d(d-1)}$ matches the family of degree-2 spherical-harmonic constants seen in [[quadratic-harmonic-sigma2-concentration]] and [[kernel-concentration-bound-K0-m2]] (both involve $c_2/B(d,2)$-type normalization for the $\sigma_2$ activation), so $\bD_3$ is likely another term in the same error decomposition as $\bD_2$, $\bD_{1,1}$, $\bD_{1,2}$, $A_1$ — but the exact definitions were never supplied in-session, so no numeric/asymptotic bound was produced.

**Why:** This is the **fourth** subtask in this project (arXiv 2411.17201) referencing an undefined decomposition term not reproduced in the prompt or captured in memory — see also [[unsolved-A1-bound-missing-decomposition]], [[unsolved-D11-D12-bound-missing-definitions]], [[unsolved-D2-bound-missing-definition]]. This strongly confirms the pattern: subtask prompts assume continuity with the paper's error-decomposition/lemma numbering that is never actually supplied in-session.

**How to apply:** Do not attempt to guess these bounds again. At the very start of a session on this paper, proactively ask the user to share (once) the paper's full error-decomposition section (defining $D_1, D_2, D_3, D_{1,1}, D_{1,2}, A_1, \bH, \bp(\cdot)$, etc.) and the relevant lemma list, rather than re-discovering the gap subtask by subtask. Once definitions are known, [[kernel-concentration-bound-K0-m2]] and [[quadratic-harmonic-sigma2-concentration]] are the likely building-block concentration results (Bernstein-type, $m_2\ge Cd^4$ regime) to invoke.
