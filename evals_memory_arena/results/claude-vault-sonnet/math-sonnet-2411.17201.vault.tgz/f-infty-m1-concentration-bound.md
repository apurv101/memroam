---
id: 01a05107-72d5-709e-9506-c7218089a546
name: f-infty-m1-concentration-bound
description: "Paper 2411.17201: Solved bound |(1/m1)sum_i v(a_i,b_i,w_i)sigma_1(eta a_i<w_i,h^(1)(x)>+b_i) - f_infty,m2(x;v)| <~ iota ||v||_L2/sqrt(m1), uniform over x in D2 w.p. >=1-2n_2 exp(-iota^2/2)"
metadata:
  type: project
---

**Setting (first-layer / m1-neuron network, distinct from the m2/sigma2-layer decomposition tracked in [[recurring-blocker-decomposition-definitions-2411-17201]]):**
- $v:\{\pm1\}\times\RR\times\RR^{m_2}\to\RR$ is a fixed function (from an earlier subtask) with
  $\|v\|_{L^2}\lesssim \|g\|_{L^2}\sum_{k=0}^p \eta^{-k}\|\bB^\star\|_{\rm op}^k r^{(p-k)/4}$,
  where $\eta = C\iota^{-5}\|\bP\|^{-1}m_2^{-1/2}d^6$.
- $f_{\infty,m_2}(\bx;v) := \mathbb E_{a,b,\bw}[v(a,b,\bw)\,\sigma_1(\eta\, a\langle \bw,\bh^{(1)}(\bx)\rangle + b)]$ is the infinite-width ($m_1\to\infty$) target the finite-$m_1$ network approximates.
- The finite network draws $\{(a_i,b_i,\bw_i)\}_{i=1}^{m_1}$ i.i.d. and computes $\frac1{m_1}\sum_i v(a_i,b_i,\bw_i)\sigma_1(\eta a_i\langle\bw_i,\bh^{(1)}(\bx)\rangle+b_i)$.

**Result (solved this session):**
$$\Big|\tfrac1{m_1}\sum_{i=1}^{m_1}v(a_i,b_i,\bw_i)\sigma_1(\eta a_i\langle \bw_i,\bh^{(1)}(\bx)\rangle+b_i) - f_{\infty,m_2}(\bx;v)\Big|
\lesssim \iota\,\frac{\|v\|_{L^2}}{\sqrt{m_1}}
\lesssim \frac{\iota}{\sqrt{m_1}}\|g\|_{L^2}\sum_{k=0}^p \eta^{-k}\|\bB^\star\|_{\rm op}^k r^{\frac{p-k}{4}},$$
uniformly over $\bx\in\mathcal D_2$, w.p. $\ge 1-2n_2\exp(-\iota^2/2)$.

**Method:** per-$\bx$ Bernstein concentration of the i.i.d. empirical mean over $m_1$ neurons (variance proxy $C_{\sigma_1}^2\|v\|_{L^2}^2$ from boundedness/Lipschitzness of $\sigma_1$, the same $C_{\sigma_1}$ constant used elsewhere in this paper's bounds), then union bound over the $n_2=|\mathcal D_2|$ points in $\mathcal D_2$. Notably this argument does **not** require an explicit definition of $\bh^{(1)}(\bx)$ — only that $\sigma_1$ is bounded/Lipschitz and $v\in L^2$ — so it sidesteps the recurring $\bh^{(1)}$-definition blocker noted in [[unsolved-w-h1-inner-product-bound-missing-definitions]].

**Caveat:** exact boundedness/Lipschitz constants for $\sigma_1$ and the precise definition of $f_{\infty,m_2}(\bx;v)$ as an expectation were inferred by analogy with the paper's other layer (cf. [[kernel-concentration-bound-K0-m2]]), not re-confirmed against the paper text this session — verify if this subtask's answer is built upon.
