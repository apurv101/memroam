---
id: 01a050e9-b60e-7af8-8747-95844b048009
name: quadratic-harmonic-sigma2-concentration
description: Concentration bound for (1/m2)sum(v_i^T A v_i)sigma2(v_i^T x) vs c2/B(d,2) x^T A x, given m2 >= C_sigma^2 C_4^{-1/2} d^4 ||A||_op^2
metadata:
  type: project
---

For $\bA$ such that $\bv^\top\bA\bv$ is a quadratic spherical harmonic, given $m_2\ge C_\sigma^2 C_4^{-1/2}d^4\|\bA\|_{\rm op}^2$, with high probability over $\bV$, uniformly for $\bx\in\cD$:

$$\left|\frac{1}{m_2}\sum_{i=1}^{m_2}(\bv_i^\top\bA\bv_i)\sigma_2(\bv_i^\top\bx) - \frac{c_2}{B(d,2)}\bx^\top\bA\bx\right| = O\!\left(\frac{\sqrt\iota}{d^2}\right),\quad \iota=\Theta(\log(dnm_2)).$$

**Derivation approach:** same Bernstein-inequality technique as [[kernel-concentration-bound-K0-m2]], applied to the i.i.d. sum over $m_2$ neurons of $(\bv_i^\top\bA\bv_i)\sigma_2(\bv_i^\top\bx)$, whose expectation over $\bv\sim$Unif-$\mathbb S^{d-1}(\sqrt d)$ is $\frac{c_2}{B(d,2)}\bx^\top\bA\bx$ (projection of $\sigma_2$ onto the degree-2 spherical harmonic $\bv^\top\bA\bv$, with $c_2$ the corresponding Hermite/Gegenbauer-type coefficient and $B(d,2)$ the dimension of the degree-2 harmonic space).
- Boundedness: $|\bv^\top\bA\bv\,\sigma_2(\bv^\top\bx)| \lesssim C_\sigma \|\bA\|_{\rm op}\cdot d$ (since $\bv^\top\bA\bv = O(d\|\bA\|_{\rm op})$ on the sphere of radius $\sqrt d$, and $|\sigma_2|\le C_\sigma$).
- Variance proxy uses the 4th-moment bound $\EE[\sigma_2^4]\le C_4/d^4$ (Assumption 4) combined with $\EE[(\bv^\top\bA\bv)^4]$ scaling, giving overall variance $O(\|\bA\|_{\rm op}^2/d^4)$ after Cauchy–Schwarz — this is why the required width scales as $m_2 \ge C_\sigma^2 C_4^{-1/2} d^4 \|\bA\|_{\rm op}^2$ (note the extra $\|\bA\|_{\rm op}^2$ factor vs. the plain kernel bound).
- Bernstein's two terms $\sqrt{\iota\|\bA\|_{\rm op}^2/(d^4m_2)} + \iota\|\bA\|_{\rm op}/m_2$ collapse to $O(\sqrt\iota/d^2)$ once $m_2\gtrsim d^4\|\bA\|_{\rm op}^2$ (first term dominates and the $\|\bA\|_{\rm op}$ dependence cancels against the width condition).
- Union bound over $\bx\in\cD$ (size $n$) absorbed into $\iota$.

Same family of results as [[kernel-concentration-bound-K0-m2]] — both are finite-width-vs-population concentration bounds for second-layer random features $\sigma_2(\bv^\top\bx)$, proved via scalar Bernstein + Assumption 4 moment bounds. Likely more such lemmas (e.g. degree-1 or degree-3 harmonic analogues, or first-layer $m_1$ versions) will appear in later sessions — check for companions with the same proof template.
