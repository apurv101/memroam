---
id: 01a050fc-7b65-7912-88ad-b1d0b8d3e246
name: unsolved-w-h1-inner-product-bound-missing-definitions
description: Subtask "bound |<w, h^(1)(x')>| given m2>=d^4 C_sigma^4, n>=C iota^2 d^2, w.p. >=1-4n exp(-iota^2/2) on w" was left unsolved — h^(1)(x') and w never defined in memory
metadata:
  type: project
---

Subtask: "Suppose $m_2\ge d^4C_\sigma^4$ and $n\ge C\iota^2d^2$ for some sufficiently large $C$. With high probability jointly on $\bV$ and the training dataset $\cD_1$, and with probability at least $1-4n\exp(-\iota^2/2)$ on $\bw$, for any $\bx'\in\cD_2$, upper bound $|\langle \bw, \mathbf h^{(1)}(\bx')\rangle|$."

Not solved — asked the user to confirm definitions instead of guessing (definition of $\mathbf h^{(1)}(\bx')$, e.g. $\sigma_1(\bW^{(1)}\bx')$ and a norm bound; definition/distribution/dimension of $\bw$ and whether independent of $\mathbf h^{(1)}(\bx')$). This is the 8th occurrence of the general blocker in [[recurring-blocker-decomposition-definitions-2411-17201]], and the first involving $\mathbf h^{(1)}$ and a bare inner product with $\bw$ (as opposed to $A_1/A_2/A_3/D_i$).

Note on probability structure: failure probability here is $4n\exp(-\iota^2/2)$ — double the $2n\exp(-\iota^2/2)$ (or $2n_2\exp(-\iota^2/2)$) seen for $A_3$. Plausible explanation (unconfirmed): this bound folds together two separate $2n\exp(-\iota^2/2)$-type tail events (e.g. a per-point sub-Gaussian bound on $\langle\bw,\mathbf h^{(1)}(\bx')\rangle$ plus a separate high-probability norm bound on $\|\mathbf h^{(1)}(\bx')\|$), each union-bounded over $n$ points. Worth confirming once real definitions are available — likely $A_3$ (or a related decomposition term) invokes this exact inner-product bound as a sub-lemma.

**Why:** Same as prior instances — the decomposition equation and term definitions have never been pasted into any session.

**How to apply:** Do not attempt to solve until the user provides: (1) the definition of $\mathbf h^{(1)}(\bx')$ and a known norm bound, (2) the definition/distribution/dimension of $\bw$ and its independence from $\mathbf h^{(1)}$, (3) how this inner-product bound relates to the $A_1/A_2/A_3/D_i$ decomposition terms already tracked.
