---
id: 01a050f3-3cff-7322-91d5-d7567702d7af
name: unsolved-D2-bound-missing-definition
description: Subtask "bound ||D_2||_inf given m2,n>=Cd^4" was left unsolved — no record of what D_2 is (matrix/vector, index set) or which decomposition it belongs to
metadata:
  type: project
---

A subtask asked to upper-bound $\|\bD_2\|_\infty$ with high probability over $\cD_1$ and $\cD_2$, given $m_2,n\ge Cd^4$. The session had **no record at all** of what $\bD_2$ denotes — not even a speculative definition. Unknown: what matrix/vector it is, its index set (e.g. rows/cols over $\cD_1,\cD_2$, or $[m_2]\times\cD_2$), and the decomposition it's part of (possibly a sibling of $D_1$ in something like $\hat f - f^* = D_1 + D_2 + \dots$, or a different layer's analogue of $\bD_{1,1}/\bD_{1,2}$ — see [[unsolved-D11-D12-bound-missing-definitions]]).

No answer was given for this subtask (unlike the D_{1,1}/D_{1,2} case, no guess was hazarded since there wasn't even enough context to speculate).

**Why:** This is the **third** subtask in this project (arXiv 2411.17201) referencing an undefined decomposition term not reproduced in the prompt or captured in memory — see also [[unsolved-A1-bound-missing-decomposition]] and [[unsolved-D11-D12-bound-missing-definitions]]. The pattern suggests subtask prompts assume continuity with the paper's decomposition/lemma numbering (e.g. "Lemma 20") that isn't being supplied.

**How to apply:** Before attempting this bound, get from the user (or the paper) the definition of $\bD_2$, the full decomposition it belongs to, and any lemma number it's meant to invoke. Given this is the third occurrence of the same gap, proactively ask the user up front — at the start of a session, or the first time an undefined symbol appears — whether they can share the paper's error-decomposition section/lemma list once, rather than re-hitting this wall subtask by subtask. Likely relevant background tools already in memory: [[kernel-concentration-bound-K0-m2]], [[quadratic-harmonic-sigma2-concentration]] (Bernstein-type concentration for $m_2\ge Cd^4$ regime), which may be the building blocks once $\bD_2$'s definition is known.
