---
id: 01a0507b-acbf-7e19-88c4-cb449a584d60
name: result-f-related-vector-fields-condition
description: Iff condition for v in X(Spec(A)) and w in X(Spec(B)) to be f-related, for a map f of local C^infty-ringed spaces Spec(B) -> Spec(A) of complete C^infty-rings.
metadata:
  type: project
---

Subtask result: given complete C^infty-rings A, B and a map of local C^infty-ringed spaces
uu{f}: Spec(B) -> Spec(A), let varphi: A -> B be the unique C^infty-ring map with
Spec(varphi) = uu{f}. Then vector fields v in X(Spec(A)) and w in X(Spec(B)) are
uu{f}-related iff

  varphi o bGamma_A(v) = bGamma_B(w) o varphi

i.e. iff their corresponding derivations (via the bGamma isomorphism, see
[[result-gamma-isomorphism-vector-fields-derivations]]) are varphi-related, in the sense of
"Fact 3.14" in this project's source material.

**Why:** This reduces the geometric notion of f-relatedness of vector fields on spectra of
complete C^infty-rings to the algebraic notion of varphi-relatedness of derivations, via the
bGamma correspondence — directly analogous to the classical manifold fact that vector fields
v, w are f-related iff their derivations satisfy Df* o w# = v# o f* (pullback commutes with
the derivations).

**How to apply:** In later subtasks of project 2503.19064 involving maps of C^infty-ringed
spaces and f-relatedness of vector fields, use this iff characterization directly; it depends
on the bGamma isomorphism result and on whatever "Fact 3.14" (varphi-relatedness of
derivations) states in the source material — check that fact's precise statement if needed.
