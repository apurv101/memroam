---
id: 01a05080-665a-7426-a335-d8cc5a30eb25
name: result-complete-vector-fields-have-flow
description: For finitely generated, germ-determined C^infty-ring A with Spec(A)=(X_A,O_A), a vector field v has a flow iff it is complete (K_p=R for all p); flow is unique, Phi_t(p)=mu_p(t), and each Phi_t is an automorphism of Spec(A).
metadata:
  type: project
---

Subtask result: let A be a finitely generated, germ-determined C^infty-ring, Spec(A) = (X_A, O_A) the affine C^infty-scheme. A vector field v in X(Spec(A)) admits a global flow iff it is **complete**, i.e. in the maximal-integral-curve data (mu_p, K_p) for each point p in X_A (Fact 4.1), K_p = R for every p.

When complete, the flow is unique and given by Phi_t(p) = mu_p(t); each Phi_t is an automorphism of Spec(A) (not just an endomorphism).

**Why:** Proof combines Facts 3.16, 4.1, 4.2, and 5.6 from the paper. Germ-determinedness of A is essential: it's what lets the ambient classical flow on R^n (from the maximal integral curves) descend to a well-defined flow on Spec(A) itself, since it lets local germ data control global behavior on the (possibly non-manifold) spectrum.

**How to apply:** In later subtasks in this project (2503.19064) that reference flows, completeness of vector fields, or automorphisms of Spec(A), recall this is the governing theorem: flow existence = completeness (K_p=R everywhere), uniqueness holds automatically, and flow maps are automorphisms. Related: [[result-gamma-isomorphism-vector-fields-derivations]], [[result-f-related-vector-fields-condition]].
