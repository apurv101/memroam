---
id: 01a05077-703c-714a-9a20-6c18ab334763
name: result-closed-set-equals-zero-set-of-vanishing-ideal
description: Proved Z(I) = C where I is the vanishing ideal of closed C subset M (converse direction to Z_J/X_A correspondence)
metadata:
  type: project
---

Project 2503.19064 (research paper on $C^\infty$-rings / real spectra of smooth ideals).

**Setup:** $M$ a manifold, $C \subset M$ closed, $I := \{f \in \cin(M) : f|_C = 0\}$ the vanishing ideal of $C$.

**Result proved this session:** the zero set $Z$ of $I$ equals $C$ itself, i.e. $C$ is recovered exactly from its vanishing ideal.

Proof strategy:
- $C \subseteq Z$: trivial, every $f \in I$ vanishes on $C$ by definition.
- $Z \subseteq C$: for $p \notin C$, since $C$ is closed use a smooth bump function $f \in \cin(M)$ with $f \equiv 0$ on $C$ (so $f \in I$) but $f(p) \neq 0$; hence $p \notin Z$.

Relation to prior work: this is the "closed subsets recovered from their vanishing ideal" fact, complementary to [[result-zj-xa-homeomorphism]] (which shows $Z_J \cong X_\scA$ for a general ideal $J$). Together they support a Galois-connection / duality picture between (closed subsets of $M$) and (ideals of $\cin(M)$, or their zero sets): vanishing-ideal and zero-set are mutually inverse on closed sets, at least for $C$ closed — likely the paper builds toward characterizing which ideals $J$ satisfy $J = I(Z_J)$ (radical-type ideals) using this and the $\R$-points correspondence.
