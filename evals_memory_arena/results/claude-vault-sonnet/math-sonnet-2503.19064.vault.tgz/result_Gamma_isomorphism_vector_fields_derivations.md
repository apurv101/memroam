---
id: 01a05078-eda9-703b-97a1-1ffdd651905b
name: result-gamma-isomorphism-vector-fields-derivations
description: For complete C^infty-ring A with Spec(A)=(X_A,O_A), the map bGamma: X(Spec(A)) -> CDer(A) (vector fields on the affine scheme to C^infty-derivations of A) is an isomorphism of real vector spaces, real Lie algebras, AND A-modules (all three structures simultaneously).
metadata:
  type: project
---

Subtask result: given a complete C^infty-ring A (so eps_A: A -> Gamma(Spec(A)) is an isomorphism), and Spec(A) = (X_A, O_A) the associated affine scheme, the map

  bGamma: X(Spec(A)) -> CDer(A),  bGamma(v) = eps_A^{-1} o Gamma(v) o eps_A

is an isomorphism of **real vector spaces**, **real Lie algebras**, and **A-modules** — i.e. all three of the multiple-choice options (A, B, C) hold simultaneously, not just one.

**Why:** This is a structural fact about the correspondence between global vector fields on the spectrum of a complete C^infty-ring and derivations of that ring — the isomorphism respects the additive/linear structure, the Lie bracket, and the module structure over A all at once.

**How to apply:** In this ongoing project (paper 2503.19064, on C^infty-rings / synthetic differential geometry style spectra), when later subtasks reference bGamma, X(Spec(A)), or CDer(A), recall that the standard result is a triple isomorphism (vector space + Lie algebra + module), analogous to the classical fact that vector fields on a manifold M correspond to derivations of C^infty(M) as R-vector spaces, Lie algebras, and C^infty(M)-modules simultaneously.
