---
id: 01a050da-e807-7325-abfa-70f8d1be44cc
name: escape-time-region-bound-tau-eq-O-1-over-gamma
description: Derived (not paper-verified) tau=O(1/gamma) time bound for MFD to decrease LL by ~Omega(gamma^2*alpha*LL^4/(k^5*d)) in the region lambda_min(Sigma_mu,mu)=Omega(1/k), given the linear-homotopy PL-type descent hypothesis and eigenfunction-overlap alpha
metadata:
  type: project
---

**Subtask setup:** MFD birth-death on $\LL$ with: (i) exists competitor $\bR\in\BB_1(k)$ with $\frac{\rd}{\rd s}\big|_{s=0}\LL(\bar\mu_s)\le0$ along linear homotopy $\bar\mu_s=(1-s)\mu+s\bR\sharp\mu^\circ$, and this derivative is $\ge-O(k^{-1}\LL(\mu_t)^2)$; (ii) eigenfunction-overlap hypothesis $\big|\int\psi_0^\top\nabla\delta\LL(\mu_t)\rd\mu_t\big|\ge\alpha$. Asked for asymptotic $\tau$ so that in the region $\{\lambda_\min(\bSig_{\mu,\mu})=\Omega(1/k)\}$, $\LL(\mu_{t+\tau})\le\LL(\mu_t)-\widetilde\Omega(\gamma^2\alpha\LL(\mu_t)^4/(k^5d))$.

**Answer given:** $\tau=\widetilde O(1/\gamma)$.

**Reasoning (scaling argument, not verified against source):** combine the chi²-PL descent bound (giving instantaneous rate $\frac{\rd}{\rd t}\LL(\mu_t)\le-\widetilde\Omega(\gamma^3\alpha\LL(\mu_t)^4/(k^5d))$ in this region) with a standard descent-lemma step-size cap $\tau\le1/\gamma$ where $\gamma$ is treated as a Lipschitz constant of $\nabla\delta\LL$ (analogous to $C_2$/$L$ in [[escape-time-bound-negative-eigenvalue-eigenfunction]] and the missing $C_2$ in [[missing-core-definitions-H-mu-L-Sigma]]). Integrating the rate over the window $[t,t+\tau]$ reproduces the target decrease exactly.

**Caveat:** $\gamma$'s exact definition and the instantaneous-rate lemma it's drawn from are not in stored memory — see [[missing-core-definitions-H-mu-L-Sigma]] (third recurrence of this gap in the Lemma E.5 neighborhood). If the user supplies Appendix E text in a future session, re-derive and replace this entry.

**How to apply:** If a later subtask needs this same $\tau$ bound or asks to verify/extend it, use this scaling relation but flag that it should be re-checked once $\gamma$ is actually defined.
