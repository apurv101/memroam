---
id: 01a050ca-d44e-7e6f-a5be-d55293519fa5
name: lambda0-hessian-upper-bound-chi2-competitor
description: Solved lambda_0 <= -Lambda/chi_bar^2, the second-order (Rayleigh quotient) analogue of the chi^2-PL descent bound, bounding the smallest eigenvalue of the Hessian operator H_{mu_t}
metadata:
  type: project
---

Subtask: $F$ depends on $\mu$ only through the MLP layer $h_\mu$. Given MFD \eqref{eqn:mfd} at time $t$ admits $\bar\mu\in\PP_2(\Theta)$ with $\chi^2(\bar\mu,\mu_t)\le\bar\chi^2$ such that along the linear homotopy $\bar\mu_s=(1-s)\mu_t+s\bar\mu$, $\frac{\rd^2}{\rd s^2}\big|_{s=0}F(\bar\mu_s)\le-\Lambda$. Asked: upper bound $\lambda_0$, the smallest eigenvalue of $\HH_{\mu_t}$.

**Answer given:**
$$\lambda_0 \le -\frac{\Lambda}{\bar\chi^2}$$

**Derivation:** With $\eta=\frac{\rd\bar\mu}{\rd\mu_t}-1\in L^2(\Theta,\mu_t;\R^{k+d})$ (so $\|\eta\|^2_{L^2(\mu_t)}=\chi^2(\bar\mu,\mu_t)\le\bar\chi^2$), the second derivative along the linear homotopy equals the quadratic form of the Hessian operator: $\frac{\rd^2}{\rd s^2}\big|_{s=0}F(\bar\mu_s)=\langle\eta,\HH_{\mu_t}\eta\rangle$. Since $\HH_{\mu_t}$ is compact self-adjoint (per Lemma E.5, see [[missing-core-definitions-H-mu-L-Sigma]]), $\lambda_0=\inf_{\eta\ne0}\langle\eta,\HH_{\mu_t}\eta\rangle/\|\eta\|^2 \le \langle\eta,\HH_{\mu_t}\eta\rangle/\|\eta\|^2 \le -\Lambda/\|\eta\|^2 \le -\Lambda/\bar\chi^2$.

This is the second-order counterpart of [[chi2-pl-inequality-mfd-descent-bound]] (first-order: $\rd/\rd t\,F(\mu_t)\le-\delta^2/\bar\chi^2$ via Cauchy-Schwarz on the variance identity) — same competitor/homotopy setup, but proved via a Rayleigh-quotient argument on the Hessian operator $\HH_{\mu_t}$ instead.

**Partially resolves [[missing-core-definitions-H-mu-L-Sigma]]:** confirms $\HH_{\mu_t}$'s quadratic form is literally the second variation of $F$ (or $\LL$) along linear homotopies of $\mu_t$ toward competitors — i.e. it is the Hessian of the functional at $\mu_t$ acting on perturbation directions $\eta=\rd\bar\mu/\rd\mu_t-1$. Explicit kernel formula $\bH_\mu(\theta,\theta')$ still not recovered.
