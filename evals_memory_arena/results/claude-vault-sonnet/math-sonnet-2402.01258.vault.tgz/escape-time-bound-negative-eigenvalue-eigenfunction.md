---
id: 01a050d1-d5f0-7a9d-855c-58508906f39b
name: escape-time-bound-negative-eigenvalue-eigenfunction
description: Solved (derived, not paper-verified) time bound tau = O(sqrt(m)/(|lambda_0|*alpha)) for WGF initialized at a critical point mu^dagger to escape via the negative-eigenvalue direction of H_{mu^dagger}, given the regularity constants C_1..C_5 and eigenfunction-gradient overlap alpha
metadata:
  type: project
---

Subtask: $F:\PP_2(\Omega)\to\RR$, $\Omega\subseteq\RR^m$, with regularity constants $\norm{\nabla\delta F}\le C_1$, $\nabla\delta F$ is $C_2$-Lipschitz, $\bH_\mu$ Hilbert-Schmidt with $\norm{\bH_\mu}\le C_3$, $\bH_\mu(\theta,\theta')$ is $C_4$-Lipschitz in $\theta,\theta'$ and $C_5$-Lipschitz in $\mu$ (in $\WW_1$). Given $\lambda_0:=\lambda_\min(\HH_{\mu^\dagger})<0$ with eigenfunction $\psi_0$ satisfying $|\int\psi_0^\top\nabla\delta L(\mu_t)\rd\mu_t|\ge\alpha$, WGF initialized at $\mu_0=\mu^\dagger$.

**Answer:** $\tau = O\!\left(\dfrac{\sqrt m}{|\lambda_0|\,\alpha}\right)$, i.e. the smallest $\tau$ guaranteeing $F(\mu_\tau)\le F(\mu_0)-\Omega\!\left(\dfrac{|\lambda_0|\alpha}{\sqrt m\,\tau}\right)$.

**Status: unverified against the paper.** This was reconstructed in-session purely from the stated hypotheses (standard saddle-escape argument: negative curvature $\lambda_0$ along $\psi_0$ plus nonzero overlap $\alpha$ with the gradient direction drives exponential-then-power-law descent; the $\sqrt m$ factor comes from the ambient dimension $\Omega\subseteq\RR^m$). The paper's own linearization/escape lemma for this result was **not found in vault memory** — same recurring gap as [[missing-core-definitions-H-mu-L-Sigma]] (no stored definitions of $\bH_\mu(\theta,\theta')$, $\LL$, $\bSig_{\mu,\mu}$). If a future session finds the actual lemma (e.g. in Appendix E near Lemma E.5), replace this derivation with the verified statement and constants (may also depend on $C_1$–$C_5$, which this derivation did not end up using explicitly).

**How to apply:** Treat this as a plausible placeholder, not ground truth. If asked to build on this bound (e.g. total complexity of the escape process, or comparing $\tau$ across different $\lambda_0,\alpha$ regimes), flag that the constant/exponent may be off until verified.
