---
id: 01a050ba-4096-761c-9af4-2f5000010d82
name: chi2-pl-inequality-mfd-descent-bound
description: Solved bound d/dt F(mu_t) <= -delta^2/chi_bar^2 for functional F of MLP layer h_mu under MFD, given a chi^2-close mu_bar with negative directional derivative along linear homotopy
metadata:
  type: project
---

Subtask: $F$ depends on $\mu$ only through the MLP layer $h_\mu$. Given MFD \eqref{eqn:mfd} at time $t$ admits $\bar\mu\in\PP_2(\Theta)$ with $\chi^2(\bar\mu,\mu_t)\le\bar\chi^2$ such that along the linear homotopy $\bar\mu_s=(1-s)\mu_t+s\bar\mu$, $\frac{\rd}{\rd s}\big|_{s=0}F(\bar\mu_s)\le-\delta\le0$. Asked: upper bound $\frac{\rd}{\rd t}F(\mu_t)$.

**Answer given:**
$$\frac{\rd}{\rd t}F(\mu_t)\ \le\ -\frac{\delta^2}{\bar\chi^2}$$

**Caveat resolved:** a later subtask explicitly states "MFD with birth-death on $\LL$", confirming \eqref{eqn:mfd} is the **Fisher–Rao (birth-death/mass-reweighting) gradient flow** $\partial_t\mu_t=-\mu_t(g_t-\E_{\mu_t}[g_t])$, $g_t=\delta F/\delta\mu(\cdot;\mu_t)$ — matches the assumption used to derive this bound. See [[chi2-pl-bound-birth-death-competitor-R]] for the generalized version of this result with the competitor written as $\bR\sharp\mu^\circ$.
