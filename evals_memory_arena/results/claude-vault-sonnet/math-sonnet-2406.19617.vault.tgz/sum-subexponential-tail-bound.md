---
id: 01a05094-ba4e-7ded-ac41-06b21564437f
name: sum-subexponential-tail-bound
description: Tail bound for sums of independent sub-exponential-type r.v.s satisfying P[|z_j|>=K]<=2exp(-K/sigma_j)
metadata:
  type: project
---

For independent real-valued $z_1,\dots,z_k$ (assumed mean-zero) satisfying
$$\mathbb P[|z_j|\ge K]\le 2\exp(-K/\sigma_j) \quad \forall j\in[k],\ K\ge 0,$$
the following Bernstein-type bound on the sum holds:

$$\mathbb P\Big[\Big|\sum_{j=1}^k z_j\Big|\ge K\Big]\ \le\ 2\exp\left(-\min\left(\frac{K^2}{16\sum_{j=1}^k\sigma_j^2},\ \frac{K}{4\max_j\sigma_j}\right)\right)$$

**Why:** This is the standard sub-exponential concentration regime — Gaussian-like ($K^2$) decay for moderate $K$, transitioning to exponential ($K$) decay governed by the heaviest tail $\max_j\sigma_j$ for large $K$ (Bernstein's inequality form).

**How to apply:** If $z_j$ are not centered, replace $z_j$ with $z_j - \mathbb E z_j$ and shift $K$ by $\sum_j \mathbb E z_j$ before applying. Reuse this directly if a later subtask in this project needs a union/sum tail bound for variables with exponential-type per-coordinate tails (e.g. bounding $|\sum_j z_j|$ where each $z_j$ has a sub-exponential MGF/tail parameterized by $\sigma_j$).
