# 2406.19617 — memory index

- [algorithm-1-definition-missing](algorithm-1-definition-missing.md) — Algorithms 1-4 exact formulas + main theorem setup not stored — RECURRING blocker, hit in 4+ sessions incl. top-level minimax regret theorem. Ask user to paste full section (setup+algorithms+theorems) once and save permanently.
- [result-fx-fstar-bound-via-local-quadratic-model](result_fx_fstar_bound_via_local_quadratic_model.md) — "Solved: for strongly-convex, rho-Lipschitz-Hessian f, with tilde-x = x_B - H^{-1}grad f(x_B) (H=Hessian at x_B) and tilde-f the quadratic model recentered at tilde-x, bound f(x)-f* in terms of tilde-f(x) plus cubic remainder terms"
- [sum-subexponential-tail-bound](sum-subexponential-tail-bound.md) — Tail bound for sums of independent sub-exponential-type r.v.s satisfying P[|z_j|>=K]<=2exp(-K/sigma_j)
