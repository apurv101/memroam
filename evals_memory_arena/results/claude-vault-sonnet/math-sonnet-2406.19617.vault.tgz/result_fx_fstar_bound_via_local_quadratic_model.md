---
id: 01a050a3-1680-7c7d-8cee-c318c71d9a58
name: result-fx-fstar-bound-via-local-quadratic-model
description: "Solved: for strongly-convex, rho-Lipschitz-Hessian f, with tilde-x = x_B - H^{-1}grad f(x_B) (H=Hessian at x_B) and tilde-f the quadratic model recentered at tilde-x, bound f(x)-f* in terms of tilde-f(x) plus cubic remainder terms"
metadata:
  type: project
---

**Result (paper 2406.19617, subtask "bound f(x)-f*"):** Let $f$ be $m$-strongly convex with $\rho$-Lipschitz Hessian. Fix $\vct x_\textup{B}$, let $H=\nabla^2f(\vct x_\textup{B})$, $g=\nabla f(\vct x_\textup{B})$, $\tilde{\vct x}=\vct x_\textup{B}-H^{-1}g$ (the exact Newton point), and $\tilde f(\vct x)=\tfrac12(\vct x-\tilde{\vct x})^\intercal H(\vct x-\tilde{\vct x})$. Then for any $\vct x$:
$$f(\vct x)-f^*\;\le\;\tilde f(\vct x)+\frac{\rho}{6}\Big(\|\vct x-\vct x_\textup{B}\|^3+\|\vct x_\textup{B}-\vct x^*\|^3\Big),$$
and since $m\|\vct x_\textup{B}-\vct x^*\|\le\|g\|$ (strong convexity), also
$$f(\vct x)-f^*\;\le\;\tilde f(\vct x)+\frac{\rho}{6}\left(\|\vct x-\vct x_\textup{B}\|^3+\frac{\|g\|^3}{m^3}\right).$$

**Proof sketch:** Let $q(\vct y)=f(\vct x_\textup{B})+g^\intercal(\vct y-\vct x_\textup{B})+\tfrac12(\vct y-\vct x_\textup{B})^\intercal H(\vct y-\vct x_\textup{B})$ (exact 2nd-order Taylor model at $\vct x_\textup{B}$). Lipschitz-Hessian integral remainder: $|f(\vct y)-q(\vct y)|\le\frac{\rho}{6}\|\vct y-\vct x_\textup{B}\|^3$ for all $\vct y$. Algebraic identity (since $\tilde{\vct x}=\arg\min q$ and $\tilde f$ shares $q$'s Hessian): $q(\vct y)=q(\tilde{\vct x})+\tilde f(\vct y)$. Apply the remainder bound at $\vct y=\vct x^*$ to get $f^*\ge q(\tilde{\vct x})-\frac{\rho}{6}\|\vct x^*-\vct x_\textup{B}\|^3$ (using $q(\tilde{\vct x})\le q(\vct x^*)$), then apply it at $\vct y=\vct x$ to get $f(\vct x)\le q(\tilde{\vct x})+\tilde f(\vct x)+\frac{\rho}{6}\|\vct x-\vct x_\textup{B}\|^3$; combine.

**Why:** This decomposes the suboptimality of any point $\vct x$ into (i) a purely algorithmic error term $\tilde f(\vct x)$ — how far $\vct x$ is (in Hessian-weighted distance) from the *exact* Newton step at $\vct x_\textup{B}$ — and (ii) a cubic Taylor-remainder term controlled by Hessian-Lipschitzness. It's the natural first half of a "local-Newton-phase" convergence analysis: part 2 of the same subtask asks to bound $\mathbb E[\tilde f(\vct x)]$ for $\vct x$ output by a specific stochastic Newton algorithm (Algorithm 4), which reduces the whole analysis to controlling $\mathbb E[\tilde f(\vct x)]$.

**How to apply:** Reuse this bound whenever the project needs to convert an estimate of $\mathbb E[\tilde f(\vct x)]$ (Hessian-weighted error vs. the exact Newton point) into a bound on $\mathbb E[f(\vct x)-f^*]$: just add $\frac{\rho}{6}(\mathbb E\|\vct x-\vct x_\textup{B}\|^3+\|g\|^3/m^3)$ (or the non-expectation cubic term with $\vct x_\textup{B}$-to-$\vct x^*$ distance if that's more natural in context). See [[algorithm-1-definition-missing]] for the blocking gap on the second half of this subtask (bounding $\mathbb E[\tilde f(\vct x)]$ for Algorithm 4's output).
