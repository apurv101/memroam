---
id: 01a05113-b7e0-78b2-a46a-00835b1cef75
name: result-uniform-max-alpha-gp-confidence-bound
description: "Paper 2309.02236: solved bound on max_V max_{s,a} 2*alphabar*e^{M/alphaubar}*max_{alpha in [alphaubar,alphabar]} |E_{Pfhatn}[e^{-V/alpha}]-E_{Pf}[e^{-V/alpha}]|; flags possible sqrt(d) vs d prefactor mismatch to double-check"
metadata:
  type: project
---

Subtask: for $\mathcal V$ = value functions $\mathcal S\to[0,1/(1-\gamma)]$, $M=1/(1-\gamma)$,
$\overline\alpha=M/\rho$, $\underline\alpha$ from Lemma 9 (found to be $\underline\alpha=\alpha^*/2$),
bound w.p. $\ge1-\delta$:
$$\max_{V\in\mathcal V}\max_{s,a}2\overline\alpha e^{M/\underline\alpha}\max_{\alpha\in[\underline\alpha,\overline\alpha]}\big|\mathbb E_{P_{\hat f_n}(s,a)}[e^{-V(s')/\alpha}]-\mathbb E_{P_f(s,a)}[e^{-V(s')/\alpha}]\big|$$

**Result:**
$$\le \frac{2\overline\alpha\sqrt d}{\sigma}\,e^{M/\underline\alpha}\,\beta_n(\delta)\,\sup_{s,a}\max_{i\in[d]}\sigma_n(s,a,i)$$

**Derivation:** the inner $\max_{s,a}\max_{\alpha}|\cdots|$ term is exactly the quantity solved in
[[gaussian-softmin-lipschitz-plus-gp-l2-bound]]; the $\max_{V\in\mathcal V}$ is vacuous since that
bound already holds uniformly over $V\in[0,M]$ via the Lipschitz argument. Just multiply through by
the constant prefactor $2\overline\alpha e^{M/\underline\alpha}$ pulled outside all the maxes.

**⚠ Open flag to verify in a future session:** this solution's final form used the $\sqrt d/\sigma$
prefactor from [[gaussian-softmin-lipschitz-plus-gp-l2-bound]] but swapped its $\ell_2$-norm term
$\|\sigma_n([s,a]_n)\|_2$ for a per-coordinate max $\sup_{s,a}\max_i\sigma_n(s,a,i)$ (dropping the
$2\sqrt d/\sqrt n$ additive term and the argmin-discretization notation $[s,a]_n$ too, replaced by a
plain $\sup_{s,a}$). Per the note in [[gaussian-softmin-lipschitz-plus-gp-l2-bound]], $\sqrt d/\sigma$
should be paired with the $\ell_2$-form bound, and $d/\sigma$ with the max-form bound — mixing them as
done here may be an error. If a later subtask needs this exact bound again, re-derive from
[[gp-l2-bound-f-mun]]'s $\ell_2$ form directly (giving $2\overline\alpha\sqrt d e^{M/\underline\alpha}/\sigma\cdot(\beta_n(\delta)\|\sigma_n([s,a]_n)\|_2+2\sqrt d/\sqrt n)$) rather than trusting the max-form version recorded here.
