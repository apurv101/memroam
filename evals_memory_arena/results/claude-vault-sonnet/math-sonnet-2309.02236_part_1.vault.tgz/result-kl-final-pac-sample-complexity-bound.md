---
id: 01a05118-dd6e-7b85-b4d6-1f5abae6e4b2
name: result-kl-final-pac-sample-complexity-bound
description: "Paper 2309.02236: solved final PAC sample-complexity bound N_KL such that N>=N_KL implies max_s |V^R_{hpi_N,f}(s) - V^R_{pi*,f}(s)| <= epsilon w.p. >=1-delta, for KL-uncertainty robust MDPs (Algorithm 1 = MVR)"
metadata:
  type: project
---

Subtask: for the KL-divergence uncertainty set, give an asymptotic upper bound $N_{\mathrm{KL}}$ such that for all
$N\ge N_{\mathrm{KL}}$,
$$\max_s\big|V^{\text R}_{\hat\pi_N,f}(s)-V^{\text R}_{\pi^*,f}(s)\big|\le\epsilon$$
w.p. $\ge1-\delta$, where $\pi^*$ is robust-optimal for true nominal dynamics $f$ and $\hat\pi_N$ is robust-optimal
for the learned nominal dynamics $\hat f_N$ via \textsc{MVR} (Algorithm 1), $\delta\in(0,1)$, $\epsilon\in(0,\tfrac1{1-\gamma})$.

**Solved bound (this session, part_1):**
$$N_{\mathrm{KL}}=\mathcal O\!\left(\frac{\gamma^{2}L_V^{2}\,d^{3}\,\Gamma_{Nd}\,\beta_N^{2}(\delta)}{(1-\gamma)^{2}\,\epsilon^{2}}\right)$$

**Derivation sketch:** reduces to term $(ii):=|V^R_{\hat\pi_N,\hat f_N}(s)-V^R_{\pi^*,f}(s)|$
(see [[result-value-function-estimation-error-bound-term-ii]]) which is itself $\le 3\times$ the fixed-policy
term-$(i)$ bound $|V^R_{\hpi,f}(s)-V^R_{\hpi,\hat f_N}(s)|\le\frac{\gamma L_V\sqrt d}{1-\gamma}\big(\beta_N(\delta)\sup\max_i\sigma_N(s,a,i)\big)$
(see [[result-value-function-estimation-error-bound-term-i]]), then substituting the kernel/GP confidence-width
scaling $\sigma_N(s,a,i)\le d\sqrt{2e\Gamma_{Nd}/N}$ and inverting $\le\epsilon$ for $N$.

**Contrast with $\chi^2$ case:** this is the KL analogue of [[result-chi2-final-pac-sample-complexity-bound]].
Because the KL-ball term-$(i)$ bound is **linear** (Lipschitz) in the estimation-error/confidence-width term rather
than entering through a square root (Hölder-$\tfrac12$, as in the $\chi^2$ dual), the final rate here is
$\epsilon^{-2}$, contrasting with $\chi^2$'s $\epsilon^{-4}$. This mirrors the same structural split already
recorded between [[result-softmin-kl-ball-sample-complexity-bound]] and [[result-chi2-ball-tv-bound]].

**Caveat:** this session's chat-side answer text claimed a vault write failed ("permission denied") and the
result was never persisted before this write — that claim was incorrect/stale; the vault was reachable and this
file is the actual persisted record. Not independently re-verified against the source paper (relies on
$\beta_N(\delta)$, $\Gamma_{Nd}$, $L_V$ definitions established earlier in-session); re-check if unavailable in a
future session.
