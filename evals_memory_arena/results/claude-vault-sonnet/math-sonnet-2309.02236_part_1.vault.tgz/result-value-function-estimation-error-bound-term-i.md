---
id: 01a050f9-bc5d-7808-93db-bcd25e8d0877
name: result-value-function-estimation-error-bound-term-i
description: "Paper 2309.02236: bound on (i) = |V^R_{hpis,f}(s) - V^R_{hpis,fhat_n}(s)| — already fully solved in sibling space 2309.02236_part_2, don't re-derive; this file just records the part_1 attempt and the discrepancy found"
metadata:
  type: project
---

Subtask "upper bound $(i):=|V^{\text{R}}_{\hpis,f}(s)-V^{\text{R}}_{\hpis,\hat{f}_{n}}(s)|$" was posed in this
(part_1) space, but is **already fully solved with a verified derivation** in
`2309.02236_part_2/result_robust_value_function_estimation_error_bound.md`:

$$(i)\;\le\;\frac{\gamma L_V\sqrt d}{1-\gamma}\Big(\beta_n(\delta)\sup_{s,a}\max_{i\in[d]}\sigma_n(s,a,i)+\frac{1}{\sqrt n}\Big)\quad\text{w.p.}\ge1-\delta$$

using: contraction split (Lemma 8) + KL-ball translation invariance under the additive-Gaussian-noise
transition model + Lemma 4's confidence bound + Assumption 1's discretization term. That derivation also
relies on `2309.02236_part_2/result_gaussian_softmin_expectation_bound.md` and
`result_softmin_dual_alpha_to_zero_limit.md` as supporting lemmas, and on `[[gp-l2-bound-f-mun]]` (this
space) for the $\beta_n(\delta)\sigma_n$ confidence-bound piece.

**This session (part_1) independently re-derived the same bound shape** via a different route (dual
representation of the robust value function + exponential-tilting Lipschitz argument, valid uniformly in
the dual variable $\alpha\to0$), landing on the single-output special case
$(i)\le\frac{\gamma L_V}{1-\gamma}\beta(\delta)\sigma_n(s,\hpis(s))$. Same shape, consistent with the
part_2 multi-output result.

**Discrepancy to check in a future session:** this session's derivation cited "Lemma 2" (dual
representation) and "Lemma 3" (GP confidence bound $|f-\mu_n|\le\beta(\delta)\sigma_n$), whereas
`[[gp-l2-bound-f-mun]]` and part_2's solved file cite "Lemma 4" for the analogous GP confidence bound.
Lemma numbering may differ between paper sections/versions seen in different sessions, or one session
mislabeled — verify against the actual paper text before citing lemma numbers in downstream work.

**Action for future part_1 sessions:** if this subtask comes up again, check part_2's memory space first
before re-deriving. Term "(ii)" (the related term $|V^R_{\hpis,\hat f_n}(s)-V^R_{\pi^*,f}(s)|$, previously
unsolved per part_2's `result_ii_bound_not_captured.md`) has since been solved in this space — see
[[result-value-function-estimation-error-bound-term-ii]].
