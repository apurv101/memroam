---
id: 01a05106-2d3f-7981-876b-c737b46cf6ff
name: gaussian-softmin-lipschitz-plus-gp-l2-bound
description: "Paper 2309.02236: final combined bound on |E_{P_fhat_n}[e^{-V/alpha}]-E_{P_f}[e^{-V/alpha}]| using the sqrt(d)/sigma Lipschitz argument plus the ||sigma_n||_2-form GP confidence bound; resolves sqrt(d) vs d ambiguity in sibling memory"
metadata:
  type: project
---

Subtask: for $V:\mathcal S\to[0,1/(1-\gamma)]$, $\alpha>0$, $P_{\hat f_n}(s,a)=\mathcal N(\hat f_n(s,a),\sigma^2I)$, $P_f(s,a)=\mathcal N(f(s,a),\sigma^2I)$, bound
$$\big|\mathbb E_{P_{\hat f_n}(s,a)}[e^{-V(s')/\alpha}]-\mathbb E_{P_f(s,a)}[e^{-V(s')/\alpha}]\big|.$$

**Result (w.p. $\ge1-\delta$):**
$$\le \frac{\sqrt d}{\sigma}\left(\beta_n(\delta)\,\|\sigma_n([s,a]_n)\|_2+\frac{2\sqrt d}{\sqrt n}\right)$$

**Derivation:** combine two already-solved pieces —
1. [[result-gaussian-softmin-expectation-bound]] (in `2309.02236_part_2`): $g=e^{-V/\alpha}\in[0,1]$ bounded, Stein's identity gives $G(\mu)=\mathbb E_{\mathcal N(\mu,\sigma^2I)}[g]$ is $\sqrt d/\sigma$-Lipschitz in $\mu$, uniformly over $\alpha>0$.
2. [[gp-l2-bound-f-mun]]: the $\ell_2$ confidence bound $\|\hat f_n(s,a)-f(s,a)\|_2\le\beta_n(\delta)\|\sigma_n([s,a]_n)\|_2+2\sqrt d/\sqrt n$.

Plugging (2) into the Lipschitz bound from (1) gives the result directly.

**Resolves the $\sqrt d$-vs-$d$ flag** left in [[result-gaussian-softmin-expectation-bound]]: $\sqrt d/\sigma$ is the correct prefactor *when paired with an $\ell_2$-norm confidence bound* like (2) above. The $d/\sigma$ variant only appears if instead paired with a per-coordinate max confidence bound ($\max_i\sigma_n(s,a,i)$ instead of $\|\sigma_n([s,a]_n)\|_2$) — both are self-consistent, just don't mix the Lipschitz form with the wrong confidence-bound convention.
