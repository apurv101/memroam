---
id: 01a050ed-c67a-7ba2-ae33-8862c488bf5a
name: gp-l2-bound-f-mun
description: Derived L2 bound on ||f(s,a)-mu_n(s,a)|| for GP model trained on n iterations, under Assumption 1 + Lemma 4's beta_n(delta)
metadata:
  type: project
---

Subtask solved: under Assumption 1, with $\beta_n(\delta)$ from Lemma 4, and a GP trained on
observations $\{s_1,\dots,s_n\}$ with inputs $\{(s_0,a_0),\dots,(s_{n-1},a_{n-1})\}$, derived a
uniform (prob $\ge 1-\delta$) bound on $\|f(s,a)-\mu_n(s,a)\|_2$ for all $(s,a)\in\mathcal S\times\mathcal A$,
where $[s,a]_n = \arg\min_{(s',a')\in\mathcal D_n(\mathcal S\times\mathcal A)} \|(s,a)-(s',a')\|_2$ (nearest
discretized point).

**Result:**
$$\|f(s,a)-\mu_n(s,a)\|_2 \le \beta_n(\delta)\,\|\sigma_n([s,a]_n)\|_2 + \frac{2\sqrt d}{\sqrt n}$$
for all $(s,a)$, with probability $\ge 1-\delta$, where
- $\beta_n(\delta) = 2B + \beta\!\left(\dfrac{\delta}{3C(B+\sqrt n\,\beta(2\delta/3n))^p n^{p/2} d}\right)$
- $\beta(\delta) = B + \dfrac{\sigma}{\lambda}\sqrt{2\log(2/\delta)}$
- $\|\sigma_n([s,a]_n)\|_2 = \sqrt{\sum_{i=1}^d \sigma_n([s,a]_n,i)^2}$ (per-coordinate GP posterior std, combined in $\ell_2$)
- $d$ = output dimension (state dimension), $B,\sigma,\lambda,C,p$ = constants from Assumption 1 / Lemma 4.

**Derivation approach (for reuse in later subtasks building on this):**
1. Apply Lemma 4 per-coordinate at the discretized point $[s,a]_n$ to get a scalar confidence bound for each of the $d$ output coordinates.
2. Assumption 1 provides the discretization cardinality $C B^p n^{p/2} d$ used inside the union-bound argument (over $d$ coordinates and the discretization grid growing with $n$), which is why $\beta_n(\delta)$'s confidence parameter has that factor in the denominator.
3. Assumption 1 is invoked *twice* more to extend from the discretized grid to the full continuous domain: once for the true (unknown) function $\tilde f$ and once for the posterior mean $\mu_n$, since both are assumed to lie in the RKHS $\mathcal H_k$ (this is where the extra additive $\tfrac{2\sqrt d}{\sqrt n}$ term and the $2B$ inside $\beta_n(\delta)$ come from).
4. Combine the $d$ per-coordinate scalar bounds into one $\ell_2$-norm bound via triangle inequality / Cauchy-Schwarz.

This is part of a paper reproduction/derivation project (paper likely arXiv 2309.02236, based on project space name — model-based RL / GP dynamics model regret analysis with multi-dimensional state). Notation used throughout: $f$ = true dynamics, $\mu_n,\sigma_n$ = GP posterior mean/std after $n$ steps, $\mathcal D_n$ = discretization of $\mathcal S\times\mathcal A$ at iteration $n$.

**Aliases confirmed in a later subtask:** the "MVR algorithm" (Algorithm 1) outputs dynamics estimate $\hat f_n(\cdot,\cdot) = \mu_n(\cdot,\cdot)$, i.e. $\hat f_n$ is just the paper's name for the GP posterior mean. $\mathcal I_d = \{1,\dots,d\}$ is the index set notation used for the per-coordinate sum in $\|\sigma_n(\cdot)\|_2$. Same result as above, just phrased as bounding $\|\mu_n(s,a)-f(s,a)\|_2$ (order flipped, same quantity).
