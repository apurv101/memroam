---
id: 01a05101-3971-7273-8083-a0d3ea99a00a
name: result-value-function-estimation-error-bound-term-ii
description: "Paper 2309.02236: solved bound on (ii) = |V^R_{hpis,fhat_n}(s) - V^R_{pi*,f}(s)|, via triangle inequality reducing to term (i) applied twice"
metadata:
  type: project
---

Subtask "upper bound $(ii):=\big|V^{\text{R}}_{\hpis,\hat f_n}(s)-V^{\text{R}}_{\pi^*,f}(s)\big|$" (gap
between robust value of the *learned* policy $\hpis$ under *learned* dynamics $\hat f_n$, and robust value
of the *optimal* policy $\pi^*$ under *true* dynamics $f$) — **solved in this (part_1) session**.

**Approach:** two-step optimality/triangle-inequality decomposition that reuses the already-established
term-$(i)$ bound $|V^R_{\hpis,f}(s)-V^R_{\hpis,\hat f_n}(s)|$ (see [[result-value-function-estimation-error-bound-term-i]]),
applied once to $\hpis$ and once to $\pi^*$:

$$(ii)\;\le\;2\,(i)(\hpis)+(i)(\pi^*)\;\le\;\frac{3\gamma L_V\sqrt d}{1-\gamma}\Big(\beta_n(\delta)\sup_{s,a}\max_{i}\sigma_n(s,a,i)+\frac{1}{\sqrt n}\Big)$$

i.e. $(ii)\le 3\times(i)$ (three copies of the single-term-$(i)$ bound, since the decomposition needs term
$(i)$ evaluated for both $\hpis$ and $\pi^*$, with the $\hpis$ instance counted twice via optimality of
$\hpis$ under $\hat f_n$ / $\pi^*$ under $f$).

This resolves the open item flagged in `2309.02236_part_2/result_ii_bound_not_captured.md` — that file's
speculative reconstruction (triangle split into an $(i)$-like term plus a policy-suboptimality term) was on
the right track; this session confirmed and completed it. Future sessions (in either part_1 or part_2)
should treat $(ii)$ as solved and can cite this bound directly.
