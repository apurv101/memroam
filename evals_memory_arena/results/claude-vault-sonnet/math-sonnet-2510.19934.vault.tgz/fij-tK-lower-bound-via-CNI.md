---
id: 01a050ec-9b1c-78b0-9d6a-a3bb664dcde0
name: fij-tK-lower-bound-via-CNI
description: "Paper 2510.19934: lower bound for f_{ij}^{tK} (m-strongly-convex, M-smooth losses) via Lemma B.3 (CNI) applied to Algorithm 1's random-walk update, in terms of recursive sequences a_k, b_k built from contraction constant c and per-step sensitivity s_k."
metadata:
  type: project
---

Subtask: assuming loss functions ℓ_i are m-strongly-convex and M-smooth, for any
γ_1,...,γ_{tK} ∈ [0,1] with γ_{tK}=1, lower-bound f_{ij}^{tK}.

Solution approach: apply Lemma B.3 (referred to as "CNI" — contraction/noise
inequality-type lemma) to the iterates of Algorithm 1. Key ingredients:

- Contraction constant c = max(|1-ηm|, |1-ηM|), coming from strong convexity +
  smoothness of ℓ_i and non-expansiveness of the projection step.
- Per-step sensitivity s_k = η·Δ·1{i_{r(k)} = i}, nonzero only on rounds k where
  the random walk visits node i.
- Recursions (b_0 = 0):
  a_{k+1} = γ_{k+1}(c·b_k + s_{k+1})
  b_{k+1} = (1-γ_{k+1})(c·b_k + s_{k+1})

Result:
  f_{ij}^{tK} ≥ G( (1/σ)·sqrt( Σ_{k=1}^{tK} a_k^2 ) )

where G and σ are quantities defined elsewhere in the paper's framework (not
re-derived here — check paper/prior context for exact definitions if picking
this back up).

Context: paper involves a distributed/decentralized SGD-type algorithm
(Algorithm 1) where a token/model performs a random walk over nodes i_{r(1)},
i_{r(2)}, ... and updates using each visited node's local loss ℓ_i; f_{ij}^{tK}
appears to track some influence/sensitivity of node i's data on iterate j at
time tK. This is the first memory saved for project 2510.19934 — no prior
context existed in the vault, so later sessions should treat Lemma B.3, G, σ,
Δ, and the exact meaning of f_{ij}^{tK} as needing re-verification against the
paper text if not otherwise recorded by then.
