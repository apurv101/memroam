---
id: 01a050f1-9556-7540-9958-e49384a30b4f
name: min-sum-ak2-piecewise-sensitivity
description: "Paper 2510.19934: closed-form min of sum a_k^2 (from [[fij-tK-lower-bound-via-CNI]] recursion) for piecewise-constant sensitivity s_k=s on [0,K], 0 on [K+1,tK], with b_0=b_{tK}=0."
metadata:
  type: project
---

Subtask: for the a_k/b_k recursion in [[fij-tK-lower-bound-via-CNI]]
(a_{k+1}=γ_{k+1}(c·b_k+s_{k+1}), b_{k+1}=(1-γ_{k+1})(c·b_k+s_{k+1}), 0≤γ_k≤1,
a_k,b_k≥0, b_0=b_{tK}=0), specialize to the piecewise sensitivity s_k=s
(constant) for 0≤k≤K and s_k=0 for K+1≤k≤tK, 0<c<1. Find
min Σ_{k=1}^{tK} a_k^2.

Result (derived, not yet cross-checked against paper text):

  min Σ_{k=1}^{tK} a_k^2 = (1+c)/(1-c) · c^{2K(t-1)}(1-c^K)^2/(1-c^{2tK}) · s^2

Optimal sequence: a_k = A·c^{tK-k} with A = s(1+c)c^{tK-K}(1-c^K)/(1-c^{2tK}).

Status: this is a specific instance of the general min-sum-a_k^2 problem
(closed-form under the given piecewise-s boundary conditions); worth
rechecking against the paper's actual γ_{tK}=1 constraint from
[[fij-tK-lower-bound-via-CNI]] (this subtask's stated constraints only had
0≤γ_k≤1, not γ_{tK}=1 — reconcile if the two problems are meant to be the
same one).
