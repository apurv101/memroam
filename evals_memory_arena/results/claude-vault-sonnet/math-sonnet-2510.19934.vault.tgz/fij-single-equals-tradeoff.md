---
id: 01a050fc-fe02-7b0f-b9da-d0d4afcf0a2f
name: fij-single-equals-tradeoff
description: "Paper 2510.19934: T(A_j^single(D), A_j^single(D')) = f_{ij}^single exactly (equality, not just ≤), where f_{ij}^single is the w-weighted mixture over rounds t=1..T of per-round tradeoff functions f_{ij}^t plus a "no-release" term w^{T+1}(1-α_{T+1})."
metadata:
  type: project
---

For the mixture mechanism $\mathcal A_j^{\mathrm{single}}$ defined by rounds $t=1,\dots,T$ (each with tradeoff function $f_{ij}^t = T(P_j^t,Q_j^t)$) plus a "no release" option (weight $w_{ij}^{T+1}$, contributes $1-\alpha_{T+1}(s)$ with $\alpha_{T+1}(s)=\mathbf 1_{[s<1]}$), define
$$f_{ij}^{\mathrm{single}}(\alpha(s)) = \sum_{t=1}^T w^t_{ij} f_{ij}^t(\alpha_t(s)) + w_{ij}^{T+1}(1-\alpha_{T+1}(s)), \quad \alpha(s)=\sum_{t=1}^{T+1} w^t_{ij}\alpha_t(s).$$

**Result:** $T(\mathcal A_j^{\mathrm{single}}(D),\mathcal A_j^{\mathrm{single}}(D')) = f_{ij}^{\mathrm{single}}$ — equality, answer (C) among {<, ≤, =, ≥, >}.

**Why:** $\mathcal A_j^{\mathrm{single}}$'s output reveals which round $t$ (or "no release") produced it, and the mixing weights $w^t_{ij}$ are data-independent. So the joint likelihood ratio of $(t,\text{output})$ under $D$ vs $D'$ collapses to the per-round ratio $p_j^t(x)/q_j^t(x)$ — weights cancel. Hence the joint LR-threshold test at level $s$ *is* the per-round threshold test, and by Neyman–Pearson $\alpha_t(s), f_{ij}^t(\alpha_t(s))$ trace the actual optimal trade-off curve of $(P_j^t,Q_j^t)$, not merely a bound. The weighted sum is therefore the true (optimal) trade-off function of the joint mixture mechanism — not just an upper/lower bound like the CNI-based results in [[fij-tK-lower-bound-via-CNI]].

**How to apply:** Use this equality (not an inequality) whenever composing/analyzing $\mathcal A_j^{\mathrm{single}}$-style mixture mechanisms in this paper's later subtasks — it's the exact building block, contrast with the inequality-based bounds elsewhere in the project.
