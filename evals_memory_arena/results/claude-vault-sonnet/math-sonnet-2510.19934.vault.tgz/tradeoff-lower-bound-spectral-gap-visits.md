---
id: 01a05108-35d4-7df7-b66f-b592213c1a1d
name: tradeoff-lower-bound-spectral-gap-visits
description: "Paper 2510.19934: solved high-probability lower bound on T(A_j(D),A_j(D')) using spectral-gap concentration on random-walk visit counts N_i(T), combining with f_{ij}^t from Lemma 4.2/4.3."
metadata:
  type: project
---

Subtask: given W irreducible, aperiodic, symmetric transition matrix with
spectral gap 1-λ2>0, for D~D', under Lemma 4.2 (strongly convex) or 4.3
(non-convex), for any ζ>0 and
  δ'_{T,n} = exp( -((1-λ2)/(1+λ2)) · 2ζ²T/n² ),
lower-bound T(A_j(D), A_j(D')).

Result:

  T(A_j(D), A_j(D')) ≥ f_{ij}^{t*},   t* = ⌈T/n + ζ⌉,   w.p. ≥ 1-δ'_{T,n}.

Derivation: spectral-gap concentration (Chernoff-type bound for Markov
chains, using the gap (1-λ2)/(1+λ2)) gives Pr(N_i(T) ≥ T/n+ζ) ≤ δ'_{T,n},
where N_i(T) is the number of visits to the differing node i by time T.
Since f_{ij}^t (from [[fij-t-lower-bound-uniform-sensitivity]] /
[[fij-t-nonconvex-gap]]) is non-increasing in t, the worst case (most
visits) t* = ⌈T/n+ζ⌉ gives the valid high-probability lower bound.

Strongly-convex case explicit form (uses [[fij-t-lower-bound-uniform-sensitivity]]):
  f_{ij}^{t*} = G_{μ_{t*}},
  μ_{t*} = (ηΔ/σ)·sqrt( (1+c)/(1-c) · (1-c^{t*})/(1+c^{t*}) ),
  c = max(|1-ηm|, |1-ηM|).

Status: derived and internally consistent (matches non-increasing-in-t
structure of f_{ij}^t from prior sessions); not cross-checked against the
paper's printed equations.
