---
id: 01a05101-cb6e-7b53-aaee-ee933daafc8d
name: fij-t-lower-bound-uniform-sensitivity
description: "Paper 2510.19934: closed-form lower bound for f_{ij}^t (m-strongly-convex, M-smooth losses, uniform per-step sensitivity s=ηΔ) in terms of contraction constant c=max(|1-ηm|,|1-ηM|); handles both 0<c<1 and the c=1 edge case."
metadata:
  type: project
---

Subtask: assuming ℓ_i are m-strongly-convex and M-smooth, with
c = max(|1-ηm|, |1-ηM|):
(1) for 0<c<1, lower-bound f_{ij}^t.
(2) for c=1, express μ_t.

This is the same [[fij-tK-lower-bound-via-CNI]] framework (f_{ij}^t ≥ G_{μ_t},
μ_t = (1/σ)·sqrt(Σ a_k^2)), but specialized to uniform per-step sensitivity
s_k = s = ηΔ for all k=1..t (not the piecewise s-then-0 case in
[[min-sum-ak2-piecewise-sensitivity]]).

Result:

  (1) 0<c<1:  f_{ij}^t ≥ G_{μ_t},
      μ_t = (s/σ) · sqrt( (1+c)/(1-c) · (1-c^t)/(1+c^t) )

  (2) c=1:  μ_t = (s/σ) · sqrt(t)
      — recovers ordinary Gaussian-DP composition (linear growth in t);
      the c<1 formula's limit as c→1 reduces algebraically to t, confirming
      no privacy amplification when the update map isn't a strict contraction.

Status: derived and internally verified (limit check c→1) but not yet
cross-checked against the paper's printed equations — recheck if picked back
up and discrepancies matter.
