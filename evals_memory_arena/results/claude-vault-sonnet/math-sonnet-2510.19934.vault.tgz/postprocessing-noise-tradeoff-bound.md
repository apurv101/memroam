---
id: 01a050f9-15eb-7117-92d8-a64b05a0ddb3
name: postprocessing-noise-tradeoff-bound
description: "Paper 2510.19934: post-processing/Blackwell bound T(X+ξ,X'+ξ') ≥ G_{μ/√(σ1²+σ2²)} when T(X,X') ≥ G_{μ/σ1}, i.e. adding independent N(0,σ2²) noise shrinks the mean-shift-to-noise ratio."
metadata:
  type: project
---

Subtask: given random variables X, X' with trade-off function T(X,X') ≥
T(ζ,ζ') where ζ~N(0,σ1²), ζ'~N(μ,σ1²) (μ>0), lower-bound T(X+ξ, X'+ξ')
for independent noise ξ,ξ' ~ i.i.d. N(0,σ2²), independent of (X,X').

Result:
  T(X+ξ, X'+ξ') ≥ G_{μ/√(σ1²+σ2²)}

where G_ν(α) = Φ(Φ⁻¹(1-α) - ν) is the standard Gaussian trade-off function
(this matches the G used in [[fij-tK-lower-bound-via-CNI]] — confirms G_ν is
the Gaussian trade-off function with parameter ν = mean-shift/stddev).

Derivation: post-processing monotonicity of trade-off functions (Blackwell's
theorem) — convolving both X and X' with the same noise distribution can only
make hypothesis testing harder, so T is monotone under this post-processing.
Applying it to ζ,ζ' directly: ζ+ξ ~ N(0, σ1²+σ2²), ζ'+ξ' ~ N(μ, σ1²+σ2²), so
T(ζ+ξ,ζ'+ξ') = G_{μ/√(σ1²+σ2²)}. Chaining with T(X,X')≥T(ζ,ζ') via
post-processing monotonicity gives the result.

General pattern for this paper: adding independent noise of variance σ2² to
both sides of a Gaussian-dominated pair shrinks the effective ν parameter from
μ/σ1 to μ/√(σ1²+σ2²) — i.e. variances add before taking the ratio with μ.
Useful building block anywhere in the paper that composes a trade-off-function
lower bound with an additional independent noise-injection step.
