---
id: 01a05104-f71b-7f23-a0f5-ee827a7525a8
name: fij-t-nonconvex-gap
description: "Paper 2510.19934: a subtask on lower-bounding f_{ij}^t for NON-convex losses (gradient sensitivity Δ) was worked in a prior session, but the resulting formula was not captured in the handoff — treat as unsolved/needs re-derivation, not as an existing result."
metadata:
  type: project
---

A session subtask was: "For non-convex loss functions with gradient sensitivity Δ, lower bound f_{ij}^t." The session ended before its mathematical content (the actual closed-form or derivation) reached this memory — the handoff only contained a remark that an in-session memory save had failed, no formula.

**Why:** Existing memories ([[fij-t-lower-bound-uniform-sensitivity]], [[fij-tK-lower-bound-via-CNI]]) only cover the m-strongly-convex, M-smooth case via a contraction-constant argument (c = max(|1-ηm|,|1-ηM|)); that machinery doesn't directly apply without convexity, since there's no contraction constant to exploit. The non-convex analogue is a genuinely open/undocumented piece of this project.

**How to apply:** If a future session is asked to use or extend a non-convex f_{ij}^t bound, do NOT assume one already exists in memory — re-derive it (likely still via Lemma B.3 CNI applied to Algorithm 1's random walk, as in [[fij-tK-lower-bound-via-CNI]], but replacing the contraction-based per-step argument with something valid under only gradient-sensitivity Δ, e.g. non-expansiveness assumptions or a different per-step bound). Once solved, replace this memory with the actual result.
