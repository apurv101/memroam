---
id: 01a050d9-23c9-7d4f-8d73-5b7417ee7107
name: kkt-condition-ball-constrained-min
description: KKT-point iff condition for min_{||x||<=1/lambda} L(x) in terms of ||x|| and <-lambda*x, grad L(x)>
metadata:
  type: project
---

**Setup:** Euclidean norm $\norm\cdot$ (this specific form requires Euclidean — see below). Consider $\min_{\norm{\vx}\le 1/\lambda} L(\vx)$.

**Solved result:**

$$\vx \text{ is a KKT point} \iff \norm{\vx}\le\frac1\lambda \ \text{ and }\ \inner{-\lambda\vx}{\nabla L(\vx)} = \norm{\nabla L(\vx)}$$

Equivalently "$=$" can be written "$\ge$", since $\inner{-\lambda\vx}{\nabla L(\vx)}\le\norm{\lambda\vx}\norm{\nabla L(\vx)}\le\norm{\nabla L(\vx)}$ automatically holds for any feasible $\vx$ by Cauchy–Schwarz (using $\norm{\vx}\le1/\lambda$), so the inequality form and equality form are equivalent given feasibility.

**Why:** Standard KKT for $\min L(\vx)$ s.t. $\norm{\vx}-1/\lambda\le0$: stationarity $\nabla L(\vx)+\mu\cdot\vx/\norm\vx=0$ (or $\vx=0$ trivial) for some $\mu\ge0$, plus complementary slackness $\mu(\norm\vx-1/\lambda)=0$ and primal feasibility. Combining these collapses to the single inner-product identity above, since $\mu = \norm{\nabla L(\vx)}$ and stationarity forces $-\lambda\vx$ and $\nabla L(\vx)$ to be positively aligned with the given magnitude relation exactly when $\vx$ is on the boundary or $\nabla L(\vx)=0$.

**How to apply:** Reuse directly if later subtasks reference KKT points of this same ball-constrained problem (this is the constraint set matching the weight-decay confinement radius $R=1/\lambda$ used in [[weight-decay-steepest-descent-convergence-bound]]) — e.g., characterizing stationary points of steepest-descent-with-weight-decay dynamics, or showing fixed points of the iteration correspond to KKT points. For a general (non-Euclidean) norm, $\norm{\nabla L(\vx)}$ must be replaced by the dual norm $\norm{\nabla L(\vx)}_*$ and the inner-product condition follows the same pattern as [[subdifferential-of-norm]].
