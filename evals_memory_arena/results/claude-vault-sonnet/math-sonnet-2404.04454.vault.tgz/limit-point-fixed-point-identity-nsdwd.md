---
id: 01a050e0-f095-7c57-b457-91d5379bf543
name: limit-point-fixed-point-identity-nsdwd
description: If nSDWD iterates x_t converge to x_infty under any schedule with sum eta_t = infinity, then Delta_infty=-lambda*x_infty, its inner product with grad L(x_infty) equals the dual norm of grad L(x_infty), and ||x_infty||<=1/lambda
metadata:
  type: project
---

**Setup:** Normalized steepest descent with weight decay (nSDWD), iterates $\vx_t = (1-\lambda\eta_t)\vx_{t-1} - \eta_t\vDelta_t$ with $\vDelta_t \in \argmax_{\norm{\vDelta}\le1}\nabla L(\vx_{t-1})^\top\vDelta$ (see [[weight-decay-steepest-descent-convergence-bound]]). Assume the learning-rate schedule satisfies $\sum_{t=1}^\infty \eta_t=\infty$, and assume the iterates converge to some $\vx_\infty$.

**Solved result:**

- $\vDelta_\infty = -\lambda\vx_\infty$ (from taking $t\to\infty$ in the update rule, using $\eta_t\to0$ is *not* required — divergent sum forces the fixed-point relation $\vx_\infty=(1-\lambda\eta_t)\vx_\infty-\eta_t\vDelta_\infty$ to hold in the limit along a subsequence, giving $\vDelta_\infty=-\lambda\vx_\infty$ directly).
- $\inner{\nabla L(\vx_\infty)}{\vDelta_\infty} = \norm{\nabla L(\vx_\infty)}_*$ (dual norm) — equivalently $-\lambda\inner{\vx_\infty}{\nabla L(\vx_\infty)}=\norm{\nabla L(\vx_\infty)}_*$. Follows because $\vDelta_\infty$ is a limit of steepest-descent directions, which satisfy $\inner{\nabla L(\vx_{t-1})}{\vDelta_t}=\norm{\nabla L(\vx_{t-1})}_*$ exactly (subdifferential-of-norm duality, [[subdifferential-of-norm]]).
- $\norm{\vDelta_\infty}\le 1$, equivalently $\norm{\vx_\infty}\le 1/\lambda$ (since $\vDelta_t$ is always norm-$\le1$ by construction, so the limit is too; combined with $\vDelta_\infty=-\lambda\vx_\infty$).

**Why:** Together these three facts show $\vx_\infty$ is exactly a KKT point of $\min_{\norm{\vx}\le1/\lambda}L(\vx)$ — matches the KKT identity in [[kkt-condition-ball-constrained-min]] (general-norm/dual-norm form). So: *any* nSDWD schedule with divergent $\sum\eta_t$ that produces a convergent iterate sequence converges to a KKT point of the ball-constrained problem, regardless of the specific schedule shape.

**How to apply:** Reuse directly for later subtasks about convergence guarantees / limit points of nSDWD, schedule-independence results, or connecting nSDWD to constrained optimization. Don't re-derive; just cite the KKT-point conclusion.
