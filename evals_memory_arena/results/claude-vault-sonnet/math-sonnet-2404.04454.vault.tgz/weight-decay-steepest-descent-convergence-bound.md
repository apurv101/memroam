---
id: 01a050d2-db00-7587-83d6-6c394b63de5c
name: weight-decay-steepest-descent-convergence-bound
description: Solved suboptimality bound L(x_t)-L(x*) for weight-decayed steepest-descent iterates x_t=(1-lambda*eta_t)x_{t-1}-eta_t*Delta_t, Delta_t in argmax_{||Delta||<=1} grad L(x_{t-1})^T Delta
metadata:
  type: project
---

**Setup:** $L$ convex, $H$-Lipschitz gradient w.r.t. norm $\norm{\cdot}$. Iterates $\vx_t = (1-\lambda\eta_t)\vx_{t-1} - \eta_t\vDelta_t$ with $\vDelta_t \in \argmax_{\norm{\vDelta}\le1}\nabla L(\vx_{t-1})^\top\vDelta$ (steepest descent direction under the norm, per [[subdifferential-of-norm]]).

**Solved bound:**

$$L(\vx_t)-L(\vx^*)\;\le\; e^{-\lambda\sum_{i=1}^t\eta_i}\big[L(\vx_0)-L(\vx^*)\big] \;+\;\frac H2\big(1+\lambda R\big)^2\sum_{s=1}^{t} e^{-\lambda\sum_{i=s+1}^{t}\eta_i}\,\eta_s^2$$

where $R=\max(\norm{\vx_0},1/\lambda)$.

**Derivation ingredients:** $H$-smoothness descent lemma + convexity + Hölder's inequality + a "Lemma 3.1" norm bound on the iterates (referenced in the paper being reconstructed; gives $\norm{\vx_t}\le R$ for all $t$ under weight decay). Requires the mild assumption $\lambda\norm{\vx^*}\le1$ (the optimum lies within the confinement ball that weight decay drives iterates toward).

**Special case:** constant $\eta_t\equiv\eta$ collapses the bound to an exponentially-decaying initial term plus a steady-state floor of $O(H\eta)$ — the expected behavior for smooth convex optimization with constant step size and weight decay acting as a contraction.

**Why:** This is a core convergence result for the weight-decay + steepest-descent algorithm family being analyzed in this paper (arXiv 2404.04454).

**How to apply:** Reuse directly if later subtasks ask about convergence rate, choice of $\eta_t$ schedule (e.g. tuning to minimize the RHS), or extensions (non-convex $L$, stochastic gradients, different $\lambda$ schedules) — don't re-derive from scratch. The "Lemma 3.1" norm bound this relies on should be looked up/re-derived and saved separately if it recurs, since only its role (bounding $\norm{\vx_t}$ by $R$) is captured here, not its own proof.
