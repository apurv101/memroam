---
id: 01a050e8-8ce9-70a3-8a51-bb33962d0d14
name: adam-normalized-momentum-weighted-average-bound
description: Solved bound on |sum eta_t*Delta_t|/sum eta_t for Adam-style Delta_t=m_t/sqrt(v_t) with m_t=beta1*m_{t-1}+(1-beta1)g_t and v_t-beta2*v_{t-1}>=(1-beta2)g_t^2
metadata:
  type: project
---

**Setup:** Given $\beta_1\le\beta_2<1$, scalar sequences $v_t\ge0$ (with $v_1>0$), $g_t$, satisfying $v_t-\beta_2 v_{t-1}\ge(1-\beta_2)g_t^2$ for $t\ge1$; $|m_0|\le\sqrt{v_0}$; $m_t=\beta_1 m_{t-1}+(1-\beta_1)g_t$; $\Delta_t=m_t/\sqrt{v_t}$. This is the Adam/AdamW-style normalized-momentum update, appearing as a building block alongside the nSDWD/steepest-descent-with-weight-decay results already in this project (see [[weight-decay-steepest-descent-convergence-bound]], [[limit-point-fixed-point-identity-nsdwd]]).

**Result:** For any $\eta_t\ge0$ (not all zero) and any $T$,
$$\frac{\left|\sum_{t=1}^T \eta_t\Delta_t\right|}{\sum_{t=1}^T \eta_t}\;\le\;\frac{1-\beta_1}{\sqrt{1-\beta_2}}\sqrt{\frac{\beta_2}{\beta_2-\beta_1^2}}.$$

**Proof sketch:** Show pointwise $m_t^2\le C^2 v_t$ (with $C$ = the RHS constant) by induction, using a Cauchy–Schwarz split at $\lambda=\beta_1^2/\beta_2$ on the recursion for $m_t^2$ vs. the given lower bound on $v_t-\beta_2v_{t-1}$; then $|\Delta_t|\le C$ for all $t$, and the weighted-average bound follows from the triangle inequality.

**Tightness/special cases:**
- Constant is tight, approached asymptotically by $g_t=(\beta_2/\beta_1)^t$.
- $\beta_1=\beta_2 \Rightarrow$ bound reduces to $1$.
- $\beta_1=0 \Rightarrow$ bound reduces to the classical $1/\sqrt{1-\beta_2}$ (pure RMSProp-style normalization, no momentum).
