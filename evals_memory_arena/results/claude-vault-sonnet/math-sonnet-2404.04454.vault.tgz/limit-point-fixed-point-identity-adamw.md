---
id: 01a050ef-b029-74c7-90d9-5f09ce73baa7
name: limit-point-fixed-point-identity-adamw
description: If AdamW iterates x_t converge to x_infty under non-increasing schedule with sum eta_t=infinity and beta2>=beta1, then Delta_infty=-lambda*x_infty, its inner product with grad L(x_infty) equals ||grad L(x_infty)||_1, and ||Delta_infty||_inf is bounded by the Adam-style constant
metadata:
  type: project
---

**Setup:** AdamW iterates $\vx_t=(1-\lambda\eta_t)\vx_{t-1}-\eta_t\vDelta_t$ with $\vDelta_t$ the usual Adam normalized-momentum update (coordinatewise $\Delta_{t,i}=m_{t,i}/\sqrt{v_{t,i}}$, as in [[adam-normalized-momentum-weighted-average-bound]]). Schedule $\{\eta_t\}$ non-increasing with $\sum_{t=1}^\infty\eta_t=\infty$, and $\beta_2\ge\beta_1$. Assume $\vx_t\to\vx_\infty$.

**Solved result (analogue of [[limit-point-fixed-point-identity-nsdwd]] for AdamW):**

- $\vDelta_\infty=-\lambda\vx_\infty$ — same fixed-point argument from taking $t\to\infty$ in the update rule; depends only on the affine form of the update, not on what $\vDelta_t$ is.
- $\inner{\nabla L(\vx_\infty)}{\vDelta_\infty}=\norm{\nabla L(\vx_\infty)}_1$ — coordinatewise, on any coordinate with nonzero gradient the Adam ratio $\Delta_{t,i}$ converges to $\operatorname{sign}(\nabla_i L(\vx_\infty))$, so the inner product collapses to the $\ell_1$ norm (this is the Adam/$\ell_\infty$-geometry analogue of the dual-norm identity in the nSDWD case — here the "norm" is $\ell_\infty$ so its dual is $\ell_1$).
- $\norm{\vDelta_\infty}_\infty\le\dfrac{1-\beta_1}{\sqrt{1-\beta_2}}\sqrt{\dfrac{\beta_2}{\beta_2-\beta_1^2}}$ — only an upper bound, not exact: on coordinates where the gradient is zero, $\lim \Delta_{t,i}$ is indeterminate and only constrained by the pointwise Adam bound from [[adam-normalized-momentum-weighted-average-bound]]. Equals $1$ exactly when $\beta_1=\beta_2$ (recovers the clean $\ell_\infty$-ball KKT picture matching the nSDWD case with the $\ell_\infty$ norm).

**Why:** This is the AdamW-specific instantiation of the general nSDWD limit-point argument, specialized to $\ell_\infty$-normalized steepest descent geometry (since Adam's per-coordinate ratio is effectively sign-like / $\ell_\infty$-steepest-descent flavored). Unlike nSDWD's exact KKT-point conclusion, AdamW's conclusion is only a one-sided bound because Adam's $\vDelta_t$ is not an exact steepest-descent direction under any fixed norm — it only satisfies the inequality-form pointwise bound.

**How to apply:** Reuse directly for later subtasks about AdamW convergence guarantees, limit points, or comparisons between AdamW and nSDWD/steepest-descent-with-weight-decay. Don't re-derive.
