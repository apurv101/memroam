---
id: 01a050fa-4796-795b-85a9-f91bb2d20905
name: adamw-limit-point-kkt-problem
description: The optimization problem P (min L(x) s.t. ||x||_inf<=1/lambda) whose KKT point is the AdamW limit x_infty, and m-m'=0 when L convex
metadata:
  type: project
---

**Setup:** Same AdamW convergence setting as [[limit-point-fixed-point-identity-adamw]]: $L\in C^1$, $\beta_1\le\beta_2<1$, non-increasing $\{\eta_t\}$ with $\sum\eta_t=\infty$, AdamW iterates $\vx_t\to\vx_\infty$. $\lambda$ = weight-decay coefficient.

**Solved result:**

1. **Problem $P$:** $\min_{\vx} L(\vx)\ \text{ s.t. } \norm{\vx}_\infty\le\frac1\lambda$. $\vx_\infty$ is a KKT point of $P$. This follows directly from plugging the two identities in [[limit-point-fixed-point-identity-adamw]] — $\vDelta_\infty=-\lambda\vx_\infty$ and $\inner{\nabla L(\vx_\infty)}{\vDelta_\infty}=\norm{\nabla L(\vx_\infty)}_1$ — into the $\ell_\infty$-ball KKT characterization (dual norm of $\ell_\infty$ is $\ell_1$; same pattern as the Euclidean case in [[kkt-condition-ball-constrained-min]], generalized via [[subdifferential-of-norm]]).
2. **$m-m'=0$ when $L$ convex:** $m$ = optimal value of $P$; $m'=L(\vx_\infty)$ (value of $P$ "at" $\vx_\infty$). Since $L$ convex and the $\ell_\infty$-ball constraint is convex with nonempty interior (Slater), KKT points of $P$ are global minimizers, so $\vx_\infty$ is optimal for $P$ and $m=L(\vx_\infty)=m'$.

**Why:** This is the natural follow-up question to [[limit-point-fixed-point-identity-adamw]] — turning the fixed-point identities into an explicit constrained-optimization characterization of AdamW's limit point, mirroring the nSDWD KKT story in [[limit-point-fixed-point-identity-nsdwd]].

**How to apply:** Reuse directly for later subtasks asking "what problem does AdamW/nSDWD implicitly solve" or comparing AdamW's implicit bias to explicit $\ell_\infty$-constrained ERM. The convex case always gives $m-m'=0$ (exact solve) by Slater + convexity; don't re-derive.
