---
id: 01a050c9-993e-7397-b940-de52391c39de
name: subdifferential-of-norm
description: Formula for the subdifferential of a general norm ||x||, in terms of the dual norm; used in steepest descent (Definition 2.1)
metadata:
  type: project
---

For any norm $\norm{\cdot}$ on $\R^d$ with dual norm $\norm{\cdot}_*$, and $\vx\in\R^d$:

$$\partial \norm{\vx} = \{\vg\in\R^d : \norm{\vg}_*\le 1,\ \inner{\vg}{\vx}=\norm{\vx}\}$$

- For $\vx\neq\vzero$: simplifies to $\{\vg : \norm{\vg}_*=1,\ \inner{\vg}{\vx}=\norm{\vx}\}$.
- At $\vx=\vzero$: equals the full dual unit ball $\{\vg:\norm{\vg}_*\le1\}$.

**Why:** Derived as a subtask in this project. Connects directly to Definition 2.1: a steepest descent direction $\vv$ satisfies $-\vv \in \partial\norm{\nabla L(\vx)}_*$ (i.e., steepest descent under a norm is characterized via the subdifferential of the dual norm applied to the gradient).

**How to apply:** Reuse this formula directly if later subtasks need the subdifferential of a norm (e.g., deriving steepest descent directions for specific norms like $\ell_1$, $\ell_2$, $\ell_\infty$, spectral norm, etc.) rather than re-deriving from scratch.

**Related result already solved:** $\argmax_{\norm{\vDelta}\le 1} \nabla L(\vx)^\top\vDelta = \partial\norm{\nabla L(\vx)}_*$ (apply the formula above with $\vx \to \nabla L(\vx)$ and norm $\to$ dual norm $\norm{\cdot}_*$; the maximizing $\vDelta
s are exactly the subgradients of $\norm{\cdot}_*$ at $\nabla L(\vx)$). This is the $\vDelta^*$ whose negation gives the steepest descent direction $\vv$ in Definition 2.1. No need to re-derive this argmax if it comes up again.
