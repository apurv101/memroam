---
id: 01a050d0-605f-7851-8f65-698fc524b679
name: mu-theta-out-final-bound
description: Final theorem bound mu(theta_out) = O(epsilon) w.p. 1-xi under given batch sizes, M=4rho, eps<=4L^2rho/M, T>=25*Delta_J*rho^{1/2}*eps^{-3/2}
metadata:
  type: project
---

Solved this session as a subtask in the 2311.08914 project (culminating theorem for Algorithm 1 / "cap", combining prior subtasks).

**Setup:** Assumptions 3.1, 3.2 hold. $|\mathcal{B}_{check}| \ge \frac{19440 W^2 \log^2(4T/\xi)}{\epsilon^2}$, $|\mathcal{B}_h| \ge \frac{1080 L^2 \log(4dT/\xi)}{\rho\epsilon}$, cubic penalty $M = 4\rho$, $\epsilon \le 4L^2\rho/M$, $T \ge 25\Delta_J \rho^{1/2}\epsilon^{-3/2}$ where $\Delta_J = J^* - J(\theta_0)$.

**Result:** With probability $1-\xi$, $\theta_{out}$ (output of Algorithm 1) satisfies
$$\mu(\theta_{out}) \le O(\epsilon),$$
i.e. $\theta_{out}$ is an $\epsilon$-approximate second-order stationary point: $\|\nabla J(\theta_{out})\| \le \epsilon$ and $\lambda_{\min}(\nabla^2 J(\theta_{out})) \ge -\sqrt{\rho\epsilon}$.

**Derivation idea:** Combines [[mu-theta-plus-h-upper-bound]] (per-step decrease in terms of $\|h\|^2$), [[gradient-estimate-error-bound-epsilon2]] (gradient estimator concentration), [[hessian-estimate-error-bound-rho-epsilon]] (Hessian estimator concentration), and [[cubic-terms-negative-bound]] (cubic subproblem negative-progress bound) into a standard cubic-regularization telescoping argument: total objective decrease $\Delta_J$ over $T$ iterations bounds the number of "large step" iterations, and the choice of $T$ forces at least one iterate (the output) to have small $\mu$.

**Caveat — not fully independently verified:** The exact leading constant in $O(\epsilon)$ depends on the paper's own one-step-decrease lemma, which was reconstructed from standard cubic-regularization theory (Nesterov-Polyak / cubic-regularized Newton style arguments) rather than retrieved verbatim from the paper. The scaling in $\epsilon$ is solid but the precise constant is unconfirmed. If a later subtask needs the exact constant, re-derive by combining the four linked lemmas explicitly rather than trusting the constant here.
