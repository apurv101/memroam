---
id: 01a050c0-e5be-7cc9-9c2b-17f11c336281
name: cubic-terms-negative-bound
description: Trivial upper bound -(rho/8)||h||^3 - C <= -C for C = (10/rho^2)||Hess-U_t||^3 or (6/(5*sqrt(rho)))||grad-v_t||^{3/2}, tight at h=0
metadata:
  type: project
---

Solved this session as a standalone subtask in the 2311.08914 project.

For $h \in \mathbb{R}^d$, $\rho > 0$, and error terms from stochastic Hessian/gradient estimates $U_t$, $v_t$:

$$-\frac{\rho}{8}\|h\|^3 - \frac{10}{\rho^2}\|\nabla^2 J(\theta_t)-U_t\|^3 \;\le\; -\frac{10}{\rho^2}\|\nabla^2 J(\theta_t)-U_t\|^3$$

$$-\frac{\rho}{8}\|h\|^3 - \frac{6}{5\sqrt{\rho}}\|\nabla J(\theta_t) -v_t\|^{3/2} \;\le\; -\frac{6}{5\sqrt{\rho}}\|\nabla J(\theta_t) -v_t\|^{3/2}$$

Both hold because each expression has the form $-\frac{\rho}{8}\|h\|^3 - C$ with $C \ge 0$ independent of $h$, which is non-increasing in $\|h\|$; the bound is tight at $h=0$ (just drop the negative cubic-in-$h$ term).

**How to apply:** This is a trivial dropping step, likely used inside a larger proof (e.g. bounding a decrease/progress guarantee for a cubic-regularized method with stochastic Hessian estimate $U_t$ and stochastic gradient estimate $v_t$, related to [[mu-theta-plus-h-upper-bound]]). If a later subtask asks to combine this with other terms (e.g. into a per-iteration progress bound), recall that $C$ terms here bound the estimation error of $U_t$ and $v_t$ relative to the true Hessian/gradient at $\theta_t$.
