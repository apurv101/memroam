# 2311.08914 — memory index

- [cubic-terms-negative-bound](cubic-terms-negative-bound.md) — Trivial upper bound -(rho/8)||h||^3 - C <= -C for C = (10/rho^2)||Hess-U_t||^3 or (6/(5*sqrt(rho)))||grad-v_t||^{3/2}, tight at h=0
- [gradient-estimate-error-bound-epsilon2](gradient-estimate-error-bound-epsilon2.md) — High-prob bound ||v_i - grad J(theta_i)||^2 <= epsilon^2 for floor(t/Q).Q <= i <= t, using batch size S_k = C_2 Q ||theta_k-theta_{k-1}||^2/epsilon^2
- [hessian-estimate-error-bound-rho-epsilon](hessian-estimate-error-bound-rho-epsilon.md) — High-prob bound ||U_t - nabla^2 J(theta_t)||^2 <= rho*epsilon, for batch size |B_h| >= 1080 L^2 log(4dT/xi) / (rho*epsilon)
- [mu-theta-out-final-bound](mu-theta-out-final-bound.md) — Final theorem bound mu(theta_out) = O(epsilon) w.p. 1-xi under given batch sizes, M=4rho, eps<=4L^2rho/M, T>=25*Delta_J*rho^{1/2}*eps^{-3/2}
- [mu-theta-plus-h-upper-bound](mu-theta-plus-h-upper-bound.md) — Upper bound on mu(theta_t + h) in terms of (M+rho)/2 * ||h||^2, simplified to (3M/4)||h||^2 when M/rho >= 2
- [vector-azuma-hoeffding](vector-azuma-hoeffding.md) — High-probability norm bound for a sum of a bounded vector martingale difference sequence (vector Azuma-Hoeffding)
