---
id: 01a050b9-e9bf-791c-94aa-9ce0cc1221d1
name: vector-azuma-hoeffding
description: High-probability norm bound for a sum of a bounded vector martingale difference sequence (vector Azuma-Hoeffding)
metadata:
  type: project
---

For a vector martingale difference sequence $\{a_k\}$ in $\mathbb{R}^d$ (i.e. $\mathbf{E}[a_k \mid \sigma(a_1,\dots,a_{k-1})] = 0$) with $\|a_k\| \le A_k$ almost surely, with probability at least $1-\delta$:

$$
\left\|\sum_k a_k\right\| \;\le\; \sqrt{8\log\!\left(\frac{2\cdot 5^{d}}{\delta}\right)\sum_k A_k^{2}}.
$$

**Why:** Derived this session as a standalone lemma request within the 2311.08914 research project. The $5^d$ factor comes from a standard $\varepsilon$-net covering argument on the unit sphere in $\mathbb{R}^d$ combined with scalar Azuma-Hoeffding applied to $\langle u, \sum_k a_k\rangle$ for net points $u$, then a union bound.

**How to apply:** Use this directly if a later subtask needs a high-probability bound on the norm of a sum of bounded martingale difference vectors (e.g. concentration arguments for vector-valued stochastic processes in this paper's proofs). If $d$ is not fixed/finite or the norm is not Euclidean, this bound (as stated, via the $5^d$ net) may not directly apply — revisit the derivation.
