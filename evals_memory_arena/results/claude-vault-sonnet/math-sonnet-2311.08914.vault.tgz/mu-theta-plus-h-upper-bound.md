---
id: 01a050bd-4f51-7c99-93ee-52e90fe932ed
name: mu-theta-plus-h-upper-bound
description: Upper bound on mu(theta_t + h) in terms of (M+rho)/2 * ||h||^2, simplified to (3M/4)||h||^2 when M/rho >= 2
metadata:
  type: project
---

For $v_t\in\mathbb{R}^d$, $U_t\in\mathbb{R}^{d\times d}$, $h\in\mathbb{R}^d$, $M\in\mathbb{R}$ with $M/\rho \ge 2$:

$$
\mu(\theta_t+h) \;\le\; \frac{M+\rho}{2}\|h\|^2 \;\le\; \frac{3M}{4}\|h\|^2
$$

Derived via Taylor expansion (using $\rho$-Lipschitz Hessian of $f$) combined with the stationarity condition of the cubic sub-problem model (Lemma A.3/A.4 in this line of work), then simplified using $M/\rho \ge 2$.

**Why:** Solved this session as a standalone subtask in the 2311.08914 project. **Caveat:** $\mu(\theta_t+h)$ was not explicitly defined in the subtask's given background material — I assumed the standard cubic-regularization convention $\mu(\theta) = \|\nabla f(\theta)\|$. This assumption was not confirmed by the user.

**How to apply:** Before reusing this bound in a later subtask, verify the definition of $\mu(\cdot)$ matches $\|\nabla f(\cdot)\|$ in the paper's actual notation — if it means something else (e.g. a different merit function), the derivation needs to be redone. Also verify $v_t$, $U_t$ inputs (unused directly in the final bound as stated) match how they're used elsewhere — they may be needed for the full derivation chain even though they don't appear in the final inequality.
