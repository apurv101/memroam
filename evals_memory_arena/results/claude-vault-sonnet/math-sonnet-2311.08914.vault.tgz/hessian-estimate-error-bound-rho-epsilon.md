---
id: 01a050c9-d801-75eb-9dca-e31ba2169425
name: hessian-estimate-error-bound-rho-epsilon
description: High-prob bound ||U_t - nabla^2 J(theta_t)||^2 <= rho*epsilon, for batch size |B_h| >= 1080 L^2 log(4dT/xi) / (rho*epsilon)
metadata:
  type: project
---

Solved this session as a standalone subtask in the 2311.08914 project (Algorithm 1, Hessian estimator $U_t$ vs. true Hessian $\nabla^2 J(\theta_t)$).

**Setup:** Assumptions 3.1 and 3.2 hold conditioned on $\mathcal{F}_t$. Batch size:
$$|\mathcal{B}_h| \ge \frac{1080 L^2 \log(4dT/\xi)}{\rho\epsilon}.$$

**Result:** With probability at least $1-\delta$:
$$\|U_t - \nabla^2 J(\theta_t)\|^2 \le \rho\epsilon.$$

**Note:** This is the Hessian-estimate counterpart to [[gradient-estimate-error-bound-epsilon2]] (which bounds the gradient estimator error by $\epsilon^2$ using batch size scaling as $1/\epsilon^2$). Here the batch size scales as $1/(\rho\epsilon)$ and the resulting squared-error bound is $\rho\epsilon$ rather than $\epsilon^2$ — worth double-checking against the paper's exact statement/notation ($\xi$ vs $\delta$, matrix Bernstein/Azuma constant 1080) if a later subtask needs the derivation reused, since this was recorded from the final answer only, not re-verified step by step.
