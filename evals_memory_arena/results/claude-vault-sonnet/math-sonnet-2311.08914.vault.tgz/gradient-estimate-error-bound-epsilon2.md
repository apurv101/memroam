---
id: 01a050c4-688a-7f80-a683-f2e605b351c6
name: gradient-estimate-error-bound-epsilon2
description: High-prob bound ||v_i - grad J(theta_i)||^2 <= epsilon^2 for floor(t/Q).Q <= i <= t, using batch size S_k = C_2 Q ||theta_k-theta_{k-1}||^2/epsilon^2
metadata:
  type: project
---

Solved this session as a standalone subtask in the 2311.08914 project (Algorithm 1, gradient estimator $v_i$ vs. true gradient $\nabla J(\theta_i)$).

**Setup:** Assumptions 3.1 and 3.2 hold conditioned on $\mathcal{F}_{\lfloor t/Q\rfloor.Q}$. Batch size at consecutive points $\theta_{k-1},\theta_k$:
$$S_k = C_2 Q \frac{\|\theta_k-\theta_{k-1}\|_2^2}{\epsilon^2}, \qquad C_2 = 38880L^2\log^2(1/\delta) + 4^{5/4}\sqrt{1080\log(1/\delta)}\,\rho^2 L_1^3 M^{-7/4}.$$

**Result:** With probability at least $1-2\delta(t-\lfloor t/Q\rfloor.Q)$, for all $i$ with $\lfloor t/Q\rfloor.Q \le i \le t$:
$$\|v_i - \nabla J(\theta_i)\|_2^2 \le \epsilon^2.$$

**Derivation idea:** $S_k$ is calibrated so each recursive/telescoping step (from $\theta_{k-1}$ to $\theta_k$) contributes at most $\epsilon^2/Q$ of squared estimation error, via a vector-martingale concentration argument (see [[vector-azuma-hoeffding]]) under Assumptions 3.1–3.2. Summing over at most $Q$ steps within the current epoch (from $\lfloor t/Q\rfloor.Q$ to $t$) telescopes to $\epsilon^2$; a union bound over these $\le Q$ steps gives the stated failure probability $2\delta(t-\lfloor t/Q\rfloor.Q)$.

**Caveat:** Assumptions 3.1/3.2, and the exact recursive update defining $v_i$ from $v_{i-1}$ across $\theta_{k-1}\to\theta_k$ (e.g. an SVRG/STORM-style recursive gradient estimator), were taken from the paper's stated background rather than re-derived in full here — if a later subtask needs the intermediate per-step $\epsilon^2/Q$ bound or the exact constant $C_2$ derivation, that algebra was not re-verified independently.
