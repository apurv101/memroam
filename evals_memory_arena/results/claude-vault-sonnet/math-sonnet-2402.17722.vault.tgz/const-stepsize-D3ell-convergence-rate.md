---
id: 01a050f4-0bdf-7fd8-96c5-02cbd0cca69d
name: const-stepsize-D3ell-convergence-rate
description: Solved for paper 2402.17722 — plugging constant step-size eta_t=min{1/(2ell), sqrt(lambda_0/(sigma^2 ell T))} into the diminishing-step-size bound gives E[D_3ell(bar x_T)] = O(ell*lambda_0/T + sigma*sqrt(ell*lambda_0/T))
metadata:
  type: project
---

Derived from the general diminishing-step-size bound
E[D_3ell(bar x_T)] <= (3*lambda_0 + 6*ell*sigma^2*sum eta_t^2) / sum eta_t,
under Assumptions 3.1/3.2, non-increasing eta_t <= 1/(2ell), lambda_0 = Phi_{1/rho}(x_0) - Phi* + Phi(x_0) - Phi*.

With constant eta_t = min{1/(2ell), sqrt(lambda_0/(sigma^2 ell T))} for all t=0..T-1:

E[D_3ell(bar x_T)] <= 6*ell*lambda_0/T + 9*sqrt(ell*sigma^2*lambda_0/T)
                    = O( ell*lambda_0/T + sigma*sqrt(ell*lambda_0/T) ).

**Why:** This is the standard trick of balancing the two terms of the diminishing-step-size bound by choosing the largest constant step size satisfying both the smoothness cap (1/(2ell)) and the noise-balancing cap (sqrt(lambda_0/(sigma^2 ell T))), giving the usual O(1/T + sigma/sqrt(T)) nonconvex-SGD-style rate but for the D_3ell stationarity measure of this paper.

**How to apply:** If later subtasks ask for rates under other step-size choices or want to interpret the O(1/T + 1/sqrt(T)) behavior of Theorem-type results in this paper, this is the reference derivation/result to build on or compare against.
