---
id: 01a050d9-1361-745b-993d-8059ca328af1
name: envelope-descent-lemma
description: Proved lemma for paper 2402.17722 — Φ_{1/ρ}(x) ≥ Φ(x^+) for (ℓ,ω)-smooth F when ρ≥2ℓ, with proof sketch and key definitions
metadata:
  type: project
---

**Setting (paper 2402.17722):** $F$ is $(\ell,\omega)$-smooth (relatively smooth w.r.t. Bregman divergence $D_\omega$ of reference function $\omega$), $r$ is the (possibly nonsmooth) regularizer, $\Phi = F + r$. Define the Moreau-type envelope
$$\Phi_{1/\rho}(x) = \min_{y\in\cX}\big[F(y)+r(y)+\rho D_\omega(y,x)\big],$$
and the prox-linear/mirror step
$$x^+ = \argmin_{y\in\cX}\big[\langle\nabla F(x),y\rangle + r(y) + (\rho-\ell)D_\omega(y,x)\big].$$

**Result proved:** For any $\rho \ge 2\ell$ and $x\in\cX\cap\cS$,
$$\Phi_{1/\rho}(x) \ge \Phi(x^+) \qquad \big(\text{i.e. } \Phi_{1/\rho}(x) - \Phi(x^+) \ge (\rho-2\ell) D_\omega(x^+,x) \ge 0\big).$$
Equality is only tight at the boundary $\rho=2\ell$ with $D_\omega(x^+,x)=0$ — so the relation is non-strict ($\ge$), not strict.

**Proof technique (reusable pattern for this project):**
1. Lower-bound $F(y)$ inside $\Phi_{1/\rho}$'s objective using the relative-smoothness lower bound $F(y)\ge F(x)+\langle\nabla F(x),y-x\rangle-\ell D_\omega(y,x)$; minimizing the resulting bound over $y$ is exactly the $x^+$ problem, giving $\Phi_{1/\rho}(x) \ge$ (linearized objective at $x^+$).
2. Upper-bound $F(x^+)$ via the relative-smoothness upper bound $F(x^+)\le F(x)+\langle\nabla F(x),x^+-x\rangle+\ell D_\omega(x^+,x)$ to relate the linearized term back to $F(x^+)$.
3. Combine to get $\Phi_{1/\rho}(x) \ge \Phi(x^+) + (\rho-2\ell)D_\omega(x^+,x)$.

This "sandwich via both sides of relative smoothness, evaluated at the minimizer of a linearized subproblem" is the standard proof template likely reused for related envelope/descent lemmas later in this project.
