---
id: 01a050f7-4b8e-71a7-8a3b-3c5383a90eec
name: smd-iteration-complexity-under-KL
description: Solved for paper 2402.17722 — under Assumptions 3.1/3.2/4.6 (KL/Hölder growth, exponent α), SMD with the balanced constant step-size achieves min_{t≤T} E[Φ(x_t^+)-Φ*] ≤ ε after T = O(ℓΛ0/(με^{2/α}) + ℓΛ0σ²/(μ²ε^{4/α})) iterations
metadata:
  type: project
---

**Task:** Given Assumptions 3.1, 3.2 (smoothness/noise, underlying [[const-stepsize-D3ell-convergence-rate]]) and 4.6 (KL/Hölder growth condition with exponent α∈[1,2], constant μ — see [[rel-strong-convexity-implies-KL-alpha2]]), find step-sizes {η_t} for SMD such that min_{t≤T} E[Φ(x_t^+)-Φ*] ≤ ε in T = O(F(ℓ,Λ0,μ,ε,α,σ)) iterations.

**Result:**
$$F(\ell,\Lambda_0,\mu,\varepsilon,\alpha,\sigma) = \frac{\ell\Lambda_0}{\mu\varepsilon^{2/\alpha}} + \frac{\ell\Lambda_0\sigma^2}{\mu^2\varepsilon^{4/\alpha}}.$$

**Derivation sketch:** Start from the [[const-stepsize-D3ell-convergence-rate]] bound E[D_{3ℓ}(bar x_T)] = O(ℓΛ0/T + σ√(ℓΛ0/T)) with the same balanced constant step-size η_t = min{1/(2ℓ), √(Λ0/(σ²ℓT))}. Combine with the envelope inequality Φ(x_t^+) ≤ Φ(x_t) (from [[envelope-descent-lemma]]) and the KL/Hölder growth assumption D_ρ(x) ≥ 2μ(Φ(x)-Φ*)^{2/α} (Assumption 4.6, general α case — [[rel-strong-convexity-implies-KL-alpha2]] is the α=2 special case). Since α/2 ≤ 1, apply Jensen's inequality to pass from E[D_{3ℓ}] to a bound on min_{t≤T} E[Φ(x_t^+)-Φ*], then invert to solve for T achieving ε accuracy — this produces the two-term sum above (a "deterministic" ℓΛ0/(με^{2/α}) term and a "stochastic" ℓΛ0σ²/(μ²ε^{4/α}) term, structurally analogous to how the D_{3ℓ} bound itself splits into a 1/T term and a σ/√T term, but transformed through the α-Hölder growth exponent).

**Note:** This session's attempt to save this memory failed once (tool call reported as not permitted) before this successful save — if a stale/incomplete version of this memory or a note about a failed save is found elsewhere, it can be disregarded/removed.
