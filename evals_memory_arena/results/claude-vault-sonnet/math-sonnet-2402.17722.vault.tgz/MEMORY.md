# 2402.17722 — memory index

- [const-stepsize-D3ell-convergence-rate](const-stepsize-D3ell-convergence-rate.md) — Solved for paper 2402.17722 — plugging constant step-size eta_t=min{1/(2ell), sqrt(lambda_0/(sigma^2 ell T))} into the diminishing-step-size bound gives E[D_3ell(bar x_T)] = O(ell*lambda_0/T + sigma*sqrt(ell*lambda_0/T))
- [envelope-descent-lemma](envelope-descent-lemma.md) — Proved lemma for paper 2402.17722 — Φ_{1/ρ}(x) ≥ Φ(x^+) for (ℓ,ω)-smooth F when ρ≥2ℓ, with proof sketch and key definitions
- [open-question-delta-rho-notation](open-question-delta-rho-notation.md) — UNRESOLVED — paper 2402.17722 uses notation Δ_ρ(x) and Δ_ρ^+(x) (with constant C(ℓ,ρ,s)) not yet defined anywhere in this project's memory; a subtask asking to compare them was left unanswered pending the exact definitions
- [rel-strong-convexity-implies-KL-alpha2](rel-strong-convexity-implies-KL-alpha2.md) — Proved for paper 2402.17722 — μ-relative strong convexity of F implies the KL/Hölder growth assumption with α=2, constant μ, for all ρ≥μ (weaker than the general ρ≥3ℓ requirement)
- [smd-iteration-complexity-under-KL](smd-iteration-complexity-under-KL.md) — Solved for paper 2402.17722 — under Assumptions 3.1/3.2/4.6 (KL/Hölder growth, exponent α), SMD with the balanced constant step-size achieves min_{t≤T} E[Φ(x_t^+)-Φ*] ≤ ε after T = O(ℓΛ0/(με^{2/α}) + ℓΛ0σ²/(μ²ε^{4/α})) iterations
- [sym-bregman-bound-hat-x-xplus](sym-bregman-bound-hat-x-xplus.md) — Proved for paper 2402.17722 — bound on ρ²D_ω^sym(x̂,x^+) between exact prox-minimizer x̂ and prox-linear step x^+, for ρ>ℓ
