---
id: 01a050e8-5f28-7adb-a858-9baf1c572f03
name: sym-bregman-bound-hat-x-xplus
description: Proved for paper 2402.17722 — bound on ρ²D_ω^sym(x̂,x^+) between exact prox-minimizer x̂ and prox-linear step x^+, for ρ>ℓ
metadata:
  type: project
---

**Setting (paper 2402.17722, same as [[envelope-descent-lemma]]):** $F$ is $(\ell,\omega)$-smooth, $r$ the regularizer. Define
$$\hat x = \argmin_{y\in\cX}\big[F(y)+r(y)+\rho D_\omega(y,x)\big]$$
(the exact Bregman-proximal minimizer, i.e. the minimizer achieving $\Phi_{1/\rho}(x)$), and $x^+$ the prox-linear/mirror step as in [[envelope-descent-lemma]]. $D_\omega^{\text{sym}}(a,b) := D_\omega(a,b)+D_\omega(b,a)$.

**Result proved:** For any $\rho>\ell$ and all $x\in\cX\cap\cS$,
$$\rho^2\, D_\omega^{\text{sym}}(\hat x, x^+) \;\le\; \frac{2\ell\,\rho^2}{\rho-\ell}\, D_\omega(x^+,x).$$

**Proof sketch:** Apply the Bregman three-point inequality to both subproblems (the $\hat x$-problem and the $x^+$-problem), cross-evaluated at each other's minimizer, then combine with the two-sided relative-smoothness bound on $F$ at $x$. All first-order terms and $D_\omega(\hat x,x)$ cancel, leaving the intermediate inequality
$$\rho D_\omega(x^+,\hat x)+(\rho-\ell)D_\omega(\hat x,x^+)\le 2\ell D_\omega(x^+,x).$$
The symmetric bound follows since $\rho \ge \rho-\ell>0$, so both $\rho D_\omega(\cdot)$ and $\rho D_\omega(\cdot)$ dominate the two terms on the left.

Note: this reuses the same "sandwich via both sides of relative smoothness at the minimizer of a linearized subproblem" template as [[envelope-descent-lemma]], but applied twice (once per subproblem) and combined via the three-point identity rather than a single one-sided bound.
