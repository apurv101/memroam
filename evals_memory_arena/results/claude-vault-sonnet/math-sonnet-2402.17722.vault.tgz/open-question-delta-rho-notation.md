---
id: 01a050eb-e769-7fbc-980a-8387e404d10c
name: open-question-delta-rho-notation
description: UNRESOLVED — paper 2402.17722 uses notation Δ_ρ(x) and Δ_ρ^+(x) (with constant C(ℓ,ρ,s)) not yet defined anywhere in this project's memory; a subtask asking to compare them was left unanswered pending the exact definitions
metadata:
  type: project
---

**Status:** A subtask asked to compare $\Delta_\rho^+(x)$, $C(\ell,\rho,s)\Delta_\rho(x)$, and $\Delta_\rho(x)/C(\ell,\rho,s)$ for $(\ell,\omega)$-smooth $F$ with $\sqrt{D_\omega^{\text{sym}}(x,y)}$ a metric, given
$$C(\ell,\rho,s) := \frac{(1+s)(\rho-\ell)+(1+s^{-1})\ell}{\rho-\ell-(1+s^{-1})\ell}, \qquad \rho > \ell/s + 2\ell.$$
This was **not solved** — none of the three existing memories ([[envelope-descent-lemma]], [[rel-strong-convexity-implies-KL-alpha2]], [[sym-bregman-bound-hat-x-xplus]]) define $\Delta_\rho(x)$ or $\Delta_\rho^+(x)$, and the definitions were not recovered in that session.

**Why:** Without the exact definitions of $\Delta_\rho(x)$/$\Delta_\rho^+(x)$ from the source paper, any comparison risks proving the wrong statement. The task was left as an open question back to the user rather than guessed at.

**Plausible guess (unverified):** Given the Young's-inequality shape of $C(\ell,\rho,s)$ — matching the $(1+s)a^2+(1+s^{-1})b^2$ split from applying the triangle inequality to the metric $\sqrt{D_\omega^{\text{sym}}}$ — $\Delta_\rho(x)$ and $\Delta_\rho^+(x)$ are likely some measure of distance/stationarity at $x$ vs. $x^+$ (e.g. built from $D_\omega(x^+,x)$ or the envelope gap), and the result is likely a two-sided sandwich $\Delta_\rho(x)/C(\ell,\rho,s) \le \Delta_\rho^+(x) \le C(\ell,\rho,s)\Delta_\rho(x)$ proved by triangle-inequality chaining through $\hat x$, reusing [[sym-bregman-bound-hat-x-xplus]]. **Not verified — do not treat as established.**

**How to apply:** If a future session encounters $\Delta_\rho(x)$/$\Delta_\rho^+(x)$ again, check whether the paper's definition has since been supplied/saved elsewhere first; if still missing, ask the user for the exact definitions (or the surrounding lemma statement/page) before attempting a proof.

**Second unresolved subtask (same session):** asked for the relationship between $2\mathcal D_{\rho/2}(x)$ and $\Delta_\rho^+(x)$ for $x\in\mathcal X\cap\mathcal S$, multiple choice among $<,\le,=,\ge,>$. Answered **B ($2\mathcal D_{\rho/2}(x)\le\Delta_\rho^+(x)$)** by pattern-matching the project's relative-smoothness sandwich technique, but this is **unconfirmed** — $\mathcal D_{\rho/2}(x)$, $\mathcal X$, $\mathcal S$ are also undefined in memory. Also note $\mathcal D_{\rho/2}$ (curly D, subscript $\rho/2$) is a distinct symbol from $D_\omega$/$D_\omega^{\text{sym}}$ (Bregman divergence) used elsewhere — likely a related but separate quantity (possibly an envelope/gap function evaluated at parameter $\rho/2$). If the paper's definitions are ever obtained, resolve both this and the first open question together, as they likely share the same definitional gap.
