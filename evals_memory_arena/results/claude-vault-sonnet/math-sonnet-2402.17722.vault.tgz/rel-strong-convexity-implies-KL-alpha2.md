---
id: 01a050e0-fdd9-779f-8b52-197618d733f6
name: rel-strong-convexity-implies-KL-alpha2
description: Proved for paper 2402.17722 — μ-relative strong convexity of F implies the KL/Hölder growth assumption with α=2, constant μ, for all ρ≥μ (weaker than the general ρ≥3ℓ requirement)
metadata:
  type: project
---

**Setting:** Same as [[envelope-descent-lemma]] — $\Phi=F+r$, $D_\omega$ Bregman divergence of reference $\omega$, $\cD_\rho(x)$ is (up to the scaling below) the gap of the linearized-Bregman envelope $\Phi_{1/\rho}$ at $x$:
$$\cD_\rho(x) = 2\rho\big(\Phi(x) - q_\rho(x,y_\rho^+)\big),\qquad q_\rho(x,y):=F(x)+\langle\nabla F(x),y-x\rangle+r(y)+\rho D_\omega(y,x),$$
with $y_\rho^+=\arg\min_y q_\rho(x,y)$. (This is my reconstruction of $\cD_\rho$ consistent with the envelope lemma — not yet confirmed against the paper's literal defining equation; re-verify if a discrepancy shows up.)

**KL assumption in this project:** $\exists \alpha\in[1,2]$, $\mu>0$, $\rho\ge3\ell$ s.t. $\cD_\rho(x)\ge 2\mu(\Phi(x)-\Phi^*)^{2/\alpha}$ for all $x\in\cX\cap\cS$.

**Result proved (this subtask):** If $F$ is $\mu$-relatively strongly convex w.r.t. $\omega$ (i.e. $F(y)\ge F(x)+\langle\nabla F(x),y-x\rangle+\mu D_\omega(y,x)$), then for **all** $\rho\ge\mu$:
$$\cD_\rho(x)\ge 2\mu\big(\Phi(x)-\Phi^*\big),$$
i.e. the KL condition holds with $\alpha=2$ and the *same* constant $\mu$, but under the relaxed threshold $\rho\ge\mu$ rather than $\rho\ge3\ell$.

**Proof technique:** Bregman/relative-smoothness analogue of Karimi–Nutini–Schmidt's "strong convexity ⇒ PL inequality" argument. Interpolate $z_\theta=\theta x^*+(1-\theta)x$ with $\theta=\mu/\rho\in(0,1]$ (valid exactly because $\rho\ge\mu$); bound $q_\rho(x,y_\rho^+)\le q_\rho(x,z_\theta)$ using convexity of $r$ and the relative-strong-convexity inequality at $y=x^*$; the curvature term from $D_\omega(z_\theta,x)$ cancels the strong-convexity term against the $\rho D_\omega$ penalty. At $\rho=\mu$ boundary, $\theta=1$ and the argument reduces to plugging $y=x^*$ directly.

**Significance:** $\alpha=2$ is the "linear PL" case — matches classical result that strong convexity gives inequalities linear in the suboptimality gap, unlike weaker growth conditions ($\alpha>2$, sublinear) needed elsewhere in the general $\alpha\in[1,2]$ range. This gives a *structural* (rather than assumed) route to verifying the KL condition whenever relative strong convexity is available, and shows the required $\rho$ can be much smaller ($\ge\mu$) than the general blanket requirement ($\ge3\ell$).
