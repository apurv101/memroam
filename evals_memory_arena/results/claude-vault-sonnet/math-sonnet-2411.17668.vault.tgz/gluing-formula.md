---
id: 01a050b3-d4ed-797f-8276-b92d3a311281
name: gluing-formula
description: Formula for the connector stepsize alpha_ell that glues two primitive stepsize blocks into one longer primitive schedule
metadata:
  type: project
---

**Result:** Given a stepsize schedule where $\bm\alpha_{1:\ell-1}$ and $\bm\alpha_{\ell+1:k-1}$ are both primitive (see [[definitions]]), the unique choice of the connector stepsize $\alpha_\ell$ making the full concatenated schedule $\bm\alpha_{1:k-1}$ primitive is

$$
\alpha_\ell = \varphi\big(A_\ell,\; A_{k-\ell}(\bm\alpha_{\ell+1:k-1})\big), \qquad
A_\ell = \sum_{i=1}^{\ell-1}\alpha_i,\quad A_{k-\ell}(\bm\alpha_{\ell+1:k-1}) = \sum_{i=\ell+1}^{k-1}\alpha_i,
$$

where
$$
\varphi(x,y) \coloneqq \frac{-(x+y)+\sqrt{(x+y+2)^2+4(x+1)(y+1)}}{2}
$$
is the unique nonnegative root in $z$ of
$$
z^2+(x+y)z-(xy+2x+2y+2)=0.
$$

Key facts:
- $\varphi(x,y)=\varphi(y,x)$ (symmetric — matches the expected symmetry of gluing two blocks together in either order).
- Derivation idea: link the two blocks' $(A,C)$ pairs through the single gradient step at index $\ell$ (using $x_{\ell+1}=x_\ell-\alpha_\ell g_\ell$), which forces the compatibility quadratic above.
- Self-gluing with $x=y=A(\overline{\bm s}_{i-1})$ gives the connector stepsize for Definition 5's recursive-doubling construction $\overline{\bm s}_i=\mathsf{concat}(\overline{\bm s}_{i-1},\overline{\bm s}_{i-1})$.

**Why:** This is the general two-block gluing formula; the doubling construction (Definition 5) is just the symmetric special case, so this result is likely reused whenever future subtasks build longer primitive schedules from shorter ones.
**How to apply:** If a later subtask asks to combine/extend primitive schedules or construct specific schedule families, check whether it reduces to an application of this formula before re-deriving.
