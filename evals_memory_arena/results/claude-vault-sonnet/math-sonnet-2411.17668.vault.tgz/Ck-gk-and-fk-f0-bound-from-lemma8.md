---
id: 01a050c8-4836-7ce7-9b1c-8d2a2b861d9d
name: Ck-gk-and-fk-f0-bound-from-lemma8
description: Upper bounds on C_k||g_k||^2 and f_k-f_0 for primitive schedule alpha_{1:k-1} with x_1 = x_0 - alpha_0 g_0, derived from Lemma 8
metadata:
  type: project
---

For a primitive stepsize schedule $\bm s=\bm\alpha_{1:k-1}$ with $\bm x_1=\bm x_0-\alpha_0\bm g_0$, substituting into Lemma 8 (referenced in the paper, not yet itself transcribed into this vault) and dropping other nonnegative left-hand terms gives:

$$C_k\|\bm g_k\|^2 \le \frac{\alpha_0^2}{2}\|\bm g_0\|^2+\sum_{i=1}^{k-1}\alpha_i\langle\bm g_i,\bm g_0\rangle-\frac{A_k}{2}\|\bm g_0\|^2$$

$$f_k-f_0 \le \frac{\alpha_0^2}{2A_k}\|\bm g_0\|^2+\frac1{A_k}\sum_{i=1}^{k-1}\alpha_i\langle\bm g_i,\bm g_0\rangle-\frac12\|\bm g_0\|^2$$

**Why:** The $f_k-f_0$ bound only needs $\|\bm x_k-\bm x_0\|^2\ge0$ and $C_k\|\bm g_k\|^2\ge0$ (no sign assumption on $f_k-f_0$ needed). The $C_k\|\bm g_k\|^2$ bound additionally requires $A_k(f_k-f_0)\ge0$ — this step should be re-checked against the paper's actual definition of "primitive" (see [[definitions]]), since that definition wasn't fully restated in this vault and the sign of $f_k-f_0$ isn't otherwise guaranteed.

**How to apply:** Reuse these two bounds directly if a later subtask needs $C_k\|\bm g_k\|^2$ or $f_k-f_0$ under the same setup ($\bm x_1=\bm x_0-\alpha_0\bm g_0$, primitive $\bm\alpha_{1:k-1}$). If "Lemma 8" itself is needed verbatim, it is not yet captured in this vault — ask the user to paste it before relying on it further.
