---
id: 01a050d3-0a05-78c4-adf9-9901d0ea4ae9
name: anytime-descent-f-ell-f0-bound
description: For silver schedule with boosted alpha_0 >= (sqrt2-1)A_k+sqrt2, f_ell - f_0 <= 0 for all intermediate 1<=ell<=k-1 (anytime descent, not just at k)
metadata:
  type: project
---

**Setup:** $k=2^i$, $\overline{\bm s}_i=[\alpha_1,\dots,\alpha_{k-1}]^\top$ the $i$-th order silver stepsize schedule, $\alpha_0=\alpha$, $\bm x_1=\bm x_0-\alpha_0\bm g_0$.

**Result:** If $\alpha \ge (\sqrt2-1)A_k+\sqrt2$, then for every $\ell$ with $1\le \ell\le k-1$:
$$f_\ell - f_0 \le 0$$

So boosting the first stepsize enough (relative to $A_k$, the total schedule length) guarantees the objective never exceeds $f_0$ at *any* intermediate iterate, not just at the final iterate $k$. This is an "anytime descent" strengthening of the endpoint bound in [[Ck-gk-and-fk-f0-bound-from-lemma8]].

**Why:** Derived via the paper's "Lemma 8" (same lemma used for the $f_k-f_0$/$C_k\|g_k\|^2$ bounds) — still not transcribed verbatim into this vault. The threshold $(\sqrt2-1)A_k+\sqrt2$ is the key quantity controlling when descent is guaranteed at every intermediate step of a silver schedule.

**How to apply:** Reuse this threshold and conclusion directly if a later subtask asks about intermediate/anytime function-value guarantees for silver step schedules. If "Lemma 8" itself is needed verbatim, ask the user to paste it before relying on further derivations from it.
