---
id: 01a050b3-b94c-75a2-a24f-16841854b83a
name: definitions
description: Core definitions for this project — primitive stepsize schedules, A_n(r), C_n notation
metadata:
  type: project
---

Working definitions used throughout this project (stepsize schedule research):

- A stepsize schedule $\{\alpha_t\}_{t\ge1}$ (or a finite sub-block $\bm\alpha_{i:j}=[\alpha_i,\dots,\alpha_j]^\top$) is called **primitive** if it satisfies some recursive/optimality property (defined earlier in the paper — not fully restated here, but it's the property preserved/combined by the gluing formula in [[gluing-formula]]).
- For an arbitrary sequence $\bm r$ of length $n$, $A_n(\bm r) \coloneqq \sum_{i=1}^n r_i$ is its total sum — this generalized notation (sum indexed from 1 regardless of the block's original position in a longer schedule) was introduced specifically so blocks could be relabeled and treated as stand-alone schedules.
- $C_n \coloneqq A_n(A_n+1)/2$ pairs with $A_n$ to describe a primitive schedule via an $(A,C)$ pair.
- Definition 5 in the paper builds schedules of length $2^i-1$ via recursive doubling: $\overline{\bm s}_i = \mathsf{concat}(\overline{\bm s}_{i-1}, \overline{\bm s}_{i-1})$, with a single connector stepsize inserted between the two copies. Computing that connector stepsize is a special case of gluing (self-gluing, $x=y=A(\overline{\bm s}_{i-1})$) — see [[gluing-formula]].

**Why:** These are the building blocks reused across subtasks in this session; later subtasks build on primitivity and the $(A,C)$ notation without re-deriving them.
**How to apply:** When a later subtask references "primitive", $A_n(\bm r)$, or $C_n$, use these definitions rather than re-deriving from scratch.
