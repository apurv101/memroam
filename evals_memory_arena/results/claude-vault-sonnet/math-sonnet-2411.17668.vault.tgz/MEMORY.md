# 2411.17668 — memory index

- [A-t-plus-1-lower-bound-and-o-t](A-t-plus-1-lower-bound-and-o-t.md) — Lower bound on A_{t+1}(hat-s) and relation 2^{o_t} <= 2 t^{1/(c+1)} where o_t indexes cumulative block sums sum k_j 2^j
- [anytime-convergence-exponent-theta](anytime-convergence-exponent-theta.md) — The stopping-time-agnostic GD convergence exponent achieved by the silver stepsize schedule is theta = log2(1+sqrt2) ≈ 1.2716
- [anytime-descent-f-ell-f0-bound](anytime-descent-f-ell-f0-bound.md) — For silver schedule with boosted alpha_0 >= (sqrt2-1)A_k+sqrt2, f_ell - f_0 <= 0 for all intermediate 1<=ell<=k-1 (anytime descent, not just at k)
- [Ck-gk-and-fk-f0-bound-from-lemma8](Ck-gk-and-fk-f0-bound-from-lemma8.md) — Upper bounds on C_k||g_k||^2 and f_k-f_0 for primitive schedule alpha_{1:k-1} with x_1 = x_0 - alpha_0 g_0, derived from Lemma 8
- [definitions](definitions.md) — Core definitions for this project — primitive stepsize schedules, A_n(r), C_n notation
- [gluing-formula](gluing-formula.md) — Formula for the connector stepsize alpha_ell that glues two primitive stepsize blocks into one longer primitive schedule
- [hat-s-sequence-primitivity](hat-s-sequence-primitivity.md) — Result — if each s_i is primitive then each hat-s_i is primitive, and the infinite limit hat-s is well-defined and primitive
