---
id: 01a050bb-215f-7680-b235-9f580afe8e43
name: hat-s-sequence-primitivity
description: Result — if each s_i is primitive then each hat-s_i is primitive, and the infinite limit hat-s is well-defined and primitive
metadata:
  type: project
---

**Result:** Given primitive blocks $\bm s_i$ ($i\ge1$, see [[definitions]]), and $\widehat{\bm s}_i$ defined as the sequential gluing of $\bm s_1,\dots,\bm s_i$ (via repeated application of the connector formula in [[gluing-formula]]):

- Each $\widehat{\bm s}_i$ is primitive — proved by induction on $i$, gluing $\widehat{\bm s}_{i-1}$ to $\bm s_i$ with a single connector stepsize at each step.
- The infinite sequence $\widehat{\bm s} = \lim_i \widehat{\bm s}_i$ is well-defined, since the $\widehat{\bm s}_i$ form a prefix-consistent chain (each $\widehat{\bm s}_i$ extends $\widehat{\bm s}_{i-1}$ by appending $\bm s_i$ plus one connector stepsize), and $\widehat{\bm s}$ is itself primitive.

**Caveat:** This answer assumed $\widehat{\bm s}_i$ = sequential gluing of $\bm s_1,\dots,\bm s_i$, since the exact paper definition of $\widehat{\bm s}_i$ wasn't in scope during this session. **Verify this assumption against the paper's actual Definition of $\widehat{\bm s}_i$ before reusing this result** — if the construction differs (e.g., some other recursive scheme distinct from Definition 5's doubling for $\overline{\bm s}_i$), the induction argument may need to be redone.

**Why:** Extends the gluing-formula machinery to an infinite chain of primitive blocks; likely a stepping stone toward later results about infinite primitive schedules.
**How to apply:** If a later subtask references $\widehat{\bm s}$ or asks about limits/infinite concatenations of primitive schedules, start here, but first confirm the definition of $\widehat{\bm s}_i$ matches the assumption above.
