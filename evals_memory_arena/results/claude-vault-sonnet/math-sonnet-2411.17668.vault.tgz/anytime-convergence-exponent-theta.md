---
id: 01a050d9-663f-701f-b60a-79315a561e2c
name: anytime-convergence-exponent-theta
description: The stopping-time-agnostic GD convergence exponent achieved by the silver stepsize schedule is theta = log2(1+sqrt2) ≈ 1.2716
metadata:
  type: project
---

**Result:** There exists a stepsize schedule $\{\alpha_t\}_{t=1}^\infty$ (the silver stepsize schedule, built without knowing the stopping time in advance) such that for *any* stopping time $T\ge1$:
$$f(\bm x_T) - f^\star \le O\!\left(\frac{\|\bm x_1-\bm x^\star\|^2}{T^\vartheta}\right), \qquad \vartheta = \log_2(1+\sqrt2) \approx 1.2716.$$

This is the anytime/universal analogue of the classical accelerated rate exponent 2 (which requires knowing $T$ in advance to tune a fixed-horizon schedule); $\log_2(1+\sqrt2)$ is strictly between the vanilla GD exponent 1 and the accelerated exponent 2, and is the silver ratio's binary log.

**Why:** This is the headline convergence-rate exponent for the silver stepsize schedule construction ([[hat-s-sequence-primitivity]], [[anytime-descent-f-ell-f0-bound]], [[Ck-gk-and-fk-f0-bound-from-lemma8]]) — it's the payoff quantity all the primitivity/gluing/anytime-descent machinery in this vault is built to prove.

**How to apply:** If a later subtask asks "what rate/exponent does the silver schedule achieve" or asks to verify/derive $\vartheta$, this is the answer — no need to re-derive from the recursive doubling construction.
